const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const SULTAN_UID = "sultan_123";
const OTHER_UID = "intruder_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read memories", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(SULTAN_UID).collection("memories").get());
});

test("Authenticated user: cannot read another user's memory", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("users").doc(SULTAN_UID).collection("memories").doc("mem1").set({
      memoryId: "mem1",
      userId: SULTAN_UID,
      content: "Sultan Mirza prefers Hindi and direct answers",
      category: "preference",
      isApproved: true
    });
  });

  const otherDb = testEnv.authenticatedContext(OTHER_UID).firestore();
  await assertFails(otherDb.collection("users").doc(SULTAN_UID).collection("memories").doc("mem1").get());
});

test("Authenticated user: can read and write own memories", async () => {
  const sultanDb = testEnv.authenticatedContext(SULTAN_UID).firestore();
  await assertSucceeds(sultanDb.collection("users").doc(SULTAN_UID).collection("memories").doc("mem1").set({
    memoryId: "mem1",
    userId: SULTAN_UID,
    content: "Muskan is Sultan's personal assistant",
    category: "core_fact",
    isApproved: true
  }));

  const doc = await sultanDb.collection("users").doc(SULTAN_UID).collection("memories").doc("mem1").get();
  assertSucceeds(Promise.resolve(doc));
});

test("Authenticated user: cannot spoof userId in memories", async () => {
  const sultanDb = testEnv.authenticatedContext(SULTAN_UID).firestore();
  await assertFails(sultanDb.collection("users").doc(SULTAN_UID).collection("memories").doc("mem2").set({
    memoryId: "mem2",
    userId: OTHER_UID,
    content: "Spoofed user id",
    category: "core_fact",
    isApproved: true
  }));
});
