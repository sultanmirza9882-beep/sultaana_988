# Muskan chat-to-source workflow update — 2026-10-30

- Pending source drafts now refresh automatically when a new conversation turn arrives, so Muskan-generated drafts appear without requiring the user to leave the screen or press Refresh.
- Expanded the prompt router with common English, Hindi, and Hinglish requests for modifying Muskan/the current project. Existing review-first behavior remains: generated changes stay drafts until explicit approval.
- This update does not build or modify the installed APK. Android compilation and device testing have not been run.
