# Muskan UI — "Ember" layout (2026-11-03)

## What changed
- Brand: every user-facing and code-level "Jarvis" / "Stonic" label was removed; only **Muskan** remains.
  (`JarvisChatScreen` -> `MuskanChatScreen`, `JarvisTaskManager` -> `MuskanTaskManager`, `MuskanTab.JARVIS` -> `MuskanTab.CHAT`,
  the old `JarvisExactHomeScreen` and the unused `Stonic*HudStage` files were deleted.)
- New home layout (`MuskanHomeScreen`): a big animated robot face (`MuskanBotFace`) in the centre, status pill,
  live task card, reply bubble, bento tile grid (Bolo / Chat / Upload + Drive / Camera / Voice) and a rounded command pill.
- New chrome (`MuskanChrome.kt`): slim header with round menu button + capsule (mic / key / settings), and a floating
  dock where the selected tab expands into a coral pill and the centre bot orb opens Chat.
- New "Ember" palette (`Mk*` colours in `Color.kt`): plum ink, cream, coral, amber, mint, violet — no navy/cyan HUD.
- Agent cursor: the arrow was replaced by a little bot (head, antenna, eyes, smile) on a pointer. The tip of the pointer is the exact tap point.

## Not verified
Android build, unit tests and on-device rendering were not run in this environment. Please build once in Android Studio.
