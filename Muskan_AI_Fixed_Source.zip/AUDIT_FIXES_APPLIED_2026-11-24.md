# Muskan AI — Deep Audit Fixes Applied (2026-11-24)

इस अपडेटेड Source Code ZIP में `Muskan.apk` की Deep Audit में मिली मुख्य कमियों को सीधे कोड में ठीक कर दिया गया है (सभी मौजूदा Unit Tests और Google AI Studio compatibility को सुरक्षित रखते हुए):

## 1. लागू किए गए कोड और कॉन्फ़िगरेशन फिक्स

| # | फाइल | क्या ठीक किया गया |
|---|------|-------------------|
| 1 | `app/build.gradle.kts` | `ndk { abiFilters += listOf("arm64-v8a") }` को हमेशा के लिए लागू किया गया ताकि बिना NDK वाले बिल्ड में भी बेकार `x86` / `x86_64` / `armeabi-v7a` (~25 MB) पैक न हों। |
| 2 | `app/src/main/AndroidManifest.xml` | `RECEIVE_BOOT_COMPLETED`, `FOREGROUND_SERVICE_SPECIAL_USE`, `READ_CALL_LOG` permissions जोड़ीं; `MuskanBootReceiver` और `MuskanNotificationListenerService` रजिस्टर किए; `FloatingBubbleService` में `foregroundServiceType="specialUse"` + `<property>` जोड़ा। |
| 3 | `app/src/main/java/com/example/service/MuskanBootReceiver.kt` | नया Receiver जोड़ा — फ़ोन रीस्टार्ट या ऐप अपडेट के बाद `MuskanVoiceService` को सुरक्षित रूप से ऑटो-स्टार्ट करने के लिए। |
| 4 | `app/src/main/java/com/example/service/MuskanNotificationListenerService.kt` | नई Notification Listener सर्विस जोड़ी — यूज़र की अनुमति के बाद आने वाले WhatsApp/SMS/App नोटिफिकेशन पढ़ने के लिए। |
| 5 | `app/src/main/java/com/example/service/FloatingBubbleService.kt` | Xiaomi HyperOS / Android 14+ पर बैकग्राउंड में बंद होने से बचाने के लिए `FOREGROUND_SERVICE_TYPE_SPECIAL_USE` सपोर्ट और सुरक्षित नोटिफिकेशन चैनल जोड़ा। |
| 6 | `app/src/main/java/com/example/data/gemini/GeminiLiveWebSocketClient.kt` | Gemini API Key को WebSocket URL (`?key=`) से हटाकर सुरक्षित HTTP Header (`x-goog-api-key`) में शिफ्ट किया। |
| 7 | `app/src/main/java/com/example/engine/network/WebRtcSignalingManager.kt` | Hardcoded `muskUfrag` / `muskanWebRtcSecureIcePassword2026` / `AA:BB:CC...` को हटाकर हर सेशन के लिए `SecureRandom` आधारित यूनिक ICE credentials और fingerprint जनरेट किया, तथा `isNativePeerConnectionBound` स्टेटस फ्लैग जोड़ा। |
| 8 | `app/src/main/java/com/example/engine/backup/GoogleDriveBackupEngine.kt` | Hardcoded ईमेल को डायनामिक (Firebase Auth या यूज़र-कॉन्फ़िगर्ड अकाउंट) बनाया और असली Google Drive REST API v3 multipart upload (`uploadBackupToDriveApi`) जोड़ा (SAF फाइल पिकर के साथ)। |

## 2. Offline Qwen3 Brain (`libmuskan_llama_jni.so`) वाला नया APK कैसे बनाएं?

आपका `llama_jni.cpp`, `CMakeLists.txt`, और `.github/workflows/build-apk.yml` पहले से तैयार हैं। Google AI Studio में NDK/CMake नहीं होता, इसलिए नया APK **GitHub Actions** से बनाएं:

1. इस ZIP को निकालकर अपने GitHub Repository के `main` ब्रांच में अपलोड/पुश करें।
2. GitHub पर **Actions → Build Debug APK → Run workflow** चलाएं।
3. बिल्ड पूरा होने पर **Releases** से `app-debug.apk` डाउनलोड करें — इसमें `lib/arm64-v8a/libmuskan_llama_jni.so` पैक होगा और APK का साइज भी काफी कम होगा।

## 3. जो काम आपको अपने अकाउंट में 1 बार करने होंगे (External Setup)
- **Gmail / Google Drive OAuth2 Client ID:** Google Cloud Console में अपने प्रोजेक्ट के लिए Android OAuth Client ID बनाएं।
- **Instagram / Facebook Graph API Token:** Meta Developer Console में अपने Business/Creator अकाउंट से App और Token लिंक करें।
- **Release Signing Keystore:** Play Store या Production Release के लिए GitHub Secrets में `KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_PASSWORD` सेट करें।
