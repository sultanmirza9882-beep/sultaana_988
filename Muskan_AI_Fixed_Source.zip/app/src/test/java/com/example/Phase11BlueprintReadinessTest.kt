package com.example

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ApplicationProvider
import com.example.engine.backup.GoogleDriveBackupEngine
import com.example.engine.email.EmailEngine
import com.example.engine.social.SocialMediaEngine
import com.example.service.MuskanCallScreeningService
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

@RunWith(RobolectricTestRunner::class)
class Phase11BlueprintReadinessTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        EmailEngine.setOAuthAccessToken(context, null)
        SocialMediaEngine.setMetaOAuthToken(context, null)
    }

    @Test
    fun emailEngineStoresAndClearsEncryptedOAuthToken() {
        assertNull(EmailEngine.getOAuthAccessToken(context))

        EmailEngine.setOAuthAccessToken(context, "  ya29.test_gmail_token_12345  ")
        assertEquals("ya29.test_gmail_token_12345", EmailEngine.getOAuthAccessToken(context))

        EmailEngine.setOAuthAccessToken(context, null)
        assertNull(EmailEngine.getOAuthAccessToken(context))
    }

    @Test
    fun socialMediaEngineStoresAndClearsEncryptedMetaOAuthToken() {
        assertNull(SocialMediaEngine.getMetaOAuthToken(context))

        SocialMediaEngine.setMetaOAuthToken(context, "  EAAG_test_meta_token_67890  ")
        assertEquals("EAAG_test_meta_token_67890", SocialMediaEngine.getMetaOAuthToken(context))

        SocialMediaEngine.setMetaOAuthToken(context, "")
        assertNull(SocialMediaEngine.getMetaOAuthToken(context))
    }

    @Test
    fun callScreeningRoleHelperWorksOnApi34() {
        assertTrue(MuskanCallScreeningService.isCallScreeningRoleSupported())
        // Default test sandbox does not hold ROLE_CALL_SCREENING
        assertFalse(MuskanCallScreeningService.isCallScreeningRoleHeld(context))
    }

    @Test
    fun googleDriveBackupSafIntentsAndStreamRoundTripWork() = runBlocking {
        val saveIntent = GoogleDriveBackupEngine.createDriveSaveIntent()
        assertEquals(Intent.ACTION_CREATE_DOCUMENT, saveIntent.action)
        assertEquals("application/json", saveIntent.type)
        assertNotNull(saveIntent.getStringExtra(Intent.EXTRA_TITLE))

        val restoreIntent = GoogleDriveBackupEngine.createDriveRestoreIntent()
        assertEquals(Intent.ACTION_OPEN_DOCUMENT, restoreIntent.action)

        val outStream = ByteArrayOutputStream()
        val wrote = GoogleDriveBackupEngine.writeBackupToStream(context, outStream)
        assertTrue(wrote)

        val jsonText = outStream.toString(Charsets.UTF_8.name())
        assertTrue(jsonText.contains("Muskan Autonomous AI Assistant"))

        val restored = GoogleDriveBackupEngine.restoreFromStream(
            context,
            ByteArrayInputStream(jsonText.toByteArray(Charsets.UTF_8))
        )
        assertTrue(restored)
    }
}
