package com.example

import com.example.engine.learning.SelfTrainingMemoryEngine
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SelfTrainingMemoryEngineTest {

    @Test
    fun testRecordAndRetrieveLearnedProcedure() = runBlocking {
        val objective = "Salon Appointment Booking System"
        val schemas = listOf("BookingEntity(id, client, time)", "ServiceEntity(id, name, price)")
        val plan = listOf("Ingest schemas", "Synthesize repository", "Verify syntax")

        // Record procedure
        val procedure = SelfTrainingMemoryEngine.recordLearnedProcedure(
            context = null,
            objective = objective,
            schemas = schemas,
            executionPlan = plan,
            componentStructure = "DashboardContainer(id=123)"
        )

        assertNotNull(procedure)
        assertEquals(objective, procedure.objective)
        assertTrue(procedure.verifiedBlueprint.contains("Salon Appointment Booking System"))
        assertTrue(procedure.verifiedBlueprint.contains("BookingEntity"))
        assertTrue(procedure.domainKeywords.contains("salon") || procedure.domainKeywords.contains("booking"))

        // Retrieve procedure with similar prompt
        val matched = SelfTrainingMemoryEngine.findMatchingProcedure("Need a booking system for salon")
        assertNotNull(matched)
        assertEquals(objective, matched?.objective)

        // Test Voice Summary
        val voiceSummary = SelfTrainingMemoryEngine.getLearnedSummaryForVoice(context = null)
        assertTrue(voiceSummary.contains("Sultan"))
        assertTrue(voiceSummary.contains("procedure") || voiceSummary.contains("seekha"))
    }
}
