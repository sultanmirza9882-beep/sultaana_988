package com.example.automation

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AutomationActionEngineTest {

    private val context: Context = ApplicationProvider.getApplicationContext()

    @Test
    fun testGlobalNavigationWithoutServiceRequestsAccessibility() {
        // When service is not running, calling global actions should return AccessibilityRequired
        val homeResult = AutomationActionEngine.processVoiceCommand(context, "go home")
        assertTrue(homeResult is AutomationResult.AccessibilityRequired)

        val backResult = AutomationActionEngine.processVoiceCommand(context, "peeche jao")
        assertTrue(backResult is AutomationResult.AccessibilityRequired)

        val recentsResult = AutomationActionEngine.processVoiceCommand(context, "recent apps dikhao")
        assertTrue(recentsResult is AutomationResult.AccessibilityRequired)

        val notifResult = AutomationActionEngine.processVoiceCommand(context, "open notifications")
        assertTrue(notifResult is AutomationResult.AccessibilityRequired)

        val lockResult = AutomationActionEngine.processVoiceCommand(context, "lock screen")
        assertTrue(lockResult is AutomationResult.AccessibilityRequired)
    }

    @Test
    fun testScrollCommandsDetection() {
        val scrollDownResult = AutomationActionEngine.processVoiceCommand(context, "scroll down")
        assertTrue(scrollDownResult is AutomationResult.AccessibilityRequired)

        val scrollUpResult = AutomationActionEngine.processVoiceCommand(context, "upar scroll karo")
        assertTrue(scrollUpResult is AutomationResult.AccessibilityRequired)
    }

    @Test
    fun testTypingCommandsDetection() {
        val typingResult = AutomationActionEngine.processVoiceCommand(context, "type Hello World")
        assertTrue(typingResult is AutomationResult.AccessibilityRequired)

        val hindiTypingResult = AutomationActionEngine.processVoiceCommand(context, "kahan ho likh do")
        assertTrue(hindiTypingResult is AutomationResult.AccessibilityRequired)
    }

    @Test
    fun testClickCommandsDetection() {
        val clickResult = AutomationActionEngine.processVoiceCommand(context, "click on Submit")
        assertTrue(clickResult is AutomationResult.AccessibilityRequired)

        val hindiClickResult = AutomationActionEngine.processVoiceCommand(context, "Send par click karo")
        assertTrue(hindiClickResult is AutomationResult.AccessibilityRequired)
    }

    @Test
    fun testAppLaunchCommands() {
        // App launching uses PackageManager which works without AccessibilityService
        val appResult = AutomationActionEngine.processVoiceCommand(context, "open Settings")
        assertTrue(appResult is AutomationResult.Handled)
        val handled = appResult as AutomationResult.Handled
        assertTrue(
            handled.spokenFeedback.contains("ओपन कर दिया") ||
                handled.spokenFeedback.contains("नहीं मिला") ||
                handled.spokenFeedback.contains("khol rahi hoon") ||
                handled.spokenFeedback.contains("nahi mila")
        )
    }

    @Test
    fun testNonAutomationCommandPassesThrough() {
        val weatherResult = AutomationActionEngine.processVoiceCommand(context, "Aaj ka mausam kaisa hai?")
        assertEquals(AutomationResult.NotAnAutomationCommand, weatherResult)

        val generalQuery = AutomationActionEngine.processVoiceCommand(context, "Who is the president of India?")
        assertEquals(AutomationResult.NotAnAutomationCommand, generalQuery)
    }
}
