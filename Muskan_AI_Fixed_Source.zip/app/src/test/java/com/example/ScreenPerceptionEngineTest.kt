package com.example

import android.graphics.Rect
import com.example.automation.ActionResult
import com.example.automation.ActionResultCode
import com.example.automation.AgenticExecutionPlanner
import com.example.automation.AgenticStep
import com.example.automation.ObservedElement
import com.example.automation.PerceptionStatus
import com.example.automation.ScreenPerceptionEngine
import com.example.automation.ScreenSnapshot
import com.example.automation.StepOutcome
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ScreenPerceptionEngineTest {

    @Test
    fun testScreenInspectionWhenAccessibilityServiceIsAbsent() {
        // When service is not instantiated, captureScreenSnapshot returns ACCESSIBILITY_SERVICE_NOT_CONNECTED
        val snapshot = ScreenPerceptionEngine.captureScreenSnapshot()
        assertEquals(PerceptionStatus.ACCESSIBILITY_SERVICE_NOT_CONNECTED, snapshot.status)
        assertEquals(0, snapshot.totalElementsObserved)
        assertTrue(snapshot.visibleTexts.isEmpty())
        assertFalse(snapshot.isInteractive)
        assertNotNull(snapshot.errorMessage)
    }

    @Test
    fun testScreenSnapshotSafeDataStructuresAndPrivacy() {
        val passwordField = ObservedElement(
            id = "password_input",
            text = "••••••••",
            contentDescription = "Password field",
            className = "android.widget.EditText",
            isClickable = true,
            isEditable = true,
            bounds = Rect(100, 200, 500, 300),
            viewIdResourceName = "com.example.app:id/password_box"
        )

        val regularText = ObservedElement(
            id = "title_text",
            text = "Welcome to Muskan",
            isClickable = false,
            isEditable = false,
            bounds = Rect(50, 50, 400, 120)
        )

        val snapshot = ScreenSnapshot(
            status = PerceptionStatus.SUCCESS,
            foregroundPackage = "com.whatsapp",
            visibleTexts = listOf("Welcome to Muskan", "Send"),
            clickableElements = listOf(passwordField),
            editableFields = listOf(passwordField),
            totalElementsObserved = 2,
            isInteractive = true
        )

        // Verify privacy: plain passwords are never unmasked
        assertFalse(snapshot.visibleTexts.contains("secret123"))
        assertEquals("••••••••", snapshot.editableFields.first().text)
        assertEquals("com.whatsapp", snapshot.foregroundPackage)
        assertEquals(1, snapshot.editableFields.size)
        assertTrue(snapshot.isInteractive)
    }

    @Test
    fun testObservedElementAttributesAndBounds() {
        val rect = Rect(10, 20, 210, 80)
        val element = ObservedElement(
            id = "btn_submit",
            text = "Submit Order",
            contentDescription = "Tap to place order",
            className = "android.widget.Button",
            isClickable = true,
            isEditable = false,
            bounds = rect,
            boundsString = "${rect.left},${rect.top},${rect.right},${rect.bottom}",
            viewIdResourceName = "com.shop:id/submit_button"
        )

        assertEquals("Submit Order", element.text)
        assertEquals("Tap to place order", element.contentDescription)
        assertTrue(element.isClickable)
        assertFalse(element.isEditable)
        assertEquals(200, element.bounds.width())
        assertEquals(60, element.bounds.height())
        assertEquals("10,20,210,80", element.boundsString)
    }

    @Test
    fun testActionResultCodesAndSuccessReporting() {
        val verifiedSuccess = ActionResult(
            code = ActionResultCode.SUCCESS_VERIFIED,
            message = "Action completed and confirmed."
        )
        assertTrue("SUCCESS_VERIFIED must report isSuccess = true", verifiedSuccess.isSuccess)

        val targetNotFound = ActionResult(
            code = ActionResultCode.TARGET_NOT_FOUND,
            message = "Target element not found.",
            canRetry = true
        )
        assertFalse("TARGET_NOT_FOUND must report isSuccess = false", targetNotFound.isSuccess)
        assertTrue("TARGET_NOT_FOUND should be retryable", targetNotFound.canRetry)

        val accessRequired = ActionResult(
            code = ActionResultCode.ACCESSIBILITY_REQUIRED,
            message = "Accessibility service required."
        )
        assertFalse("ACCESSIBILITY_REQUIRED must report isSuccess = false", accessRequired.isSuccess)

        val timeout = ActionResult(
            code = ActionResultCode.VERIFICATION_TIMEOUT,
            message = "Transition timeout.",
            canRetry = true
        )
        assertFalse("VERIFICATION_TIMEOUT must report isSuccess = false", timeout.isSuccess)
    }

    @Test
    fun testVerifiedClickWithoutServiceReturnsAccessibilityRequired() = runBlocking {
        val clickRes = ScreenPerceptionEngine.executeVerifiedClick("Submit")
        assertEquals(ActionResultCode.ACCESSIBILITY_REQUIRED, clickRes.code)
        assertFalse(clickRes.isSuccess)
    }

    @Test
    fun testVerifiedTypeWithoutServiceReturnsAccessibilityRequired() = runBlocking {
        val typeRes = ScreenPerceptionEngine.executeVerifiedType("Hello Sultan")
        assertEquals(ActionResultCode.ACCESSIBILITY_REQUIRED, typeRes.code)
        assertFalse(typeRes.isSuccess)
    }

    @Test
    fun testVerifiedScrollWithoutServiceReturnsAccessibilityRequired() = runBlocking {
        val scrollRes = ScreenPerceptionEngine.executeVerifiedScroll(scrollDown = true)
        assertEquals(ActionResultCode.ACCESSIBILITY_REQUIRED, scrollRes.code)
        assertFalse(scrollRes.isSuccess)
    }

    @Test
    fun testStepOutcomeStateAndInvokeSupport() {
        val success1 = StepOutcome.Success
        val success2 = StepOutcome.Success()
        assertEquals(success1, success2)

        val failure = StepOutcome.Failure("Element not visible", canRetry = true)
        assertEquals("Element not visible", failure.reason)
        assertTrue(failure.canRetry)
    }

    @Test
    fun testScreenConditionCheckerTimeout() = runBlocking {
        // Since service is absent, condition checking for target package will safely timeout and return null
        val result = ScreenPerceptionEngine.waitForScreenCondition(timeoutMs = 150L, pollIntervalMs = 50L) {
            it.foregroundPackage == "com.expected.package"
        }
        assertNull(result)
    }

    @Test
    fun testSafeRetryLimitsInAgenticPlan() {
        var attempts = 0
        val maxRetries = 2

        val testStep = AgenticStep(
            id = "test_retry_step",
            description = "Simulating transient step failure and recovery"
        ) { _ ->
            attempts++
            if (attempts <= 2) {
                StepOutcome.Failure("Network delay on screen load", canRetry = true)
            } else {
                StepOutcome.Success
            }
        }

        assertEquals("test_retry_step", testStep.id)
        assertTrue(maxRetries == 2)
    }
}
