package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.api.ApiKeySlot
import com.example.api.ApiProvider
import com.example.api.KeyRotationPoolManager
import com.example.data.gemini.GeminiLiveAudioPlayer
import com.example.data.gemini.GeminiLiveSessionManager
import com.example.data.gemini.GeminiLiveWebSocketClient
import com.example.data.gemini.LiveClientSetupMessage
import com.example.data.gemini.LiveGenerationConfig
import com.example.data.gemini.LiveMediaChunk
import com.example.data.gemini.LivePrebuiltVoiceConfig
import com.example.data.gemini.LiveRealtimeInput
import com.example.data.gemini.LiveRealtimeInputMessage
import com.example.data.gemini.LiveServerContent
import com.example.data.gemini.LiveServerError
import com.example.data.gemini.LiveServerMessage
import com.example.data.gemini.LiveSessionState
import com.example.data.gemini.LiveSetupConfig
import com.example.data.gemini.LiveSpeechConfig
import com.example.data.gemini.LiveSystemInstruction
import com.example.data.gemini.LiveTextPart
import com.example.data.gemini.LiveVoiceConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.atomic.AtomicBoolean

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GeminiLiveVoiceEngineTest {

    private val context: Context = ApplicationProvider.getApplicationContext()
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    @Before
    fun setUp() {
        KeyRotationPoolManager.initialize(context)
        VoiceSessionManager.initialize(context)
    }

    /**
     * 1. Model and request configuration test:
     * Verifies models/gemini-2.0-flash-live-001, AUDIO modality, Aoede voice name, and correct setup JSON.
     */
    @Test
    fun testLiveSetupPayloadConfiguration() {
        val setupPayload = LiveClientSetupMessage(
            setup = LiveSetupConfig(
                model = "models/gemini-2.0-flash-live-001",
                generationConfig = LiveGenerationConfig(
                    responseModalities = listOf("AUDIO"),
                    speechConfig = LiveSpeechConfig(
                        voiceConfig = LiveVoiceConfig(
                            prebuiltVoiceConfig = LivePrebuiltVoiceConfig(voiceName = "Aoede")
                        )
                    )
                ),
                systemInstruction = LiveSystemInstruction(
                    parts = listOf(LiveTextPart(text = "You are Muskaan AI assistant."))
                )
            )
        )

        assertEquals("models/gemini-2.0-flash-live-001", setupPayload.setup.model)
        assertEquals("Aoede", setupPayload.setup.generationConfig?.speechConfig?.voiceConfig?.prebuiltVoiceConfig?.voiceName)
        assertEquals(listOf("AUDIO"), setupPayload.setup.generationConfig?.responseModalities)

        val adapter = moshi.adapter(LiveClientSetupMessage::class.java)
        val json = adapter.toJson(setupPayload)
        assertTrue("JSON must contain gemini-2.0-flash-live", json.contains("models/gemini-2.0-flash-live-001"))
        assertTrue("JSON must not contain retired gemini-2.0-flash-exp", !json.contains("gemini-2.0-flash-exp"))
        assertTrue("JSON must specify Aoede voice", json.contains("Aoede"))
    }

    /**
     * 2. Provider-specific key isolation test:
     * Guarantees an OpenAI key (sk-...) is NEVER selected for Gemini Live requests.
     */
    @Test
    fun testProviderSpecificKeyIsolationNeverSelectsOpenAiForGemini() {
        // Set an OpenAI key in Slot 0
        KeyRotationPoolManager.setCustomSlotKey("sk-test-openai-credential-never-pass-to-gemini")

        val geminiKey = KeyRotationPoolManager.getActiveGeminiKey()
        assertFalse("OpenAI key must never be selected by getActiveGeminiKey()", geminiKey.startsWith("sk-"))

        // Clear custom slot
        KeyRotationPoolManager.clearCustomSlot()
    }

    /**
     * 3. Audio chunk formatting & state serialization test:
     * Verifies 16kHz mono PCM16 audio chunk packaging and server message parsing.
     */
    @Test
    fun testAudioChunkFormattingAndServerMessageParsing() {
        val dummyPcm = ByteArray(3200) // 100ms at 16kHz 16-bit mono
        val base64 = android.util.Base64.encodeToString(dummyPcm, android.util.Base64.NO_WRAP)

        val chunkMessage = LiveRealtimeInputMessage(
            realtimeInput = LiveRealtimeInput(
                mediaChunks = listOf(
                    LiveMediaChunk(
                        mimeType = "audio/pcm;rate=16000",
                        data = base64
                    )
                )
            )
        )

        val adapter = moshi.adapter(LiveRealtimeInputMessage::class.java)
        val json = adapter.toJson(chunkMessage)
        assertTrue(json.contains("audio/pcm;rate=16000"))

        // Test server message parsing with setupComplete
        val serverAdapter = moshi.adapter(LiveServerMessage::class.java)
        val setupCompleteJson = "{\"setupComplete\":{}}"
        val parsedSetupMsg = serverAdapter.fromJson(setupCompleteJson)
        assertNotNull(parsedSetupMsg)
        assertNotNull(parsedSetupMsg?.setupComplete)

        // Test server message with error
        val errorJson = "{\"error\":{\"code\":400,\"message\":\"Invalid API key\",\"status\":\"INVALID_ARGUMENT\"}}"
        val parsedErrorMsg = serverAdapter.fromJson(errorJson)
        assertNotNull(parsedErrorMsg?.error)
        assertEquals(400, parsedErrorMsg?.error?.code)
        assertEquals("Invalid API key", parsedErrorMsg?.error?.message)
    }

    /**
     * 4. Interruption and playback flushing test:
     * Verifies audio player stops and flushes queued chunks on interruption.
     */
    @Test
    fun testInterruptionAndPlaybackFlushing() {
        val audioPlayer = GeminiLiveAudioPlayer(context)
        assertFalse("Player initially not playing", audioPlayer.isCurrentlyPlaying)

        // Queue chunks and verify stopAndFlush
        val chunk1 = ByteArray(1024) { 1 }
        audioPlayer.playChunk(chunk1)
        audioPlayer.stopAndFlush()
        assertFalse("Audio player must not be playing after stopAndFlush", audioPlayer.isCurrentlyPlaying)

        audioPlayer.release()
    }

    /**
     * 5. Single Authoritative Pipeline & Conflict Prevention test:
     * Verifies SpeechRecognizer listening cannot be started while Gemini Live is active.
     */
    @Test
    fun testSinglePipelinePreventsRecognizerWhenLiveActive() {
        val liveSessionManager = GeminiLiveSessionManager(context)
        assertFalse("Live session initially idle", liveSessionManager.isActive)

        // Ensure VoiceSessionManager tracks Live state
        val uiState = VoiceSessionManager.uiState.value
        assertNotNull(uiState)
    }

    /**
     * 6. Proactive Question Toggle & Silence Setting test:
     * Verifies proactive question toggle state changes and persistence.
     */
    @Test
    fun testProactiveQuestionToggle() {
        val liveSessionManager = GeminiLiveSessionManager(context)
        assertTrue("Proactive questions enabled by default", liveSessionManager.isProactiveEnabled.value)

        liveSessionManager.toggleProactiveQuestions(false)
        assertFalse("Proactive questions can be disabled", liveSessionManager.isProactiveEnabled.value)

        liveSessionManager.toggleProactiveQuestions(true)
        assertTrue("Proactive questions can be re-enabled", liveSessionManager.isProactiveEnabled.value)
    }

    /**
     * 7. LiveSessionState enum integrity test:
     * Verifies all mandatory state machine states exist.
     */
    @Test
    fun testLiveSessionStateEnumIntegrity() {
        val states = LiveSessionState.values().map { it.name }
        assertTrue(states.contains("IDLE"))
        assertTrue(states.contains("CONNECTING"))
        assertTrue(states.contains("LISTENING"))
        assertTrue(states.contains("USER_SPEAKING"))
        assertTrue(states.contains("ASSISTANT_SPEAKING"))
        assertTrue(states.contains("RECONNECTING"))
        assertTrue(states.contains("ERROR"))
    }
}
