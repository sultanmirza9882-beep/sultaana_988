package com.example

import android.content.Context
import android.os.Looper
import androidx.test.core.app.ApplicationProvider
import com.example.engine.EngineExecutionManager
import com.example.engine.EngineRegistry
import com.example.engine.EngineStatus
import com.example.engine.approval.OwnerApprovalGate
import com.example.engine.approval.SensitiveActionType
import com.example.engine.calling.CallFollowUpChannel
import com.example.engine.calling.CallRiskVerdict
import com.example.engine.calling.CallingEngine
import com.example.engine.osint.DigitalIntelligenceEngine
import com.example.engine.osint.RiskLevel
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Phase8CallingAndOsintTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        OwnerApprovalGate.resetForTest()
        CallingEngine.resetForTest(context)
    }

    @After
    fun tearDown() {
        OwnerApprovalGate.resetForTest()
        CallingEngine.resetForTest(context)
    }

    private suspend fun waitForPendingSensitiveAction(
        expectedType: SensitiveActionType,
        timeoutMs: Long = 2000L
    ): String {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            shadowOf(Looper.getMainLooper()).idle()
            val active = OwnerApprovalGate.activeActionPrompt.value
            if (active != null && active.sensitiveActionType == expectedType) {
                return active.id
            }
            delay(15L)
        }
        throw AssertionError("Timed out waiting for pending sensitive action of type $expectedType")
    }

    @Test
    fun callingEngineNormalizesNumbersAndClassifiesSpamAllowlistBlocklist() {
        assertEquals("+919876543210", CallingEngine.normalizePhoneNumber("tel:98765 43210"))
        assertEquals("+919876543210", CallingEngine.normalizePhoneNumber("098765-43210"))
        assertEquals("+911409123456", CallingEngine.normalizePhoneNumber("+91 140-912-3456"))

        // Indian 140-series telemarketing number -> BLOCKED_SPAM
        val telemarketer = CallingEngine.evaluateIncomingCall("+911409123456", "Loan Offer")
        assertEquals(CallRiskVerdict.BLOCKED_SPAM, telemarketer.verdict)
        assertTrue(telemarketer.shouldReject)
        assertTrue(telemarketer.shouldSilence)
        assertTrue(telemarketer.riskScore >= 75)

        // Normal Indian mobile number -> ALLOWED
        val normal = CallingEngine.evaluateIncomingCall("9876543210", "Aman")
        assertEquals(CallRiskVerdict.ALLOWED, normal.verdict)
        assertFalse(normal.shouldReject)
        assertFalse(normal.shouldSilence)

        // Adding to user blocklist -> BLOCKED_USER_LIST
        CallingEngine.addToBlocklist(context, "9876543210")
        val blocked = CallingEngine.evaluateIncomingCall("+91 9876543210")
        assertEquals(CallRiskVerdict.BLOCKED_USER_LIST, blocked.verdict)
        assertTrue(blocked.shouldReject)

        // Moving to allowlist overrides spam patterns -> ALLOWLISTED
        CallingEngine.addToAllowlist(context, "+911409123456")
        val allowlisted = CallingEngine.evaluateIncomingCall("+911409123456")
        assertEquals(CallRiskVerdict.ALLOWLISTED, allowlisted.verdict)
        assertFalse(allowlisted.shouldReject)
        assertEquals(0, allowlisted.riskScore)

        // STIR/SHAKEN failure alone flags as SUSPICIOUS_SPAM (silenced, not hard-rejected)
        val stirFailed = CallingEngine.evaluateIncomingCall("9123456789", stirVerificationFailed = true)
        assertEquals(CallRiskVerdict.SUSPICIOUS_SPAM, stirFailed.verdict)
        assertTrue(stirFailed.shouldSilence)
        assertFalse(stirFailed.shouldReject)

        // Logging screened calls updates summaries and spam reports
        CallingEngine.logScreenedCall(context, "+911409123456", "Loan Offer", telemarketer)
        assertTrue(CallingEngine.generateLastCallSummary().contains("Loan Offer"))
        assertTrue(CallingEngine.generateSpamReport().contains("1 spam/suspicious"))
    }

    @Test
    fun callerFollowUpSmsAndWhatsappAreApprovalGated() = runBlocking {
        // Deny path blocks and cancels cleanly
        val denyDeferred = async {
            CallingEngine.sendApprovedCallerFollowUp(
                context = context,
                phoneNumber = "9876543210",
                message = "Busy right now, will call back shortly.",
                channel = CallFollowUpChannel.SMS
            )
        }
        val denyId = waitForPendingSensitiveAction(SensitiveActionType.SEND_SMS)
        assertFalse("Follow-up SMS must block until owner decision", denyDeferred.isCompleted)
        OwnerApprovalGate.rejectProposal(denyId, "Owner denied follow-up")

        val denyRes = denyDeferred.await()
        assertFalse(denyRes.success)
        assertTrue(denyRes.approvalDenied)

        // Approve path succeeds for WhatsApp follow-up
        val approveDeferred = async {
            CallingEngine.sendApprovedCallerFollowUp(
                context = context,
                phoneNumber = "9876543210",
                message = "Call back in 10 minutes.",
                channel = CallFollowUpChannel.WHATSAPP
            )
        }
        val approveId = waitForPendingSensitiveAction(SensitiveActionType.WHATSAPP_SEND)
        assertFalse(approveDeferred.isCompleted)
        OwnerApprovalGate.approveProposal(approveId)

        val approveRes = approveDeferred.await()
        assertTrue("Approved WhatsApp follow-up should dispatch cleanly", approveRes.success)
        assertFalse(approveRes.approvalDenied)
        assertTrue(CallingEngine.PLATFORM_VOICE_UPLINK_LIMITATION.contains("uplink", ignoreCase = true))
    }

    @Test
    fun phishingAndScamHeuristicsDetectPunycodeLookalikesAndCleanDomains() {
        // Clean legitimate domain
        val clean = DigitalIntelligenceEngine.analyzePhishingAndScam("https://www.google.com/search?q=android")
        assertEquals(RiskLevel.LOW, clean.riskLevel)
        assertTrue("Expected low score for google.com, got ${clean.riskScore}", clean.riskScore < 25)

        // Punycode lookalike + unencrypted HTTP + risky TLD + credential keyword -> CRITICAL
        val punycode = DigitalIntelligenceEngine.analyzePhishingAndScam(
            "http://xn--pypal-4ve.tk/login/verify-account"
        )
        assertTrue("Expected HIGH or CRITICAL for punycode phishing URL, got ${punycode.riskLevel}", punycode.riskLevel >= RiskLevel.HIGH)
        assertTrue(punycode.indicators.any { it.contains("Punycode", ignoreCase = true) })

        // Banking KYC brand impersonation lookalike -> HIGH/CRITICAL
        val kycLookalike = DigitalIntelligenceEngine.analyzePhishingAndScam(
            "https://sbi-kyc-verify.login.security-check.xyz/update"
        )
        assertTrue("Expected HIGH or CRITICAL for SBI KYC lookalike, got ${kycLookalike.riskLevel}", kycLookalike.riskLevel >= RiskLevel.HIGH)
        assertTrue(kycLookalike.indicators.any { it.contains("impersonation", ignoreCase = true) || it.contains("brand", ignoreCase = true) })

        // Raw IP + '@' credential obfuscation
        val obfuscated = DigitalIntelligenceEngine.analyzePhishingAndScam("http://paypal.com@45.33.32.156/otp")
        assertTrue(obfuscated.riskLevel >= RiskLevel.HIGH)
        assertTrue(obfuscated.indicators.any { it.contains("@") })

        // Scam SMS text with OTP & blocked account threat
        val scamText = DigitalIntelligenceEngine.analyzePhishingAndScam(
            "Urgent: Your bank account will be blocked! Share OTP and UPI PIN immediately."
        )
        assertTrue(scamText.riskLevel >= RiskLevel.HIGH)
        assertTrue(scamText.indicators.any { it.contains("share otp", ignoreCase = true) })
    }

    @Test
    fun rdapAndDnsOverHttpsJsonParsersExtractExpectedFields() {
        val rdapJson = """
            {
              "ldhName": "EXAMPLE.COM",
              "handle": "2336799_DOMAIN_COM-VRSN",
              "status": ["client delete prohibited", "client transfer prohibited"],
              "events": [
                { "eventAction": "registration", "eventDate": "1995-08-14T04:00:00Z" },
                { "eventAction": "expiration", "eventDate": "2027-08-13T04:00:00Z" }
              ],
              "nameservers": [
                { "ldhName": "A.IANA-SERVERS.NET" },
                { "ldhName": "B.IANA-SERVERS.NET" }
              ],
              "entities": [
                {
                  "roles": ["registrar"],
                  "vcardArray": [
                    "vcard",
                    [
                      ["version", {}, "text", "4.0"],
                      ["fn", {}, "text", "RESERVED-Internet Assigned Numbers Authority"]
                    ]
                  ]
                }
              ]
            }
        """.trimIndent()

        val rdap = DigitalIntelligenceEngine.parseRdapJson("example.com", rdapJson)
        assertEquals("example.com", rdap.domain)
        assertEquals("2336799_DOMAIN_COM-VRSN", rdap.handle)
        assertEquals("RESERVED-Internet Assigned Numbers Authority", rdap.registrar)
        assertEquals("1995-08-14T04:00:00Z", rdap.registrationDate)
        assertEquals("2027-08-13T04:00:00Z", rdap.expirationDate)
        assertEquals(listOf("a.iana-servers.net", "b.iana-servers.net"), rdap.nameservers)
        assertEquals(2, rdap.statuses.size)

        val dohJson = """
            {
              "Status": 0,
              "Answer": [
                { "name": "example.com.", "type": 16, "TTL": 3600, "data": "\"v=spf1 -all\"" },
                { "name": "example.com.", "type": 16, "TTL": 3600, "data": "\"v=DMARC1; p=reject\"" }
              ]
            }
        """.trimIndent()
        val records = DigitalIntelligenceEngine.parseDnsOverHttpsJson(dohJson)
        assertEquals(listOf("v=spf1 -all", "v=DMARC1; p=reject"), records)

        // Non-zero DNS status (NXDOMAIN=3) returns empty list cleanly
        val nxdomainJson = """{ "Status": 3 }"""
        assertTrue(DigitalIntelligenceEngine.parseDnsOverHttpsJson(nxdomainJson).isEmpty())
    }

    @Test
    fun voiceCommandRouterClassifiesCallingAndOsintCommandsWithoutCollisions() {
        assertTrue(VoiceCommandRouter.isCallingCommand("last call summary batao"))
        assertTrue(VoiceCommandRouter.isCallingCommand("spam calls check karo"))
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.CALLING_COMMAND,
            VoiceCommandRouter.classifyPreLlmRoute("last call summary")
        )
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.CALLING_COMMAND,
            VoiceCommandRouter.classifyPreLlmRoute("spam calls check karo")
        )

        assertTrue(VoiceCommandRouter.isOsintCommand("is link ko check karo https://example.com"))
        assertTrue(VoiceCommandRouter.isOsintCommand("domain research karo example.com"))
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.OSINT_COMMAND,
            VoiceCommandRouter.classifyPreLlmRoute("is link ko check karo http://paypa1.tk")
        )
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.OSINT_COMMAND,
            VoiceCommandRouter.classifyPreLlmRoute("domain research karo google.com")
        )

        // Outbound dialing and normal questions must NOT collide with CALLING_COMMAND / OSINT_COMMAND
        assertFalse(VoiceCommandRouter.isCallingCommand("call 9876543210"))
        assertFalse(VoiceCommandRouter.isOsintCommand("What is the capital of India?"))
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.NONE,
            VoiceCommandRouter.classifyPreLlmRoute("What is the capital of India?")
        )
    }

    @Test
    fun engineRegistryReportsOperationalForOsintAndCallScreeningEngines() = runBlocking {
        assertEquals(128, EngineRegistry.getAllEngines().size)

        val osintProbe = EngineExecutionManager.testEngine(context, 18)
        assertEquals(EngineStatus.OPERATIONAL, osintProbe.status)
        assertTrue(osintProbe.isSuccess)
        assertTrue(osintProbe.verificationNotes.contains("DigitalIntelligenceEngine"))

        val callingProbe = EngineExecutionManager.testEngine(context, 99)
        assertEquals(EngineStatus.OPERATIONAL, callingProbe.status)
        assertTrue(callingProbe.isSuccess)
        assertTrue(callingProbe.verificationNotes.contains("CallingEngine"))
    }
}
