package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.automation.AgenticExecutionPlanner
import com.example.service.AgentTouchVisualizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MuskanActionFirstAgentTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        VoiceSessionManager.initialize(context)
    }

    @Test
    fun testAgentTouchVisualizerInstantiationAndPointerMethods() {
        val visualizer = AgentTouchVisualizer.getInstance(context)
        assertNotNull(visualizer)

        // Verifies no crashes on pointer invocation
        visualizer.showPointer(300f, 600f, isClick = true)
        visualizer.animateSwipe(100f, 800f, 100f, 200f)
        visualizer.hidePointer()
    }

    @Test
    fun testSpeechNormalizerStripsTriggerWordsFromYouTubeQuery() {
        val raw1 = "ओपन जरा Motu Patlu cartoon chalao"
        val clean1 = AgenticExecutionPlanner.sanitizeYouTubeQuery(raw1)
        assertFalse("Must not contain 'ओपन जरा'", clean1.contains("ओपन जरा"))
        assertTrue("Must preserve core subject", clean1.contains("Motu Patlu"))

        val raw2 = "open zara lofi music video play karke rakh do"
        val clean2 = AgenticExecutionPlanner.sanitizeYouTubeQuery(raw2)
        assertFalse("Must not contain 'open zara'", clean2.contains("open zara"))
        assertTrue("Must preserve core subject", clean2.contains("lofi music"))

        val raw3 = "zara Sholay movie video chalao"
        val clean3 = AgenticExecutionPlanner.sanitizeYouTubeQuery(raw3)
        assertFalse("Must not contain 'zara'", clean3.contains("zara"))
    }

    @Test
    fun testUniversalAgentRouting() {
        val a = com.example.automation.UniversalPhoneAgent
        // Sultan's own examples go to the agent first
        assertTrue(a.shouldTakePriority("youtube open karo aur motu patlu ki video chalakar full screen kar do"))
        assertTrue(a.shouldTakePriority("mera ek number likho is number ko contact mein save kar do aur whatsapp par message kar do"))
        assertTrue(a.shouldTakePriority("diljale movie download karke do"))
        assertTrue(a.shouldTakePriority("दिलजले मूवी डाउनलोड करके दो"))
        assertTrue(a.shouldTakePriority("instagram par story laga do mera photo edit karke"))
        // plain chat is never taken over
        assertFalse(a.shouldHandle("kya time hua hai"))
        assertFalse(a.shouldHandle("tum kaise ho"))
        assertTrue(a.shouldHandle("bluetooth on karo"))
    }

    @Test
    fun testYouTubeQueryKeepsFullArtistName() {
        val q = AgenticExecutionPlanner.sanitizeYouTubeQuery("यूट्यूब पर सॉन्ग चलाओ मोहम्मद रफी का")
        assertEquals("मोहम्मद रफी", q)
        val q2 = AgenticExecutionPlanner.sanitizeYouTubeQuery("youtube par mohammed rafi ka song chalao")
        assertEquals("mohammed rafi", q2)
    }

    @Test
    fun testMuskanVocalPersonaResponses() {
        // WhatsApp Plan
        val whatsappPlan = AgenticExecutionPlanner.createPlanForPrompt("Aman ko WhatsApp par message bhejo Hello")
        assertNotNull(whatsappPlan)
        assertEquals("मैसेज सेंड हो गया है, सर।", whatsappPlan?.completionSpeech)

        // YouTube Plan
        val ytPlan = AgenticExecutionPlanner.createPlanForPrompt("YouTube par cartoon chalao")
        assertNotNull(ytPlan)
        assertEquals("वीडियो प्ले कर दी गई है, सर।", ytPlan?.completionSpeech)

        // Notes Plan
        val notePlan = AgenticExecutionPlanner.createPlanForPrompt("Notes mein likho Buy groceries")
        assertNotNull(notePlan)
        assertEquals("नया नोट तैयार कर दिया गया है, सर।", notePlan?.completionSpeech)
    }

    @Test
    fun testAllTargetAppsPlansCreatedSuccessfully() {
        // Telegram Plan
        val tgPlan = AgenticExecutionPlanner.createPlanForPrompt("Telegram par Rahul ko message bhejo Meet at 5")
        assertNotNull(tgPlan)
        assertEquals("मैसेज सेंड हो गया है, सर।", tgPlan?.completionSpeech)

        // SMS Plan
        val smsPlan = AgenticExecutionPlanner.createPlanForPrompt("Aman ko SMS bhejo Call me")
        assertNotNull(smsPlan)
        assertEquals("मैसेज सेंड हो गया है, सर।", smsPlan?.completionSpeech)

        // Call Logs Plan
        val callLogPlan = AgenticExecutionPlanner.createPlanForPrompt("Call logs dikhao")
        assertNotNull(callLogPlan)
        assertTrue(callLogPlan?.completionSpeech?.contains("कॉल लॉग्स") == true)

        // Facebook Feed Scroll Plan
        val fbPlan = AgenticExecutionPlanner.createPlanForPrompt("Facebook scroll karo")
        assertNotNull(fbPlan)
        assertEquals("काम मुकम्मल हो गया है, सर।", fbPlan?.completionSpeech)

        // ShareChat Scroll Plan
        val scPlan = AgenticExecutionPlanner.createPlanForPrompt("ShareChat scroll karo")
        assertNotNull(scPlan)
        assertEquals("काम मुकम्मल हो गया है, सर।", scPlan?.completionSpeech)

        // TeraBox Cloud Storage Plan
        val tbPlan = AgenticExecutionPlanner.createPlanForPrompt("TeraBox kholo")
        assertNotNull(tbPlan)
        assertTrue(tbPlan?.completionSpeech?.contains("TeraBox") == true)
    }

    @Test
    fun testActionFirstAcknowledgmentChimeExecution() {
        // Must execute without exception
        VoiceSessionManager.playAcknowledgeChime()
        assertTrue(true)
    }
}
