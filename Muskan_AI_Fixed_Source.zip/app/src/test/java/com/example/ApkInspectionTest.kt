package com.example

import com.example.engine.dev.ApkInspectionEngine
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ApkInspectionTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    @Test
    fun rejectsMissingOrEmptyApk() = runBlocking {
        val emptyFile = tempFolder.newFile("empty.apk")
        val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()

        val report = ApkInspectionEngine.inspectApk(context, emptyFile)
        assertFalse(report.isSuccess)
        assertTrue(report.message.contains("does not exist or is empty"))
    }

    @Test
    fun inspectsValidApkZipEntriesAndLimitations() = runBlocking {
        val apkFile = tempFolder.newFile("sample.apk")
        ZipOutputStream(FileOutputStream(apkFile)).use { zos ->
            zos.putNextEntry(ZipEntry("classes.dex"))
            zos.write("DEX_MAGIC".toByteArray())
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("classes2.dex"))
            zos.write("DEX_MAGIC_2".toByteArray())
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("lib/arm64-v8a/libnative.so"))
            zos.write("ELF_SO".toByteArray())
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("res/layout/activity_main.xml"))
            zos.write("<xml/>".toByteArray())
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("META-INF/CERT.RSA"))
            zos.write("SIG".toByteArray())
            zos.closeEntry()
        }

        val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
        val report = ApkInspectionEngine.inspectApk(context, apkFile)

        assertTrue(report.isSuccess)
        assertNotNull(report.entries)
        assertEquals(2, report.entries!!.dexFileNames.size)
        assertTrue(report.entries!!.dexFileNames.contains("classes.dex"))
        assertTrue(report.entries!!.dexFileNames.contains("classes2.dex"))
        assertTrue(report.entries!!.nativeAbis.contains("arm64-v8a"))
        assertEquals(1, report.entries!!.resourceEntryCount)
        assertTrue(report.entries!!.signatureFiles.contains("CERT.RSA"))

        assertFalse(report.limitations.decompilationSupportedOnDevice)
        assertTrue(report.limitations.decompilationExplanation.contains("cannot be reliably decompiled"))
        assertTrue(report.limitations.signingRequirement.contains("cryptographic signing"))
    }
}
