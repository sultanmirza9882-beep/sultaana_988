package com.example

import com.example.engine.dev.SelfDevelopmentEngine
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SelfDevelopmentPromptRoutingTest {
    @Test fun routesExplicitHindiAndHinglishCodeRequests() {
        assertTrue(SelfDevelopmentEngine.isSelfDevelopmentPrompt("Muskan ka voice issue fix karo"))
        assertTrue(SelfDevelopmentEngine.isSelfDevelopmentPrompt("इस ऐप का कोड ठीक करो"))
        assertTrue(SelfDevelopmentEngine.isSelfDevelopmentPrompt("sound nahi aa rahi, fix karo"))
        assertTrue(SelfDevelopmentEngine.isSelfDevelopmentPrompt("Please fix the audio issue in Muskan"))
        assertTrue(SelfDevelopmentEngine.isSelfDevelopmentPrompt("इसमें नया feature add करो"))
        assertTrue(SelfDevelopmentEngine.isSelfDevelopmentPrompt("मेरी ऐप की आवाज़ ठीक करो"))
        assertTrue(SelfDevelopmentEngine.isSelfDevelopmentPrompt("voice theek karo"))
        assertTrue(SelfDevelopmentEngine.isSelfDevelopmentPrompt("इस बग को ठीक कर दो"))
        assertTrue(SelfDevelopmentEngine.isSelfDevelopmentPrompt("isme change kar do"))
        assertTrue(SelfDevelopmentEngine.isSelfDevelopmentPrompt("इसमें कोड बदल दो"))
        assertTrue(SelfDevelopmentEngine.isSelfDevelopmentPrompt("Please add kar do a review screen"))
    }

    @Test fun routesClearFeatureAndBugRequestsAcrossLanguages() {
        val prompts = listOf(
            "Add a review screen to Muskan",
            "Muskan mein approval screen add karo",
            "इस ऐप में approval screen जोड़ो",
            "sound theek nahi hai, fix kar do",
            "कोड में बदलाव कर दो",
            "Please implement this feature"
        )
        prompts.forEach { prompt ->
            assertTrue("Expected source-change routing for: $prompt", SelfDevelopmentEngine.isSelfDevelopmentPrompt(prompt))
        }
    }

    @Test fun doesNotRouteOrdinaryQuestionsAsCodeChanges() {
        assertFalse(SelfDevelopmentEngine.isSelfDevelopmentPrompt("Muskan kaise kaam karti hai?"))
        assertFalse(SelfDevelopmentEngine.isSelfDevelopmentPrompt("What is an Android APK?"))
        assertFalse(SelfDevelopmentEngine.isSelfDevelopmentPrompt("हमने जो तय किया था उस पर आगे काम शुरू करो"))
        assertFalse(SelfDevelopmentEngine.isSelfDevelopmentPrompt("Can you explain why voice assistants use APIs?"))
        assertFalse(SelfDevelopmentEngine.isSelfDevelopmentPrompt("Muskan ki awaaz kaisi hai?"))
        assertFalse(SelfDevelopmentEngine.isSelfDevelopmentPrompt("What features does this app have?"))
    }
}
