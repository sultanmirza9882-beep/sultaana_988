package com.example

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.firebase.FirestoreMemoryRepository
import com.example.data.firebase.UserPreferences
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class FirestoreMemoryRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun authenticatedUser_canSaveAndRetrieveMemory(): Unit = runBlocking {
        val uid = signInTestUser("sultan@example.com")
        val repo = FirestoreMemoryRepository(firestore, auth)

        val memory = repo.saveMemory(
            content = "Sultan Mirza is the creator and owner of Muskaan AI",
            category = "core_fact"
        )
        assertNotNull(memory.memoryId)
        assertEquals(uid, memory.userId)

        val memories = repo.observeUserMemories().first()
        assertTrue(memories.any { it.content.contains("Sultan Mirza") })
    }

    @Test
    fun unauthenticatedUser_cannotSaveMemory(): Unit = runBlocking {
        auth.signOut()
        val repo = FirestoreMemoryRepository(firestore, auth)

        try {
            repo.saveMemory("This should fail")
            fail("Expected exception for unauthenticated user")
        } catch (e: Exception) {
            assertTrue(e.message?.contains("User must be signed in") == true)
        }
    }

    @Test
    fun authenticatedUser_canSavePreferences(): Unit = runBlocking {
        val uid = signInTestUser("sultan_prefs@example.com")
        val repo = FirestoreMemoryRepository(firestore, auth)

        val prefs = UserPreferences(
            userId = uid,
            assistantPersona = "Muskaan",
            proactiveQuestionsEnabled = true,
            inactivitySeconds = 20
        )
        repo.saveUserPreferences(prefs)

        val loaded = repo.observeUserPreferences().first()
        assertNotNull(loaded)
        assertEquals(20, loaded?.inactivitySeconds)
        assertEquals(true, loaded?.proactiveQuestionsEnabled)
    }
}
