package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.api.ApiErrorType
import com.example.api.ApiProfile
import com.example.api.ApiProfileManager
import com.example.api.ApiProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ApiManagementAndListeningTest {

    private val context: Context = ApplicationProvider.getApplicationContext()

    @Before
    fun setUp() {
        ApiProfileManager.initialize(context)
        ApiProfileManager.clearAllCustomProfilesForTesting()
        VoiceSessionManager.initialize(context)
    }

    @Test
    fun testDefaultProfilePreservedAndActiveByDefault() {
        val active = ApiProfileManager.getActiveProfile()
        assertTrue("Active profile should be default initially", active.isDefault)
        assertEquals(ApiProfile.DEFAULT_ID, active.id)

        // Try deleting default profile - must fail
        val deleted = ApiProfileManager.deleteProfile(ApiProfile.DEFAULT_ID)
        assertFalse("Default profile must never be deleted", deleted)
        assertEquals(ApiProfile.DEFAULT_ID, ApiProfileManager.getActiveProfile().id)
    }

    @Test
    fun testKeyMaskingProtectsCredentials() {
        val plainKey = "AIzaSyABC123456789XYZ"
        val customProfile = ApiProfile(
            id = UUID.randomUUID().toString(),
            name = "Test Gemini Key",
            provider = ApiProvider.GEMINI,
            apiKey = plainKey
        )

        val masked = customProfile.getMaskedApiKey()
        assertFalse("Masked key must not contain plain key in full", masked == plainKey)
        assertTrue("Masked key should start with prefix", masked.startsWith("AIzaSy"))
        assertTrue("Masked key should end with suffix", masked.endsWith("XYZ"))
        assertTrue("Masked key should have bullet masking", masked.contains("••••"))
    }

    @Test
    fun testUnverifiedApiCannotBecomeActive() {
        val unverifiedProfile = ApiProfile(
            id = "custom_unverified_1",
            name = "Unverified Custom Key",
            provider = ApiProvider.GEMINI,
            apiKey = "AIzaSyDummyKeyUnverified",
            isVerified = false,
            verificationMessage = "Not Verified"
        )
        ApiProfileManager.saveProfile(unverifiedProfile)

        val activationResult = ApiProfileManager.setActiveProfile("custom_unverified_1")
        assertTrue("Activation of unverified API must fail", activationResult.isFailure)

        // Active profile must remain default
        val currentActive = ApiProfileManager.getActiveProfile()
        assertEquals(ApiProfile.DEFAULT_ID, currentActive.id)
    }

    @Test
    fun testVerifiedApiCanBeActivatedAndSwitchedBack() {
        val verifiedProfile = ApiProfile(
            id = "custom_verified_1",
            name = "Verified Backup Key",
            provider = ApiProvider.GEMINI,
            apiKey = "AIzaSyDummyKeyVerified",
            isVerified = true,
            verificationMessage = "VERIFIED • Ready for use"
        )
        ApiProfileManager.saveProfile(verifiedProfile)

        val activationResult = ApiProfileManager.setActiveProfile("custom_verified_1")
        assertTrue("Activation of verified API must succeed", activationResult.isSuccess)
        assertEquals("custom_verified_1", ApiProfileManager.getActiveProfile().id)

        // Switch back to Default API
        val resetProfile = ApiProfileManager.resetToDefault()
        assertTrue("Reset must return default profile", resetProfile.isDefault)
        assertEquals(ApiProfile.DEFAULT_ID, ApiProfileManager.getActiveProfile().id)
    }

    @Test
    fun testDeletingActiveProfileRevertsToDefault() {
        val customProfile = ApiProfile(
            id = "custom_to_delete",
            name = "Temporary Key",
            provider = ApiProvider.GEMINI,
            apiKey = "AIzaSyTemporaryKey",
            isVerified = true
        )
        ApiProfileManager.saveProfile(customProfile)
        ApiProfileManager.setActiveProfile("custom_to_delete")
        assertEquals("custom_to_delete", ApiProfileManager.getActiveProfile().id)

        // Delete active profile
        val deleted = ApiProfileManager.deleteProfile("custom_to_delete")
        assertTrue("Custom profile should be deleted", deleted)

        // Must automatically revert to default
        val activeAfterDelete = ApiProfileManager.getActiveProfile()
        assertTrue("Active profile must revert to default", activeAfterDelete.isDefault)
    }

    @Test
    fun testRateLimitBackoffAndBackupSelection() {
        val profileA = ApiProfile(
            id = "primary_pro",
            name = "Primary Pro",
            provider = ApiProvider.GEMINI,
            apiKey = "AIzaSyPrimary",
            isVerified = true
        )
        val profileB = ApiProfile(
            id = "backup_flash",
            name = "Backup Flash",
            provider = ApiProvider.GEMINI,
            apiKey = "AIzaSyBackup",
            isVerified = true
        )
        ApiProfileManager.saveProfile(profileA)
        ApiProfileManager.saveProfile(profileB)

        // Hit HTTP 429 on profileA
        ApiProfileManager.recordRateLimitHit(profileA.id, isQuotaExhausted = false)

        val backup = ApiProfileManager.findBackupVerifiedProfile(excludeId = profileA.id)
        assertNotNull("Backup profile should be found", backup)
        // Backup can be profileB or default
        assertTrue(backup!!.id == profileB.id || backup.id == ApiProfile.DEFAULT_ID)
    }

    @Test
    fun testContinuousListeningManualControls() {
        // Explicitly turn listening OFF
        VoiceSessionManager.stopListening()
        val stateAfterStop = VoiceSessionManager.uiState.value
        assertFalse("Listening must be marked disabled by user", stateAfterStop.isListeningEnabledByUser)
        assertFalse("Continuous session must be stopped", stateAfterStop.isContinuousSessionActive)
        assertEquals(AssistantState.IDLE, stateAfterStop.state)
        assertTrue(stateAfterStop.statusMessage.contains("OFF"))

        // Explicitly turn listening ON
        VoiceSessionManager.startExplicitListening()
        val stateAfterStart = VoiceSessionManager.uiState.value
        assertTrue("Listening must be enabled by user", stateAfterStart.isListeningEnabledByUser)
        assertTrue("Continuous session must be active", stateAfterStart.isContinuousSessionActive)
        assertFalse("Mute must be cleared", stateAfterStart.isMuted)
    }

    @Test
    fun testApiConfigHelperExtractsCurlAndJson() {
        val curlInput = """curl https://api.openai.com/v1/chat/completions -H "Authorization: Bearer sk-proj-1234567890abcdef1234567890""""
        val curlResult = com.example.api.ApiConfigHelper.analyzeAndCleanKey(curlInput)
        assertEquals("sk-proj-1234567890abcdef1234567890", curlResult.cleanedKey)
        assertEquals(ApiProvider.OPENAI_COMPATIBLE, curlResult.detectedProvider)
        assertEquals("gpt-4o-mini", curlResult.recommendedModel)

        val jsonInput = """{"apiKey": "AIzaSyTestGeminiKey1234567890abcdef"}"""
        val jsonResult = com.example.api.ApiConfigHelper.analyzeAndCleanKey(jsonInput)
        assertEquals("AIzaSyTestGeminiKey1234567890abcdef", jsonResult.cleanedKey)
        assertEquals(ApiProvider.GEMINI, jsonResult.detectedProvider)
        assertEquals("gemini-2.0-flash", jsonResult.recommendedModel)

        val groqInput = "gsk_1234567890abcdefGroqTestKey12345"
        val groqResult = com.example.api.ApiConfigHelper.analyzeAndCleanKey(groqInput)
        assertEquals("gsk_1234567890abcdefGroqTestKey12345", groqResult.cleanedKey)
        assertEquals(ApiProvider.OPENAI_COMPATIBLE, groqResult.detectedProvider)
        assertEquals("llama-3.3-70b-versatile", groqResult.recommendedModel)
    }

    @Test
    fun testEndpointUrlNormalization() {
        val normal1 = com.example.api.ApiConfigHelper.buildOpenAiChatUrl("https://api.openai.com/v1")
        assertEquals("https://api.openai.com/v1/chat/completions", normal1)

        val normal2 = com.example.api.ApiConfigHelper.buildOpenAiChatUrl("https://api.openai.com")
        assertEquals("https://api.openai.com/v1/chat/completions", normal2)

        val geminiUrl = com.example.api.ApiConfigHelper.buildGeminiUrl("https://generativelanguage.googleapis.com", "gemini-1.5-flash", "AIzaTest")
        assertEquals("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaTest", geminiUrl)
    }

    @Test
    fun testHybrid20KeyRotationPool() {
        com.example.api.KeyRotationPoolManager.initialize(context)
        com.example.api.KeyRotationPoolManager.resetForTesting()

        val initialSlots = com.example.api.KeyRotationPoolManager.slots.value
        assertEquals("Must have total 20 slots (0..19)", 20, initialSlots.size)
        assertTrue("Slot 0 is custom slot", initialSlots[0].isCustomSlot)
        assertEquals(0, initialSlots[0].slotIndex)

        // Set Custom Slot 0 with an OpenAI key
        val customSlot = com.example.api.KeyRotationPoolManager.setCustomSlotKey("sk-test-openai-key-sultan-mirza-12345")
        assertEquals(ApiProvider.OPENAI_COMPATIBLE, customSlot.provider)
        assertEquals("gpt-4o-mini", customSlot.modelId)
        assertTrue("Slot 0 should be available", customSlot.isAvailable())

        // Priority Selection: Slot 0 must be selected first
        val selected = com.example.api.KeyRotationPoolManager.selectActiveSlotForRequest()
        assertEquals(0, selected.slotIndex)

        // Record 429 quota exhaustion on Slot 0: should rotate to Default Pool (Slots 1..19)
        val rotated = com.example.api.KeyRotationPoolManager.recordErrorAndRotate(0, isQuotaExhausted = true, httpCode = 429)
        assertTrue("Rotated slot must be in 1..19", rotated.slotIndex in 1..19)
        assertEquals(com.example.api.KeySlotStatus.EXHAUSTED, com.example.api.KeyRotationPoolManager.slots.value[0].status)

        // Subsequent selection selects from Default Pool in Round-Robin
        val nextSelect = com.example.api.KeyRotationPoolManager.selectActiveSlotForRequest()
        assertTrue("Must select from default pool", nextSelect.slotIndex in 1..19)

        // Clear custom slot and verify status
        com.example.api.KeyRotationPoolManager.clearCustomSlot()
        assertEquals(com.example.api.KeySlotStatus.NOT_CONFIGURED, com.example.api.KeyRotationPoolManager.slots.value[0].status)
    }
}
