package com.example

import com.example.engine.terminal.WorkspaceTerminalEngine
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LiveWorkspaceTerminalTest {

    @Test
    fun logsTelemetryAndEventsFaithfully() {
        WorkspaceTerminalEngine.clear()

        WorkspaceTerminalEngine.logAgentActivity("ALEX", "Planning", "Analyzing source")
        WorkspaceTerminalEngine.logToolEvent("ToolRegistry", "query", "Success", 12L)
        WorkspaceTerminalEngine.logFileChange("WRITE", "app/Test.kt", "Created")
        WorkspaceTerminalEngine.logError("Compiler", "Test error message")

        val session = WorkspaceTerminalEngine.sessionState.value
        assertEquals(4, session.lines.size)

        assertEquals(WorkspaceTerminalEngine.TerminalLineType.AGENT_EVENT, session.lines[0].type)
        assertTrue(session.lines[0].text.contains("[AGENT:ALEX]"))

        assertEquals(WorkspaceTerminalEngine.TerminalLineType.TOOL_EVENT, session.lines[1].type)
        assertTrue(session.lines[1].text.contains("[TOOL:ToolRegistry]"))

        assertEquals(WorkspaceTerminalEngine.TerminalLineType.SUCCESS, session.lines[2].type)
        assertTrue(session.lines[2].text.contains("[FILE:WRITE]"))

        assertEquals(WorkspaceTerminalEngine.TerminalLineType.ERROR, session.lines[3].type)
        assertTrue(session.lines[3].text.contains("[ERROR:Compiler]"))
    }

    @Test
    fun executesHelpAndDisallowsArbitraryShellCommands() = runBlocking {
        val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()

        val helpOutput = WorkspaceTerminalEngine.executeCommand(context, "help")
        assertTrue(helpOutput.contains("Available Muskan Developer Workspace Commands"))
        assertTrue(helpOutput.contains("status"))
        assertTrue(helpOutput.contains("snapshots"))
        assertTrue(helpOutput.contains("verify"))

        val unsafeOutput = WorkspaceTerminalEngine.executeCommand(context, "rm -rf /")
        assertTrue(unsafeOutput.contains("[SECURITY] Unknown or disallowed command"))
        assertTrue(unsafeOutput.contains("Untrusted shell execution is strictly disabled"))
    }
}
