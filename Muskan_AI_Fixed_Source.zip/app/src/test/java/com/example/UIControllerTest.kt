package com.example

import com.example.ui.controller.AgentUIResult
import com.example.ui.controller.ComponentType
import com.example.ui.controller.DashboardContainer
import com.example.ui.controller.ModularDashboardComponent
import com.example.ui.controller.MuskanUIController
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class UIControllerTest {

    @Before
    fun setUp() {
        MuskanUIController.resetToDefaults()
    }

    @Test
    fun defaultContainers_areSeededCorrectly() {
        val containers = MuskanUIController.getContainers()
        assertTrue("Expected default containers to be seeded", containers.isNotEmpty())
        assertTrue("Expected at least 3 containers", containers.size >= 3)
        assertNotNull(MuskanUIController.getContainer("container_neural_telemetry"))
        assertNotNull(MuskanUIController.getContainer("container_quick_actions"))
    }

    @Test
    fun addAndRemoveContainer_worksDynamically() {
        val testContainer = DashboardContainer(
            id = "test_custom_container",
            title = "Test Telemetry",
            description = "Custom test container",
            badge = "TEST"
        )

        val added = MuskanUIController.addContainer(testContainer)
        assertTrue("Container should be successfully added", added)
        assertNotNull(MuskanUIController.getContainer("test_custom_container"))

        val removed = MuskanUIController.removeContainer("test_custom_container")
        assertTrue("Container should be successfully removed", removed)
        assertEquals(null, MuskanUIController.getContainer("test_custom_container"))
    }

    @Test
    fun addAndModifyComponent_updatesStateCorrectly() {
        val component = ModularDashboardComponent(
            id = "comp_test_metric",
            containerId = "container_quick_actions",
            title = "Live FPS",
            type = ComponentType.METRIC_CARD,
            dataPayload = mapOf("value" to "60 FPS", "status" to "SMOOTH")
        )

        val added = MuskanUIController.addComponent("container_quick_actions", component)
        assertTrue("Component should be added", added)

        // Modify component payload
        val updated = MuskanUIController.updateComponentPayload("comp_test_metric", "value", "120 FPS")
        assertTrue("Component payload should be updated", updated)

        val container = MuskanUIController.getContainer("container_quick_actions")
        val updatedComp = container?.components?.find { it.id == "comp_test_metric" }
        assertNotNull(updatedComp)
        assertEquals("120 FPS", updatedComp?.dataPayload?.get("value"))

        // Remove component
        val removed = MuskanUIController.removeComponent("comp_test_metric")
        assertTrue("Component should be removed", removed)
    }

    @Test
    fun agentUICommand_executesSuccessfully() {
        val command = "add_component: {\"containerId\":\"container_agent_workspace\",\"title\":\"AI Dynamic Gauge\",\"type\":\"TELEMETRY_GAUGE\",\"value\":\"88\",\"unit\":\"%\",\"subtitle\":\"AI Agent Created\"}"
        val result = MuskanUIController.executeAgentCommand(command)
        assertTrue("Agent UI command should succeed", result is AgentUIResult.Success)

        val container = MuskanUIController.getContainer("container_agent_workspace")
        val component = container?.components?.find { it.title == "AI Dynamic Gauge" }
        assertNotNull("AI dynamically added component should exist", component)
        assertEquals("88", component?.dataPayload?.get("value"))
    }

    @Test
    fun testDynamicTitleExtraction() {
        val title1 = MuskanUIController.extractDynamicTitle("dashboard par box add karo jisme naam likho Sultana")
        assertEquals("Sultana", title1)

        val title2 = MuskanUIController.extractDynamicTitle("ek khali box banao jisme title BatteryMonitor ho")
        assertEquals("BatteryMonitor", title2)

        val title3 = MuskanUIController.extractDynamicTitle("dashboard par widget add karo naam Sultana")
        assertEquals("Sultana", title3)
    }

    @Test
    fun testNaturalLanguageBoxCreation() {
        val command = "dashboard par box add karo jisme naam likho Sultana"
        val result = MuskanUIController.executeAgentCommand(command)
        assertTrue(result is AgentUIResult.Success)

        val containers = MuskanUIController.containersFlow.value
        val created = containers.find { it.title == "Sultana" }
        assertNotNull("Dynamic card 'Sultana' must appear in containersFlow live", created)
        assertEquals("CUSTOM", created?.badge)
    }
}
