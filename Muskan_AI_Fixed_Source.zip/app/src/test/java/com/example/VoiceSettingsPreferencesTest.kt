package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class VoiceSettingsPreferencesTest {

    @Test
    fun testWakeWordToggle() {
        val context = RuntimeEnvironment.getApplication()
        VoiceSessionManager.initialize(context)

        val initialWakeWord = VoiceSessionManager.uiState.value.isWakeWordEnabled
        VoiceSessionManager.toggleWakeWord()
        assertEquals(!initialWakeWord, VoiceSessionManager.uiState.value.isWakeWordEnabled)

        // Toggle back
        VoiceSessionManager.toggleWakeWord()
        assertEquals(initialWakeWord, VoiceSessionManager.uiState.value.isWakeWordEnabled)
    }

    @Test
    fun testUpdateSpeechRatePreference() {
        val context = RuntimeEnvironment.getApplication()
        VoiceSessionManager.initialize(context)

        VoiceSessionManager.updateSpeechRate(1.25f)
        assertEquals(1.25f, VoiceSessionManager.uiState.value.speechRate, 0.01f)

        VoiceSessionManager.updateSpeechRate(0.85f)
        assertEquals(0.85f, VoiceSessionManager.uiState.value.speechRate, 0.01f)

        VoiceSessionManager.setVoicePreset("Muskan Voice Calibration (Rate: 1.0x, Pitch: 1.0x)")
    }

    @Test
    fun testUpdateSpeechPitchPreference() {
        val context = RuntimeEnvironment.getApplication()
        VoiceSessionManager.initialize(context)

        VoiceSessionManager.updateSpeechPitch(1.20f)
        assertEquals(1.20f, VoiceSessionManager.uiState.value.speechPitch, 0.01f)

        VoiceSessionManager.updateSpeechPitch(0.95f)
        assertEquals(0.95f, VoiceSessionManager.uiState.value.speechPitch, 0.01f)

        VoiceSessionManager.setVoicePreset("Muskan Voice Calibration (Rate: 1.0x, Pitch: 1.0x)")
    }

    @Test
    fun testVoicePresetsCalibration() {
        val context = RuntimeEnvironment.getApplication()
        VoiceSessionManager.initialize(context)

        VoiceSessionManager.setVoicePreset("Natural Hinglish (Recommended)")
        assertEquals("Natural Hinglish (Recommended)", VoiceSessionManager.uiState.value.voicePresetName)
        assertEquals(1.02f, VoiceSessionManager.uiState.value.speechRate, 0.01f)

        VoiceSessionManager.setVoicePreset("Warm & Gentle")
        assertEquals("Warm & Gentle", VoiceSessionManager.uiState.value.voicePresetName)
        assertEquals(0.95f, VoiceSessionManager.uiState.value.speechRate, 0.01f)

        VoiceSessionManager.setVoicePreset("Muskan Voice Calibration (Rate: 1.0x, Pitch: 1.0x)")
        assertEquals("Muskan Voice Calibration (Rate: 1.0x, Pitch: 1.0x)", VoiceSessionManager.uiState.value.voicePresetName)
        assertEquals(1.00f, VoiceSessionManager.uiState.value.speechRate, 0.01f)
        assertEquals(1.00f, VoiceSessionManager.uiState.value.speechPitch, 0.01f)
    }
}
