package com.example

import com.example.engine.repair.FailureCategory
import com.example.engine.repair.SelfRepairEngine
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.IOException

class SelfRepairEngineTest {

    @Before
    fun setUp() {
        SelfRepairEngine.resetAllForTesting()
    }

    @Test
    fun testDiagnoseFailure_Categorization() {
        val runtimeEx = NullPointerException("Null reference encountered in pipeline")
        val report1 = SelfRepairEngine.diagnoseFailure(runtimeEx, "Autonomous pipeline execution")
        assertEquals(FailureCategory.RUNTIME_EXCEPTION, report1.failureCategory)
        assertTrue(report1.rootCauseGuess.contains("NullPointerException"))
        assertNotNull(report1.proposedFixStrategy)

        val timeoutEx = IOException("Connection timeout on API endpoint")
        val report2 = SelfRepairEngine.diagnoseFailure(timeoutEx, "Autonomous network fetch")
        assertEquals(FailureCategory.NETWORK_TIMEOUT, report2.failureCategory)
        assertTrue(report2.rootCauseGuess.contains("latency") || report2.rootCauseGuess.contains("timeout"))
    }

    @Test
    fun testDiagnoseVerificationRejection() {
        val report = SelfRepairEngine.diagnoseVerificationRejection(
            diagnostics = listOf("Unbalanced braces in data class"),
            feedback = "Fix closing brace on Line 14",
            artifactTitle = "Salon Booking Core",
            syntaxScore = 0.5f,
            securityScore = 0.9f
        )
        assertEquals(FailureCategory.DEX_VERIFICATION_REJECTION, report.failureCategory)
        assertTrue(report.stackTraceSummary.contains("Unbalanced braces"))
        assertEquals("Fix closing brace on Line 14", report.proposedFixStrategy)
    }

    @Test
    fun testClosedLoopRepairStateTransitions() {
        assertEquals(0, SelfRepairEngine.repairState.value.currentAttempt)
        assertFalse(SelfRepairEngine.repairState.value.isHealingActive)

        // Attempt 1
        SelfRepairEngine.recordHealingAttempt(1, "Syntax error in artifact")
        assertTrue(SelfRepairEngine.repairState.value.isHealingActive)
        assertEquals(1, SelfRepairEngine.repairState.value.currentAttempt)

        // Successful healing
        SelfRepairEngine.recordSuccessfulHealing("test_id", "Applied balanced AST brackets")
        assertFalse(SelfRepairEngine.repairState.value.isHealingActive)
        assertEquals(1, SelfRepairEngine.repairState.value.totalHealedCount)
        assertEquals("Applied balanced AST brackets", SelfRepairEngine.repairState.value.lastFixApplied)

        // Reset
        SelfRepairEngine.resetHealingState()
        assertFalse(SelfRepairEngine.repairState.value.isHealingActive)
    }

    @Test
    fun testVoiceSummaryFormatting() {
        // Initially when healed count > 0
        SelfRepairEngine.recordSuccessfulHealing("test_id", "Fixed schema mismatch")
        val healedSummary = SelfRepairEngine.getHealingSummaryForVoice()
        assertTrue(healedSummary.contains("Sultan"))
        assertTrue(healedSummary.contains("fix kar liya hai") || healedSummary.contains("continuous"))
    }

    @Test
    fun testGenerateRepairStrategyFallback() = runBlocking {
        val report = SelfRepairEngine.diagnoseFailure(IllegalStateException("Serialization failure"), "Bob code generator")
        val strategy = SelfRepairEngine.generateRepairStrategy(report, "Build salon template")
        assertNotNull(strategy)
        assertTrue(strategy.isNotBlank())
    }
}
