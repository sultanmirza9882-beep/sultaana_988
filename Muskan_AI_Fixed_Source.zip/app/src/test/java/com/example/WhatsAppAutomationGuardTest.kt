package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.automation.AgenticExecutionPlanner
import com.example.automation.StepOutcome
import com.example.service.MuskanAccessibilityService
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class WhatsAppAutomationGuardTest {

    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        VoiceSessionManager.initialize(context)
        VoiceSessionManager.setAccessibilityServiceConnected(false)
    }

    @Test
    fun testWhatsAppRegexExtraction() {
        val plan = AgenticExecutionPlanner.createPlanForPrompt("Aman ko whatsapp message bhejo main 10 minute me aa raha hu")
        assertNotNull("Plan should be created for WhatsApp prompt", plan)
        assertEquals("Send WhatsApp to Aman", plan?.title)
        assertTrue(plan?.requiresAccessibility == true)
    }

    @Test
    fun testWhatsAppRegexVariations() {
        val plan1 = AgenticExecutionPlanner.createPlanForPrompt("whatsapp par Rahul ko text bhejo ki call me urgent")
        assertNotNull(plan1)
        assertEquals("Send WhatsApp to Rahul", plan1?.title)

        val plan2 = AgenticExecutionPlanner.createPlanForPrompt("send whatsapp message to Priya saying Happy Birthday")
        assertNotNull(plan2)
        assertEquals("Send WhatsApp to Priya", plan2?.title)
    }

    @Test
    fun testWhatsAppAccessibilityGuardBlocksFakeSuccess() {
        val plan = AgenticExecutionPlanner.createPlanForPrompt("Aman ko whatsapp message bhejo hello")
        assertNotNull(plan)

        // Accessibility service is disconnected
        assertFalse("Accessibility must be disconnected in test", MuskanAccessibilityService.isConnected())

        // Run step 1 (check_accessibility_and_launch)
        val step1 = plan!!.steps[0]
        val outcome = kotlinx.coroutines.runBlocking { step1.action(context) }

        assertTrue("Outcome must be failure when accessibility is off", outcome is StepOutcome.Failure)
        val failureReason = (outcome as StepOutcome.Failure).reason
        assertTrue(
            "Failure reason must mention Accessibility permission",
            failureReason.contains("Accessibility permission band hai, WhatsApp control karne ke liye Settings on karein")
        )
    }
}
