package com.example

import com.example.util.OfflineKeywordResponder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OfflineKeywordResponderTest {

    @Test
    fun testTimeQueries() {
        val r1 = OfflineKeywordResponder.matchOfflineResponse("what time is it")
        assertNotNull(r1)
        assertEquals("Time", r1?.category)
        assertTrue(r1?.answer?.contains("samay ho raha hai") == true)

        val r2 = OfflineKeywordResponder.matchOfflineResponse("kya time hua hai")
        assertNotNull(r2)
        assertEquals("Time", r2?.category)
    }

    @Test
    fun testDateQueries() {
        val r = OfflineKeywordResponder.matchOfflineResponse("today's date kya hai")
        assertNotNull(r)
        assertEquals("Date", r?.category)
        assertTrue(r?.answer?.contains("Aaj") == true)
    }

    @Test
    fun testIdentityQueries() {
        val r = OfflineKeywordResponder.matchOfflineResponse("tum kaun ho")
        assertNotNull(r)
        assertEquals("Identity", r?.category)
        assertTrue(r?.answer?.contains("Muskan") == true)
    }

    @Test
    fun testGreetingQueries() {
        val r = OfflineKeywordResponder.matchOfflineResponse("namaste Muskan")
        assertNotNull(r)
        assertEquals("Greeting", r?.category)
    }

    @Test
    fun testWellBeingQueries() {
        val r = OfflineKeywordResponder.matchOfflineResponse("Muskan kaise ho aap")
        assertNotNull(r)
        assertEquals("WellBeing", r?.category)
        assertTrue(r?.answer?.contains("badhiya") == true)
    }

    @Test
    fun testAutonomousSubAgentQuery() {
        val r = OfflineKeywordResponder.matchOfflineResponse("mere neeche kaam karne wala autonomous agent")
        assertNotNull(r)
        assertEquals("Autonomous Agent", r?.category)
        assertTrue(r?.answer?.contains("मुस्कान खुद एक डायरेक्ट ऑटोनॉमस") == true)
    }

    @Test
    fun testGracefulOfflineFallbackForUnknownQuery() {
        val fallback = OfflineKeywordResponder.getGracefulOfflineFallback("Explain quantum entanglement")
        assertNotNull(fallback)
        assertTrue(fallback.answer.contains("Network connect nahi ho pa raha hai") || fallback.answer.contains("offline"))
    }
}
