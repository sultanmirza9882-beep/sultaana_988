package com.example

import android.content.Context
import android.os.Looper
import android.util.Base64
import androidx.test.core.app.ApplicationProvider
import com.example.engine.EngineExecutionManager
import com.example.engine.EngineRegistry
import com.example.engine.EngineStatus
import com.example.engine.approval.OwnerApprovalGate
import com.example.engine.approval.SensitiveActionType
import com.example.engine.calendar.CalendarEngine
import com.example.engine.calendar.CalendarEvent
import com.example.engine.email.EmailEngine
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.nio.charset.StandardCharsets
import java.util.Calendar

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Phase7CalendarAndEmailTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        OwnerApprovalGate.resetForTest()
        EmailEngine.setOAuthAccessToken(context, null)
    }

    @After
    fun tearDown() {
        OwnerApprovalGate.resetForTest()
        EmailEngine.setOAuthAccessToken(context, null)
    }

    private suspend fun waitForPendingSensitiveAction(
        expectedType: SensitiveActionType,
        timeoutMs: Long = 2000L
    ): String {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            shadowOf(Looper.getMainLooper()).idle()
            val active = OwnerApprovalGate.activeActionPrompt.value
            if (active != null && active.sensitiveActionType == expectedType) {
                return active.id
            }
            delay(15L)
        }
        throw AssertionError("Timed out waiting for pending sensitive action of type $expectedType")
    }

    @Test
    fun calendarConflictDetectionIdentifiesOverlapsAndAllowsAdjacentSlots() {
        val base = 1_700_000_000_000L
        val hour = 60L * 60L * 1000L

        val existing = listOf(
            CalendarEvent(1L, 1L, "Morning Standup", "", base + 1 * hour, base + 2 * hour),
            CalendarEvent(2L, 1L, "Client Pitch", "", base + 3 * hour, base + 5 * hour),
            CalendarEvent(3L, 1L, "Evening Review", "", base + 7 * hour, base + 8 * hour)
        )

        // Adjacent slot [2h, 3h) touches [1h, 2h) and [3h, 5h) at boundaries -> NO conflict
        val adjacentConflicts = CalendarEngine.findConflictingEvents(existing, base + 2 * hour, base + 3 * hour)
        assertTrue("Adjacent half-open slots must not conflict", adjacentConflicts.isEmpty())

        // Overlapping [1.5h, 4h) conflicts with Morning Standup and Client Pitch
        val overlapConflicts = CalendarEngine.findConflictingEvents(
            existing,
            base + (1.5 * hour).toLong(),
            base + 4 * hour
        )
        assertEquals(2, overlapConflicts.size)
        assertEquals("Morning Standup", overlapConflicts[0].title)
        assertEquals("Client Pitch", overlapConflicts[1].title)

        // Fully contained [3.5h, 4.5h) conflicts with Client Pitch
        val containedConflicts = CalendarEngine.findConflictingEvents(
            existing,
            base + (3.5 * hour).toLong(),
            base + (4.5 * hour).toLong()
        )
        assertEquals(1, containedConflicts.size)
        assertEquals("Client Pitch", containedConflicts[0].title)
    }

    @Test
    fun naturalScheduleParserParsesTomorrowTenAmMeeting() {
        val fixedNow = Calendar.getInstance().apply {
            set(2026, Calendar.NOVEMBER, 19, 8, 15, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val parsed = CalendarEngine.parseNaturalScheduleRequest("kal 10 baje team sync meeting set karo", fixedNow)
        val cal = Calendar.getInstance().apply { timeInMillis = parsed.startMillis }

        assertEquals(20, cal.get(Calendar.DAY_OF_MONTH))
        assertEquals(10, cal.get(Calendar.HOUR_OF_DAY))
        assertEquals(0, cal.get(Calendar.MINUTE))
        assertEquals(parsed.startMillis + 3_600_000L, parsed.endMillis)
        assertTrue("Parsed title should preserve topic: ${parsed.title}", parsed.title.contains("team sync", ignoreCase = true))
    }

    @Test
    fun calendarCreateEventBlocksUntilOwnerDecisionAndUsesIntentFallbackOnApprove() = runBlocking {
        val start = System.currentTimeMillis() + 3_600_000L
        val end = start + 3_600_000L

        // 1. Deny path cancels cleanly
        val denyDeferred = async {
            CalendarEngine.createEvent(
                context = context,
                title = "Board Sync",
                startMillis = start,
                endMillis = end,
                description = "Quarterly roadmap"
            )
        }
        val denyId = waitForPendingSensitiveAction(SensitiveActionType.CALENDAR_CREATE)
        assertFalse("createEvent must block until owner decides", denyDeferred.isCompleted)
        OwnerApprovalGate.rejectProposal(denyId, "Owner cancelled calendar create")

        val denyResult = denyDeferred.await()
        assertFalse(denyResult.success)
        assertTrue(denyResult.approvalDenied)
        assertTrue(denyResult.message.contains("Approval denied", ignoreCase = true))

        // 2. Approve path proceeds (without WRITE_CALENDAR permission -> ACTION_INSERT intent fallback)
        val approveDeferred = async {
            CalendarEngine.createEvent(
                context = context,
                title = "Investor Call",
                startMillis = start,
                endMillis = end,
                description = "Product demo"
            )
        }
        val approveId = waitForPendingSensitiveAction(SensitiveActionType.CALENDAR_CREATE)
        assertFalse("createEvent must remain blocked prior to approval", approveDeferred.isCompleted)
        OwnerApprovalGate.approveProposal(approveId)

        val approveResult = approveDeferred.await()
        assertTrue("Approved createEvent should succeed via ACTION_INSERT fallback", approveResult.success)
        assertTrue("Without WRITE_CALENDAR permission, intent fallback must be used", approveResult.usedIntentFallback)
        assertFalse(approveResult.approvalDenied)
    }

    @Test
    fun calendarRescheduleAndDeleteAreApprovalGated() = runBlocking {
        val newStart = System.currentTimeMillis() + 7_200_000L
        val newEnd = newStart + 3_600_000L

        val rescheduleDeferred = async {
            CalendarEngine.rescheduleEvent(context, eventId = 42L, newStartMillis = newStart, newEndMillis = newEnd, titleHint = "Design Review")
        }
        val rescheduleId = waitForPendingSensitiveAction(SensitiveActionType.CALENDAR_RESCHEDULE)
        assertFalse(rescheduleDeferred.isCompleted)
        OwnerApprovalGate.rejectProposal(rescheduleId)
        val rescheduleResult = rescheduleDeferred.await()
        assertFalse(rescheduleResult.success)
        assertTrue(rescheduleResult.approvalDenied)

        val deleteDeferred = async {
            CalendarEngine.deleteEvent(context, eventId = 42L, titleHint = "Design Review")
        }
        val deleteId = waitForPendingSensitiveAction(SensitiveActionType.CALENDAR_DELETE)
        assertFalse(deleteDeferred.isCompleted)
        OwnerApprovalGate.rejectProposal(deleteId)
        val deleteResult = deleteDeferred.await()
        assertFalse(deleteResult.success)
        assertTrue(deleteResult.approvalDenied)
    }

    @Test
    fun emailSendBlocksUntilOwnerDecisionAndUsesMailtoFallbackWhenApprovedOffline() = runBlocking {
        // 1. Deny path blocks and cancels cleanly
        val denyDeferred = async {
            EmailEngine.sendEmail(
                context = context,
                to = "partner@example.com",
                subject = "Project Update",
                body = "Namaste, update attached."
            )
        }
        val denyId = waitForPendingSensitiveAction(SensitiveActionType.EMAIL_SEND)
        assertFalse("sendEmail must stay blocked until owner decides", denyDeferred.isCompleted)
        OwnerApprovalGate.rejectProposal(denyId, "Do not send email")

        val denyResult = denyDeferred.await()
        assertFalse(denyResult.success)
        assertTrue(denyResult.approvalDenied)
        assertTrue(denyResult.message.contains("Approval denied", ignoreCase = true))

        // 2. Approve path without OAuth token proceeds via mailto fallback
        val approveDeferred = async {
            EmailEngine.sendEmail(
                context = context,
                to = "partner@example.com",
                subject = "Approved Update",
                body = "Hi team, sharing the latest milestone."
            )
        }
        val approveId = waitForPendingSensitiveAction(SensitiveActionType.EMAIL_SEND)
        assertFalse(approveDeferred.isCompleted)
        OwnerApprovalGate.approveProposal(approveId)

        val approveResult = approveDeferred.await()
        assertTrue("Approved sendEmail should succeed via mailto compose fallback", approveResult.success)
        assertTrue("Without OAuth token, mailto fallback must be used", approveResult.usedMailtoFallback)
        assertFalse(approveResult.approvalDenied)
    }

    @Test
    fun voiceCommandRouterClassifiesCalendarAndEmailCommandsAccurately() {
        // Calendar commands (Hindi/Hinglish/English)
        assertTrue(VoiceCommandRouter.isCalendarCommand("aaj ka schedule batao"))
        assertTrue(VoiceCommandRouter.isCalendarCommand("kal 10 baje meeting set karo"))
        assertTrue(VoiceCommandRouter.isCalendarCommand("schedule a meeting with Aman at 4pm"))
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.CALENDAR_COMMAND,
            VoiceCommandRouter.classifyPreLlmRoute("aaj ka schedule")
        )
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.CALENDAR_COMMAND,
            VoiceCommandRouter.classifyPreLlmRoute("kal 10 baje meeting set karo")
        )

        // Email commands (Hindi/Hinglish/English)
        assertTrue(VoiceCommandRouter.isEmailCommand("unread emails padho"))
        assertTrue(VoiceCommandRouter.isEmailCommand("email draft karo rahul@example.com ke liye"))
        assertTrue(VoiceCommandRouter.isEmailCommand("check my gmail inbox"))
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.EMAIL_COMMAND,
            VoiceCommandRouter.classifyPreLlmRoute("unread emails padho")
        )
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.EMAIL_COMMAND,
            VoiceCommandRouter.classifyPreLlmRoute("email draft karo")
        )

        // Non-calendar, non-email queries stay uncaptured
        assertFalse(VoiceCommandRouter.isCalendarCommand("What is the capital of India?"))
        assertFalse(VoiceCommandRouter.isEmailCommand("Aman ko WhatsApp message bhejo Hello"))
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.NONE,
            VoiceCommandRouter.classifyPreLlmRoute("What is the capital of India?")
        )
    }

    @Test
    fun gmailJsonParsingAndRawMimeEncodingWorkCorrectly() {
        val listJson = """
            {
              "messages": [
                { "id": "msg_101", "threadId": "thr_1" },
                { "id": "msg_102", "threadId": "thr_2" }
              ],
              "resultSizeEstimate": 2
            }
        """.trimIndent()
        assertEquals(listOf("msg_101", "msg_102"), EmailEngine.parseMessageListIds(listJson))

        val bodyText = "Namaste Sultan, kal subah 10 baje review call confirm hai."
        val encodedBody = Base64.encodeToString(
            bodyText.toByteArray(StandardCharsets.UTF_8),
            Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
        )

        val messageJson = """
            {
              "id": "msg_101",
              "threadId": "thr_1",
              "labelIds": ["INBOX", "UNREAD"],
              "snippet": "Namaste Sultan, kal subah 10 baje...",
              "payload": {
                "mimeType": "multipart/alternative",
                "headers": [
                  { "name": "From", "value": "Aarav <aarav@company.com>" },
                  { "name": "To", "value": "sultaan.m33@gmail.com" },
                  { "name": "Subject", "value": "Review Call Confirmation" },
                  { "name": "Date", "value": "Thu, 19 Nov 2026 09:00:00 +0530" }
                ],
                "parts": [
                  {
                    "mimeType": "text/plain",
                    "body": { "data": "$encodedBody" }
                  }
                ]
              }
            }
        """.trimIndent()

        val parsed = EmailEngine.parseGmailMessageJson(messageJson)
        assertEquals("msg_101", parsed.id)
        assertEquals("thr_1", parsed.threadId)
        assertEquals("Aarav <aarav@company.com>", parsed.from)
        assertEquals("sultaan.m33@gmail.com", parsed.to)
        assertEquals("Review Call Confirmation", parsed.subject)
        assertTrue(parsed.isUnread)
        assertEquals(bodyText, parsed.bodyPreview)

        // Verify RFC 2822 raw base64url MIME encoding round-trip
        val rawMimeB64 = EmailEngine.buildRawMimeBase64Url(
            to = "aarav@company.com",
            subject = "Re: Review Call",
            body = "Confirmed for 10 AM."
        )
        assertFalse("URL-safe base64 must not contain '+' or '/'", rawMimeB64.contains("+") || rawMimeB64.contains("/"))
        val decodedMime = String(Base64.decode(rawMimeB64, Base64.URL_SAFE), StandardCharsets.UTF_8)
        assertTrue(decodedMime.contains("To: aarav@company.com"))
        assertTrue(decodedMime.contains("Subject: Re: Review Call"))
        assertTrue(decodedMime.contains("Confirmed for 10 AM."))
    }

    @Test
    fun engineRegistryReportsOperationalForCalendarAndEmailEngines() = runBlocking {
        assertEquals(128, EngineRegistry.getAllEngines().size)

        val emailRes = EngineExecutionManager.testEngine(context, 103)
        assertEquals(EngineStatus.OPERATIONAL, emailRes.status)
        assertTrue(emailRes.isSuccess)
        assertTrue(emailRes.verificationNotes.contains("EmailEngine", ignoreCase = true))

        val calendarRes = EngineExecutionManager.testEngine(context, 122)
        assertEquals(EngineStatus.OPERATIONAL, calendarRes.status)
        assertTrue(calendarRes.isSuccess)
        assertTrue(calendarRes.verificationNotes.contains("CalendarEngine", ignoreCase = true))
    }
}
