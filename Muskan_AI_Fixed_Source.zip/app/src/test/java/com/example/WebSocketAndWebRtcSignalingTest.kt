package com.example

import com.example.engine.network.MuskanWebSocketBridge
import com.example.engine.network.RtcSignalingState
import com.example.engine.network.WebRtcSignalingManager
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class WebSocketAndWebRtcSignalingTest {

    @Before
    fun setUp() {
        MuskanWebSocketBridge.disconnect("Test reset")
        MuskanWebSocketBridge.clearQueue()
        WebRtcSignalingManager.closeSession("Test reset")
    }

    @Test
    fun testWebSocketUrlNormalizationAndOfflineQueue() {
        assertEquals(false, MuskanWebSocketBridge.state.value.isEnabled)
        assertEquals("wss://example.com/ws", MuskanWebSocketBridge.normalizeWsUrl("https://example.com/ws"))

        var cleartextRejected = false
        try {
            MuskanWebSocketBridge.normalizeWsUrl("http://192.168.1.5:8080/bridge")
        } catch (_: IllegalArgumentException) {
            cleartextRejected = true
        }
        assertTrue("Cleartext http:// must be rejected", cleartextRejected)

        var wsRejected = false
        try {
            MuskanWebSocketBridge.normalizeWsUrl("ws://192.168.1.5:8080/bridge")
        } catch (_: IllegalArgumentException) {
            wsRejected = true
        }
        assertTrue("Cleartext ws:// must be rejected", wsRejected)

        // When disconnected, outbound messages are queued safely
        val sentImmediately = MuskanWebSocketBridge.sendRawJson(
            JSONObject().put("type", "ping").put("ts", 12345L)
        )
        assertEquals(false, sentImmediately)
        assertEquals(1, MuskanWebSocketBridge.state.value.queuedCount)
    }

    @Test
    fun testWebRtcSignalingOfferAnswerAndEarlyIceCandidateDrain() {
        WebRtcSignalingManager.joinRoom("redmi-room-42", asInitiator = true)
        assertEquals(RtcSignalingState.WAITING_FOR_PEER, WebRtcSignalingManager.status.value.signalingState)

        // 1. Arrive early: remote Trickle-ICE candidate arrives BEFORE remote SDP Answer
        val earlyIce = JSONObject()
            .put("type", "webrtc_signal")
            .put("signalType", "ice_candidate")
            .put("roomId", "redmi-room-42")
            .put("senderId", "peer-browser")
            .put("payload", JSONObject()
                .put("sdpMid", "0")
                .put("sdpMLineIndex", 0)
                .put("candidate", "candidate:1 1 UDP 2122252543 10.0.0.2 50000 typ host"))
        MuskanWebSocketBridge.handleIncomingMessage(earlyIce.toString())

        // Must be buffered in pendingEarlyIceCandidatesCount, not applied yet
        assertEquals(1, WebRtcSignalingManager.status.value.pendingEarlyIceCandidatesCount)
        assertEquals(0, WebRtcSignalingManager.status.value.remoteIceCandidatesAppliedCount)

        // 2. Local peer sends Offer
        val offerRes = WebRtcSignalingManager.createAndSendOffer()
        assertTrue(offerRes.isSuccess)
        assertEquals(RtcSignalingState.HAVE_LOCAL_OFFER, WebRtcSignalingManager.status.value.signalingState)

        // 3. Remote peer responds with Answer over WebSocket bridge
        val answerEnv = JSONObject()
            .put("type", "webrtc_signal")
            .put("signalType", "answer")
            .put("roomId", "redmi-room-42")
            .put("senderId", "peer-browser")
            .put("payload", JSONObject()
                .put("sdpType", "answer")
                .put("sdp", WebRtcSignalingManager.createStandardSdp(isOffer = false, peerId = "peer-browser")))
        MuskanWebSocketBridge.handleIncomingMessage(answerEnv.toString())

        // State must transition to STABLE and buffered early ICE candidate must be drained & applied!
        val st = WebRtcSignalingManager.status.value
        assertEquals(RtcSignalingState.STABLE, st.signalingState)
        assertNotNull(st.remoteDescription)
        assertEquals(0, st.pendingEarlyIceCandidatesCount)
        assertEquals(1, st.remoteIceCandidatesAppliedCount)
    }

    @Test
    fun testWebRtcLoopbackSelfTestReachesStable() {
        val summary = WebRtcSignalingManager.runLoopbackSelfTest("loopback-room")
        assertTrue(summary.contains("STABLE"))
        assertEquals(RtcSignalingState.STABLE, WebRtcSignalingManager.status.value.signalingState)
    }
}
