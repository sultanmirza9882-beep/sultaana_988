package com.example

import com.example.automation.AlwaysOnScreenPerceptionManager
import com.example.automation.AutomationActionEngine
import com.example.automation.AutomationResult
import com.example.automation.PerceptionStatus
import com.example.automation.ScreenSnapshot
import com.example.engine.dialogue.DialogueManagementEngine
import com.example.engine.dialogue.ResponseLengthMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AlwaysOnPerceptionAndAdaptiveResponseTest {

    @Test
    fun testAdaptiveResponseLength_ConciseForShortQueries() {
        val shortQuery1 = "Hi Muskan"
        val config1 = DialogueManagementEngine.determineAdaptiveResponseConfig(shortQuery1)
        assertEquals(ResponseLengthMode.CONCISE, config1.mode)
        assertEquals(120, config1.maxOutputTokens)
        assertTrue(config1.promptDirective.contains("CONCISE"))

        val shortQuery2 = "Time kya hai?"
        val config2 = DialogueManagementEngine.determineAdaptiveResponseConfig(shortQuery2)
        assertEquals(ResponseLengthMode.CONCISE, config2.mode)
        assertEquals(120, config2.maxOutputTokens)
    }

    @Test
    fun testAdaptiveResponseLength_ModerateForStandardQueries() {
        val standardQuery = "Aaj ka mausam kaisa hai aur bahar jaane ke liye kya pehnu"
        val config = DialogueManagementEngine.determineAdaptiveResponseConfig(standardQuery)
        assertEquals(ResponseLengthMode.MODERATE, config.mode)
        assertEquals(350, config.maxOutputTokens)
        assertTrue(config.promptDirective.contains("MODERATE"))
    }

    @Test
    fun testAdaptiveResponseLength_DetailedForVistaarAndInDepthQueries() {
        val vistaarQuery = "Mujhe Android Jetpack Compose architecture vistaar mein samjhao"
        val config1 = DialogueManagementEngine.determineAdaptiveResponseConfig(vistaarQuery)
        assertEquals(ResponseLengthMode.DETAILED, config1.mode)
        assertEquals(1000, config1.maxOutputTokens)
        assertTrue(config1.promptDirective.contains("DETAILED"))

        val inDepthQuery = "Explain in detail the differences between Room and Firestore database architectures with examples"
        val config2 = DialogueManagementEngine.determineAdaptiveResponseConfig(inDepthQuery)
        assertEquals(ResponseLengthMode.DETAILED, config2.mode)
        assertEquals(1000, config2.maxOutputTokens)
    }

    @Test
    fun testInactivityCounterQuestion_20SecondRule() {
        val question1 = DialogueManagementEngine.getInactivityCounterQuestion(null)
        assertNotNull(question1)
        assertTrue(question1.isNotBlank())
        assertTrue(question1.contains("Sultan"))

        val screenNarrative = "Current Display: YouTube khula hua hai. Mukhya content: Lofi Chill Beats"
        val question2 = DialogueManagementEngine.getInactivityCounterQuestion(screenNarrative)
        assertNotNull(question2)
        assertTrue(question2.isNotBlank())
    }

    @Test
    fun testAlwaysOnScreenPerception_GenerateNarrative() {
        val snapshotSuccess = ScreenSnapshot(
            status = PerceptionStatus.SUCCESS,
            foregroundPackage = "com.google.android.youtube",
            windowTitle = "YouTube Player",
            visibleTexts = listOf("Lofi Hip Hop Radio", "Beats to relax to", "Subscribe", "Share"),
            clickableElements = listOf(
                com.example.automation.ObservedElement(text = "Subscribe", isClickable = true),
                com.example.automation.ObservedElement(text = "Like", isClickable = true)
            ),
            editableFields = emptyList()
        )

        val narrative = AlwaysOnScreenPerceptionManager.generateScreenNarrative(snapshotSuccess)
        assertTrue(narrative.contains("YouTube"))
        assertTrue(narrative.contains("Lofi Hip Hop Radio"))

        val snapshotStandby = ScreenSnapshot(
            status = PerceptionStatus.ROOT_NODE_NULL,
            foregroundPackage = ""
        )
        val standbyNarrative = AlwaysOnScreenPerceptionManager.generateScreenNarrative(snapshotStandby)
        assertTrue(standbyNarrative.contains("standby") || standbyNarrative.contains("active window"))
    }

    @Test
    fun testAutomationActionEngine_HandlesScreenPerceptionCommand() {
        val matches = AutomationActionEngine.isScreenPerceptionCommand("Muskan screen par kya hai")
        assertTrue(matches)
    }
}
