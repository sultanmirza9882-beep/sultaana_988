package com.example

import com.example.automation.AgenticExecutionPlanner
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AgenticExecutionPlannerTest {

    @Test
    fun testWhatsAppSendPlanCreatedSuccessfully() {
        val prompt = "WhatsApp par Rahul ko message bhejo ki main nikal gaya"
        val plan = AgenticExecutionPlanner.createPlanForPrompt(prompt)

        assertNotNull("Plan should be recognized for WhatsApp message scenario", plan)
        assertEquals("Send WhatsApp to Rahul", plan?.title)
        assertEquals(4, plan?.steps?.size)
        assertEquals("मैसेज सेंड हो गया है, सर।", plan?.completionSpeech)
    }

    @Test
    fun testYouTubeSearchPlanCreatedSuccessfully() {
        val prompt = "YouTube par lofi music search karo aur chalao"
        val plan = AgenticExecutionPlanner.createPlanForPrompt(prompt)

        assertNotNull("Plan should be created for YouTube search", plan)
        assertTrue(plan?.title?.contains("lofi music") == true)
        assertEquals(3, plan?.steps?.size)
        assertEquals("वीडियो प्ले कर दी गई है, सर।", plan?.completionSpeech)
    }

    @Test
    fun testCameraCapturePlanCreatedSuccessfully() {
        val prompt = "Camera kholo aur photo kheencho"
        val plan = AgenticExecutionPlanner.createPlanForPrompt(prompt)

        assertNotNull("Plan should be created for Camera capture", plan)
        assertEquals("Capture Camera Photo", plan?.title)
        assertEquals(2, plan?.steps?.size)
    }

    @Test
    fun testNoteTakingPlanCreatedSuccessfully() {
        val prompt = "Notes mein likho shopping list: bread, milk"
        val plan = AgenticExecutionPlanner.createPlanForPrompt(prompt)

        assertNotNull("Plan should be created for note taking", plan)
        assertTrue(plan?.title?.contains("shopping list") == true)
        assertEquals(4, plan?.steps?.size)
    }

    @Test
    fun testUnrelatedQueryDoesNotTriggerAgenticPlan() {
        val prompt = "What is the capital of France?"
        val plan = AgenticExecutionPlanner.createPlanForPrompt(prompt)

        assertNull("General queries should pass through to Gemini without agentic plan", plan)
    }

    @Test
    fun testYouTubeQuerySanitizationStrippingTrailingInstructions() {
        val raw = "Motu Patlu ka cartoon lagao aur video play karke ful screen karke rakh do"
        val sanitized = AgenticExecutionPlanner.sanitizeYouTubeQuery(raw)
        assertEquals("Motu Patlu cartoon", sanitized)
    }

    @Test
    fun testDashboardWidgetCommandDetection() {
        val prompt = "dashboard par box add karo naam likho Sultana"
        assertTrue(com.example.ui.controller.MuskanUIController.isDashboardWidgetCommand(prompt))
        val result = com.example.ui.controller.MuskanUIController.executeAgentCommand(prompt)
        assertTrue(result is com.example.ui.controller.AgentUIResult.Success)
        val container = com.example.ui.controller.MuskanUIController.getContainers().find { it.title == "Sultana" }
        assertNotNull("Sultana container should be added to containersFlow", container)
    }
}
