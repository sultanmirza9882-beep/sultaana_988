package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.llm.LlamaCppBridge
import com.example.engine.llm.LocalOfflineSmallLlmEngine
import com.example.engine.llm.QwenOfflineModelManager
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class QwenOfflineDualBrainTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    @Test
    fun testGgufHeaderValidationAcceptsValidGgufV3AndRejectsCorruptFiles() {
        val validFile = tempFolder.newFile("Qwen3-1.7B-Q4_K_M.gguf")
        FileOutputStream(validFile).use { fos ->
            val buf = ByteBuffer.allocate(32).order(ByteOrder.LITTLE_ENDIAN)
            buf.put("GGUF".toByteArray(Charsets.US_ASCII))
            buf.putInt(3) // GGUF version 3
            buf.putLong(290L) // tensor count
            buf.putLong(26L) // metadata kv count
            buf.putLong(0L)
            fos.write(buf.array())
        }

        val info = QwenOfflineModelManager.inspectGgufHeader(validFile)
        assertTrue("Valid GGUF v3 header must pass", info.isValidGguf)
        assertEquals(3, info.version)
        assertEquals(290L, info.tensorCount)
        assertEquals(26L, info.metadataKvCount)

        val invalidFile = tempFolder.newFile("corrupt.gguf")
        invalidFile.writeText("NOT_A_GGUF_MODEL_FILE_1234567890")
        val badInfo = QwenOfflineModelManager.inspectGgufHeader(invalidFile)
        assertFalse("Invalid magic bytes must be rejected", badInfo.isValidGguf)
    }

    @Test
    fun testQwen3ChatMlPromptFormattingAndThinkTagCleaning() {
        val prompt = LlamaCppBridge.buildQwen3ChatMlPrompt(
            userPrompt = "भारत की राजधानी क्या है?",
            recentHistory = listOf("नमस्ते मुस्कान" to "नमस्ते सुल्तान सर!"),
            learnedFacts = listOf("Owner: Sultan Mirza"),
            enableThinking = false
        )

        assertTrue(prompt.contains("<|im_start|>system"))
        assertTrue(prompt.contains("Owner: Sultan Mirza"))
        assertTrue(prompt.contains("<|im_start|>user\nनमस्ते मुस्कान<|im_end|>"))
        assertTrue(prompt.contains("भारत की राजधानी क्या है? /no_think<|im_end|>"))

        val rawOutput = "<think>\nThinking about India's capital...\n</think>\nसुल्तान सर, भारत की राजधानी नई दिल्ली है।<|im_end|>"
        val cleaned = LlamaCppBridge.cleanQwen3Output(rawOutput)
        assertEquals("सुल्तान सर, भारत की राजधानी नई दिल्ली है।", cleaned)
    }

    @Test
    fun testOfflineDualBrainRemembersConversationContextAndAnswersHindiQuestions() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()

        // 1. General Hindi GK question without internet or API key
        val gkResult = LocalOfflineSmallLlmEngine.processOfflineInference(
            context = context,
            rawPrompt = "Bharat ki rajdhani kya hai?"
        )
        assertTrue(gkResult.isHandled)
        assertTrue(gkResult.responseSpeech.contains("नई दिल्ली"))

        // 2. Conversation context recall across turns
        val history = listOf("Bharat ki rajdhani kya hai?" to gkResult.responseSpeech)
        val recallResult = LocalOfflineSmallLlmEngine.processOfflineInference(
            context = context,
            rawPrompt = "Maine abhi kya poocha tha?",
            recentHistory = history
        )
        assertTrue(recallResult.isHandled)
        assertEquals(LocalOfflineSmallLlmEngine.OfflineIntentType.CONVERSATION_CONTEXT, recallResult.intentType)
        assertTrue(recallResult.responseSpeech.contains("Bharat ki rajdhani kya hai?"))
    }

    @Test
    fun testForceOfflineBrainTogglePersistsState() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        QwenOfflineModelManager.initialize(context)

        QwenOfflineModelManager.setForceOfflineBrain(context, true)
        assertTrue(QwenOfflineModelManager.state.value.isForceOfflineBrain)

        QwenOfflineModelManager.setForceOfflineBrain(context, false)
        assertFalse(QwenOfflineModelManager.state.value.isForceOfflineBrain)
    }

    @Test
    fun testOfflineBatteryQueryReportsRealBatteryManagerAndChargingStateWithoutFake75Fallback() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
        val shadowBattery = org.robolectric.Shadows.shadowOf(batteryManager)

        // 1. Real charging battery reading (42%, Charging)
        shadowBattery.setIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY, 42)
        shadowBattery.setIntProperty(
            android.os.BatteryManager.BATTERY_PROPERTY_STATUS,
            android.os.BatteryManager.BATTERY_STATUS_CHARGING
        )
        shadowBattery.setIsCharging(true)

        val chargingResult = LocalOfflineSmallLlmEngine.processOfflineInference(
            context = context,
            rawPrompt = "Mere phone ki battery kitni hai?"
        )
        assertTrue(chargingResult.isHandled)
        assertEquals(LocalOfflineSmallLlmEngine.OfflineIntentType.DEVICE_CONTROL, chargingResult.intentType)
        assertTrue("Expected real 42% battery reading, got: ${chargingResult.responseSpeech}", chargingResult.responseSpeech.contains("42"))
        assertTrue("Expected charging state in response, got: ${chargingResult.responseSpeech}", chargingResult.responseSpeech.contains("चार्ज हो रही है"))
        assertFalse("Must never return fake 75% fallback", chargingResult.responseSpeech.contains("75"))

        // 2. Real discharging battery reading (88%, Not Charging)
        shadowBattery.setIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY, 88)
        shadowBattery.setIntProperty(
            android.os.BatteryManager.BATTERY_PROPERTY_STATUS,
            android.os.BatteryManager.BATTERY_STATUS_DISCHARGING
        )
        shadowBattery.setIsCharging(false)

        val dischargingResult = LocalOfflineSmallLlmEngine.processOfflineInference(
            context = context,
            rawPrompt = "Check battery status"
        )
        assertTrue(dischargingResult.isHandled)
        assertTrue("Expected real 88% battery reading, got: ${dischargingResult.responseSpeech}", dischargingResult.responseSpeech.contains("88"))
        assertTrue("Expected not-charging state, got: ${dischargingResult.responseSpeech}", dischargingResult.responseSpeech.contains("चार्जिंग पर नहीं है"))

        // 3. Unavailable reading must NOT fall back to hardcoded 75%
        shadowBattery.setIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY, Int.MIN_VALUE)
        val unavailableResult = LocalOfflineSmallLlmEngine.processOfflineInference(
            context = context,
            rawPrompt = "battery percentage"
        )
        assertTrue(unavailableResult.isHandled)
        assertFalse("Unavailable battery must never fabricate 75%", unavailableResult.responseSpeech.contains("75"))
    }

    @Test
    fun testQwenModelDiscoveryUsesAppPrivateFilesDirOnly() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val modelsDir = QwenOfflineModelManager.getModelsDirectory(context)
        assertTrue(
            "Models directory must live inside app-private filesDir: ${modelsDir.canonicalPath}",
            modelsDir.canonicalPath.startsWith(context.filesDir.canonicalPath)
        )

        val privateModel = java.io.File(modelsDir, QwenOfflineModelManager.PRIMARY_MODEL_FILENAME)
        try {
            FileOutputStream(privateModel).use { fos ->
                val buf = ByteBuffer.allocate(32).order(ByteOrder.LITTLE_ENDIAN)
                buf.put("GGUF".toByteArray(Charsets.US_ASCII))
                buf.putInt(3)
                buf.putLong(290L)
                buf.putLong(26L)
                buf.putLong(0L)
                fos.write(buf.array())
            }

            val found = QwenOfflineModelManager.findExistingGgufModel(context)
            assertEquals(privateModel.canonicalPath, found?.canonicalPath)
        } finally {
            privateModel.delete()
        }
    }
}
