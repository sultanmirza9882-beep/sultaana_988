package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Looper
import androidx.test.core.app.ApplicationProvider
import com.example.engine.EngineExecutionManager
import com.example.engine.EngineRegistry
import com.example.engine.EngineStatus
import com.example.engine.approval.OwnerApprovalGate
import com.example.engine.approval.SensitiveActionType
import com.example.engine.business.BusinessEngine
import com.example.engine.business.ClientProject
import com.example.engine.business.InvoiceLineItem
import com.example.engine.business.ProjectMilestone
import com.example.engine.business.ProjectStatus
import com.example.engine.media.CaptionCue
import com.example.engine.media.ImageFilterPreset
import com.example.engine.media.MediaStudioEngine
import com.example.engine.social.ConversationVibe
import com.example.engine.social.SocialMediaEngine
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Phase9MediaSocialBusinessTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        OwnerApprovalGate.resetForTest()
        SocialMediaEngine.setMetaOAuthToken(context, null)
        BusinessEngine.resetForTest(context)
    }

    @After
    fun tearDown() {
        OwnerApprovalGate.resetForTest()
        SocialMediaEngine.setMetaOAuthToken(context, null)
        BusinessEngine.resetForTest(context)
    }

    private suspend fun waitForPendingSensitiveAction(
        expectedType: SensitiveActionType,
        timeoutMs: Long = 2000L
    ): String {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            shadowOf(Looper.getMainLooper()).idle()
            val active = OwnerApprovalGate.activeActionPrompt.value
            if (active != null && active.sensitiveActionType == expectedType) {
                return active.id
            }
            delay(15L)
        }
        throw AssertionError("Timed out waiting for pending sensitive action of type $expectedType")
    }

    @Test
    fun mediaStudioGeneratesValidSrtSubtitlesImagenParsingAndVerticalStoryCard() {
        // 1. SubRip timestamp & .srt formatting
        assertEquals("00:00:00,000", MediaStudioEngine.formatSrtTimestamp(0L))
        assertEquals("00:01:05,250", MediaStudioEngine.formatSrtTimestamp(65_250L))
        assertEquals("01:02:03,004", MediaStudioEngine.formatSrtTimestamp(3_723_004L))

        val cues = listOf(
            CaptionCue(0L, 2500L, "Welcome to Muskan AI Studio"),
            CaptionCue(2500L, 5200L, "Autonomous Android Assistant")
        )
        val srt = MediaStudioEngine.generateSrtContent(cues)
        assertTrue(srt.contains("1\n00:00:00,000 --> 00:00:02,500\nWelcome to Muskan AI Studio"))
        assertTrue(srt.contains("2\n00:00:02,500 --> 00:00:05,200\nAutonomous Android Assistant"))

        val autoCues = MediaStudioEngine.generateAutoCaptionsFromScript(
            "One two three four five six seven eight nine ten",
            wordsPerCue = 5,
            msPerWord = 400L
        )
        assertEquals(2, autoCues.size)
        assertEquals(0L, autoCues[0].startMs)
        assertEquals(2000L, autoCues[0].endMs)
        assertEquals(2000L, autoCues[1].startMs)

        val srtFile = MediaStudioEngine.writeSrtFile(context, autoCues, "test_reel")
        assertTrue(srtFile.exists())
        assertTrue(srtFile.readText().contains("One two three four five"))

        // 2. Imagen JSON response extraction
        val imagenJson = """{"predictions": [{"bytesBase64Encoded": "iVBORw0KGgo="}]}"""
        assertEquals("iVBORw0KGgo=", MediaStudioEngine.extractImagenBase64Image(imagenJson))

        // 3. On-device Bitmap ColorMatrix filter & 9:16 Story card creation
        val src = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888).apply {
            eraseColor(Color.rgb(60, 120, 200))
        }
        val filtered = MediaStudioEngine.composeFilteredBitmap(src, ImageFilterPreset.NOIR, brightness = 10f, contrast = 1.2f)
        assertEquals(100, filtered.width)
        assertEquals(100, filtered.height)

        val storyFile = MediaStudioEngine.composeVerticalStoryCard(
            context = context,
            sourceBitmap = src,
            headline = "Muskan AI Launch",
            subtitle = "9:16 Ready",
            width = 270,
            height = 480
        )
        assertTrue("Story PNG should be saved in filesDir/media_studio/", storyFile.exists())
        assertTrue(storyFile.length() > 0L)
        assertTrue(storyFile.parentFile?.name == "media_studio")
    }

    @Test
    fun socialMediaVibeFormattingGraphJsonParsingAndApprovalGatingWork() = runBlocking {
        // 1. Vibe reply formatting produces distinct outputs per vibe
        val vibes = ConversationVibe.entries.associateWith { vibe ->
            SocialMediaEngine.formatFallbackVibeReply(vibe, "Love your new AI app!")
        }
        assertEquals("All 5 conversation vibes should produce distinct replies", 5, vibes.values.toSet().size)
        assertTrue(SocialMediaEngine.buildVibeReplyPrompt(ConversationVibe.FLIRTY, "Hey!").contains("Flirty"))
        assertTrue(SocialMediaEngine.buildVibeReplyPrompt(ConversationVibe.ARROGANT, "Nice work").contains("Arrogant"))

        // 2. Meta Graph API comments & publish JSON parsing
        val commentsJson = """
            {
              "data": [
                {
                  "id": "1789001",
                  "text": "Bhai zabardast update!",
                  "username": "rohit_dev",
                  "timestamp": "2026-11-20T08:00:00+0000"
                },
                {
                  "id": "1789002",
                  "message": "Interested in collaborating.",
                  "from": { "name": "Priya Verma", "id": "9988" },
                  "created_time": "2026-11-20T08:05:00+0000"
                }
              ]
            }
        """.trimIndent()
        val parsedComments = SocialMediaEngine.parseGraphCommentsJson(commentsJson)
        assertEquals(2, parsedComments.size)
        assertEquals("rohit_dev", parsedComments[0].author)
        assertEquals("Bhai zabardast update!", parsedComments[0].text)
        assertEquals("Priya Verma", parsedComments[1].author)
        assertEquals("post_5544", SocialMediaEngine.parseGraphPublishResponse("""{"id":"post_5544"}"""))

        // 3. Approval-gated social publish: deny blocks & cancels cleanly
        val denyDeferred = async {
            SocialMediaEngine.publishOrSharePost(
                context = context,
                platformLabel = "Instagram",
                caption = "Launching Muskan v9!"
            )
        }
        val denyId = waitForPendingSensitiveAction(SensitiveActionType.SOCIAL_PUBLISH)
        assertFalse("Social publish must block until owner approves", denyDeferred.isCompleted)
        OwnerApprovalGate.rejectProposal(denyId, "Not ready yet")
        val denyRes = denyDeferred.await()
        assertFalse(denyRes.success)
        assertTrue(denyRes.approvalDenied)

        // 4. Approval-gated social reply: approve proceeds via Share Intent fallback when Meta OAuth is unlinked
        val approveDeferred = async {
            SocialMediaEngine.replyToComment(
                context = context,
                commentId = "1789001",
                replyText = "Shukriya bhai!"
            )
        }
        val approveId = waitForPendingSensitiveAction(SensitiveActionType.SOCIAL_REPLY)
        assertFalse("Social reply must block until owner approves", approveDeferred.isCompleted)
        OwnerApprovalGate.approveProposal(approveId)
        val approveRes = approveDeferred.await()
        assertTrue(approveRes.success)
        assertTrue(approveRes.usedShareIntentFallback)
        assertFalse(approveRes.approvalDenied)
        assertTrue(SocialMediaEngine.META_OAUTH_REQUIREMENT_NOTE.contains("OAuth2"))
    }

    @Test
    fun businessEnginePersistsCrmCalculatesInvoicesAndGeneratesRealPdf() {
        // 1. CRM persistence across reload
        val project = ClientProject(
            id = "proj-acme-01",
            clientName = "Acme Ventures",
            clientEmail = "billing@acme.in",
            projectTitle = "AI Voice Assistant Integration",
            scope = "Android SDK + Dual Brain",
            totalPrice = 85_000.0,
            milestones = listOf(
                ProjectMilestone("Architecture & Prototype", 35_000.0, completed = true),
                ProjectMilestone("Production Delivery", 50_000.0, completed = false)
            ),
            status = ProjectStatus.IN_PROGRESS
        )
        BusinessEngine.upsertProject(context, project)

        val reloaded = BusinessEngine.loadProjects(context)
        assertEquals(1, reloaded.size)
        assertEquals("Acme Ventures", reloaded[0].clientName)
        assertEquals(2, reloaded[0].milestones.size)

        val updated = BusinessEngine.updateProjectStatus(context, "proj-acme-01", ProjectStatus.DELIVERED)
        assertNotNull(updated)
        assertEquals(ProjectStatus.DELIVERED, BusinessEngine.findProjectsByClient(context, "acme").first().status)

        // 2. Invoice totals calculation
        val items = listOf(
            InvoiceLineItem("Android App Architecture", quantity = 1, unitPrice = 40_000.0),
            InvoiceLineItem("AI Automation Modules", quantity = 2, unitPrice = 15_000.0)
        )
        val calc = BusinessEngine.calculateInvoiceTotals(items, taxRatePercent = 18.0, discountAmount = 5_000.0)
        assertEquals(70_000.0, calc.subtotal, 0.01)
        assertEquals(5_000.0, calc.discountAmount, 0.01)
        assertEquals(11_700.0, calc.taxAmount, 0.01) // 18% of 65,000
        assertEquals(76_700.0, calc.grandTotal, 0.01)

        // 3. Real Android PdfDocument invoice generation
        val invoice = BusinessEngine.generatePdfInvoice(
            context = context,
            invoiceNumber = "INV-2026-009",
            clientName = "Acme Ventures",
            clientEmail = "billing@acme.in",
            projectTitle = "AI Voice Assistant Integration",
            items = items,
            taxRatePercent = 18.0,
            discountAmount = 5_000.0
        )
        assertTrue("Invoice PDF must exist in filesDir/invoices/", invoice.pdfFile.exists())
        assertTrue(invoice.pdfFile.parentFile?.name == "invoices")
        assertTrue("PDF file must be non-empty", invoice.pdfFile.length() > 100L)
        val header = invoice.pdfFile.inputStream().use { ins ->
            val buf = ByteArray(5)
            val n = ins.read(buf)
            if (n > 0) String(buf, 0, n, Charsets.US_ASCII) else ""
        }
        assertEquals("Generated invoice must start with valid %PDF- header", "%PDF-", header)
    }

    @Test
    fun voiceCommandRouterClassifiesMediaSocialAndBusinessCommands() {
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.MEDIA_STUDIO_COMMAND,
            VoiceCommandRouter.classifyPreLlmRoute("ek futuristic cyber car ki image banao")
        )
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.MEDIA_STUDIO_COMMAND,
            VoiceCommandRouter.classifyPreLlmRoute("reel ke liye srt banao")
        )
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.SOCIAL_MEDIA_COMMAND,
            VoiceCommandRouter.classifyPreLlmRoute("instagram par flirty reply draft karo")
        )
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.SOCIAL_MEDIA_COMMAND,
            VoiceCommandRouter.classifyPreLlmRoute("AI niche ke liye content strategy banao")
        )
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.BUSINESS_COMMAND,
            VoiceCommandRouter.classifyPreLlmRoute("Acme ke liye 50000 ka pdf invoice banao")
        )
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.BUSINESS_COMMAND,
            VoiceCommandRouter.classifyPreLlmRoute("client projects pipeline summary dikhao")
        )
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.NONE,
            VoiceCommandRouter.classifyPreLlmRoute("What is the speed of light?")
        )
    }

    @Test
    fun engineRegistryAndProbesReportOperationalForMediaSocialAndBusinessEngines() = runBlocking {
        assertEquals(128, EngineRegistry.getAllEngines().size)

        val mediaProbe = EngineExecutionManager.testEngine(context, 101)
        assertEquals(EngineStatus.OPERATIONAL, mediaProbe.status)
        assertTrue(mediaProbe.isSuccess)
        assertTrue(mediaProbe.verificationNotes.contains("MediaStudioEngine"))

        val socialProbe = EngineExecutionManager.testEngine(context, 102)
        assertEquals(EngineStatus.OPERATIONAL, socialProbe.status)
        assertTrue(socialProbe.isSuccess)
        assertTrue(socialProbe.verificationNotes.contains("SocialMediaEngine"))

        val businessProbe = EngineExecutionManager.testEngine(context, 123)
        assertEquals(EngineStatus.OPERATIONAL, businessProbe.status)
        assertTrue(businessProbe.isSuccess)
        assertTrue(businessProbe.verificationNotes.contains("BusinessEngine"))
    }
}
