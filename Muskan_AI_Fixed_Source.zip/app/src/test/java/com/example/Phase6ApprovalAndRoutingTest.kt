package com.example

import android.content.Context
import android.os.Looper
import androidx.test.core.app.ApplicationProvider
import com.example.automation.AgenticExecutionPlanner
import com.example.automation.StepOutcome
import com.example.automation.UniversalPhoneAgent
import com.example.data.local.AppDatabase
import com.example.engine.approval.OwnerApprovalGate
import com.example.engine.approval.ProposalStatus
import com.example.engine.approval.SensitiveActionType
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Phase6ApprovalAndRoutingTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        OwnerApprovalGate.resetForTest()
    }

    @After
    fun tearDown() {
        OwnerApprovalGate.resetForTest()
    }

    private suspend fun waitForPendingSensitiveAction(
        expectedType: SensitiveActionType,
        timeoutMs: Long = 2000L
    ): String {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            shadowOf(Looper.getMainLooper()).idle()
            val active = OwnerApprovalGate.activeActionPrompt.value
            if (active != null && active.sensitiveActionType == expectedType) {
                return active.id
            }
            delay(15L)
        }
        throw AssertionError("Timed out waiting for pending sensitive action of type $expectedType")
    }

    @Test
    fun ownerApprovalGateStartsEmptyWithoutHardcodedMockProposals() {
        assertTrue(
            "OwnerApprovalGate must not seed fake hardcoded proposals",
            OwnerApprovalGate.proposals.value.isEmpty()
        )
        assertEquals(0, OwnerApprovalGate.pendingCount.value)
        assertNull(OwnerApprovalGate.activeActionPrompt.value)
    }

    @Test
    fun callPhonePlanBlocksUntilApprovedAndSucceedsOnApprove() = runBlocking {
        val plan = AgenticExecutionPlanner.createPlanForPrompt("call 9876543210")
        assertNotNull("Phone call prompt should produce an AgenticPlan", plan)
        val approvalStep = plan!!.steps.first()
        assertEquals("owner_approval_call_phone", approvalStep.id)

        val outcomeDeferred = async { approvalStep.action(context) }
        val proposalId = waitForPendingSensitiveAction(SensitiveActionType.CALL_PHONE)

        // Must still be suspended before owner approves
        assertFalse("CALL_PHONE approval step must remain blocked until owner decides", outcomeDeferred.isCompleted)
        assertEquals(1, OwnerApprovalGate.pendingCount.value)

        assertTrue(OwnerApprovalGate.approveProposal(proposalId))
        val outcome = outcomeDeferred.await()

        assertTrue("Expected StepOutcome.Success after approval, got $outcome", outcome is StepOutcome.Success)
        assertEquals(0, OwnerApprovalGate.pendingCount.value)
        assertNull(OwnerApprovalGate.activeActionPrompt.value)
        assertEquals(
            ProposalStatus.APPROVED,
            OwnerApprovalGate.proposals.value.first { it.id == proposalId }.status
        )
    }

    @Test
    fun callPhonePlanCancelsCleanlyWhenDenied() = runBlocking {
        val plan = AgenticExecutionPlanner.createPlanForPrompt("Aman ko call karo")
        assertNotNull("Hinglish call prompt should produce an AgenticPlan", plan)
        val approvalStep = plan!!.steps.first()
        assertEquals("owner_approval_call_phone", approvalStep.id)

        val outcomeDeferred = async { approvalStep.action(context) }
        val proposalId = waitForPendingSensitiveAction(SensitiveActionType.CALL_PHONE)

        assertFalse("CALL_PHONE step must stay blocked before denial", outcomeDeferred.isCompleted)
        assertTrue(OwnerApprovalGate.rejectProposal(proposalId, "Denied in test"))

        val outcome = outcomeDeferred.await()
        assertTrue("Expected StepOutcome.Failure when denied", outcome is StepOutcome.Failure)
        val failure = outcome as StepOutcome.Failure
        assertFalse("Denied approval must not be retried", failure.canRetry)
        assertTrue(
            "Failure reason should clearly indicate approval denial",
            failure.reason.contains("Approval denied", ignoreCase = true)
        )
        assertEquals(0, OwnerApprovalGate.pendingCount.value)
    }

    @Test
    fun sendSmsPlanBlocksUntilApprovedAndCancelsOnDeny() = runBlocking {
        val plan = AgenticExecutionPlanner.createPlanForPrompt("Aman ko SMS bhejo Hello bhai")
        assertNotNull("SMS prompt should produce an AgenticPlan", plan)
        val approvalStep = plan!!.steps.first()
        assertEquals("owner_approval_send_sms", approvalStep.id)

        // 1. Verify approve path
        val approveDeferred = async { approvalStep.action(context) }
        val approveId = waitForPendingSensitiveAction(SensitiveActionType.SEND_SMS)
        assertFalse("SEND_SMS step must block until owner decision", approveDeferred.isCompleted)
        OwnerApprovalGate.approveProposal(approveId)
        assertTrue(approveDeferred.await() is StepOutcome.Success)

        // 2. Verify deny path cancels cleanly without retries
        val denyDeferred = async { approvalStep.action(context) }
        val denyId = waitForPendingSensitiveAction(SensitiveActionType.SEND_SMS)
        assertFalse("SEND_SMS step must block until owner denial", denyDeferred.isCompleted)
        OwnerApprovalGate.rejectProposal(denyId, "User denied SMS")

        val denyOutcome = denyDeferred.await()
        assertTrue(denyOutcome is StepOutcome.Failure)
        val failure = denyOutcome as StepOutcome.Failure
        assertFalse(failure.canRetry)
        assertTrue(failure.reason.contains("Approval denied", ignoreCase = true))
    }

    @Test
    fun whatsappFinalSendStepBlocksUntilOwnerDecisionAndCancelsOnDeny() = runBlocking {
        val plan = AgenticExecutionPlanner.createPlanForPrompt("Aman ko whatsapp message bhejo Hi there")
        assertNotNull("WhatsApp prompt should produce an AgenticPlan", plan)
        val finalSendStep = plan!!.steps.last()
        assertEquals("send_message_and_verify_node", finalSendStep.id)

        val outcomeDeferred = async { finalSendStep.action(context) }
        val proposalId = waitForPendingSensitiveAction(SensitiveActionType.WHATSAPP_SEND)

        assertFalse("WhatsApp final Send must remain blocked before owner decision", outcomeDeferred.isCompleted)
        val active = OwnerApprovalGate.activeActionPrompt.value
        assertTrue(active?.targetRecipient.equals("Aman", ignoreCase = true))
        assertTrue(active?.payloadPreview.equals("Hi there", ignoreCase = true))

        OwnerApprovalGate.rejectProposal(proposalId, "Do not send WhatsApp")
        val outcome = outcomeDeferred.await()

        assertTrue("Denied WhatsApp send must return Failure", outcome is StepOutcome.Failure)
        val failure = outcome as StepOutcome.Failure
        assertFalse("Denied WhatsApp send must not trigger retry loop", failure.canRetry)
        assertTrue(failure.reason.contains("Approval denied", ignoreCase = true))
    }

    @Test
    fun executePlanStopsImmediatelyOnDenialWithoutRetries() = runBlocking {
        val plan = AgenticExecutionPlanner.createPlanForPrompt("call 9876543210")!!
        val resultDeferred = CompletableDeferred<Pair<Boolean, String>>()

        AgenticExecutionPlanner.executePlan(context, plan) { success, feedback ->
            resultDeferred.complete(success to feedback)
        }

        val proposalId = waitForPendingSensitiveAction(SensitiveActionType.CALL_PHONE)
        OwnerApprovalGate.rejectProposal(proposalId, "Owner cancelled call")

        val deadline = System.currentTimeMillis() + 2000L
        while (!resultDeferred.isCompleted && System.currentTimeMillis() < deadline) {
            shadowOf(Looper.getMainLooper()).idle()
            delay(15L)
        }
        val (success, feedback) = resultDeferred.await()
        assertFalse("Plan must fail cleanly when approval is denied", success)
        assertTrue(
            "Feedback must report denial, got: $feedback",
            feedback.contains("Approval denied", ignoreCase = true)
        )
    }

    @Test
    fun universalPhoneAgentGatesSensitiveActionsAndAllowsNonSensitiveTaps() = runBlocking {
        // Non-sensitive tap should pass immediately without queuing any approval
        val (benignOk, benignReason) = UniversalPhoneAgent.awaitApprovalIfSensitive(
            action = "tap",
            cmd = JSONObject().put("index", 1),
            targetLabel = "Search",
            foregroundPkg = "com.whatsapp"
        )
        assertTrue(benignOk)
        assertNull(benignReason)
        assertEquals(0, OwnerApprovalGate.pendingCount.value)

        // CALL_PHONE via open_url tel:
        val callDeferred = async {
            UniversalPhoneAgent.awaitApprovalIfSensitive(
                action = "open_url",
                cmd = JSONObject().put("url", "tel:+919876543210"),
                targetLabel = null,
                foregroundPkg = "com.example"
            )
        }
        val callId = waitForPendingSensitiveAction(SensitiveActionType.CALL_PHONE)
        assertFalse(callDeferred.isCompleted)
        OwnerApprovalGate.rejectProposal(callId)
        val (callOk, callReason) = callDeferred.await()
        assertFalse(callOk)
        assertTrue(callReason.orEmpty().startsWith("cancelled: owner denied CALL_PHONE"))

        // SEND_SMS via open_url smsto:
        val smsDeferred = async {
            UniversalPhoneAgent.awaitApprovalIfSensitive(
                action = "open_url",
                cmd = JSONObject().put("url", "smsto:+919876543210"),
                targetLabel = null,
                foregroundPkg = "com.example"
            )
        }
        val smsId = waitForPendingSensitiveAction(SensitiveActionType.SEND_SMS)
        assertFalse(smsDeferred.isCompleted)
        OwnerApprovalGate.approveProposal(smsId)
        val (smsOk, smsReason) = smsDeferred.await()
        assertTrue(smsOk)
        assertNull(smsReason)

        // WhatsApp final Send tap
        val waDeferred = async {
            UniversalPhoneAgent.awaitApprovalIfSensitive(
                action = "tap",
                cmd = JSONObject().put("index", 7),
                targetLabel = "Send",
                foregroundPkg = "com.whatsapp"
            )
        }
        val waId = waitForPendingSensitiveAction(SensitiveActionType.WHATSAPP_SEND)
        assertFalse(waDeferred.isCompleted)
        OwnerApprovalGate.rejectProposal(waId)
        val (waOk, waReason) = waDeferred.await()
        assertFalse(waOk)
        assertTrue(waReason.orEmpty().startsWith("cancelled: owner denied WHATSAPP_SEND"))
    }

    @Test
    fun voiceCommandRouterExtractsAndClassifiesPureIntents() {
        assertTrue(VoiceCommandRouter.containsWakeWord("Hey Muskan play music"))
        assertTrue(VoiceCommandRouter.containsWakeWord("सुनो मुस्कान"))
        assertFalse(VoiceCommandRouter.containsWakeWord("open calculator"))

        assertEquals("play music", VoiceCommandRouter.extractQueryAfterWakeWord("Hey Muskan, play music"))
        assertTrue(VoiceCommandRouter.isMuteCommand("Muskan chup raho"))
        assertTrue(VoiceCommandRouter.isUnmuteCommand("Muskan suno"))
        assertTrue(VoiceCommandRouter.isStopOrInterruptionCommand("ruko"))
        assertTrue(VoiceCommandRouter.isScreenQuery("screen par kya dikh raha hai"))
        assertTrue(VoiceCommandRouter.isTrainingCommand("training screen kholo"))

        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.STOP_INTERRUPTION,
            VoiceCommandRouter.classifyPreLlmRoute("stop")
        )
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.SCREEN_QUERY,
            VoiceCommandRouter.classifyPreLlmRoute("what is on my screen")
        )
        assertEquals(
            VoiceCommandRouter.PreLlmCommandRoute.NONE,
            VoiceCommandRouter.classifyPreLlmRoute("What is the capital of India?")
        )
    }

    @Test
    fun appDatabaseRegistersExplicitForwardMigrations() {
        assertEquals(2, AppDatabase.ALL_MIGRATIONS.size)
        assertEquals(1, AppDatabase.MIGRATION_1_2.startVersion)
        assertEquals(2, AppDatabase.MIGRATION_1_2.endVersion)
        assertEquals(2, AppDatabase.MIGRATION_2_3.startVersion)
        assertEquals(3, AppDatabase.MIGRATION_2_3.endVersion)

        val db = AppDatabase.getDatabase(context)
        assertNotNull(db.conversationTurnDao())
        assertNotNull(db.userMemoryDao())
        assertNotNull(db.taughtWorkflowDao())
    }
}
