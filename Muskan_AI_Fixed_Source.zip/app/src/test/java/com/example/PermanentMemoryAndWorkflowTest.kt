package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.TaughtWorkflowEntity
import com.example.engine.memory.PermanentMemoryEngine
import com.example.engine.workflow.TaughtWorkflowEngine
import com.example.engine.workflow.WorkflowStep
import com.example.engine.workflow.WorkflowStepType
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PermanentMemoryAndWorkflowTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = AppDatabase.getDatabase(context)
    }

    @Test
    fun testMemoryExtractionFromNaturalSpeech() = runBlocking {
        // 1. Creator name declaration
        val nameRes = PermanentMemoryEngine.inspectAndCaptureMemory(
            context = context,
            rawPrompt = "Mera naam Sultan Mirza hai"
        )
        assertTrue("Name declaration should be handled", nameRes.isHandled)
        assertEquals("CREATOR", nameRes.category)
        assertTrue(nameRes.detail.contains("Sultan Mirza"))
        assertNotNull(nameRes.confirmationSpeech)

        // 2. Preference declaration
        val prefRes = PermanentMemoryEngine.inspectAndCaptureMemory(
            context = context,
            rawPrompt = "Mujhe coffee pasand hai"
        )
        assertTrue("Preference should be handled", prefRes.isHandled)
        assertEquals("PREFERENCE", prefRes.category)
        assertTrue(prefRes.detail.contains("coffee"))

        // 3. Instruction declaration
        val instrRes = PermanentMemoryEngine.inspectAndCaptureMemory(
            context = context,
            rawPrompt = "Mujhe hamesha Hinglish mein jawab do"
        )
        assertTrue("Instruction should be handled", instrRes.isHandled)
        assertEquals("INSTRUCTION", instrRes.category)

        // Verify stored in Room database
        val memories = db.userMemoryDao().getAllMemories()
        assertTrue("Memories should be saved in Room", memories.size >= 3)
    }

    @Test
    fun testTaughtWorkflowSeedingAndTriggerMatching() = runBlocking {
        TaughtWorkflowEngine.ensureDefaultWorkflowsSeeded(context)

        val workflows = db.taughtWorkflowDao().getAllWorkflows()
        assertTrue("Default workflows must be seeded", workflows.size >= 3)

        // Match Good Morning
        val gmWf = TaughtWorkflowEngine.findMatchingWorkflow(context, "Muskan, good morning!")
        assertNotNull("Good morning trigger should match", gmWf)
        assertEquals("Good Morning Routine", gmWf?.title)

        // Match Night Routine
        val nightWf = TaughtWorkflowEngine.findMatchingWorkflow(context, "aaj ka kaam khatam good night")
        assertNotNull("Good night trigger should match", nightWf)
        assertEquals("Night Routine", nightWf?.title)

        // Match Focus Mode
        val focusWf = TaughtWorkflowEngine.findMatchingWorkflow(context, "focus mode chalao")
        assertNotNull("Focus mode trigger should match", focusWf)
        assertEquals("Focus Mode", focusWf?.title)
    }

    @Test
    fun testWorkflowSerializationAndExecution() = runBlocking {
        val steps = listOf(
            WorkflowStep(WorkflowStepType.SPEAK, "Starting workflow", 200L),
            WorkflowStep(WorkflowStepType.LAUNCH_APP, "WhatsApp", 500L),
            WorkflowStep(WorkflowStepType.SET_VOLUME, "50", 100L)
        )

        val json = TaughtWorkflowEngine.serializeSteps(steps)
        assertTrue(json.contains("LAUNCH_APP"))
        assertTrue(json.contains("WhatsApp"))

        val deserialized = TaughtWorkflowEngine.deserializeSteps(json)
        assertEquals(3, deserialized.size)
        assertEquals(WorkflowStepType.SPEAK, deserialized[0].type)
        assertEquals(WorkflowStepType.LAUNCH_APP, deserialized[1].type)
        assertEquals("WhatsApp", deserialized[1].target)

        // Insert and record execution
        val wf = TaughtWorkflowEntity(
            workflowId = UUID.randomUUID().toString(),
            title = "Test Workflow",
            triggerPhrase = "test trigger",
            stepsJson = json,
            isEnabled = true
        )
        val id = db.taughtWorkflowDao().insertWorkflow(wf)
        db.taughtWorkflowDao().recordExecution(id)

        val retrieved = db.taughtWorkflowDao().getWorkflowByRowId(id)
        assertNotNull(retrieved)
        assertEquals(1, retrieved?.executionCount)
    }

    @Test
    fun testAuthoritativeMemoryContextGeneration() = runBlocking {
        PermanentMemoryEngine.persistMemory(context, "CREATOR", "Identity", "Sultan Mirza (Owner)")
        PermanentMemoryEngine.persistMemory(context, "PREFERENCE", "Beverage", "Dark coffee without sugar")

        val block = PermanentMemoryEngine.buildAuthoritativeMemoryContext(context)
        assertTrue(block.contains("PERMANENT USER MEMORIES"))
        assertTrue(block.contains("Sultan Mirza"))
        assertTrue(block.contains("Dark coffee without sugar"))
    }
}
