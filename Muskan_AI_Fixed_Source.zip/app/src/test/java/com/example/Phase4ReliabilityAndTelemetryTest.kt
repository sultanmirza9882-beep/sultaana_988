package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.util.DisplayMetrics
import androidx.test.core.app.ApplicationProvider
import com.example.automation.AgenticExecutionPlanner
import com.example.automation.ScreenPerceptionEngine
import com.example.data.gemini.GeminiLiveAudioPlayer
import com.example.data.gemini.GeminiLiveSessionManager
import com.example.data.gemini.GeminiLiveWebSocketClient
import com.example.dsp.BiometricAudioStreamManager
import com.example.dsp.VoiceBiometricsEngine
import com.example.engine.EngineExecutionManager
import com.example.engine.EngineRegistry
import com.example.engine.EngineStatus
import com.example.service.MuskanAccessibilityService
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Phase4ReliabilityAndTelemetryTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        VoiceSessionManager.initialize(context)
    }

    @Test
    fun testBiometricStreamDefersWhenGeminiLiveOwnsMicAndClosesCleanly() {
        val engine = VoiceBiometricsEngine(context)
        val manager = BiometricAudioStreamManager(
            context = context,
            biometricsEngine = engine,
            isLiveMicOwnerActive = { true }
        )
        manager.startLiveVerificationStream()
        assertFalse("Biometric stream must not record while Gemini Live owns mic", manager.isRecording.value)
        assertTrue(
            "Verification message should report deferred mic ownership",
            manager.verificationResult.value.message.contains("Gemini Live", ignoreCase = true)
        )
        manager.close()

        val player = GeminiLiveAudioPlayer(context)
        player.close()

        val wsClient = GeminiLiveWebSocketClient(
            context = context,
            apiKeyProvider = { "" },
            systemInstructionProvider = { "Test" }
        )
        wsClient.close()

        val sessionManager = GeminiLiveSessionManager(context)
        sessionManager.close()
        assertFalse("Live mic flag must be false after close()", GeminiLiveSessionManager.isLiveMicActive())
    }

    @Test
    fun testSafeBiometricGateAllowsNormalCommandsWhenNotEnrolled() {
        assertFalse("Default VoiceUiState should not be enrolled", VoiceSessionManager.uiState.value.isVoiceBiometricsEnrolled)
        assertTrue(
            "Normal voice commands must pass checkBiometricMatch() when not yet enrolled",
            VoiceSessionManager.checkBiometricMatch()
        )
    }

    @Test
    fun testGoldPriceQueryDoesNotReturnHardcodedFakePrice() {
        val plan = AgenticExecutionPlanner.createPlanForPrompt("ChatGPT se search karo sone ka bhav kya hai")
        assertNotNull("Live search plan should be created", plan)
        assertFalse(
            "Fake hardcoded 72,800 gold price must be removed",
            plan!!.completionSpeech.contains("72,800")
        )
        assertFalse(
            "Fallback speech must not contain hardcoded 72,800 gold price",
            plan.fallbackSpeech.contains("72,800")
        )
    }

    @Test
    fun testDisplayMetricsScaledImeActionCoordinates() {
        val dm720 = DisplayMetrics().apply {
            widthPixels = 720
            heightPixels = 1600
        }
        val (x720, y720) = MuskanAccessibilityService.computeScaledImeActionKeyCoordinates(dm720)
        assertEquals(720f * (985f / 1080f), x720, 0.5f)
        assertEquals(1600f * (2255f / 2460f), y720, 0.5f)

        val dm1440 = DisplayMetrics().apply {
            widthPixels = 1440
            heightPixels = 3200
        }
        val imeBounds = Rect(0, 2100, 1440, 3100)
        val (xIme, yIme) = MuskanAccessibilityService.computeScaledImeActionKeyCoordinates(dm1440, imeBounds)
        assertTrue("IME-bounded X should stay within screen width", xIme in 1200f..1440f)
        assertTrue("IME-bounded Y should stay inside IME bottom row", yIme in 2800f..3100f)
    }

    @Test
    fun testScreenPerceptionMlKitOcrWiringAndRecycledBitmapGuard() = runBlocking {
        assertTrue("ML Kit Text Recognition should be available on classpath", ScreenPerceptionEngine.isOcrAvailable())
        val recycled = Bitmap.createBitmap(10, 10, Bitmap.Config.ARGB_8888)
        recycled.recycle()
        val result = ScreenPerceptionEngine.recognizeTextFromBitmap(recycled)
        assertFalse("Recycled bitmap should fail OCR gracefully", result.isSuccess)
    }

    @Test
    fun testHonestEngineRegistryAndExecutionTelemetry() = runBlocking {
        val all = EngineRegistry.getAllEngines()
        assertEquals(128, all.size)

        val opCount = EngineRegistry.getOperationalCount()
        val partialCount = EngineRegistry.getPartialCount()
        val notImplCount = EngineRegistry.getNotImplementedCount()

        assertTrue("Registry must contain operational engines", opCount > 0)
        assertTrue("Registry must contain partial engines", partialCount > 0)
        assertTrue("Registry must contain not-implemented engines", notImplCount > 0)
        assertTrue("Registry must not falsely report all 128 as OPERATIONAL", opCount < 128)

        val notImplResult = EngineExecutionManager.testEngine(context, 85) // Android Build Engine (on-device build not implemented)
        assertEquals(EngineStatus.NOT_IMPLEMENTED, notImplResult.status)
        assertFalse("NOT_IMPLEMENTED engine must not report isSuccess=true", notImplResult.isSuccess)

        val partialResult = EngineExecutionManager.testEngine(context, 13) // Web Search Engine (browser intent only)
        assertEquals(EngineStatus.PARTIAL, partialResult.status)

        val ocrEngineResult = EngineExecutionManager.testEngine(context, 93) // Screen Text Recognition Engine (ML Kit OCR)
        assertEquals(EngineStatus.OPERATIONAL, ocrEngineResult.status)
        assertTrue(ocrEngineResult.isSuccess)
    }
}
