package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.ConversationRepository
import com.example.data.local.ConversationTurnDao
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ConversationRoomDatabaseTest {

    private lateinit var database: AppDatabase
    private lateinit var dao: ConversationTurnDao
    private lateinit var repository: ConversationRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = database.conversationTurnDao()
        repository = ConversationRepository(dao)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testInsertAndRetrieveTurn() = runBlocking {
        repository.saveTurn(
            userQuery = "What is the capital of India?",
            assistantResponse = "The capital of India is New Delhi.",
            isAutomationAction = false,
            actionTag = "Gemini AI"
        )

        val turns = repository.recentTurns.first()
        assertEquals(1, turns.size)
        assertEquals("What is the capital of India?", turns[0].userQuery)
        assertEquals("The capital of India is New Delhi.", turns[0].assistantResponse)
        assertEquals(false, turns[0].isAutomationAction)
        assertEquals("Gemini AI", turns[0].actionTag)
    }

    @Test
    fun testUnlimitedStoragePreservesAllTurns() = runBlocking {
        // Insert 15 turns
        for (i in 1..15) {
            repository.saveTurn(
                userQuery = "Query $i",
                assistantResponse = "Response $i",
                isAutomationAction = i % 2 == 0,
                actionTag = if (i % 2 == 0) "Automation" else "Gemini AI"
            )
        }

        val turns = repository.recentTurns.first()
        // Unconstrained Room SQLite database preserves all turns without auto-deletion
        assertEquals(15, turns.size)
        // Must contain the latest turn first
        assertEquals("Query 15", turns[0].userQuery)
        assertEquals("Query 1", turns[14].userQuery)
    }

    @Test
    fun testDeleteTurnAndClearHistory() = runBlocking {
        repository.saveTurn("Turn 1", "Reply 1")
        repository.saveTurn("Turn 2", "Reply 2")

        var turns = repository.recentTurns.first()
        assertEquals(2, turns.size)

        val newestTurnId = turns[0].id
        repository.deleteTurn(newestTurnId)

        turns = repository.recentTurns.first()
        assertEquals(1, turns.size)
        assertEquals("Turn 1", turns[0].userQuery)

        repository.clearAllTurns()
        turns = repository.recentTurns.first()
        assertTrue(turns.isEmpty())
    }
}
