#include <jni.h>
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <mutex>
#include <string>
#include <vector>

#if defined(__ANDROID__)
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "MuskanLlamaJNI", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "MuskanLlamaJNI", __VA_ARGS__)
#else
#include <cstdio>
#define LOGI(...) do { std::printf(__VA_ARGS__); std::printf("\n"); } while (0)
#define LOGE(...) do { std::fprintf(stderr, __VA_ARGS__); std::fprintf(stderr, "\n"); } while (0)
#endif

#if defined(MUSKAN_HAS_LLAMA_CPP)
#include "llama.h"
#endif

namespace {

constexpr int kDefaultThreads = 6;
constexpr int kMinThreads = 1;
constexpr int kMaxThreads = 8;

constexpr int kMinCtxSize = 512;
constexpr int kDefaultCtxSize = 2048;
constexpr int kMaxCtxSize = 4096;

constexpr int kMaxBatchSize = 512;
constexpr int kMinMaxTokens = 1;
constexpr int kDefaultMaxTokens = 192;
constexpr int kHardMaxTokens = 512;
constexpr size_t kMaxOutputBytes = 32768;

std::mutex g_mutex;
std::string g_loaded_path;
int g_threads = kDefaultThreads;
int g_ctx_size = kDefaultCtxSize;
bool g_model_loaded = false;

#if defined(MUSKAN_HAS_LLAMA_CPP)
std::once_flag g_backend_once;
llama_model * g_model = nullptr;
llama_context * g_ctx = nullptr;

struct BatchGuard {
    llama_batch batch;
    explicit BatchGuard(llama_batch b) : batch(b) {}
    ~BatchGuard() {
        llama_batch_free(batch);
    }
    BatchGuard(const BatchGuard &) = delete;
    BatchGuard & operator=(const BatchGuard &) = delete;
};

struct SamplerGuard {
    llama_sampler * smpl;
    explicit SamplerGuard(llama_sampler * s) : smpl(s) {}
    ~SamplerGuard() {
        if (smpl != nullptr) {
            llama_sampler_free(smpl);
        }
    }
    SamplerGuard(const SamplerGuard &) = delete;
    SamplerGuard & operator=(const SamplerGuard &) = delete;
};

inline void batch_add_token(
        llama_batch & batch,
        llama_token id,
        llama_pos pos,
        llama_seq_id seq_id,
        bool logits) {
    const int32_t idx = batch.n_tokens;
    batch.token[idx] = id;
    batch.pos[idx] = pos;
    batch.n_seq_id[idx] = 1;
    batch.seq_id[idx][0] = seq_id;
    batch.logits[idx] = logits ? 1 : 0;
    batch.n_tokens = idx + 1;
}

// Strips stop markers, embedded NULs, and any incomplete trailing multi-byte UTF-8 sequence
// so JNI NewStringUTF never aborts on truncated Devanagari or emoji sequences.
std::string sanitize_utf8_output(std::string text) {
    const char * stop_markers[] = {"<|im_end|>", "<|endoftext|>"};
    for (const char * marker : stop_markers) {
        const size_t pos = text.find(marker);
        if (pos != std::string::npos) {
            text.erase(pos);
        }
    }

    text.erase(std::remove(text.begin(), text.end(), '\0'), text.end());

    // Trim any incomplete trailing UTF-8 sequence.
    while (!text.empty()) {
        const unsigned char last = static_cast<unsigned char>(text.back());
        if ((last & 0x80u) == 0u) {
            break; // Complete ASCII byte
        }
        size_t i = text.size();
        size_t cont_count = 0;
        while (i > 0 && (static_cast<unsigned char>(text[i - 1]) & 0xC0u) == 0x80u) {
            --i;
            ++cont_count;
        }
        if (i == 0) {
            text.clear();
            break;
        }
        const unsigned char lead = static_cast<unsigned char>(text[i - 1]);
        size_t expected_len = 0;
        if ((lead & 0xE0u) == 0xC0u) {
            expected_len = 2;
        } else if ((lead & 0xF0u) == 0xE0u) {
            expected_len = 3;
        } else if ((lead & 0xF8u) == 0xF0u) {
            expected_len = 4;
        } else {
            // Invalid lead byte; drop it.
            text.erase(i - 1);
            continue;
        }
        if (1 + cont_count == expected_len) {
            break; // Valid complete multi-byte UTF-8 character
        }
        text.erase(i - 1);
    }

    return text;
}
#endif

bool verify_gguf_file(const std::string & path) {
    std::ifstream in(path, std::ios::binary);
    if (!in.is_open()) return false;
    char magic[4] = {0};
    in.read(magic, 4);
    if (in.gcount() != 4) return false;
    if (magic[0] != 'G' || magic[1] != 'G' || magic[2] != 'U' || magic[3] != 'F') {
        return false;
    }
    uint32_t version = 0;
    in.read(reinterpret_cast<char *>(&version), sizeof(version));
    return in.good() && (version >= 2 && version <= 3);
}

void cleanup_locked() {
#if defined(MUSKAN_HAS_LLAMA_CPP)
    if (g_ctx != nullptr) {
        llama_free(g_ctx);
        g_ctx = nullptr;
    }
    if (g_model != nullptr) {
        llama_model_free(g_model);
        g_model = nullptr;
    }
#endif
    g_model_loaded = false;
    g_loaded_path.clear();
}

} // namespace

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_engine_llm_LlamaCppBridge_loadModelNative(
        JNIEnv * env,
        jclass /*clazz*/,
        jstring jModelPath,
        jint nThreads,
        jint nCtx) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (jModelPath == nullptr) return JNI_FALSE;

    const char * rawPath = env->GetStringUTFChars(jModelPath, nullptr);
    std::string path(rawPath ? rawPath : "");
    if (rawPath != nullptr) {
        env->ReleaseStringUTFChars(jModelPath, rawPath);
    }

    if (!verify_gguf_file(path)) {
        LOGE("Invalid or missing GGUF file: %s", path.c_str());
        return JNI_FALSE;
    }

    const int req_threads = (nThreads >= kMinThreads && nThreads <= kMaxThreads)
            ? static_cast<int>(nThreads)
            : kDefaultThreads;
    const int req_ctx = (nCtx >= kMinCtxSize && nCtx <= kMaxCtxSize)
            ? static_cast<int>(nCtx)
            : kDefaultCtxSize;

#if defined(MUSKAN_HAS_LLAMA_CPP)
    // Thread-safe context reuse when the same GGUF model and parameters are already loaded.
    if (g_model_loaded &&
        g_loaded_path == path &&
        g_threads == req_threads &&
        g_ctx_size == req_ctx &&
        g_model != nullptr &&
        g_ctx != nullptr) {
        LOGI("Reusing loaded GGUF context: %s (threads=%d, n_ctx=%d)",
             path.c_str(), g_threads, g_ctx_size);
        return JNI_TRUE;
    }
#endif

    cleanup_locked();
    g_threads = req_threads;
    g_ctx_size = req_ctx;

#if defined(MUSKAN_HAS_LLAMA_CPP)
    std::call_once(g_backend_once, []() {
        llama_backend_init();
    });

    llama_model_params model_params = llama_model_default_params();
    model_params.n_gpu_layers = 0; // CPU ARM64 NEON/dotprod inference on Snapdragon 4 Gen 2
    model_params.use_mmap = true;
    model_params.use_mlock = false; // Keep RAM usage safe on 8 GB mobile devices

    g_model = llama_model_load_from_file(path.c_str(), model_params);
    if (g_model == nullptr) {
        LOGE("llama_model_load_from_file failed for %s", path.c_str());
        return JNI_FALSE;
    }

    const int batch_cap = std::min(g_ctx_size, kMaxBatchSize);
    llama_context_params ctx_params = llama_context_default_params();
    ctx_params.n_ctx = static_cast<uint32_t>(g_ctx_size);
    ctx_params.n_batch = static_cast<uint32_t>(batch_cap);
    ctx_params.n_ubatch = static_cast<uint32_t>(batch_cap);
    ctx_params.n_threads = g_threads;
    ctx_params.n_threads_batch = g_threads;

    g_ctx = llama_init_from_model(g_model, ctx_params);
    if (g_ctx == nullptr) {
        LOGE("llama_init_from_model failed for %s", path.c_str());
        llama_model_free(g_model);
        g_model = nullptr;
        return JNI_FALSE;
    }
#endif

    g_loaded_path = path;
    g_model_loaded = true;
    LOGI("Loaded GGUF model: %s (threads=%d, n_ctx=%d)", path.c_str(), g_threads, g_ctx_size);
    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_engine_llm_LlamaCppBridge_isModelLoadedNative(
        JNIEnv * /*env*/,
        jclass /*clazz*/) {
    std::lock_guard<std::mutex> lock(g_mutex);
#if defined(MUSKAN_HAS_LLAMA_CPP)
    return (g_model_loaded && g_model != nullptr && g_ctx != nullptr) ? JNI_TRUE : JNI_FALSE;
#else
    return g_model_loaded ? JNI_TRUE : JNI_FALSE;
#endif
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_engine_llm_LlamaCppBridge_generateCompletionNative(
        JNIEnv * env,
        jclass /*clazz*/,
        jstring jPrompt,
        jint maxTokens,
        jfloat temperature) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model_loaded || jPrompt == nullptr) {
        return env->NewStringUTF("");
    }

    const char * rawPrompt = env->GetStringUTFChars(jPrompt, nullptr);
    std::string prompt(rawPrompt ? rawPrompt : "");
    if (rawPrompt != nullptr) {
        env->ReleaseStringUTFChars(jPrompt, rawPrompt);
    }
    if (prompt.empty()) {
        return env->NewStringUTF("");
    }

#if defined(MUSKAN_HAS_LLAMA_CPP)
    if (g_model == nullptr || g_ctx == nullptr) {
        return env->NewStringUTF("");
    }

    // Reuse the loaded context cleanly across calls by clearing KV memory.
    llama_memory_clear(llama_get_memory(g_ctx), true);

    const llama_vocab * vocab = llama_model_get_vocab(g_model);
    if (vocab == nullptr) {
        LOGE("llama_model_get_vocab returned null");
        return env->NewStringUTF("");
    }

    // 1. Tokenize prompt (two-pass exact allocation).
    int32_t token_capacity = static_cast<int32_t>(prompt.size()) + 32;
    std::vector<llama_token> prompt_tokens(static_cast<size_t>(token_capacity));
    int32_t n_prompt_tokens = llama_tokenize(
        vocab,
        prompt.c_str(),
        static_cast<int32_t>(prompt.size()),
        prompt_tokens.data(),
        token_capacity,
        true,
        true
    );
    if (n_prompt_tokens < 0) {
        token_capacity = -n_prompt_tokens;
        prompt_tokens.resize(static_cast<size_t>(token_capacity));
        n_prompt_tokens = llama_tokenize(
            vocab,
            prompt.c_str(),
            static_cast<int32_t>(prompt.size()),
            prompt_tokens.data(),
            token_capacity,
            true,
            true
        );
    }
    if (n_prompt_tokens <= 0) {
        LOGE("llama_tokenize produced %d tokens", n_prompt_tokens);
        return env->NewStringUTF("");
    }
    prompt_tokens.resize(static_cast<size_t>(n_prompt_tokens));

    // Reserve room in the KV cache for generation so we never overflow n_ctx.
    const int requested_limit = (maxTokens > 0)
            ? std::clamp(static_cast<int>(maxTokens), kMinMaxTokens, kHardMaxTokens)
            : kDefaultMaxTokens;
    const int min_gen_headroom = std::min(64, g_ctx_size / 4);
    const int max_prompt_tokens = std::max(1, g_ctx_size - min_gen_headroom);
    if (static_cast<int>(prompt_tokens.size()) > max_prompt_tokens) {
        prompt_tokens.erase(
            prompt_tokens.begin(),
            prompt_tokens.end() - max_prompt_tokens
        );
    }

    // 2. Allocate reusable llama_batch with RAII cleanup and chunk prompt prefill <= n_batch.
    const int batch_cap = std::min(g_ctx_size, kMaxBatchSize);
    BatchGuard batch_guard(llama_batch_init(batch_cap, 0, 1));
    llama_batch & batch = batch_guard.batch;

    llama_pos n_cur = 0;
    const size_t total_prompt = prompt_tokens.size();
    for (size_t offset = 0; offset < total_prompt; offset += static_cast<size_t>(batch_cap)) {
        const size_t chunk_len = std::min(static_cast<size_t>(batch_cap), total_prompt - offset);
        batch.n_tokens = 0;
        for (size_t j = 0; j < chunk_len; ++j) {
            const bool is_last_prompt_token = (offset + j + 1 == total_prompt);
            batch_add_token(batch, prompt_tokens[offset + j], n_cur, 0, is_last_prompt_token);
            ++n_cur;
        }
        if (llama_decode(g_ctx, batch) != 0) {
            LOGE("llama_decode failed during prompt prefill at pos=%d", static_cast<int>(n_cur));
            return env->NewStringUTF("");
        }
    }

    // 3. Configure sampler chain (greedy when temperature <= 0.05, otherwise top-k + top-p + temp).
    auto sparams = llama_sampler_chain_default_params();
    SamplerGuard sampler_guard(llama_sampler_chain_init(sparams));
    llama_sampler * smpl = sampler_guard.smpl;
    if (smpl == nullptr) {
        LOGE("llama_sampler_chain_init failed");
        return env->NewStringUTF("");
    }

    if (temperature <= 0.05f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        const float safe_temp = std::clamp(static_cast<float>(temperature), 0.06f, 2.0f);
        llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.90f, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(safe_temp));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    }

    // 4. Autoregressive token generation with RAM-safe token and byte bounds.
    const int remaining_ctx = std::max(0, g_ctx_size - static_cast<int>(n_cur) - 1);
    const int effective_limit = std::min(requested_limit, remaining_ctx);

    std::string result;
    result.reserve(std::min<size_t>(static_cast<size_t>(effective_limit) * 8, kMaxOutputBytes));
    std::vector<char> piece_buf(256);

    for (int step = 0; step < effective_limit; ++step) {
        const llama_token new_token_id = llama_sampler_sample(smpl, g_ctx, -1);
        llama_sampler_accept(smpl, new_token_id);

        if (llama_vocab_is_eog(vocab, new_token_id)) {
            break;
        }

        int32_t piece_len = llama_token_to_piece(
            vocab,
            new_token_id,
            piece_buf.data(),
            static_cast<int32_t>(piece_buf.size()),
            0,
            true
        );
        if (piece_len < 0) {
            piece_buf.resize(static_cast<size_t>(-piece_len));
            piece_len = llama_token_to_piece(
                vocab,
                new_token_id,
                piece_buf.data(),
                static_cast<int32_t>(piece_buf.size()),
                0,
                true
            );
        }
        if (piece_len > 0) {
            result.append(piece_buf.data(), static_cast<size_t>(piece_len));
            if (result.find("<|im_end|>") != std::string::npos ||
                result.find("<|endoftext|>") != std::string::npos ||
                result.size() >= kMaxOutputBytes) {
                break;
            }
        }

        if (step + 1 >= effective_limit) {
            break;
        }

        batch.n_tokens = 0;
        batch_add_token(batch, new_token_id, n_cur, 0, true);
        ++n_cur;

        if (llama_decode(g_ctx, batch) != 0) {
            LOGE("llama_decode failed during generation at step=%d", step);
            break;
        }
    }

    const std::string clean_output = sanitize_utf8_output(std::move(result));
    return env->NewStringUTF(clean_output.c_str());
#else
    (void)maxTokens;
    (void)temperature;
    return env->NewStringUTF("[LLAMA_STUB]");
#endif
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_engine_llm_LlamaCppBridge_freeModelNative(
        JNIEnv * /*env*/,
        jclass /*clazz*/) {
    std::lock_guard<std::mutex> lock(g_mutex);
    cleanup_locked();
}
