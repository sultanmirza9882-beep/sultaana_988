cmake_minimum_required(VERSION 3.22.1)
project("muskan_llama_jni" LANGUAGES C CXX)

set(CMAKE_C_STANDARD 11)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

set(LLAMA_CPP_DIR "${CMAKE_CURRENT_SOURCE_DIR}/llama.cpp")

if(EXISTS "${LLAMA_CPP_DIR}/CMakeLists.txt")
    message(STATUS "Muskan Offline AI: Found llama.cpp source at ${LLAMA_CPP_DIR}, building full GGUF inference engine")

    # Disable standalone CLI/server/tests and host-native flags for clean Android ARM64 cross-compilation
    set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
    set(LLAMA_BUILD_COMMON OFF CACHE BOOL "" FORCE)
    set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
    set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
    set(LLAMA_BUILD_TOOLS OFF CACHE BOOL "" FORCE)
    set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)
    set(LLAMA_CURL OFF CACHE BOOL "" FORCE)
    set(LLAMA_OPENSSL OFF CACHE BOOL "" FORCE)
    set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
    set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
    set(GGML_LLAMAFILE OFF CACHE BOOL "" FORCE)
    set(GGML_BACKEND_DL OFF CACHE BOOL "" FORCE)
    set(GGML_CPU_ALL_VARIANTS OFF CACHE BOOL "" FORCE)

    add_subdirectory("${LLAMA_CPP_DIR}" build-llama EXCLUDE_FROM_ALL)

    add_library(muskan_llama_jni SHARED llama_jni.cpp)
    target_compile_definitions(muskan_llama_jni PRIVATE MUSKAN_HAS_LLAMA_CPP=1)
    if(ANDROID_ABI STREQUAL "arm64-v8a")
        target_compile_options(muskan_llama_jni PRIVATE -O3)
    endif()
    target_include_directories(muskan_llama_jni PRIVATE
        "${LLAMA_CPP_DIR}/include"
        "${LLAMA_CPP_DIR}/ggml/include"
    )
    target_link_libraries(muskan_llama_jni PRIVATE
        llama
        ggml
        android
        log
    )
else()
    message(STATUS "Muskan Offline AI: llama.cpp source not present; building GGUF header-verifier JNI bridge")
    add_library(muskan_llama_jni SHARED llama_jni.cpp)
    if(ANDROID_ABI STREQUAL "arm64-v8a")
        target_compile_options(muskan_llama_jni PRIVATE -O3)
    endif()
    target_link_libraries(muskan_llama_jni PRIVATE
        android
        log
    )
endif()
