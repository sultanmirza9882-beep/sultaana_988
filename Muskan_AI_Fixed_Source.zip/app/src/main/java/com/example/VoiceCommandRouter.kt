package com.example

import com.example.engine.dev.SelfDevelopmentEngine
import com.example.ui.controller.MuskanUIController
import java.util.Locale

/**
 * Pure, stateless command and intent classification helpers extracted from [VoiceSessionManager]
 * to decouple voice pipeline lifecycle management from prompt routing rules.
 */
object VoiceCommandRouter {

    enum class PreLlmCommandRoute {
        STOP_INTERRUPTION,
        SCREEN_QUERY,
        DASHBOARD_UI,
        LEARNING_INQUIRY,
        ERROR_INQUIRY,
        SELF_DEVELOPMENT,
        WEBSOCKET_WEBRTC,
        TRAINING_SCREEN,
        CALENDAR_COMMAND,
        EMAIL_COMMAND,
        CALLING_COMMAND,
        OSINT_COMMAND,
        MEDIA_STUDIO_COMMAND,
        SOCIAL_MEDIA_COMMAND,
        BUSINESS_COMMAND,
        NONE
    }

    private val stopPhrases = listOf(
        "ruko", "ruk jao", "stop", "cancel", "abort", "chup", "chup raho",
        "band karo", "roko", "rok do", "khatam karo", "ruk", "rukjao", "pause", "wait",
        "ruk ja", "ruk jaiye", "ruk jaao"
    )

    private val automationTriggers = listOf(
        "whatsapp", "message bhejo", "message karo", "text bhejo", "text karo",
        "youtube", "video chalao", "skip ad", "skip add", "ad skip",
        "torch", "flashlight", "volume", "awaz", "mute karo",
        "bluetooth", "wifi", "hotspot",
        "camera", "photo kheencho", "selfie",
        "instagram", "reels scroll",
        "call karo", "call lagao", "phone mila",
        "calculator", "alarm lagao"
    )

    private val wakeWordPrefixRegex = Regex(
        "(?i)^.*?(hey|hello|hi|ok|suno|arre|हे|सुनो|अरे)?\\s*(muskan|muskaan|muscan|mus khan|मुस्कान)[,:\\s]*"
    )

    fun containsWakeWord(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT)
        return lower.contains("muskan") ||
            lower.contains("muskaan") ||
            lower.contains("muscan") ||
            lower.contains("mus khan") ||
            lower.contains("मुस्कान") ||
            lower.contains("hey muskan") ||
            lower.contains("hello muskan") ||
            lower.contains("suno muskan") ||
            lower.contains("arre muskan") ||
            lower.contains("सुनो मुस्कान") ||
            lower.contains("हे मुस्कान") ||
            lower.contains("अरे मुस्कान")
    }

    fun extractQueryAfterWakeWord(text: String): String {
        return text.replace(wakeWordPrefixRegex, "").trim()
    }

    fun isMuteCommand(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT)
        return (containsWakeWord(lower) || lower.contains("muskan")) &&
            (lower.contains("mute") ||
                lower.contains("chup") ||
                lower.contains("chup raho") ||
                lower.contains("chup ho jao") ||
                lower.contains("shant raho") ||
                lower.contains("stop listening"))
    }

    fun isUnmuteCommand(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT)
        return (containsWakeWord(lower) || lower.contains("muskan")) &&
            (lower.contains("unmute") ||
                lower.contains("suno") ||
                lower.contains("bolo") ||
                lower.contains("wake up") ||
                lower.contains("start listening"))
    }

    fun isStopOrInterruptionCommand(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT).trim()
        return stopPhrases.any { lower.contains(it) }
    }

    fun isTrainingCommand(prompt: String): Boolean {
        val l = prompt.lowercase(Locale.ROOT)
        val topic = l.contains("training") || l.contains("ट्रेनिंग") || l.contains("train screen") || l.contains("sikhane wali screen")
        val open = l.contains("kholo") || l.contains("खोलो") || l.contains("open") || l.contains("dikhao") || l.contains("दिखाओ")
        return topic && open
    }

    fun isDeviceAutomationRequest(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        return automationTriggers.any { lower.contains(it) }
    }

    fun isScreenQuery(prompt: String): Boolean {
        val lowerPrompt = prompt.lowercase(Locale.ROOT).trim()
        return lowerPrompt.contains("screen dekho") ||
            lowerPrompt.contains("screen par kya") ||
            lowerPrompt.contains("display par kya") ||
            lowerPrompt.contains("screen share") ||
            lowerPrompt.contains("screen activity") ||
            lowerPrompt.contains("what is on my screen") ||
            lowerPrompt.contains("what's on my screen") ||
            lowerPrompt.contains("kya dikh raha hai") ||
            lowerPrompt.contains("screen padho") ||
            lowerPrompt.contains("screen read")
    }

    fun isSkipAdCommand(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        return lower.contains("skip ad") ||
            lower.contains("skip add") ||
            lower.contains("ad skip") ||
            lower.contains("add skip") ||
            lower.contains("skip karo") ||
            lower.contains("skip kro") ||
            lower.contains("ad hatao") ||
            lower.contains("add hatao") ||
            lower == "skip"
    }

    fun isDashboardUiCommand(prompt: String): Boolean {
        val lowerPrompt = prompt.lowercase(Locale.ROOT).trim()
        return lowerPrompt.contains("box") ||
            lowerPrompt.contains("widget") ||
            lowerPrompt.contains("dashboard") ||
            lowerPrompt.contains("sultana") ||
            MuskanUIController.isDashboardWidgetCommand(prompt)
    }

    fun isLearningInquiry(prompt: String): Boolean {
        val lowerPrompt = prompt.lowercase(Locale.ROOT).trim()
        return lowerPrompt.contains("seekha") ||
            lowerPrompt.contains("kya sikha") ||
            (lowerPrompt.contains("naya") && lowerPrompt.contains("learn")) ||
            lowerPrompt.contains("procedural memory") ||
            lowerPrompt.contains("procedure")
    }

    fun isErrorInquiry(prompt: String): Boolean {
        val lowerPrompt = prompt.lowercase(Locale.ROOT).trim()
        return lowerPrompt.contains("error") ||
            lowerPrompt.contains("kharabi") ||
            lowerPrompt.contains("koi issue") ||
            lowerPrompt.contains("problem") ||
            (lowerPrompt.contains("koi") && lowerPrompt.contains("dikkat"))
    }

    fun isWebSocketOrWebRtcCommand(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        return lower.contains("websocket") ||
            lower.contains("वेबसॉकेट") ||
            lower.contains("webrtc") ||
            lower.contains("signaling")
    }

    fun isCalendarCommand(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        if (lower.isBlank()) return false
        val calendarTerms = listOf(
            "aaj ka schedule", "kal ka schedule", "mera schedule", "my schedule",
            "calendar", "कैलेंडर", "शेड्यूल",
            "meeting set", "meeting schedule", "schedule meeting", "schedule a meeting",
            "meeting rakho", "meeting fix", "upcoming meeting", "upcoming events",
            "appointment", "अपॉइंटमेंट", "मीटिंग सेट", "मीटिंग शेड्यूल",
            "calendar event", "event set karo", "event add karo", "reschedule meeting",
            "delete meeting", "kya meeting hai", "koi meeting hai"
        )
        return calendarTerms.any { lower.contains(it) } ||
            ((lower.contains("meeting") || lower.contains("मीटिंग")) &&
                (lower.contains("baje") || lower.contains("बजे") || lower.contains("am") || lower.contains("pm") ||
                    lower.contains("set") || lower.contains("book") || lower.contains("schedule") || lower.contains("kal") || lower.contains("aaj")))
    }

    fun isEmailCommand(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        if (lower.isBlank()) return false
        val emailTerms = listOf(
            "unread email", "unread mail", "emails padho", "email padho",
            "mail padho", "email check", "emails check", "check email", "check my email",
            "email draft", "mail draft", "draft email", "draft an email", "draft a mail",
            "email bhejo", "mail bhejo", "send email", "send an email", "send mail",
            "reply email", "email reply", "email summarize", "inbox", "gmail",
            "ईमेल", "मेल भेजो", "मेल पढ़ो", "इनबॉक्स"
        )
        return emailTerms.any { lower.contains(it) }
    }

    fun isCallingCommand(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        if (lower.isBlank()) return false
        val callingTerms = listOf(
            "last call summary", "call summary", "pichli call", "pichhli call",
            "missed call summary", "missed calls summary", "screened calls",
            "spam calls", "spam call", "scam call", "scam calls", "blocked calls",
            "call screening", "caller follow up", "caller followup", "callback message",
            "number block karo", "block number", "caller block",
            "कॉल समरी", "स्पैम कॉल", "पिछली कॉल"
        )
        return callingTerms.any { lower.contains(it) }
    }

    fun isOsintCommand(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        if (lower.isBlank()) return false
        val osintTerms = listOf(
            "is link ko check", "link check karo", "check this link", "link safe hai",
            "url check", "check url", "phishing check", "scam check", "scam link",
            "domain research", "domain check", "domain info", "website safe hai",
            "website check karo", "whois", "rdap", "dns check", "osint",
            "लिंक चेक", "डोमेन रिसर्च", "वेबसाइट सेफ"
        )
        return osintTerms.any { lower.contains(it) }
    }

    fun isMediaStudioCommand(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        if (lower.isBlank()) return false
        val mediaTerms = listOf(
            "image banao", "photo generate", "generate image", "ai image", "imagen",
            "story card banao", "poster banao", "reel caption", "srt banao", "subtitle banao",
            "caption file", "video trim", "video edit", "media studio",
            "इमेज बनाओ", "पोस्टर बनाओ", "सबटाइटल बनाओ"
        )
        return mediaTerms.any { lower.contains(it) }
    }

    fun isSocialMediaCommand(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        if (lower.isBlank()) return false
        val socialTerms = listOf(
            "instagram reply", "comment reply", "flirty reply", "friendly reply",
            "arrogant reply", "professional reply", "hinglish reply",
            "content strategy", "instagram strategy", "social media post",
            "hashtag strategy", "reel story", "9:16 story", "instagram post",
            "facebook post", "social publish", "इंस्टाग्राम पोस्ट", "कंटेंट स्ट्रैटेजी"
        )
        return socialTerms.any { lower.contains(it) }
    }

    fun isBusinessCommand(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        if (lower.isBlank()) return false
        val businessTerms = listOf(
            "invoice banao", "generate invoice", "create invoice", "pdf invoice",
            "bill banao", "client crm", "client add", "add client", "naya client",
            "client projects", "business summary", "project pipeline", "client invoice",
            "इनवॉइस बनाओ", "क्लाइंट प्रोजेक्ट"
        )
        return businessTerms.any { lower.contains(it) }
    }

    fun classifyPreLlmRoute(prompt: String): PreLlmCommandRoute {
        if (prompt.isBlank()) return PreLlmCommandRoute.NONE
        return when {
            isStopOrInterruptionCommand(prompt) -> PreLlmCommandRoute.STOP_INTERRUPTION
            isScreenQuery(prompt) -> PreLlmCommandRoute.SCREEN_QUERY
            isDashboardUiCommand(prompt) -> PreLlmCommandRoute.DASHBOARD_UI
            isLearningInquiry(prompt) -> PreLlmCommandRoute.LEARNING_INQUIRY
            isErrorInquiry(prompt) -> PreLlmCommandRoute.ERROR_INQUIRY
            SelfDevelopmentEngine.isSelfDevelopmentPrompt(prompt) -> PreLlmCommandRoute.SELF_DEVELOPMENT
            isWebSocketOrWebRtcCommand(prompt) -> PreLlmCommandRoute.WEBSOCKET_WEBRTC
            isTrainingCommand(prompt) -> PreLlmCommandRoute.TRAINING_SCREEN
            isCalendarCommand(prompt) -> PreLlmCommandRoute.CALENDAR_COMMAND
            isEmailCommand(prompt) -> PreLlmCommandRoute.EMAIL_COMMAND
            isCallingCommand(prompt) -> PreLlmCommandRoute.CALLING_COMMAND
            isOsintCommand(prompt) -> PreLlmCommandRoute.OSINT_COMMAND
            isMediaStudioCommand(prompt) -> PreLlmCommandRoute.MEDIA_STUDIO_COMMAND
            isSocialMediaCommand(prompt) -> PreLlmCommandRoute.SOCIAL_MEDIA_COMMAND
            isBusinessCommand(prompt) -> PreLlmCommandRoute.BUSINESS_COMMAND
            else -> PreLlmCommandRoute.NONE
        }
    }
}
