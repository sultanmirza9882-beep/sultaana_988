package com.example.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Offline keyword response engine.
 * Provides instant answers to common questions and utility queries (time, date, battery, greetings, identity, status)
 * even without internet access or if Gemini API is unreachable.
 */
object OfflineKeywordResponder {

    data class OfflineResponse(
        val answer: String,
        val category: String
    )

    /**
     * Attempts to find a tailored offline response for [rawPrompt].
     * Returns null if no known local offline pattern matches.
     */
    fun matchOfflineResponse(rawPrompt: String): OfflineResponse? {
        val p = rawPrompt.lowercase(Locale.ROOT).trim()

        // 1. Time / Samay
        if (isTimeQuery(p)) {
            val timeStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            return OfflineResponse(
                answer = "Abhi samay ho raha hai $timeStr.",
                category = "Time"
            )
        }

        // 2. Date / Tareekh / Day
        if (isDateQuery(p)) {
            val dateStr = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
            return OfflineResponse(
                answer = "Aaj $dateStr hai.",
                category = "Date"
            )
        }

        // 3. Name / Identity / Creator
        if (isCreatorQuery(p)) {
            return OfflineResponse(
                answer = "Mujhe Sultan Mirza ne banaya hai! Main unki personal AI voice assistant hoon, unhi ke standards aur priorities par kaam karti hoon.",
                category = "Creator"
            )
        }

        if (isIdentityQuery(p)) {
            return OfflineResponse(
                answer = "Mera naam Muskan hai! Sultan Mirza ki personal ethereal AI voice assistant, hamesha aapki sewa mein hazir.",
                category = "Identity"
            )
        }

        // 4. Greetings
        if (isGreetingQuery(p)) {
            val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
            val greeting = when (hour) {
                in 4..11 -> "Namaste aur Good morning! Aaj main aapki kya madad kar sakti hoon?"
                in 12..16 -> "Namaste aur Good afternoon! Boliye, kya sahayata chahiye?"
                in 17..21 -> "Namaste aur Good evening! Boliye, kya madad karoon?"
                else -> "Namaste! Itni raat ko bhi main aapki sewa mein hazir hoon. Boliye?"
            }
            return OfflineResponse(answer = greeting, category = "Greeting")
        }

        // 5. Well-being / Kaise ho
        if (isWellBeingQuery(p)) {
            return OfflineResponse(
                answer = "Main bilkul badhiya aur energetic hoon! Aap batayein, aapka din kaisa chal raha hai?",
                category = "WellBeing"
            )
        }

        // 6. Capability / Tum kya kar sakti ho
        if (isCapabilityQuery(p)) {
            return OfflineResponse(
                answer = "Main phone control kar sakti hoon jaise WhatsApp messages bhejna, YouTube search, screen navigation, aur aapke sawaalon ke jawab dena.",
                category = "Capability"
            )
        }

        // 7. Thank you / Shukriya
        if (isThanksQuery(p)) {
            return OfflineResponse(
                answer = "Aapka swagat hai! Madad karke bahut khushi hui. Kuch aur chahiye toh bataiye.",
                category = "Politeness"
            )
        }

        // 8. Autonomous Agent Query
        if (p.contains("agent") || (p.contains("neeche") && p.contains("kaam")) || (p.contains("niche") && p.contains("kam"))) {
            return OfflineResponse(
                answer = "सुल्तान सर, मुस्कान खुद एक डायरेक्ट ऑटोनॉमस मोबाइल एजेंट है। किसी सब-एजेंट की ज़रूरत नहीं, स्क्रीन पर सभी टच, स्वाइप और एक्शंस मुस्कान सीधे खुद पूरा करती है।",
                category = "Autonomous Agent"
            )
        }

        // 9. Help / Help command
        if (isHelpQuery(p)) {
            return OfflineResponse(
                answer = "Aap mujhse pooch sakte hain: 'WhatsApp par message bhejo', 'YouTube par gana chalao', 'Go home', ya koi bhi sawaal.",
                category = "Help"
            )
        }

        return null
    }

    /**
     * Fallback generator when Gemini network fails, returning either a tailored offline answer
     * or a graceful offline acknowledgment.
     */
    fun getGracefulOfflineFallback(prompt: String): OfflineResponse {
        val matched = matchOfflineResponse(prompt)
        if (matched != null) {
            return matched
        }

        return OfflineResponse(
            answer = "Network connect nahi ho pa raha hai, lekin main sun rahi hoon. Aap offline commands jaise Home, Back, open apps, time ya date use kar sakte hain.",
            category = "Offline Fallback"
        )
    }

    // --- Matchers ---

    private fun isTimeQuery(p: String): Boolean {
        return p == "time" || p == "what time is it" || p == "time kya hua hai" ||
                p.contains("kya time hua") || p.contains("kitne baje") ||
                p.contains("samay kya hai") || p.contains("current time") ||
                p.contains("time batao")
    }

    private fun isDateQuery(p: String): Boolean {
        return p == "date" || p == "what is the date" || p.contains("aaj kaun si date hai") ||
                p.contains("aaj ki date") || p.contains("aaj date") || p.contains("aaj kaun sa din hai") ||
                p.contains("today's date") || p.contains("tareekh kya hai") ||
                p.contains("date batao") || p.contains("what day is it") ||
                p.contains("aaj ki tareekh")
    }

    private fun isCreatorQuery(p: String): Boolean {
        return p.contains("who made you") || p.contains("who created you") ||
                p.contains("kisne banaya") || p.contains("kon banaya") ||
                p.contains("sultan mirza") || p.contains("who is your developer") ||
                p.contains("creator kaun") || p.contains("developer kaun")
    }

    private fun isIdentityQuery(p: String): Boolean {
        return p.contains("who are you") || p.contains("tum kaun ho") ||
                p.contains("aap kaun ho") || p.contains("tumhara naam kya hai") ||
                p.contains("aapka naam kya hai") || p.contains("what is your name") ||
                p.contains("introduce yourself") || p.contains("apna parichay do")
    }

    private fun isGreetingQuery(p: String): Boolean {
        return p == "hello" || p == "hi" || p == "hey" || p == "namaste" ||
                p == "good morning" || p == "good evening" || p == "good afternoon" ||
                p.startsWith("hello muskan") || p.startsWith("hi muskan") ||
                p.startsWith("namaste muskan")
    }

    private fun isWellBeingQuery(p: String): Boolean {
        return p.contains("kaise ho") || p.contains("kaisi ho") ||
                p.contains("kaisa chal raha hai") || p.contains("how are you") ||
                p.contains("sab theek") || p.contains("kya haal hai")
    }

    private fun isCapabilityQuery(p: String): Boolean {
        return p.contains("kya kar sakti ho") || p.contains("what can you do") ||
                p.contains("tumhare features") || p.contains("kya aata hai") ||
                p.contains("capabilities")
    }

    private fun isThanksQuery(p: String): Boolean {
        return p.contains("thank you") || p.contains("thanks") ||
                p.contains("shukriya") || p.contains("dhanyawad") ||
                p.contains("bohot accha")
    }

    private fun isHelpQuery(p: String): Boolean {
        return p == "help" || p == "madad" || p.contains("help me") ||
                p.contains("kya bolu") || p.contains("instructions")
    }
}
