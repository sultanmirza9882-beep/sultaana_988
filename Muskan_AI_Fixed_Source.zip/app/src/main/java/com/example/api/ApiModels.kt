package com.example.api

import com.squareup.moshi.JsonClass

enum class ApiProvider {
    GEMINI,
    OPENAI_COMPATIBLE
}

enum class ApiStatus {
    NOT_VERIFIED,
    VERIFYING,
    VERIFIED,
    CONNECTED,
    ACTIVE,
    INVALID_KEY,
    MODEL_UNAVAILABLE,
    QUOTA_EXHAUSTED,
    RATE_LIMITED,
    NETWORK_ERROR,
    CONFIGURATION_ERROR
}

enum class ApiErrorType {
    NONE,
    INVALID_API_KEY,
    AUTHENTICATION_FAILED,
    QUOTA_EXCEEDED,
    RATE_LIMIT,
    NETWORK_UNAVAILABLE,
    SERVER_ERROR,
    MODEL_OR_ENDPOINT_NOT_FOUND,
    PROVIDER_ERROR
}

data class ModelDiscoveryResult(
    val isSuccess: Boolean,
    val models: List<String> = emptyList(),
    val recommendedModel: String? = null,
    val errorMessage: String? = null
)

data class ApiVerificationResult(
    val isSuccess: Boolean,
    val status: ApiStatus = if (isSuccess) ApiStatus.VERIFIED else ApiStatus.NOT_VERIFIED,
    val errorType: ApiErrorType = ApiErrorType.NONE,
    val message: String,
    val responseLatencyMs: Long = 0L,
    val discoveredModels: List<String> = emptyList(),
    val selectedModel: String? = null
)

@JsonClass(generateAdapter = true)
data class ApiProfile(
    val id: String,
    val name: String,
    val provider: ApiProvider = ApiProvider.GEMINI,
    val apiKey: String,
    val endpointUrl: String = "",
    val modelId: String = "gemini-1.5-flash",
    val isVerified: Boolean = false,
    val verificationMessage: String = "Not Verified",
    val lastVerifiedTimestamp: Long = 0L,
    val lastErrorCode: Int? = null,
    val lastErrorType: ApiErrorType = ApiErrorType.NONE,
    val rateLimitBackoffUntil: Long = 0L,
    val availableModels: List<String> = emptyList(),
    val status: ApiStatus = if (isVerified) ApiStatus.VERIFIED else ApiStatus.NOT_VERIFIED
) {
    val isDefault: Boolean get() = id == DEFAULT_ID

    fun getMaskedApiKey(): String {
        if (isDefault) return "System Default (BuildConfig)"
        if (apiKey.isBlank()) return "No Key"
        if (apiKey.length <= 10) return "••••••••"
        val prefix = apiKey.take(6)
        val suffix = apiKey.takeLast(4)
        return "$prefix...••••...$suffix"
    }

    companion object {
        const val DEFAULT_ID = "default"
    }
}
