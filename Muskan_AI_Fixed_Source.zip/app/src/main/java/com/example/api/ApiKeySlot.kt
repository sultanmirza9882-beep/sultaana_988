package com.example.api

import com.squareup.moshi.JsonClass

enum class KeySlotStatus {
    ACTIVE,
    EXHAUSTED,
    INVALID,
    COOLING_DOWN,
    NOT_CONFIGURED
}

@JsonClass(generateAdapter = true)
data class ApiKeySlot(
    val slotIndex: Int, // 0 = Custom Open Slot, 1..19 = Hardcoded Default Pool
    val label: String,
    val keyString: String,
    val provider: ApiProvider = ApiProvider.GEMINI,
    val endpointUrl: String = "",
    val modelId: String = "gemini-2.0-flash",
    val status: KeySlotStatus = KeySlotStatus.ACTIVE,
    val lastUsedTimestamp: Long = 0L,
    val errorCount: Int = 0,
    val requestsToday: Int = 0,
    val cooldownUntilTimestamp: Long = 0L,
    val isCustomSlot: Boolean = (slotIndex == 0)
) {
    fun isAvailable(now: Long = System.currentTimeMillis()): Boolean {
        if (keyString.isBlank()) return false
        if (status == KeySlotStatus.INVALID || status == KeySlotStatus.NOT_CONFIGURED) return false
        if (status == KeySlotStatus.EXHAUSTED) return false
        if (cooldownUntilTimestamp > now) return false
        return true
    }

    companion object {
        fun isPlaceholderKey(key: String): Boolean {
            val k = key.trim()
            return k.isBlank() ||
                    k == "MY_GEMINI_API_KEY" ||
                    k.startsWith("AIzaSyDefaultPoolKey") ||
                    k.startsWith("AIzaSyDDefaultKey") ||
                    k.startsWith("AIzaDummy") ||
                    k.startsWith("sk-dummy")
        }
    }

    fun getMaskedKey(): String {
        if (keyString.isBlank()) return "Not Set"
        if (keyString.length <= 8) return "••••••••"
        val prefix = keyString.take(4)
        val suffix = keyString.takeLast(4)
        return "$prefix...••••...$suffix"
    }
}
