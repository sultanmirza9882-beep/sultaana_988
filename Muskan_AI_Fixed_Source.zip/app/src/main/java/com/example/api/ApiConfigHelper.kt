package com.example.api

import java.util.regex.Pattern

data class ExtractedApiKeyResult(
    val originalInput: String,
    val cleanedKey: String,
    val detectedProvider: ApiProvider?,
    val recommendedModel: String?,
    val recommendedEndpoint: String?,
    val hintMessage: String?
)

object ApiConfigHelper {

    private val BEARER_REGEX = Pattern.compile("""(?i)Bearer\s+([a-zA-Z0-9_\-\.]{10,})""")
    private val AUTH_HEADER_REGEX = Pattern.compile("""(?i)Authorization:\s*Bearer\s+([a-zA-Z0-9_\-\.]{10,})""")
    private val KEY_PARAM_REGEX = Pattern.compile("""(?i)[?&]key=([a-zA-Z0-9_\-\.]{10,})""")
    private val JSON_KEY_REGEX = Pattern.compile("""(?i)["'](?:api[_-]?key|key|secret)["']\s*:\s*["']([a-zA-Z0-9_\-\.]{10,})["']""")
    private val ENV_KEY_REGEX = Pattern.compile("""(?i)(?:GEMINI_API_KEY|OPENAI_API_KEY|GROQ_API_KEY|API_KEY)\s*=\s*["']?([a-zA-Z0-9_\-\.]{10,})["']?""")
    private val DIRECT_GEMINI_REGEX = Pattern.compile("""((?:AIza[0-9A-Za-z_\-]{10,})|(?:AQ\.[0-9A-Za-z_\-\.]{10,})|(?:AQ[0-9A-Za-z_\-\.]{10,}))""")
    private val DIRECT_OPENAI_REGEX = Pattern.compile("""(sk-(?:proj-|none-)?[0-9A-Za-z_\-]{10,})""")
    private val DIRECT_GROQ_REGEX = Pattern.compile("""(gsk_[0-9A-Za-z_\-]{10,})""")
    private val DIRECT_CLAUDE_REGEX = Pattern.compile("""(sk-ant-[0-9A-Za-z_\-]{10,})""")
    private val DIRECT_OPENROUTER_REGEX = Pattern.compile("""(sk-or-[0-9A-Za-z_\-]{10,})""")
    private val DIRECT_PERPLEXITY_REGEX = Pattern.compile("""(pplx-[0-9A-Za-z_\-]{10,})""")

    /**
     * Sanitizes any pasted input (raw keys, curl commands, JSON wrappers, URLs, env vars, surrounding quotes)
     * and universally auto-detects the provider and recommended model without truncating user keys.
     * Fully compatible with all Google AI Studio free API keys of any version or length.
     */
    fun analyzeAndCleanKey(rawInput: String): ExtractedApiKeyResult {
        // Strip invisible Unicode zero-width spaces, non-breaking spaces, and newlines
        val sanitized = rawInput
            .replace("\u200B", "")
            .replace("\uFEFF", "")
            .replace("\u00A0", "")
            .replace("\r", "")
            .replace("\n", "")
            .replace("\t", "")
            .trim()

        if (sanitized.isBlank()) {
            return ExtractedApiKeyResult(
                originalInput = rawInput,
                cleanedKey = "",
                detectedProvider = null,
                recommendedModel = null,
                recommendedEndpoint = null,
                hintMessage = null
            )
        }

        var candidateKey = ""
        var hint: String? = null

        // 1. Direct Pattern Extraction (Google Gemini / AI Studio key)
        val geminiMatcher = DIRECT_GEMINI_REGEX.matcher(sanitized)
        val openAiMatcher = DIRECT_OPENAI_REGEX.matcher(sanitized)
        val groqMatcher = DIRECT_GROQ_REGEX.matcher(sanitized)
        val claudeMatcher = DIRECT_CLAUDE_REGEX.matcher(sanitized)
        val openRouterMatcher = DIRECT_OPENROUTER_REGEX.matcher(sanitized)
        val perplexityMatcher = DIRECT_PERPLEXITY_REGEX.matcher(sanitized)

        if (geminiMatcher.find()) {
            candidateKey = geminiMatcher.group(1).orEmpty()
            hint = "Google AI Studio Free API Key (${candidateKey.length} chars)"
        } else if (openAiMatcher.find()) {
            candidateKey = openAiMatcher.group(1).orEmpty()
            hint = "OpenAI API Key (${candidateKey.length} chars)"
        } else if (groqMatcher.find()) {
            candidateKey = groqMatcher.group(1).orEmpty()
            hint = "Groq API Key (${candidateKey.length} chars)"
        } else if (claudeMatcher.find()) {
            candidateKey = claudeMatcher.group(1).orEmpty()
            hint = "Anthropic Claude API Key (${candidateKey.length} chars)"
        } else if (openRouterMatcher.find()) {
            candidateKey = openRouterMatcher.group(1).orEmpty()
            hint = "OpenRouter API Key (${candidateKey.length} chars)"
        } else if (perplexityMatcher.find()) {
            candidateKey = perplexityMatcher.group(1).orEmpty()
            hint = "Perplexity API Key (${candidateKey.length} chars)"
        }
        // 2. URL query param (?key=AIzaSy... or &key=...)
        else if (sanitized.contains("?key=") || sanitized.contains("&key=")) {
            val paramMatcher = KEY_PARAM_REGEX.matcher(sanitized)
            if (paramMatcher.find()) {
                candidateKey = paramMatcher.group(1).orEmpty()
                hint = "Extracted API key from URL parameter"
            }
        }
        // 3. Detect curl command / Authorization header
        else if (sanitized.contains("Bearer ", ignoreCase = true)) {
            val bearerMatcher = BEARER_REGEX.matcher(sanitized)
            if (bearerMatcher.find()) {
                candidateKey = bearerMatcher.group(1).orEmpty()
                hint = "Extracted API key from Bearer token"
            }
        }
        // 4. Detect JSON object (e.g. {"apiKey": "..."})
        else if (sanitized.contains("{") && sanitized.contains("}")) {
            val jsonMatcher = JSON_KEY_REGEX.matcher(sanitized)
            if (jsonMatcher.find()) {
                candidateKey = jsonMatcher.group(1).orEmpty()
                hint = "Extracted API key from JSON payload"
            }
        }
        // 5. Detect ENV assignment (e.g. GEMINI_API_KEY=AIzaSy...)
        else if (sanitized.contains("=")) {
            val envMatcher = ENV_KEY_REGEX.matcher(sanitized)
            if (envMatcher.find()) {
                candidateKey = envMatcher.group(1).orEmpty()
                hint = "Extracted API key from environment variable definition"
            }
        }

        // 6. Universal Fallback: Strip prefixes like "API Key:", "Key:", "gemini key:", quotes, whitespace
        if (candidateKey.isBlank()) {
            var raw = sanitized
            if (raw.contains(":") || raw.contains("=")) {
                val afterDelimiter = if (raw.contains(":")) raw.substringAfter(":") else raw.substringAfter("=")
                if (afterDelimiter.isNotBlank()) {
                    raw = afterDelimiter.trim()
                }
            }
            // Strip quotes and spaces
            candidateKey = raw.trim('\"', '\'', '`', '\\', ' ', '\t')
                .replace(" ", "")

            hint = when {
                candidateKey.startsWith("AIza") || candidateKey.startsWith("AQ") -> "Google AI Studio API Key (${candidateKey.length} chars)"
                candidateKey.startsWith("sk-") -> "OpenAI API Key (${candidateKey.length} chars)"
                candidateKey.startsWith("gsk_") -> "Groq API Key (${candidateKey.length} chars)"
                candidateKey.isNotBlank() -> "Custom API Key (${candidateKey.length} chars)"
                else -> null
            }
        }

        // Final sanitation
        candidateKey = candidateKey
            .replace(" ", "")
            .trim('\"', '\'', '`', '\\')

        // Provider & model auto-detection
        val (provider, model, endpoint, providerHint) = detectProviderAndDefaults(candidateKey, sanitized)

        val finalHint = when {
            hint != null && providerHint != null && hint != providerHint -> "$hint • $providerHint"
            hint != null -> hint
            else -> providerHint
        }

        return ExtractedApiKeyResult(
            originalInput = rawInput,
            cleanedKey = candidateKey,
            detectedProvider = provider,
            recommendedModel = model,
            recommendedEndpoint = endpoint,
            hintMessage = finalHint
        )
    }

    private data class ProviderDefaults(
        val provider: ApiProvider?,
        val model: String?,
        val endpoint: String?,
        val hint: String?
    )

    private fun detectProviderAndDefaults(key: String, fullText: String): ProviderDefaults {
        // Google Gemini check: starts with AIza or new Google AI Studio AQ. prefix
        if (key.startsWith("AIza") || key.startsWith("AQ.") || key.startsWith("AQ")) {
            return ProviderDefaults(
                provider = ApiProvider.GEMINI,
                model = "gemini-2.0-flash",
                endpoint = "https://generativelanguage.googleapis.com/",
                hint = "Google AI Studio API Key (Gemini 2.0 Flash)"
            )
        }

        // Groq check: starts with gsk_
        if (key.startsWith("gsk_")) {
            return ProviderDefaults(
                provider = ApiProvider.OPENAI_COMPATIBLE,
                model = "llama-3.3-70b-versatile",
                endpoint = "https://api.groq.com/openai/v1",
                hint = "Auto-detected: Groq API Key (Ultra-fast Llama 3.3)"
            )
        }

        // Perplexity check: starts with pplx-
        if (key.startsWith("pplx-")) {
            return ProviderDefaults(
                provider = ApiProvider.OPENAI_COMPATIBLE,
                model = "sonar",
                endpoint = "https://api.perplexity.ai",
                hint = "Auto-detected: Perplexity Sonar API Key"
            )
        }

        // OpenRouter check: starts with sk-or-
        if (key.startsWith("sk-or-")) {
            return ProviderDefaults(
                provider = ApiProvider.OPENAI_COMPATIBLE,
                model = "meta-llama/llama-3.3-70b-instruct",
                endpoint = "https://openrouter.ai/api/v1",
                hint = "Auto-detected: OpenRouter API Key"
            )
        }

        // Anthropic Claude check: starts with sk-ant-
        if (key.startsWith("sk-ant-")) {
            return ProviderDefaults(
                provider = ApiProvider.OPENAI_COMPATIBLE,
                model = "claude-3-5-sonnet-20241022",
                endpoint = "https://api.anthropic.com/v1",
                hint = "Auto-detected: Anthropic API Key"
            )
        }

        // OpenAI check: starts with sk- or sk-proj-
        if (key.startsWith("sk-") || key.startsWith("sk-proj-")) {
            return ProviderDefaults(
                provider = ApiProvider.OPENAI_COMPATIBLE,
                model = "gpt-4o-mini",
                endpoint = "https://api.openai.com",
                hint = "Auto-detected: OpenAI API Key (GPT-4o Mini)"
            )
        }

        // Check if endpoint mentions known host
        if (fullText.contains("generativelanguage.googleapis.com")) {
            return ProviderDefaults(
                provider = ApiProvider.GEMINI,
                model = "gemini-1.5-flash",
                endpoint = "https://generativelanguage.googleapis.com/",
                hint = "Auto-detected: Google Generative AI Endpoint"
            )
        }

        if (fullText.contains("api.openai.com")) {
            return ProviderDefaults(
                provider = ApiProvider.OPENAI_COMPATIBLE,
                model = "gpt-4o-mini",
                endpoint = "https://api.openai.com",
                hint = "Auto-detected: OpenAI Endpoint"
            )
        }

        return ProviderDefaults(
            provider = if (key.isNotBlank()) ApiProvider.GEMINI else null,
            model = if (key.isNotBlank()) "gemini-2.0-flash" else null,
            endpoint = if (key.isNotBlank()) "https://generativelanguage.googleapis.com/" else null,
            hint = if (key.isNotBlank()) "Google AI Studio Key (Gemini 2.0 Flash)" else null
        )
    }

    /**
     * Normalizes OpenAI-compatible base URL to prevent duplicate /v1 paths
     */
    fun buildOpenAiChatUrl(rawEndpoint: String): String {
        val base = if (rawEndpoint.isNotBlank()) rawEndpoint.trim().trimEnd('/') else "https://api.openai.com"
        return when {
            base.endsWith("/chat/completions") -> base
            base.endsWith("/v1") -> "$base/chat/completions"
            else -> "$base/v1/chat/completions"
        }
    }

    fun cleanModelId(rawModel: String): String {
        val sanitized = rawModel.trim()
            .trimStart('/')
            .removePrefix("models/")
            .trimStart('/')
            .removeSuffix(":generateContent")
            .trim()
        return when {
            sanitized.isBlank() -> "gemini-2.0-flash"
            sanitized == "gemini-1.5-flash-8b" -> "gemini-2.0-flash"
            else -> sanitized
        }
    }

    /**
     * Strictly normalizes Gemini generateContent URL:
     * https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={apiKey}
     */
    fun buildGeminiUrl(rawEndpoint: String, modelId: String, apiKey: String): String {
        val model = cleanModelId(modelId)
        val cleanKey = apiKey.trim()
        return "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$cleanKey"
    }

    /**
     * Normalizes OpenAI-compatible models discovery URL
     */
    fun buildOpenAiModelsUrl(rawEndpoint: String): String {
        val base = if (rawEndpoint.isNotBlank()) rawEndpoint.trim().trimEnd('/') else "https://api.openai.com"
        return when {
            base.endsWith("/models") -> base
            base.endsWith("/v1") -> "$base/models"
            base.endsWith("/chat/completions") -> base.removeSuffix("/chat/completions") + "/models"
            else -> "$base/v1/models"
        }
    }

    /**
     * Normalizes Gemini models list URL
     */
    fun buildGeminiModelsListUrl(rawEndpoint: String, apiKey: String): String {
        val base = if (rawEndpoint.isNotBlank()) rawEndpoint.trim().trimEnd('/') else "https://generativelanguage.googleapis.com"
        val cleanKey = apiKey.trim()
        return if (base.contains("models")) {
            if (base.contains("?")) "$base&key=$cleanKey" else "$base?key=$cleanKey"
        } else {
            "$base/v1beta/models?key=$cleanKey"
        }
    }
}
