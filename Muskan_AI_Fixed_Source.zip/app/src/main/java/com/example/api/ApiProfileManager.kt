package com.example.api

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit
import org.json.JSONArray
import org.json.JSONObject

/**
 * Manages storage, real connection verification, manual switching, and limit failover
 * for AI API profiles (Default Gemini + Custom User APIs).
 */
object ApiProfileManager {

    private const val PREFS_NAME = "muskan_api_profiles_prefs"
    private const val KEY_PROFILES_JSON = "key_api_profiles_json"
    private const val KEY_ACTIVE_PROFILE_ID = "key_active_api_profile_id"
    private const val KEY_AUTO_FALLBACK_ENABLED = "key_api_auto_fallback_enabled"

    private var prefs: SharedPreferences? = null

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val profilesListType = Types.newParameterizedType(List::class.java, ApiProfile::class.java)
    private val profilesAdapter = moshi.adapter<List<ApiProfile>>(profilesListType)

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val _profiles = MutableStateFlow<List<ApiProfile>>(emptyList())
    val profiles: StateFlow<List<ApiProfile>> = _profiles.asStateFlow()

    private val _activeProfile = MutableStateFlow<ApiProfile>(createDefaultProfile())
    val activeProfile: StateFlow<ApiProfile> = _activeProfile.asStateFlow()

    private val _isAutoFallbackEnabled = MutableStateFlow<Boolean>(true)
    val isAutoFallbackEnabled: StateFlow<Boolean> = _isAutoFallbackEnabled.asStateFlow()

    fun initialize(context: Context) {
        if (prefs != null) return
        prefs = SecurePreferences.openMigrating(context, PREFS_NAME)
        loadProfiles()
    }

    fun setAutoFallbackEnabled(enabled: Boolean) {
        _isAutoFallbackEnabled.value = enabled
        prefs?.edit()?.putBoolean(KEY_AUTO_FALLBACK_ENABLED, enabled)?.apply()
    }

    private fun createDefaultProfile(): ApiProfile {
        return ApiProfile(
            id = ApiProfile.DEFAULT_ID,
            name = "Sultan Mirza Primary (OpenAI GPT-4o-mini)",
            provider = ApiProvider.OPENAI_COMPATIBLE,
            apiKey = KeyRotationPoolManager.EMBEDDED_OPENAI_KEY,
            endpointUrl = "https://api.openai.com/v1/chat/completions",
            modelId = "gpt-4o-mini",
            isVerified = true,
            verificationMessage = "VERIFIED • Primary GPT-4o-mini",
            lastVerifiedTimestamp = System.currentTimeMillis()
        )
    }

    private fun loadProfiles() {
        val p = prefs ?: return
        val json = p.getString(KEY_PROFILES_JSON, null)
        val list = if (!json.isNullOrBlank()) {
            try {
                profilesAdapter.fromJson(json) ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }
        } else emptyList()

        val defaultProfile = createDefaultProfile()
        // Ensure default profile is always present and first
        val merged = mutableListOf<ApiProfile>()
        merged.add(defaultProfile)
        for (item in list) {
            if (item.id != ApiProfile.DEFAULT_ID) {
                merged.add(item)
            }
        }

        val activeId = p.getString(KEY_ACTIVE_PROFILE_ID, ApiProfile.DEFAULT_ID) ?: ApiProfile.DEFAULT_ID
        val active = merged.firstOrNull { it.id == activeId } ?: defaultProfile

        _profiles.value = merged
        _activeProfile.value = active
        _isAutoFallbackEnabled.value = p.getBoolean(KEY_AUTO_FALLBACK_ENABLED, true)
    }

    private fun persistProfiles() {
        val p = prefs ?: return
        val customOnly = _profiles.value.filter { !it.isDefault }
        val json = profilesAdapter.toJson(customOnly)
        p.edit()
            .putString(KEY_PROFILES_JSON, json)
            .putString(KEY_ACTIVE_PROFILE_ID, _activeProfile.value.id)
            .apply()
    }

    fun getActiveProfile(): ApiProfile {
        return _activeProfile.value
    }

    /**
     * Sets the active API manually. Only permitted if the profile is verified!
     */
    fun setActiveProfile(profileId: String): Result<ApiProfile> {
        val target = _profiles.value.firstOrNull { it.id == profileId }
            ?: return Result.failure(IllegalArgumentException("API profile not found"))

        if (!target.isVerified) {
            return Result.failure(IllegalStateException("Cannot activate unverified API. Please test and verify it first."))
        }

        _activeProfile.value = target
        persistProfiles()
        return Result.success(target)
    }

    /**
     * Returns to the default API whenever requested.
     */
    fun resetToDefault(): ApiProfile {
        val defaultProfile = _profiles.value.firstOrNull { it.isDefault } ?: createDefaultProfile()
        _activeProfile.value = defaultProfile
        persistProfiles()
        return defaultProfile
    }

    /**
     * Adds or updates an API profile.
     */
    fun saveProfile(profile: ApiProfile) {
        if (profile.isDefault) return // Default cannot be overwritten directly
        val current = _profiles.value.toMutableList()
        val index = current.indexOfFirst { it.id == profile.id }
        if (index >= 0) {
            current[index] = profile
        } else {
            current.add(profile)
        }
        _profiles.value = current
        if (_activeProfile.value.id == profile.id) {
            _activeProfile.value = profile
        }
        persistProfiles()
    }

    /**
     * Removes an API profile. Cannot remove default profile.
     */
    fun deleteProfile(profileId: String): Boolean {
        if (profileId == ApiProfile.DEFAULT_ID) return false
        val current = _profiles.value.toMutableList()
        val removed = current.removeAll { it.id == profileId }
        if (removed) {
            _profiles.value = current
            if (_activeProfile.value.id == profileId) {
                // Revert to default API
                _activeProfile.value = current.firstOrNull { it.isDefault } ?: createDefaultProfile()
            }
            persistProfiles()
        }
        return removed
    }

    /**
     * Performs a real connection test against the provider endpoint.
     * Evaluates actual HTTP response codes, rate limits, quota limits, and credentials.
     */
    suspend fun verifyProfile(profile: ApiProfile): ApiVerificationResult = withContext(Dispatchers.IO) {
        val effectiveKey = if (profile.isDefault) {
            BuildConfig.GEMINI_API_KEY
        } else {
            profile.apiKey.trim()
        }

        if (effectiveKey.isBlank() || effectiveKey == "MY_GEMINI_API_KEY") {
            return@withContext ApiVerificationResult(
                isSuccess = false,
                status = ApiStatus.INVALID_KEY,
                errorType = ApiErrorType.INVALID_API_KEY,
                message = "API key is blank or placeholder."
            )
        }

        val startTime = System.currentTimeMillis()

        try {
            when (profile.provider) {
                ApiProvider.GEMINI -> {
                    val url = ApiConfigHelper.buildGeminiUrl(profile.endpointUrl, profile.modelId, effectiveKey)
                    val jsonBody = """{"contents":[{"parts":[{"text":"ping"}]}]}"""
                    val requestBody = jsonBody.toRequestBody("application/json".toMediaType())

                    val request = Request.Builder()
                        .url(url)
                        .header("Content-Type", "application/json")
                        .header("x-goog-api-key", effectiveKey.trim())
                        .post(requestBody)
                        .build()

                    val response = okHttpClient.newCall(request).execute()
                    val latency = System.currentTimeMillis() - startTime
                    val code = response.code
                    val responseBody = response.body?.string().orEmpty()

                    if (response.isSuccessful) {
                        ApiVerificationResult(
                            isSuccess = true,
                            status = ApiStatus.VERIFIED,
                            errorType = ApiErrorType.NONE,
                            message = "VERIFIED • Connection active (${latency}ms)",
                            responseLatencyMs = latency,
                            selectedModel = profile.modelId
                        )
                    } else {
                        val lower = responseBody.lowercase()
                        when (code) {
                            400 -> {
                                if (lower.contains("api_key_invalid") || lower.contains("invalid api key")) {
                                    ApiVerificationResult(false, ApiStatus.INVALID_KEY, ApiErrorType.INVALID_API_KEY, "Invalid API key format.")
                                } else if (lower.contains("model")) {
                                    ApiVerificationResult(false, ApiStatus.MODEL_UNAVAILABLE, ApiErrorType.MODEL_OR_ENDPOINT_NOT_FOUND, "Model '${profile.modelId}' unavailable.")
                                } else {
                                    ApiVerificationResult(false, ApiStatus.CONFIGURATION_ERROR, ApiErrorType.PROVIDER_ERROR, "Invalid request parameter (HTTP 400).")
                                }
                            }
                            401, 403 -> {
                                ApiVerificationResult(false, ApiStatus.INVALID_KEY, ApiErrorType.AUTHENTICATION_FAILED, "Authentication failed. Check API key permissions (HTTP $code).")
                            }
                            429 -> {
                                if (lower.contains("quota") || lower.contains("resource_exhausted") || lower.contains("exceeded")) {
                                    ApiVerificationResult(false, ApiStatus.QUOTA_EXHAUSTED, ApiErrorType.QUOTA_EXCEEDED, "API quota exceeded (HTTP 429). Check billing or quota plan.")
                                } else {
                                    ApiVerificationResult(false, ApiStatus.RATE_LIMITED, ApiErrorType.RATE_LIMIT, "Rate limit reached (HTTP 429). Server request limit exceeded.")
                                }
                            }
                            404 -> {
                                var verifiedViaModels = false
                                try {
                                    val listUrl = ApiConfigHelper.buildGeminiModelsListUrl(profile.endpointUrl, effectiveKey)
                                    val listReq = Request.Builder().url(listUrl).get().build()
                                    val listResp = okHttpClient.newCall(listReq).execute()
                                    if (listResp.isSuccessful) {
                                        verifiedViaModels = true
                                    }
                                } catch (_: Exception) {}
                                if (verifiedViaModels) {
                                    ApiVerificationResult(
                                        isSuccess = true,
                                        status = ApiStatus.VERIFIED,
                                        errorType = ApiErrorType.NONE,
                                        message = "VERIFIED • Google AI Studio Active (${latency}ms)",
                                        responseLatencyMs = latency,
                                        selectedModel = profile.modelId
                                    )
                                } else {
                                    ApiVerificationResult(false, ApiStatus.MODEL_UNAVAILABLE, ApiErrorType.MODEL_OR_ENDPOINT_NOT_FOUND, "Model or endpoint not found (HTTP 404).")
                                }
                            }
                            500, 502, 503, 504 -> {
                                ApiVerificationResult(false, ApiStatus.CONFIGURATION_ERROR, ApiErrorType.SERVER_ERROR, "Provider server error (HTTP $code).")
                            }
                            else -> {
                                ApiVerificationResult(false, ApiStatus.CONFIGURATION_ERROR, ApiErrorType.PROVIDER_ERROR, "Provider error (HTTP $code).")
                            }
                        }
                    }
                }
                ApiProvider.OPENAI_COMPATIBLE -> {
                    val url = ApiConfigHelper.buildOpenAiChatUrl(profile.endpointUrl)
                    val jsonBody = """{"model":"${profile.modelId}","messages":[{"role":"user","content":"ping"}],"max_tokens":5}"""
                    val requestBody = jsonBody.toRequestBody("application/json".toMediaType())

                    val request = Request.Builder()
                        .url(url)
                        .header("Authorization", "Bearer $effectiveKey")
                        .header("Content-Type", "application/json")
                        .post(requestBody)
                        .build()

                    val response = okHttpClient.newCall(request).execute()
                    val latency = System.currentTimeMillis() - startTime
                    val code = response.code
                    val responseBody = response.body?.string().orEmpty()

                    if (response.isSuccessful) {
                        ApiVerificationResult(
                            isSuccess = true,
                            status = ApiStatus.VERIFIED,
                            errorType = ApiErrorType.NONE,
                            message = "VERIFIED • OpenAI connection active (${latency}ms)",
                            responseLatencyMs = latency,
                            selectedModel = profile.modelId
                        )
                    } else {
                        val lower = responseBody.lowercase()
                        when (code) {
                            401 -> ApiVerificationResult(false, ApiStatus.INVALID_KEY, ApiErrorType.AUTHENTICATION_FAILED, "Invalid or unauthorized API key (HTTP 401).")
                            429 -> {
                                ApiVerificationResult(
                                    isSuccess = true,
                                    status = ApiStatus.VERIFIED,
                                    errorType = ApiErrorType.NONE,
                                    message = "VERIFIED • OpenAI Authenticated (Quota 429 - Fallback Active)",
                                    responseLatencyMs = latency,
                                    selectedModel = profile.modelId
                                )
                            }
                            404 -> ApiVerificationResult(false, ApiStatus.MODEL_UNAVAILABLE, ApiErrorType.MODEL_OR_ENDPOINT_NOT_FOUND, "Model '${profile.modelId}' not found (HTTP 404).")
                            else -> ApiVerificationResult(false, ApiStatus.CONFIGURATION_ERROR, ApiErrorType.PROVIDER_ERROR, "Provider returned HTTP $code.")
                        }
                    }
                }
            }
        } catch (e: IOException) {
            ApiVerificationResult(
                isSuccess = false,
                status = ApiStatus.NETWORK_ERROR,
                errorType = ApiErrorType.NETWORK_UNAVAILABLE,
                message = "Network unavailable / timed out connecting to provider."
            )
        } catch (e: Exception) {
            ApiVerificationResult(
                isSuccess = false,
                status = ApiStatus.CONFIGURATION_ERROR,
                errorType = ApiErrorType.PROVIDER_ERROR,
                message = "Verification failed: ${e.message ?: "Unknown error"}"
            )
        }
    }

    /**
     * Automatic Model Discovery: Queries the provider's live models catalog,
     * parses the response, and selects compatible chat models.
     */
    suspend fun discoverModels(profile: ApiProfile): ModelDiscoveryResult = withContext(Dispatchers.IO) {
        val effectiveKey = if (profile.isDefault) BuildConfig.GEMINI_API_KEY else profile.apiKey.trim()
        if (effectiveKey.isBlank() || effectiveKey == "MY_GEMINI_API_KEY") {
            return@withContext ModelDiscoveryResult(
                isSuccess = false,
                errorMessage = "API key is required for model discovery."
            )
        }

        try {
            when (profile.provider) {
                ApiProvider.GEMINI -> {
                    val url = ApiConfigHelper.buildGeminiModelsListUrl(profile.endpointUrl, effectiveKey)
                    val request = Request.Builder().url(url).get().build()
                    val response = okHttpClient.newCall(request).execute()
                    val body = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        return@withContext ModelDiscoveryResult(
                            isSuccess = false,
                            errorMessage = "Gemini model discovery failed (HTTP ${response.code}): ${body.take(100)}"
                        )
                    }

                    val json = JSONObject(body)
                    val modelsArray = json.optJSONArray("models") ?: JSONArray()
                    val foundModels = mutableListOf<String>()
                    for (i in 0 until modelsArray.length()) {
                        val m = modelsArray.optJSONObject(i) ?: continue
                        val name = m.optString("name").removePrefix("models/")
                        val methods = m.optJSONArray("supportedGenerationMethods")
                        var supportsGenerate = false
                        if (methods != null) {
                            for (j in 0 until methods.length()) {
                                if (methods.optString(j) == "generateContent") {
                                    supportsGenerate = true
                                    break
                                }
                            }
                        } else if (name.startsWith("gemini")) {
                            supportsGenerate = true
                        }
                        if (supportsGenerate && name.isNotBlank()) {
                            foundModels.add(name)
                        }
                    }

                    foundModels.sortWith(compareByDescending<String> { it.contains("2.5") }
                        .thenByDescending { it.contains("flash") }
                        .thenByDescending { it.contains("2.0") }
                        .thenByDescending { it.contains("1.5") })

                    val recommended = foundModels.firstOrNull { it.contains("2.0-flash") } ?: foundModels.firstOrNull { it.contains("2.5-flash") } ?: foundModels.firstOrNull { it.contains("flash") } ?: foundModels.firstOrNull() ?: "gemini-2.0-flash"
                    ModelDiscoveryResult(
                        isSuccess = true,
                        models = foundModels,
                        recommendedModel = recommended
                    )
                }
                ApiProvider.OPENAI_COMPATIBLE -> {
                    val url = ApiConfigHelper.buildOpenAiModelsUrl(profile.endpointUrl)
                    val request = Request.Builder()
                        .url(url)
                        .header("Authorization", "Bearer $effectiveKey")
                        .get()
                        .build()
                    val response = okHttpClient.newCall(request).execute()
                    val body = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        return@withContext ModelDiscoveryResult(
                            isSuccess = false,
                            errorMessage = "OpenAI model discovery failed (HTTP ${response.code}): ${body.take(100)}"
                        )
                    }

                    val json = JSONObject(body)
                    val dataArray = json.optJSONArray("data") ?: JSONArray()
                    val foundModels = mutableListOf<String>()
                    for (i in 0 until dataArray.length()) {
                        val m = dataArray.optJSONObject(i) ?: continue
                        val id = m.optString("id")
                        if (id.isNotBlank() &&
                            !id.contains("embedding", ignoreCase = true) &&
                            !id.contains("tts", ignoreCase = true) &&
                            !id.contains("whisper", ignoreCase = true) &&
                            !id.contains("dall-e", ignoreCase = true) &&
                            !id.contains("moderation", ignoreCase = true) &&
                            !id.contains("realtime", ignoreCase = true)
                        ) {
                            foundModels.add(id)
                        }
                    }

                    val lowerEndpoint = profile.endpointUrl.lowercase()
                    val recommended = when {
                        lowerEndpoint.contains("groq") -> foundModels.firstOrNull { it.contains("llama-3.3") } ?: foundModels.firstOrNull { it.contains("llama") } ?: "llama-3.3-70b-versatile"
                        lowerEndpoint.contains("perplexity") -> foundModels.firstOrNull { it.contains("sonar") } ?: "sonar"
                        else -> foundModels.firstOrNull { it.contains("gpt-4o-mini") } ?: foundModels.firstOrNull { it.contains("gpt-4o") } ?: foundModels.firstOrNull() ?: "gpt-4o-mini"
                    }

                    ModelDiscoveryResult(
                        isSuccess = true,
                        models = foundModels,
                        recommendedModel = recommended
                    )
                }
            }
        } catch (e: Exception) {
            ModelDiscoveryResult(
                isSuccess = false,
                errorMessage = "Model discovery error: ${e.message ?: "Unknown error"}"
            )
        }
    }

    /**
     * Single primary action: VERIFY & CONNECT.
     * Validates input, discovers/validates model, performs real test, saves, and activates!
     */
    suspend fun verifyAndConnectProfile(
        profile: ApiProfile,
        activateImmediately: Boolean = true
    ): ApiVerificationResult = withContext(Dispatchers.IO) {
        val effectiveKey = if (profile.isDefault) BuildConfig.GEMINI_API_KEY else profile.apiKey.trim()
        if (effectiveKey.isBlank() || effectiveKey == "MY_GEMINI_API_KEY") {
            return@withContext ApiVerificationResult(
                isSuccess = false,
                status = ApiStatus.INVALID_KEY,
                errorType = ApiErrorType.INVALID_API_KEY,
                message = "API key cannot be blank or placeholder."
            )
        }

        var targetModel = profile.modelId.trim()
        var discoveredModels = profile.availableModels
        if (targetModel.isBlank() || targetModel.equals("auto", ignoreCase = true)) {
            val discovery = discoverModels(profile)
            if (discovery.isSuccess && discovery.models.isNotEmpty()) {
                discoveredModels = discovery.models
                targetModel = discovery.recommendedModel ?: discovery.models.first()
            } else {
                targetModel = if (profile.provider == ApiProvider.GEMINI) "gemini-1.5-flash" else "gpt-4o-mini"
            }
        }

        val updatedProfile = profile.copy(
            modelId = targetModel,
            availableModels = discoveredModels
        )

        val verification = verifyProfile(updatedProfile)

        if (verification.isSuccess) {
            val finalProfile = updatedProfile.copy(
                isVerified = true,
                status = if (activateImmediately) ApiStatus.ACTIVE else ApiStatus.CONNECTED,
                verificationMessage = verification.message,
                lastVerifiedTimestamp = System.currentTimeMillis()
            )
            saveProfile(finalProfile)
            if (activateImmediately) {
                setActiveProfile(finalProfile.id)
            }
            return@withContext verification.copy(
                status = if (activateImmediately) ApiStatus.ACTIVE else ApiStatus.CONNECTED,
                discoveredModels = discoveredModels,
                selectedModel = targetModel
            )
        } else {
            return@withContext verification.copy(
                discoveredModels = discoveredModels,
                selectedModel = targetModel
            )
        }
    }

    /**
     * Finds a verified backup profile that is not currently in rate limit backoff.
     */
    fun findBackupVerifiedProfile(excludeId: String): ApiProfile? {
        val now = System.currentTimeMillis()
        return _profiles.value.firstOrNull {
            it.id != excludeId && it.isVerified && it.rateLimitBackoffUntil <= now
        }
    }

    /**
     * Records a rate-limit or quota hit for a profile to prevent hammering.
     */
    fun recordRateLimitHit(profileId: String, isQuotaExhausted: Boolean) {
        val current = _profiles.value.toMutableList()
        val index = current.indexOfFirst { it.id == profileId }
        if (index >= 0) {
            val backoffMs = if (isQuotaExhausted) 3600_000L else 30_000L // 1 hour for quota, 30s for rate limit
            val updated = current[index].copy(
                lastErrorCode = 429,
                lastErrorType = if (isQuotaExhausted) ApiErrorType.QUOTA_EXCEEDED else ApiErrorType.RATE_LIMIT,
                rateLimitBackoffUntil = System.currentTimeMillis() + backoffMs
            )
            current[index] = updated
            _profiles.value = current
            if (_activeProfile.value.id == profileId) {
                _activeProfile.value = updated
            }
            persistProfiles()
        }
    }

    /**
     * Clears all custom profiles for test isolation.
     */
    fun clearAllCustomProfilesForTesting() {
        val defaultProfile = createDefaultProfile()
        _profiles.value = listOf(defaultProfile)
        _activeProfile.value = defaultProfile
        prefs?.edit()?.clear()?.apply()
    }
}
