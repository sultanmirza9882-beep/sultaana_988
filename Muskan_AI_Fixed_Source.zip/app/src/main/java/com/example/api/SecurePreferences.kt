package com.example.api

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Opens encrypted preferences and migrates legacy plaintext values before clearing them.
 * Fails closed on real devices: if encryption cannot be initialized, it never returns plaintext preferences.
 * In local JVM Robolectric unit tests (without AndroidKeyStore), uses an isolated test store.
 */
internal object SecurePreferences {

    private fun isRobolectricUnitTest(): Boolean {
        if (Build.FINGERPRINT.equals("robolectric", ignoreCase = true)) return true
        return try {
            Class.forName("org.robolectric.Robolectric")
            true
        } catch (_: ClassNotFoundException) {
            false
        }
    }

    fun openMigrating(context: Context, legacyName: String): SharedPreferences {
        val app = context.applicationContext
        val encryptedName = "${legacyName}_encrypted_v1"
        val legacy = app.getSharedPreferences(legacyName, Context.MODE_PRIVATE)
        return try {
            val masterKey = MasterKey.Builder(app)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            val encrypted = EncryptedSharedPreferences.create(
                app,
                encryptedName,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            // Copy supported preference types; only erase legacy values after encrypted commit succeeds.
            if (legacy.all.isNotEmpty() && encrypted.all.isEmpty()) {
                val editor = encrypted.edit()
                for ((key, value) in legacy.all) {
                    when (value) {
                        is String -> editor.putString(key, value)
                        is Boolean -> editor.putBoolean(key, value)
                        is Int -> editor.putInt(key, value)
                        is Long -> editor.putLong(key, value)
                        is Float -> editor.putFloat(key, value)
                        is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toSet())
                    }
                }
                check(editor.commit()) { "Encrypted preference migration failed; legacy values retained" }
                check(legacy.edit().clear().commit()) { "Encrypted data copied, but legacy plaintext could not be cleared" }
            }
            encrypted
        } catch (error: Exception) {
            if (isRobolectricUnitTest()) {
                return app.getSharedPreferences("${encryptedName}_robolectric_mem", Context.MODE_PRIVATE)
            }
            throw IllegalStateException(
                "Secure storage is unavailable; refusing to fall back to plaintext preferences.",
                error
            )
        }
    }
}
