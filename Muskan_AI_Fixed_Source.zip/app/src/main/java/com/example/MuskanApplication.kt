package com.example

import android.app.Application
import com.example.data.firebase.configureAppCheck

/**
 * Initializes Firebase App Check before app features access Firebase services.
 * In debug builds Firebase prints the generated debug token to Logcat for console registration.
 */
class MuskanApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        configureAppCheck(this, null)
    }
}
