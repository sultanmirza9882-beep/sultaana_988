package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ConversationRepository
import com.example.data.local.ConversationTurnEntity
import com.example.data.local.UserMemoryEntity
import com.example.service.MuskanVoiceService
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class VoiceViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = ConversationRepository(
        dao = db.conversationTurnDao(),
        memoryDao = db.userMemoryDao()
    )

    init {
        VoiceSessionManager.initialize(application)
    }

    val uiState: StateFlow<VoiceUiState> = VoiceSessionManager.uiState

    /**
     * Reactive stream of conversation turns persisted in Room SQLite.
     */
    val recentHistoryTurns: StateFlow<List<ConversationTurnEntity>> = repository.recentTurns
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    /**
     * Reactive stream of persistent learned neural memories and custom instructions.
     */
    val persistentMemories: StateFlow<List<UserMemoryEntity>> = repository.allMemories
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    /**
     * Reactive count of stored conversation turns.
     */
    val historyTurnCount: StateFlow<Int> = repository.turnCount
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    fun saveMemory(category: String, title: String, detail: String) {
        viewModelScope.launch {
            repository.saveMemory(category, title, detail)
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            repository.deleteMemory(id)
        }
    }

    fun updateSpeechRate(rate: Float) {
        VoiceSessionManager.updateSpeechRate(rate)
    }

    fun updateSpeechPitch(pitch: Float) {
        VoiceSessionManager.updateSpeechPitch(pitch)
    }

    fun showHistoryPanel(show: Boolean) {
        VoiceSessionManager.setHistoryPanelVisible(show)
    }

    fun deleteHistoryTurn(id: Long) {
        viewModelScope.launch {
            repository.deleteTurn(id)
        }
    }

    fun clearRoomHistory() {
        viewModelScope.launch {
            repository.clearAllTurns()
        }
    }

    fun replayTurn(response: String) {
        VoiceSessionManager.speakOut(response)
    }

    fun setPermissionGranted(granted: Boolean) {
        VoiceSessionManager.setPermissionGranted(granted)
        if (granted && uiState.value.isWakeWordEnabled) {
            startBackgroundService()
        }
    }

    fun startBackgroundService() {
        try {
            MuskanVoiceService.start(getApplication())
        } catch (_: Exception) {}
    }

    fun stopBackgroundService() {
        try {
            MuskanVoiceService.stop(getApplication())
        } catch (_: Exception) {}
    }

    fun toggleWakeWord() {
        val willEnable = !uiState.value.isWakeWordEnabled
        VoiceSessionManager.toggleWakeWord()
        if (willEnable && uiState.value.hasAudioPermission) {
            startBackgroundService()
        } else if (!willEnable) {
            stopBackgroundService()
        }
    }

    fun toggleMute() {
        VoiceSessionManager.toggleMute()
    }

    fun setMuted(muted: Boolean) {
        VoiceSessionManager.setMuted(muted)
    }

    fun startListening() {
        VoiceSessionManager.startExplicitListening()
    }

    fun stopListening() {
        VoiceSessionManager.stopListening()
    }

    fun processSpeechInput(prompt: String) {
        VoiceSessionManager.processSpeechInput(prompt)
    }

    fun speakOut(text: String) {
        VoiceSessionManager.speakOut(text)
    }

    fun stopTts() {
        VoiceSessionManager.stopTts()
    }

    fun stopTtsAndListen() {
        VoiceSessionManager.stopTtsAndListen()
    }

    fun replayLastResponse() {
        VoiceSessionManager.replayLastResponse()
    }

    fun clearHistory() {
        VoiceSessionManager.clearHistory()
    }

    fun setVoicePreset(preset: String) {
        VoiceSessionManager.setVoicePreset(preset)
    }

    fun checkAccessibilityStatus() {
        VoiceSessionManager.checkAccessibilityStatus()
    }

    fun checkOverlayPermission() {
        VoiceSessionManager.checkOverlayPermission()
    }

    fun setOverlayPermissionGranted(granted: Boolean) {
        VoiceSessionManager.setOverlayPermissionGranted(granted)
    }

    fun startFloatingBubble() {
        val app = getApplication<Application>()
        if (com.example.service.FloatingBubbleService.hasOverlayPermission(app)) {
            com.example.service.FloatingBubbleService.start(app)
            VoiceSessionManager.setFloatingBubbleActive(true)
        }
    }

    fun stopFloatingBubble() {
        val app = getApplication<Application>()
        com.example.service.FloatingBubbleService.stop(app)
        VoiceSessionManager.setFloatingBubbleActive(false)
    }

    fun toggleFloatingBubble() {
        val app = getApplication<Application>()
        if (uiState.value.isFloatingBubbleActive) {
            stopFloatingBubble()
        } else {
            if (com.example.service.FloatingBubbleService.hasOverlayPermission(app)) {
                startFloatingBubble()
            } else {
                com.example.service.FloatingBubbleService.openOverlaySettings(app)
            }
        }
    }

    fun cancelAgenticExecution() {
        com.example.automation.AgenticExecutionPlanner.cancelExecution()
        com.example.automation.UniversalPhoneAgent.cancel()
    }

    fun toggleGamingMode() {
        VoiceSessionManager.toggleGamingMode()
    }

    fun setGamingMode(enabled: Boolean) {
        VoiceSessionManager.setGamingMode(enabled)
    }

    fun toggleVoiceBiometrics() {
        VoiceSessionManager.toggleVoiceBiometrics()
    }

    fun toggleNoiseSuppression() {
        VoiceSessionManager.toggleNoiseSuppression()
    }

    fun setShowVoiceEnrollmentDialog(show: Boolean) {
        VoiceSessionManager.setShowVoiceEnrollmentDialog(show)
    }

    fun setShowMasterDashboard(show: Boolean) {
        VoiceSessionManager.setShowMasterDashboard(show)
    }

    fun enrollVoiceSamples(samples: List<ShortArray>): Boolean {
        return VoiceSessionManager.enrollVoiceSamples(samples)
    }

    suspend fun recordEnrollmentSample(durationMs: Long = 2500): ShortArray {
        return VoiceSessionManager.recordEnrollmentSample(durationMs)
    }

    fun setBiometricThreshold(threshold: Float) {
        VoiceSessionManager.setBiometricThreshold(threshold)
    }

    /* -------------------------------------------------------------
     * MANUAL API MANAGEMENT
     * ------------------------------------------------------------- */

    fun setShowApiManagerDialog(show: Boolean) {
        VoiceSessionManager.setShowApiManagerDialog(show)
    }

    fun setActiveApiProfile(profileId: String): Result<com.example.api.ApiProfile> {
        return VoiceSessionManager.setActiveApiProfile(profileId)
    }

    fun resetToDefaultApi(): com.example.api.ApiProfile {
        return VoiceSessionManager.resetToDefaultApi()
    }

    suspend fun verifyApiProfile(profile: com.example.api.ApiProfile): com.example.api.ApiVerificationResult {
        return VoiceSessionManager.verifyApiProfile(profile)
    }

    fun saveApiProfile(profile: com.example.api.ApiProfile) {
        VoiceSessionManager.saveApiProfile(profile)
    }

    fun deleteApiProfile(profileId: String): Boolean {
        return VoiceSessionManager.deleteApiProfile(profileId)
    }

    /* -------------------------------------------------------------
     * GEMINI LIVE API & FIREBASE INTEGRATION
     * ------------------------------------------------------------- */

    fun startGeminiLiveSession() {
        VoiceSessionManager.startGeminiLiveSession()
    }

    fun stopGeminiLiveSession() {
        VoiceSessionManager.stopGeminiLiveSession()
    }

    fun toggleGeminiLiveSession() {
        VoiceSessionManager.toggleGeminiLiveSession()
    }

    fun toggleProactiveQuestions(enabled: Boolean) {
        VoiceSessionManager.toggleProactiveQuestions(enabled)
    }

    fun setShowMemoryManagerDialog(show: Boolean) {
        VoiceSessionManager.setShowMemoryManagerDialog(show)
    }

    suspend fun saveUserApprovedMemory(content: String, category: String = "preference") {
        VoiceSessionManager.saveUserApprovedMemory(content, category)
    }

    suspend fun deleteUserMemory(memoryId: String) {
        VoiceSessionManager.deleteUserMemory(memoryId)
    }

    suspend fun clearAllUserMemories() {
        VoiceSessionManager.clearAllUserMemories()
    }

    fun getFirestoreMemories(): kotlinx.coroutines.flow.Flow<List<com.example.data.firebase.UserMemory>>? {
        return VoiceSessionManager.memoryRepository?.observeUserMemories()
    }

    suspend fun signInWithGoogle(context: android.content.Context, webClientId: String): Result<com.google.firebase.auth.FirebaseUser>? {
        return VoiceSessionManager.authManager?.signInWithGoogle(context, webClientId)
    }

    fun signOutFirebase() {
        VoiceSessionManager.authManager?.signOut()
    }

    fun setForceOfflineBrain(enabled: Boolean) {
        VoiceSessionManager.setForceOfflineBrain(enabled)
    }

    fun toggleForceOfflineBrain() {
        VoiceSessionManager.toggleForceOfflineBrain()
    }
}
