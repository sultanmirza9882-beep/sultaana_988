package com.example.automation

import android.content.Context
import com.example.service.MuskanAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Manages always-on, real-time screen perception for Muskan AI.
 * Continuously monitors display activity via Accessibility Node Hierarchies
 * and Android 11+ MuskanAccessibilityService.takeScreenshot() without requiring MediaProjection.
 */
object AlwaysOnScreenPerceptionManager {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var perceptionLoopJob: Job? = null

    private val _isAlwaysOnPerceptionActive = MutableStateFlow(true)
    val isAlwaysOnPerceptionActive: StateFlow<Boolean> = _isAlwaysOnPerceptionActive.asStateFlow()

    private val _latestSnapshot = MutableStateFlow(ScreenSnapshot())
    val latestSnapshot: StateFlow<ScreenSnapshot> = _latestSnapshot.asStateFlow()

    private val _screenActivityNarrative = MutableStateFlow("Screen perception initializing…")
    val screenActivityNarrative: StateFlow<String> = _screenActivityNarrative.asStateFlow()

    init {
        startPerceptionLoop()
    }

    fun setAlwaysOnPerceptionEnabled(enabled: Boolean) {
        _isAlwaysOnPerceptionActive.value = enabled
        if (enabled) {
            startPerceptionLoop()
        } else {
            perceptionLoopJob?.cancel()
            perceptionLoopJob = null
            _screenActivityNarrative.value = "Screen perception is currently paused"
        }
    }

    private fun startPerceptionLoop() {
        perceptionLoopJob?.cancel()
        perceptionLoopJob = scope.launch {
            while (isActive) {
                if (_isAlwaysOnPerceptionActive.value) {
                    try {
                        val snapshot = ScreenPerceptionEngine.captureScreenSnapshot()
                        _latestSnapshot.value = snapshot
                        val narrative = generateScreenNarrative(snapshot)
                        _screenActivityNarrative.value = narrative
                    } catch (_: Exception) {}
                }
                delay(2000L) // 2-second interval for real-time display understanding with minimal battery usage
            }
        }
    }

    /**
     * Translates raw screen elements and foreground package into natural conversational narrative.
     */
    fun generateScreenNarrative(snapshot: ScreenSnapshot): String {
        if (snapshot.status == PerceptionStatus.ACCESSIBILITY_SERVICE_NOT_CONNECTED) {
            return "Accessibility Service connect nahi hai. Settings mein jakar Muskan Automation on karein."
        }
        if (snapshot.status == PerceptionStatus.ROOT_NODE_NULL || snapshot.foregroundPackage.isBlank()) {
            return "Screen display standby mode mein hai ya koi active window nahi mili."
        }

        val appName = when {
            snapshot.foregroundPackage.contains("youtube") -> "YouTube"
            snapshot.foregroundPackage.contains("whatsapp") -> "WhatsApp"
            snapshot.foregroundPackage.contains("chrome") -> "Chrome Browser"
            snapshot.foregroundPackage.contains("instagram") -> "Instagram"
            snapshot.foregroundPackage.contains("settings") -> "Phone Settings"
            snapshot.foregroundPackage.contains("camera") -> "Camera"
            snapshot.foregroundPackage.contains("calculator") -> "Calculator"
            snapshot.foregroundPackage.contains("launcher") || snapshot.foregroundPackage.contains("home") -> "Home Screen"
            else -> snapshot.foregroundPackage.substringAfterLast('.').replaceFirstChar { it.uppercase(Locale.ROOT) }
        }

        val texts = snapshot.visibleTexts.take(6)
        val textSummary = if (texts.isNotEmpty()) {
            "Mukhya content: ${texts.joinToString(", ")}"
        } else {
            "Display par koi text nahi dikh raha"
        }

        val interactiveCount = snapshot.clickableElements.size + snapshot.editableFields.size
        val interactiveNote = if (interactiveCount > 0) " ($interactiveCount clickable/editable elements)" else ""

        return "Current Display: $appName khula hua hai.$interactiveNote. $textSummary"
    }

    /**
     * Generates a context block to append into LLM prompts so Muskan knows what's on screen.
     */
    fun getScreenPerceptionPromptContext(): String {
        val snapshot = _latestSnapshot.value
        if (snapshot.status != PerceptionStatus.SUCCESS || snapshot.foregroundPackage.isBlank()) {
            return ""
        }
        val topTexts = snapshot.visibleTexts.take(8).joinToString("\n") { "  - $it" }
        return """
            
            [LIVE SCREEN PERCEPTION (Always-On)]:
            - Foreground Package: ${snapshot.foregroundPackage}
            - Window Title: ${snapshot.windowTitle.ifBlank { "Active Window" }}
            - Interactive Elements: ${snapshot.clickableElements.size} clickable, ${snapshot.editableFields.size} editable fields
            - Visible Text on Screen:
            $topTexts
        """.trimIndent()
    }
}
