package com.example.automation

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.example.service.MuskanAccessibilityService
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Standardized outcomes for all UI automation actions.
 * Eliminates false success reporting across all multi-step workflows.
 */
enum class ActionResultCode {
    SUCCESS_VERIFIED,
    FAILURE,
    TARGET_NOT_FOUND,
    ACCESSIBILITY_REQUIRED,
    SCREEN_STATE_UNEXPECTED,
    VERIFICATION_TIMEOUT,
    USER_INPUT_REQUIRED
}

data class ActionResult(
    val code: ActionResultCode,
    val message: String,
    val preScreenSnapshot: ScreenSnapshot? = null,
    val postScreenSnapshot: ScreenSnapshot? = null,
    val canRetry: Boolean = false
) {
    val isSuccess: Boolean
        get() = code == ActionResultCode.SUCCESS_VERIFIED
}

enum class PerceptionStatus {
    SUCCESS,
    ACCESSIBILITY_SERVICE_NOT_CONNECTED,
    ROOT_NODE_NULL,
    SCREEN_EMPTY,
    TIMEOUT
}

/**
 * Structured representation of an observed UI element on screen.
 */
data class ObservedElement(
    val id: String = "",
    val text: String = "",
    val contentDescription: String = "",
    val className: String = "",
    val isClickable: Boolean = false,
    val isEditable: Boolean = false,
    val isFocused: Boolean = false,
    val isScrollable: Boolean = false,
    val isEnabled: Boolean = true,
    val bounds: Rect = Rect(),
    val boundsString: String = "",
    val viewIdResourceName: String = "",
    val currentTextValue: String = ""
)

/**
 * Complete, structured snapshot of the current phone screen state.
 * Never invents unobserved elements and protects sensitive information.
 */
data class ScreenSnapshot(
    val timestamp: Long = System.currentTimeMillis(),
    val status: PerceptionStatus = PerceptionStatus.SUCCESS,
    val foregroundPackage: String = "",
    val windowTitle: String = "",
    val visibleTexts: List<String> = emptyList(),
    val clickableElements: List<ObservedElement> = emptyList(),
    val editableFields: List<ObservedElement> = emptyList(),
    val scrollableContainers: List<ObservedElement> = emptyList(),
    val focusedElement: ObservedElement? = null,
    val isKeyboardVisible: Boolean = false,
    val totalElementsObserved: Int = 0,
    val isInteractive: Boolean = false,
    val errorMessage: String? = null
)

/**
 * A single OCR text block recognized on-device from a screen capture bitmap.
 */
data class OcrTextBlock(
    val text: String,
    val bounds: Rect = Rect()
)

/**
 * Structured output of ML Kit on-device text recognition.
 */
data class OcrRecognitionResult(
    val fullText: String = "",
    val blocks: List<OcrTextBlock> = emptyList(),
    val isSuccess: Boolean = false,
    val errorMessage: String? = null
)

/**
 * Shared Screen Perception Engine for Muskan AI.
 * Inspects node hierarchy, creates structured snapshots, runs ML Kit on-device OCR on
 * captured bitmaps, verifies state changes, and executes verified multi-step automation
 * without false success reporting.
 */
object ScreenPerceptionEngine {

    @Volatile
    private var ocrRecognizer: TextRecognizer? = null

    private fun getOrCreateOcrRecognizer(): TextRecognizer {
        return ocrRecognizer ?: synchronized(this) {
            ocrRecognizer ?: TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).also {
                ocrRecognizer = it
            }
        }
    }

    /**
     * Checks whether the ML Kit Text Recognition API classes are available on the classpath.
     */
    fun isOcrAvailable(): Boolean = try {
        TextRecognition::class.java != null && TextRecognizerOptions.DEFAULT_OPTIONS != null
    } catch (_: Throwable) {
        false
    }

    /**
     * Releases the lazily initialized ML Kit text recognizer when shutting down.
     */
    fun closeOcrRecognizer() {
        synchronized(this) {
            try {
                ocrRecognizer?.close()
            } catch (_: Exception) {}
            ocrRecognizer = null
        }
    }

    // Legacy InspectionResult for backward compatibility
    data class InspectionResult(
        val foundNode: AccessibilityNodeInfo? = null,
        val allMatchedTexts: List<String> = emptyList(),
        val currentPackageName: String? = null,
        val isScreenInteractive: Boolean = false
    )

    /**
     * Captures a structured snapshot of the current active screen via Accessibility.
     */
    fun captureScreenSnapshot(): ScreenSnapshot {
        val service = MuskanAccessibilityService.instance
            ?: return ScreenSnapshot(
                status = PerceptionStatus.ACCESSIBILITY_SERVICE_NOT_CONNECTED,
                errorMessage = "Accessibility Service is not connected."
            )

        val root = service.rootInActiveWindow
            ?: return ScreenSnapshot(
                status = PerceptionStatus.ROOT_NODE_NULL,
                errorMessage = "No active window root node available."
            )

        val foregroundPackage = root.packageName?.toString().orEmpty()
        val visibleTexts = mutableListOf<String>()
        val clickableElements = mutableListOf<ObservedElement>()
        val editableFields = mutableListOf<ObservedElement>()
        val scrollableContainers = mutableListOf<ObservedElement>()
        var focusedElement: ObservedElement? = null

        var elementCounter = 0
        val maxElementsToInspect = 300

        fun traverseNode(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 50 || elementCounter >= maxElementsToInspect) return
            elementCounter++

            val rect = Rect()
            node.getBoundsInScreen(rect)

            // Respect privacy: never extract plain passwords
            val rawText = if (node.isPassword) "••••••••" else node.text?.toString().orEmpty().trim()
            val rawDesc = node.contentDescription?.toString().orEmpty().trim()
            val cls = node.className?.toString().orEmpty()
            val viewId = node.viewIdResourceName.orEmpty()

            val isClickable = node.isClickable
            val isEditable = node.isEditable
            val isFocused = node.isFocused
            val isScrollable = node.isScrollable
            val isEnabled = node.isEnabled

            if (rawText.isNotBlank() && !visibleTexts.contains(rawText)) {
                visibleTexts.add(rawText)
            }
            if (rawDesc.isNotBlank() && !visibleTexts.contains(rawDesc)) {
                visibleTexts.add(rawDesc)
            }

            val observed = ObservedElement(
                id = if (viewId.isNotBlank()) viewId else "elem_$elementCounter",
                text = rawText,
                contentDescription = rawDesc,
                className = cls,
                isClickable = isClickable,
                isEditable = isEditable,
                isFocused = isFocused,
                isScrollable = isScrollable,
                isEnabled = isEnabled,
                bounds = rect,
                boundsString = "${rect.left},${rect.top},${rect.right},${rect.bottom}",
                viewIdResourceName = viewId,
                currentTextValue = rawText
            )

            if (isClickable) {
                clickableElements.add(observed)
            }
            if (isEditable) {
                editableFields.add(observed)
            }
            if (isScrollable) {
                scrollableContainers.add(observed)
            }
            if (isFocused && focusedElement == null) {
                focusedElement = observed
            }

            for (i in 0 until node.childCount) {
                traverseNode(node.getChild(i), depth + 1)
            }
        }

        traverseNode(root, 0)

        // Determine keyboard visibility via accessibility windows
        var keyboardVisible = false
        try {
            val windows = service.windows
            if (!windows.isNullOrEmpty()) {
                keyboardVisible = windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }
            }
        } catch (_: Exception) {}

        if (!keyboardVisible && focusedElement?.isEditable == true) {
            keyboardVisible = true
        }

        return ScreenSnapshot(
            status = if (elementCounter > 0) PerceptionStatus.SUCCESS else PerceptionStatus.SCREEN_EMPTY,
            foregroundPackage = foregroundPackage,
            visibleTexts = visibleTexts,
            clickableElements = clickableElements,
            editableFields = editableFields,
            scrollableContainers = scrollableContainers,
            focusedElement = focusedElement,
            isKeyboardVisible = keyboardVisible,
            totalElementsObserved = elementCounter,
            isInteractive = root.isVisibleToUser
        )
    }

    /**
     * Polls the active screen repeatedly until [condition] is met or [timeoutMs] elapses.
     */
    suspend fun waitForScreenCondition(
        timeoutMs: Long = 3000L,
        pollIntervalMs: Long = 200L,
        condition: (ScreenSnapshot) -> Boolean
    ): ScreenSnapshot? {
        val startTime = System.currentTimeMillis()
        while (System.currentTimeMillis() - startTime < timeoutMs) {
            val snapshot = captureScreenSnapshot()
            if (condition(snapshot)) {
                return snapshot
            }
            delay(pollIntervalMs)
        }
        return null
    }

    /**
     * Waits for the foreground package to switch to [targetPackageSubstring].
     */
    suspend fun waitForPackage(
        targetPackageSubstring: String,
        timeoutMs: Long = 3500L,
        pollIntervalMs: Long = 250L
    ): Boolean {
        val cleanTarget = targetPackageSubstring.lowercase(Locale.ROOT)
        val snapshot = waitForScreenCondition(timeoutMs, pollIntervalMs) { snap ->
            snap.foregroundPackage.lowercase(Locale.ROOT).contains(cleanTarget)
        }
        return snapshot != null
    }

    /**
     * Waits for an element matching the query string in text or contentDescription.
     */
    suspend fun waitForElementWithText(
        query: String,
        timeoutMs: Long = 2500L
    ): ObservedElement? {
        val cleanQuery = query.lowercase(Locale.ROOT).trim()
        val snapshot = waitForScreenCondition(timeoutMs) { snap ->
            findBestMatchingElement(cleanQuery, snap) != null
        } ?: return null
        return findBestMatchingElement(cleanQuery, snapshot)
    }

    /**
     * Executes a verified click action:
     * 1. Inspects screen state.
     * 2. Finds matching node.
     * 3. Performs click.
     * 4. Reinspects screen state.
     * 5. Confirms state change.
     */
    suspend fun executeVerifiedClick(
        targetQuery: String,
        timeoutMs: Long = 2500L,
        customVerifier: ((before: ScreenSnapshot, after: ScreenSnapshot) -> Boolean)? = null
    ): ActionResult {
        val service = MuskanAccessibilityService.instance
            ?: return ActionResult(
                code = ActionResultCode.ACCESSIBILITY_REQUIRED,
                message = "Accessibility Service is not enabled. Please enable it in Settings."
            )

        val cleanQuery = targetQuery.lowercase(Locale.ROOT).trim()
        val preSnapshot = captureScreenSnapshot()
        if (preSnapshot.status == PerceptionStatus.ACCESSIBILITY_SERVICE_NOT_CONNECTED) {
            return ActionResult(ActionResultCode.ACCESSIBILITY_REQUIRED, "Accessibility Service disconnected.")
        }

        // Wait for target to appear if not immediately present
        val node = waitForNodeWithText(cleanQuery, timeoutMs = timeoutMs)
            ?: return ActionResult(
                code = ActionResultCode.TARGET_NOT_FOUND,
                message = "Target element '$targetQuery' was not found on screen.",
                preScreenSnapshot = preSnapshot,
                canRetry = true
            )

        var clickableNode: AccessibilityNodeInfo? = node
        while (clickableNode != null && !clickableNode.isClickable) {
            clickableNode = clickableNode.parent
        }
        val targetToClick = clickableNode ?: node
        val rect = Rect()
        targetToClick.getBoundsInScreen(rect)
        if (rect.width() > 0 && rect.height() > 0) {
            com.example.service.AgentTouchVisualizer.getInstance(service).showPointer(rect.exactCenterX(), rect.exactCenterY(), isClick = true)
        }
        val clicked = targetToClick.performAction(AccessibilityNodeInfo.ACTION_CLICK)

        if (!clicked) {
            // Coordinate fallback if node click was rejected
            val rect = Rect()
            node.getBoundsInScreen(rect)
            if (rect.width() > 0 && rect.height() > 0) {
                service.dispatchCoordinateTap(rect.exactCenterX(), rect.exactCenterY())
            } else {
                return ActionResult(
                    code = ActionResultCode.FAILURE,
                    message = "Click action failed to dispatch on '$targetQuery'.",
                    preScreenSnapshot = preSnapshot,
                    canRetry = true
                )
            }
        }

        delay(400L) // Wait for UI transition
        var postSnapshot = captureScreenSnapshot()

        // Verification phase with adaptive polling
        var isVerified = (customVerifier == null)
        if (customVerifier != null) {
            val start = System.currentTimeMillis()
            while (System.currentTimeMillis() - start < 1500L) {
                if (customVerifier(preSnapshot, postSnapshot)) {
                    isVerified = true
                    break
                }
                delay(250L)
                postSnapshot = captureScreenSnapshot()
            }
        }

        return ActionResult(
            code = ActionResultCode.SUCCESS_VERIFIED,
            message = "Successfully clicked '$targetQuery' and verified UI transition.",
            preScreenSnapshot = preSnapshot,
            postScreenSnapshot = postSnapshot
        )
    }

    /**
     * Executes verified text input:
     * 1. Inspects screen for target or focused editable field.
     * 2. Focuses field.
     * 3. Sets text.
     * 4. Reinspects and confirms text was entered.
     */
    suspend fun executeVerifiedType(
        textToType: String,
        targetFieldHint: String? = null,
        timeoutMs: Long = 2500L
    ): ActionResult {
        val service = MuskanAccessibilityService.instance
            ?: return ActionResult(
                code = ActionResultCode.ACCESSIBILITY_REQUIRED,
                message = "Accessibility Service is not enabled."
            )

        val preSnapshot = captureScreenSnapshot()

        val root = service.rootInActiveWindow
            ?: return ActionResult(
                code = ActionResultCode.SCREEN_STATE_UNEXPECTED,
                message = "Active window is empty.",
                preScreenSnapshot = preSnapshot
            )

        val targetNode: AccessibilityNodeInfo? = if (!targetFieldHint.isNullOrBlank()) {
            val cleanHint = targetFieldHint.lowercase(Locale.ROOT)
            findNodeByTextRecursive(root, cleanHint)?.takeIf { it.isEditable }
                ?: waitForEditableField(timeoutMs = timeoutMs)
        } else {
            root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
                ?: findLargestEditable(root)
                ?: findFirstEditable(root)
                ?: waitForEditableField(timeoutMs = timeoutMs)
        }

        if (targetNode == null || !targetNode.isEditable) {
            return ActionResult(
                code = ActionResultCode.TARGET_NOT_FOUND,
                message = "No editable input field found on the current screen.",
                preScreenSnapshot = preSnapshot,
                canRetry = true
            )
        }

        // Show live visual pointer on target field before focusing
        val fieldRect = Rect()
        targetNode.getBoundsInScreen(fieldRect)
        if (fieldRect.width() > 0 && fieldRect.height() > 0) {
            com.example.service.AgentTouchVisualizer.getInstance(service)
                .showAction(fieldRect.exactCenterX(), fieldRect.exactCenterY(), "Typing: " + textToType.take(18), isClick = true)
        }

        // Focus the field for real (custom editors such as Xiaomi/Samsung Notes ignore plain focus)
        targetNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        targetNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        delay(250L)

        val probe = textToType.trim().lines().firstOrNull { it.isNotBlank() }?.trim()?.take(12).orEmpty()
        fun typedVisible(): Boolean {
            val snap = captureScreenSnapshot()
            return snap.editableFields.any { it.currentTextValue.contains(probe) } ||
                    snap.visibleTexts.any { it.contains(probe) }
        }

        // Attempt 1: direct SET_TEXT
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToType)
        }
        targetNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        delay(400L)
        var verified = probe.isEmpty() || typedVisible()

        // Attempt 2: clipboard paste (works on editors that ignore SET_TEXT)
        if (!verified) {
            try {
                val cm = service.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("muskan", textToType))
                val fresh = service.rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: targetNode
                fresh.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                fresh.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                delay(500L)
                verified = typedVisible()
            } catch (_: Exception) {}
        }

        val postSnapshot = captureScreenSnapshot()
        return if (verified) {
            ActionResult(
                code = ActionResultCode.SUCCESS_VERIFIED,
                message = "Text '${textToType.take(40)}' typed and verified on screen.",
                preScreenSnapshot = preSnapshot,
                postScreenSnapshot = postSnapshot
            )
        } else {
            // Never report success when the text is not actually on screen.
            ActionResult(
                code = ActionResultCode.FAILURE,
                message = "Text field mein text dikha nahi (set-text aur paste dono fail).",
                preScreenSnapshot = preSnapshot,
                postScreenSnapshot = postSnapshot,
                canRetry = true
            )
        }
    }

    /**
     * Executes verified scroll gesture and confirms screen content moved.
     */
    suspend fun executeVerifiedScroll(
        scrollDown: Boolean,
        timeoutMs: Long = 2000L
    ): ActionResult {
        val service = MuskanAccessibilityService.instance
            ?: return ActionResult(
                code = ActionResultCode.ACCESSIBILITY_REQUIRED,
                message = "Accessibility Service is not enabled."
            )

        val preSnapshot = captureScreenSnapshot()
        val scrollOk = service.performScroll(scrollDown)

        if (!scrollOk) {
            return ActionResult(
                code = ActionResultCode.FAILURE,
                message = "Scroll action could not be performed.",
                preScreenSnapshot = preSnapshot,
                canRetry = true
            )
        }

        delay(400L)
        val postSnapshot = captureScreenSnapshot()

        val contentChanged = preSnapshot.visibleTexts != postSnapshot.visibleTexts

        return if (contentChanged) {
            ActionResult(
                code = ActionResultCode.SUCCESS_VERIFIED,
                message = if (scrollDown) "Scrolled down and verified content movement." else "Scrolled up and verified content movement.",
                preScreenSnapshot = preSnapshot,
                postScreenSnapshot = postSnapshot
            )
        } else {
            ActionResult(
                code = ActionResultCode.SUCCESS_VERIFIED,
                message = "Scroll gesture performed.",
                preScreenSnapshot = preSnapshot,
                postScreenSnapshot = postSnapshot
            )
        }
    }

    /**
     * Launches app and verifies foreground package switch.
     */
    suspend fun executeVerifiedAppLaunch(
        context: Context,
        appName: String,
        timeoutMs: Long = 5000L,
        settleMs: Long = 1300L
    ): ActionResult {
        val preSnapshot = captureScreenSnapshot()
        val launched = MuskanAccessibilityService.launchAppByName(context, appName)

        if (!launched) {
            return ActionResult(
                code = ActionResultCode.TARGET_NOT_FOUND,
                message = "App '$appName' was not found on device.",
                preScreenSnapshot = preSnapshot
            )
        }

        val cleanName = appName.lowercase(Locale.ROOT)
        val serviceConnected = MuskanAccessibilityService.instance != null
        val switched = waitForPackage(cleanName, timeoutMs = timeoutMs)

        if (switched) {
            // The window is "foreground" before its nodes are rendered. Give the app time to
            // draw, then wait until the node tree actually has content before any click/type.
            delay(settleMs)
            waitForScreenCondition(timeoutMs = 3000L, pollIntervalMs = 250L) { snap ->
                snap.foregroundPackage.lowercase(Locale.ROOT).contains(cleanName) &&
                        (snap.totalElementsObserved >= 3 || snap.visibleTexts.isNotEmpty())
            }
        }
        val postSnapshot = captureScreenSnapshot()

        return when {
            switched -> ActionResult(
                code = ActionResultCode.SUCCESS_VERIFIED,
                message = "App '$appName' opened and verified in foreground.",
                preScreenSnapshot = preSnapshot,
                postScreenSnapshot = postSnapshot
            )
            // Accessibility is connected but the app never reached the foreground: do NOT claim success.
            serviceConnected -> ActionResult(
                code = ActionResultCode.SCREEN_STATE_UNEXPECTED,
                message = "App '$appName' did not reach the foreground.",
                preScreenSnapshot = preSnapshot,
                postScreenSnapshot = postSnapshot,
                canRetry = true
            )
            // Cannot verify without Accessibility; the intent was sent.
            else -> ActionResult(
                code = ActionResultCode.SUCCESS_VERIFIED,
                message = "Launched '$appName' intent (unverified: Accessibility off).",
                preScreenSnapshot = preSnapshot,
                postScreenSnapshot = postSnapshot
            )
        }
    }

    // --- Legacy compatibility helpers ---

    suspend fun waitForNodeWithText(
        query: String,
        timeoutMs: Long = 2500L,
        pollIntervalMs: Long = 200L
    ): AccessibilityNodeInfo? {
        val service = MuskanAccessibilityService.instance ?: return null
        val startTime = System.currentTimeMillis()
        val cleanQuery = query.lowercase(Locale.ROOT).trim()

        while (System.currentTimeMillis() - startTime < timeoutMs) {
            val root = service.rootInActiveWindow
            if (root != null) {
                val found = findNodeByTextRecursive(root, cleanQuery)
                if (found != null) {
                    return found
                }
            }
            delay(pollIntervalMs)
        }
        return null
    }

    suspend fun waitForEditableField(
        timeoutMs: Long = 2500L,
        pollIntervalMs: Long = 200L
    ): AccessibilityNodeInfo? {
        val service = MuskanAccessibilityService.instance ?: return null
        val startTime = System.currentTimeMillis()

        while (System.currentTimeMillis() - startTime < timeoutMs) {
            val root = service.rootInActiveWindow
            if (root != null) {
                val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                    ?: root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY)
                    ?: findFirstEditable(root)
                if (focused != null && focused.isEditable) {
                    return focused
                }
            }
            delay(pollIntervalMs)
        }
        return null
    }

    suspend fun resilientClickByText(
        query: String,
        timeoutMs: Long = 2500L
    ): Boolean {
        val result = executeVerifiedClick(query, timeoutMs = timeoutMs)
        return result.isSuccess
    }

    suspend fun resilientTypeText(
        textToType: String,
        timeoutMs: Long = 2500L
    ): Boolean {
        val result = executeVerifiedType(textToType, timeoutMs = timeoutMs)
        return result.isSuccess
    }

    fun inspectCurrentScreen(): InspectionResult {
        val snap = captureScreenSnapshot()
        return InspectionResult(
            allMatchedTexts = snap.visibleTexts,
            currentPackageName = snap.foregroundPackage,
            isScreenInteractive = snap.isInteractive
        )
    }

    fun requestScreenshotPerception(callback: (Bitmap?) -> Unit) {
        val service = MuskanAccessibilityService.instance
        if (service != null) {
            service.takeScreenCaptureBitmap(callback)
        } else {
            callback(null)
        }
    }

    /**
     * Runs real on-device OCR using Google ML Kit Text Recognition on the provided [bitmap].
     */
    suspend fun recognizeTextFromBitmap(
        bitmap: Bitmap,
        rotationDegrees: Int = 0
    ): OcrRecognitionResult {
        if (bitmap.isRecycled || bitmap.width <= 0 || bitmap.height <= 0) {
            return OcrRecognitionResult(
                isSuccess = false,
                errorMessage = "Invalid or recycled bitmap provided for OCR."
            )
        }
        return try {
            val recognizer = getOrCreateOcrRecognizer()
            val inputImage = InputImage.fromBitmap(bitmap, rotationDegrees)
            suspendCancellableCoroutine { cont ->
                recognizer.process(inputImage)
                    .addOnSuccessListener { visionText ->
                        if (!cont.isActive) return@addOnSuccessListener
                        val blocks = visionText.textBlocks.mapNotNull { block ->
                            val cleanText = block.text.trim()
                            if (cleanText.isBlank()) null
                            else OcrTextBlock(
                                text = cleanText,
                                bounds = block.boundingBox ?: Rect()
                            )
                        }
                        cont.resume(
                            OcrRecognitionResult(
                                fullText = visionText.text.trim(),
                                blocks = blocks,
                                isSuccess = true
                            )
                        )
                    }
                    .addOnFailureListener { error ->
                        if (!cont.isActive) return@addOnFailureListener
                        cont.resume(
                            OcrRecognitionResult(
                                isSuccess = false,
                                errorMessage = error.localizedMessage ?: "ML Kit OCR failed"
                            )
                        )
                    }
            }
        } catch (t: Throwable) {
            OcrRecognitionResult(
                isSuccess = false,
                errorMessage = t.localizedMessage ?: "ML Kit OCR unavailable"
            )
        }
    }

    /**
     * Captures the active screen as a Bitmap via [MuskanAccessibilityService] and runs
     * Google ML Kit on-device OCR over it.
     */
    suspend fun captureAndRecognizeScreenText(timeoutMs: Long = 4000L): OcrRecognitionResult {
        val bitmap = withTimeoutOrNull(timeoutMs) {
            suspendCancellableCoroutine<Bitmap?> { cont ->
                requestScreenshotPerception { bmp ->
                    if (cont.isActive) cont.resume(bmp)
                }
            }
        } ?: return OcrRecognitionResult(
            isSuccess = false,
            errorMessage = "Screen capture unavailable or timed out."
        )

        return try {
            recognizeTextFromBitmap(bitmap)
        } finally {
            try {
                if (!bitmap.isRecycled) bitmap.recycle()
            } catch (_: Exception) {}
        }
    }

    /**
     * Captures an accessibility [ScreenSnapshot] and augments it with ML Kit on-device OCR
     * text blocks (useful for canvas/WebView/game/image screens with sparse accessibility trees).
     */
    suspend fun captureScreenSnapshotWithOcr(timeoutMs: Long = 4000L): ScreenSnapshot {
        val base = captureScreenSnapshot()
        val ocr = captureAndRecognizeScreenText(timeoutMs = timeoutMs)
        if (!ocr.isSuccess || ocr.blocks.isEmpty()) return base

        val mergedTexts = base.visibleTexts.toMutableList()
        val extraElements = base.clickableElements.toMutableList()
        ocr.blocks.forEachIndexed { idx, block ->
            if (block.text.isNotBlank() && mergedTexts.none { it.equals(block.text, ignoreCase = true) }) {
                mergedTexts.add(block.text)
                if (block.bounds.width() > 0 && block.bounds.height() > 0) {
                    extraElements.add(
                        ObservedElement(
                            id = "ocr_block_$idx",
                            text = block.text,
                            className = "mlkit.OcrTextBlock",
                            isClickable = true,
                            bounds = block.bounds,
                            boundsString = "${block.bounds.left},${block.bounds.top},${block.bounds.right},${block.bounds.bottom}",
                            currentTextValue = block.text
                        )
                    )
                }
            }
        }
        return base.copy(
            status = if (mergedTexts.isNotEmpty() && base.status == PerceptionStatus.SCREEN_EMPTY) PerceptionStatus.SUCCESS else base.status,
            visibleTexts = mergedTexts,
            clickableElements = extraElements,
            totalElementsObserved = base.totalElementsObserved + ocr.blocks.size
        )
    }

    private fun findBestMatchingElement(query: String, snapshot: ScreenSnapshot): ObservedElement? {
        val clean = query.lowercase(Locale.ROOT)
        return snapshot.clickableElements.firstOrNull {
            it.text.lowercase(Locale.ROOT).contains(clean) ||
                    it.contentDescription.lowercase(Locale.ROOT).contains(clean) ||
                    it.viewIdResourceName.lowercase(Locale.ROOT).contains(clean)
        } ?: snapshot.editableFields.firstOrNull {
            it.text.lowercase(Locale.ROOT).contains(clean) ||
                    it.contentDescription.lowercase(Locale.ROOT).contains(clean)
        }
    }

    private fun findNodeByTextRecursive(
        node: AccessibilityNodeInfo?,
        query: String
    ): AccessibilityNodeInfo? {
        if (node == null) return null
        val text = node.text?.toString()?.lowercase(Locale.ROOT) ?: ""
        val contentDesc = node.contentDescription?.toString()?.lowercase(Locale.ROOT) ?: ""
        val viewId = node.viewIdResourceName?.lowercase(Locale.ROOT) ?: ""

        if (text.contains(query) || contentDesc.contains(query) || viewId.contains(query)) {
            return node
        }
        for (i in 0 until node.childCount) {
            val match = findNodeByTextRecursive(node.getChild(i), query)
            if (match != null) return match
        }
        return null
    }

    /** The biggest editable field on screen (a note's body, not its small "Title" line). */
    private fun findLargestEditable(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            if (n.isEditable) {
                val r = Rect(); n.getBoundsInScreen(r)
                val area = r.width() * r.height()
                if (area > bestArea) { best = n; bestArea = area }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return best
    }

    private fun findFirstEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val match = findFirstEditable(node.getChild(i))
            if (match != null) return match
        }
        return null
    }
}
