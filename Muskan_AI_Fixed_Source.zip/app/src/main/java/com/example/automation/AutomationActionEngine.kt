package com.example.automation

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import com.example.service.MuskanAccessibilityService
import java.util.Locale

sealed class AutomationResult {
    data class Handled(val spokenFeedback: String) : AutomationResult()
    data class AccessibilityRequired(val message: String) : AutomationResult()
    object NotAnAutomationCommand : AutomationResult()
}

object AutomationActionEngine {

    private var isTorchOn = false

    /**
     * Inspects the prompt and executes matching device or accessibility actions.
     * Always prioritizes direct execution without unnecessary roadblocks or excuses!
     */
    fun processVoiceCommand(context: Context, rawPrompt: String): AutomationResult {
        val prompt = rawPrompt.lowercase(Locale.ROOT).trim()
        val service = MuskanAccessibilityService.instance

        // 1. Direct App Launching Commands (WhatsApp, YouTube, Instagram, Camera, etc.)
        val appName = extractAppToLaunch(prompt)
        if (appName != null) {
            val launched = MuskanAccessibilityService.launchAppByName(context, appName)
            return if (launched) {
                AutomationResult.Handled("काम मुकम्मल हो गया है, सर। $appName ओपन कर दिया है।")
            } else {
                AutomationResult.Handled("सर, $appName डिवाइस में नहीं मिला।")
            }
        }

        // 2. YouTube Search or Music playback intent: "youtube par lofi music search karo / chalao"
        val ytQuery = extractYouTubeQuery(prompt)
        if (ytQuery != null) {
            val encoded = Uri.encode(ytQuery)
            val ytIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(ytIntent)
                return AutomationResult.Handled("Ji Sultan, YouTube par '$ytQuery' chala rahi hoon.")
            } catch (_: Exception) {}
        }

        // 3. Web Search: "google par search karo..." or "search karo..."
        val webQuery = extractWebSearchQuery(prompt)
        if (webQuery != null) {
            val encoded = Uri.encode(webQuery)
            val searchIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encoded")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(searchIntent)
                return AutomationResult.Handled("'$webQuery' Google par search kar rahi hoon.")
            } catch (_: Exception) {}
        }

        // 4. Flashlight / Torch Commands
        if (isTorchOnCommand(prompt)) {
            val success = setFlashlight(context, true)
            return if (success) {
                isTorchOn = true
                AutomationResult.Handled("Torch on kar diya hai.")
            } else {
                AutomationResult.Handled("Torch on karne ki koshish ki.")
            }
        }

        if (isTorchOffCommand(prompt)) {
            val success = setFlashlight(context, false)
            return if (success) {
                isTorchOn = false
                AutomationResult.Handled("Torch band kar diya hai.")
            } else {
                AutomationResult.Handled("Torch band kar diya hai.")
            }
        }

        // 5. Volume Controls
        if (isVolumeUpCommand(prompt)) {
            adjustVolume(context, raise = true)
            return AutomationResult.Handled("Awaaz badha di hai.")
        }

        if (isVolumeDownCommand(prompt)) {
            adjustVolume(context, raise = false)
            return AutomationResult.Handled("Awaaz dheemi kar di hai.")
        }

        // 6. Connectivity Settings (Wi-Fi, Bluetooth)
        if (isWifiCommand(prompt)) {
            try {
                val wifiIntent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(wifiIntent)
                return AutomationResult.Handled("Wi-Fi settings khol diye hain.")
            } catch (_: Exception) {}
        }

        if (isBluetoothCommand(prompt)) {
            try {
                val btIntent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(btIntent)
                return AutomationResult.Handled("Bluetooth settings khol diye hain.")
            } catch (_: Exception) {}
        }

        // 7. Global Navigation Commands
        if (isHomeCommand(prompt)) {
            if (service != null) {
                service.triggerHome()
                return AutomationResult.Handled("Home screen par jaa rahi hoon.")
            } else {
                return AutomationResult.AccessibilityRequired("Home screen ke liye Accessibility Service enable karein.")
            }
        }

        if (isBackCommand(prompt)) {
            if (service != null) {
                service.triggerBack()
                return AutomationResult.Handled("Peeche jaa rahi hoon.")
            } else {
                return AutomationResult.AccessibilityRequired("Back action ke liye Accessibility Service enable karein.")
            }
        }

        if (isRecentsCommand(prompt)) {
            if (service != null) {
                service.triggerRecents()
                return AutomationResult.Handled("Recent apps khol diye hain.")
            } else {
                return AutomationResult.AccessibilityRequired("Recent apps ke liye Accessibility Service enable karein.")
            }
        }

        if (isNotificationsCommand(prompt)) {
            if (service != null) {
                service.triggerNotifications()
                return AutomationResult.Handled("Notifications khol diye hain.")
            } else {
                return AutomationResult.AccessibilityRequired("Notifications ke liye Accessibility Service enable karein.")
            }
        }

        if (isQuickSettingsCommand(prompt)) {
            if (service != null) {
                service.triggerQuickSettings()
                return AutomationResult.Handled("Quick settings open kar diye hain.")
            } else {
                return AutomationResult.AccessibilityRequired("Quick settings ke liye Accessibility Service enable karein.")
            }
        }

        if (isLockScreenCommand(prompt)) {
            if (service != null) {
                service.triggerLockScreen()
                return AutomationResult.Handled("Screen lock kar rahi hoon.")
            } else {
                return AutomationResult.AccessibilityRequired("Screen lock ke liye Accessibility Service enable karein.")
            }
        }

        if (isScreenshotCommand(prompt)) {
            if (service != null) {
                service.triggerTakeScreenshot()
                return AutomationResult.Handled("Screenshot le liya hai.")
            } else {
                return AutomationResult.AccessibilityRequired("Screenshot ke liye Accessibility Service enable karein.")
            }
        }

        // 8. Gesture Scrolling Commands (When Accessibility is connected)
        if (isScrollDownCommand(prompt)) {
            if (service != null) {
                service.performScroll(scrollDown = true)
                return AutomationResult.Handled("Neeche scroll kar diya.")
            } else {
                return AutomationResult.AccessibilityRequired("Scroll karne ke liye Accessibility Service enable karein.")
            }
        }

        if (isScrollUpCommand(prompt)) {
            if (service != null) {
                service.performScroll(scrollDown = false)
                return AutomationResult.Handled("Upar scroll kar diya.")
            } else {
                return AutomationResult.AccessibilityRequired("Scroll karne ke liye Accessibility Service enable karein.")
            }
        }

        // 9. Automated Typing Commands
        val typingText = extractTypingText(prompt)
        if (typingText != null) {
            if (service != null) {
                val typed = service.typeTextIntoFocusedField(typingText)
                return if (typed) {
                    AutomationResult.Handled("'$typingText' likh diya hai.")
                } else {
                    AutomationResult.Handled("Kripya kisi input box par tap karein.")
                }
            } else {
                return AutomationResult.AccessibilityRequired("Text type karne ke liye Accessibility Service enable karein.")
            }
        }

        // 10. Click / Tap On Screen Commands
        val clickTarget = extractClickTarget(prompt)
        if (clickTarget != null) {
            if (service != null) {
                val clicked = service.clickElementByText(clickTarget)
                return if (clicked) {
                    AutomationResult.Handled("'$clickTarget' par tap kar diya.")
                } else {
                    AutomationResult.Handled("Screen par '$clickTarget' nahi mila.")
                }
            } else {
                return AutomationResult.AccessibilityRequired("Screen par tap karne ke liye Accessibility Service enable karein.")
            }
        }

        // 11. Skip Ad Command ("muskan ad skip karo", "skip ad", "ad skip", etc.)
        if (isSkipAdCommand(prompt)) {
            if (service != null) {
                val clicked = service.performSkipAd()
                return if (clicked) {
                    AutomationResult.Handled("Ad skip kar diya hai, Sultan.")
                } else {
                    AutomationResult.Handled("Screen par abhi 'Skip Ad' button nahi mila ya ad timer chal raha hai.")
                }
            } else {
                return AutomationResult.AccessibilityRequired("Ad skip karne ke liye Accessibility Service enable karein.")
            }
        }

        // 12. Conversation History Panel
        if (isHistoryCommand(prompt)) {
            com.example.VoiceSessionManager.setHistoryPanelVisible(true)
            return AutomationResult.Handled("Conversation history panel khol diya hai.")
        }

        // 13. Always-On Screen Perception & Display Understanding
        if (isScreenPerceptionCommand(prompt)) {
            val snapshot = AlwaysOnScreenPerceptionManager.latestSnapshot.value
            val narrative = AlwaysOnScreenPerceptionManager.generateScreenNarrative(snapshot)
            return AutomationResult.Handled("Ji Sultan! Screen perception ke hisaab se: $narrative")
        }

        return AutomationResult.NotAnAutomationCommand
    }

    fun setFlashlight(context: Context, enable: Boolean): Boolean {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            val cameraId = cm?.cameraIdList?.firstOrNull() ?: return false
            cm.setTorchMode(cameraId, enable)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun adjustVolume(context: Context, raise: Boolean) {
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            val direction = if (raise) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
            am?.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        } catch (_: Exception) {}
    }

    // --- Matchers ---

    private fun isTorchOnCommand(p: String): Boolean {
        return p.contains("torch on") || p.contains("flashlight on") ||
                p.contains("torch jalao") || p.contains("light jalao") ||
                p.contains("torch chalao") || p.contains("flash on")
    }

    private fun isTorchOffCommand(p: String): Boolean {
        return p.contains("torch off") || p.contains("flashlight off") ||
                p.contains("torch band") || p.contains("light band") ||
                p.contains("torch bujha") || p.contains("flash off")
    }

    private fun isVolumeUpCommand(p: String): Boolean {
        return p.contains("volume up") || p.contains("volume badhao") ||
                p.contains("awaaz badhao") || p.contains("awaaz tezz") ||
                p.contains("increase volume") || p.contains("sound badhao")
    }

    private fun isVolumeDownCommand(p: String): Boolean {
        return p.contains("volume down") || p.contains("volume kam") ||
                p.contains("awaaz kam") || p.contains("awaaz dheemi") ||
                p.contains("decrease volume") || p.contains("sound kam")
    }

    private fun isWifiCommand(p: String): Boolean {
        return p.contains("wifi") || p.contains("wi-fi")
    }

    private fun isBluetoothCommand(p: String): Boolean {
        return p.contains("bluetooth")
    }

    private fun extractYouTubeQuery(p: String): String? {
        val patterns = listOf(
            Regex("^(?:youtube par|youtube mein)\\s+(.+?)(?:\\s+search karo|\\s+chalao|\\s+play karo)?$"),
            Regex("^(?:play|chalao)\\s+(.+?)\\s+on youtube$"),
            Regex("^youtube\\s+(.+?)(?:\\s+chalao)?$")
        )
        for (pattern in patterns) {
            val match = pattern.find(p)
            if (match != null) {
                val query = match.groupValues[1].trim()
                if (query.isNotBlank() && query != "kholo" && query != "open") {
                    return query
                }
            }
        }
        return null
    }

    private fun extractWebSearchQuery(p: String): String? {
        val patterns = listOf(
            Regex("^(?:google par|search karo|search)\\s+(.+)$"),
            Regex("^(.+?)\\s+search karo$")
        )
        for (pattern in patterns) {
            val match = pattern.find(p)
            if (match != null) {
                val query = match.groupValues[1].trim()
                if (query.isNotBlank() && !query.contains("youtube")) {
                    return query
                }
            }
        }
        return null
    }

    private fun isHomeCommand(p: String): Boolean {
        return p == "go home" || p == "home jao" || p == "home" || p == "home screen" ||
                p == "open home" || p == "go to home" || p == "main screen"
    }

    private fun isBackCommand(p: String): Boolean {
        return p == "go back" || p == "peeche jao" || p == "back jao" || p == "back" ||
                p == "wapas jao" || p == "take me back"
    }

    private fun isRecentsCommand(p: String): Boolean {
        return p.contains("recent apps") || p.contains("recent app") || p.contains("recents") ||
                p.contains("multitask") || p.contains("recent kholo")
    }

    private fun isNotificationsCommand(p: String): Boolean {
        return p.contains("notification") || p.contains("notifications")
    }

    private fun isQuickSettingsCommand(p: String): Boolean {
        return p.contains("quick settings") || p.contains("control center")
    }

    private fun isLockScreenCommand(p: String): Boolean {
        return p.contains("lock screen") || p.contains("screen lock") ||
                p.contains("phone lock") || p.contains("phone band karo")
    }

    private fun isScreenshotCommand(p: String): Boolean {
        return p.contains("screenshot") || p.contains("screen shot")
    }

    private fun isScrollDownCommand(p: String): Boolean {
        return p == "scroll down" || p.contains("neeche scroll") || p.contains("scroll neeche") ||
                p == "scroll neeche karo" || p == "neeche jao"
    }

    private fun isScrollUpCommand(p: String): Boolean {
        return p == "scroll up" || p.contains("upar scroll") || p.contains("scroll upar") ||
                p == "scroll upar karo" || p == "upar jao"
    }

    private fun extractTypingText(p: String): String? {
        val patterns = listOf(
            Regex("^(?:type|write|likho|enter)\\s+(.+)"),
            Regex("^(.+)\\s+likh\\s+do$"),
            Regex("^(.+)\\s+type\\s+karo$")
        )
        for (pattern in patterns) {
            val match = pattern.find(p)
            if (match != null) {
                val text = match.groupValues[1].trim()
                if (text.isNotBlank()) return text
            }
        }
        return null
    }

    private fun extractClickTarget(p: String): String? {
        val patterns = listOf(
            Regex("^(?:click\\s+on|tap\\s+on|press)\\s+(.+)"),
            Regex("^(.+)\\s+par\\s+(?:click|tap)\\s+karo$"),
            Regex("^(.+)\\s+dabao$")
        )
        for (pattern in patterns) {
            val match = pattern.find(p)
            if (match != null) {
                val target = match.groupValues[1].trim()
                if (target.isNotBlank()) return target
            }
        }
        return null
    }

    private fun extractAppToLaunch(p: String): String? {
        // Multi-Step Action Guard: Never hijack messaging, media playback, search, or capture actions
        val multiStepIntents = listOf(
            "message", "text", "bhejo", "bhej", "sandesh", "likho", "send", "song",
            "gaana", "gana", "geet", "download", "kheencho", "photo", "search",
            "dhoondo", "khojo", "karke", "aage karo", "skip ad", "skip add",
            "मैसेज", "भेजो", "सॉन्ग", "गाना", "गीत", "फोटो", "खींचो", "सर्च", "खोजो", "डाउनलोड", "करके"
        )
        if (multiStepIntents.any { p.contains(it) }) {
            return null
        }

        val knownTargetApps = listOf(
            "instagram", "insta", "इंस्टाग्राम",
            "youtube", "yt", "युटुब",
            "facebook", "fb", "फेसबुक",
            "telegram", "टेलीग्राम",
            "whatsapp", "व्हाट्सएप",
            "call logs", "call log", "calls", "कॉल लॉग्स", "कॉल लॉग", "call history",
            "sms", "messages", "message", "मैसेज",
            "sharechat", "शेयरचैट",
            "chrome", "chrome browser", "browser", "ब्राउज़र", "क्रोम",
            "android studio", "एंड्राइड स्टूडियो", "studio",
            "chatgpt", "chet gpt", "chat gpt",
            "gemini", "bard",
            "notes", "nots", "keep", "नोट्स",
            "google drive", "drive", "ड्राइव",
            "terabox", "टेराबॉक्स",
            "camera", "settings", "calculator", "maps", "photos", "gallery", "clock", "gmail"
        )

        for (target in knownTargetApps) {
            if (p == target || p.contains("$target kholo") || p.contains("kholo $target") ||
                p.contains("$target open") || p.contains("open $target") ||
                p.contains("$target chalao") || p.contains("$target dikhao")) {
                return target
            }
        }

        val patterns = listOf(
            Regex("^(?:open|launch|start|kholo|dikhao)\\s+([\\p{L}\\p{N} ]+)"),
            Regex("^([\\p{L}\\p{N} ]+)\\s+(?:kholo|open\\s+karo|open|chalao|dikhao)$")
        )
        for (pattern in patterns) {
            val match = pattern.find(p)
            if (match != null) {
                val app = match.groupValues[1].trim()
                if (app !in listOf("home", "back", "recents", "recent", "recent apps", "recent app", "notifications", "notification", "torch", "light", "volume", "quick settings") || (app.contains("settings") && !app.contains("quick settings"))) {
                    return app
                }
            }
        }
        return null
    }

    private fun isHistoryCommand(p: String): Boolean {
        return p == "history" || p.contains("show history") || p.contains("open history") ||
                p.contains("history dikhao") || p.contains("recent history") ||
                p.contains("conversation history") || p.contains("view history") ||
                p.contains("purani baatein") || p.contains("history panel") ||
                p.contains("previous conversations") || p.contains("history kholo")
    }

    private fun isSkipAdCommand(p: String): Boolean =
        com.example.VoiceCommandRouter.isSkipAdCommand(p)

    internal fun isScreenPerceptionCommand(p: String): Boolean =
        com.example.VoiceCommandRouter.isScreenQuery(p)
}
