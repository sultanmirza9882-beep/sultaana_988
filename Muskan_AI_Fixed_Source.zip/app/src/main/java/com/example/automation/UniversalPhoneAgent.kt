package com.example.automation

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import android.net.Uri
import android.provider.ContactsContract
import android.util.Base64
import android.view.accessibility.AccessibilityNodeInfo
import com.example.VoiceSessionManager
import com.example.data.AgentLlm
import com.example.engine.approval.OwnerApprovalGate
import com.example.engine.approval.SensitiveActionType
import com.example.engine.learning.PhoneKnowledgeStore
import com.example.service.AgentTouchVisualizer
import com.example.service.MuskanAccessibilityService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Locale
import kotlin.random.Random

/**
 * UniversalPhoneAgent (v8 — Patched & Hardened for Redmi 13 5G / Xiaomi HyperOS)
 *
 * Loop: look at the screen -> think (Gemini) -> do ONE human-like action -> look again -> ...
 *   - "Look" = Accessibility UI tree (numbered elements) + an optional screenshot when the tree is poor.
 *   - "Do"   = the neon cursor travels along a natural curve to the target, presses, then a real
 *              touch gesture is dispatched.
 *   - "Think" gets the phone profile, what Sultan taught Muskan (notes / video lessons), built-in Redmi 13 5G
 *              knowledge, and routines Muskan already completed successfully before.
 */
object UniversalPhoneAgent {

    private const val MAX_STEPS = 45

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    @Volatile private var job: Job? = null
    @Volatile private var cancelFlag = false

    val isRunning: Boolean get() = job?.isActive == true

    // ------------------------------------------------------------------ routing helpers

    private val actionVerbs = listOf(
        "open", "kholo", "खोलो", "खोल", "chalao", "चलाओ", "play", "bhejo", "भेजो", "send", "message", "msg",
        "save", "सेव", "download", "डाउनलोड", "laga", "लगा", "post", "likho", "लिखो", "type", "टाइप",
        "search", "dhundo", "ढूंढो", "ढूँढो", "call", "install", "set", "bana", "बना", "edit", "share", "शेयर",
        "scroll", "click", "tap", "dabao", "दबाओ", "delete", "hata", "हटा", "upload", "अपलोड", "daal", "डाल",
        "on karo", "off karo", "band karo", "बंद", "ऑन करो", "ऑफ करो", "kar do", "कर दो", "karke", "करके",
        "like karo", "लाइक करो", "translate", "ट्रांसलेट"
    )
    private val joiners = listOf(" aur ", " phir ", " fir ", " uske baad", " और ", " फिर ", " उसके बाद", " karke ", " करके ", " then ", " and then ")
    private val questionStarts = listOf("kya ", "kaun ", "kyun ", "kyu ", "kab ", "kitna ", "kaise ", "what ", "who ", "why ", "how ", "when ",
        "क्या ", "कौन ", "क्यों ", "कब ", "कितना ", "कैसे ")
    private val imperative = listOf("karo", "kar do", "करो", "कर दो", "kijiye", "कीजिए")

    private fun verbCount(l: String): Int = actionVerbs.count { l.contains(it) }

    /** Multi-step / open-ended requests are given to the agent FIRST (fixed macros handle them badly). */
    fun shouldTakePriority(prompt: String): Boolean {
        val l = " " + prompt.lowercase(Locale.ROOT).trim() + " "
        val compound = joiners.any { l.contains(it) } && verbCount(l) >= 2
        val download = l.contains("download") || l.contains("डाउनलोड")
        val story = (l.contains("story") || l.contains("स्टोरी")) &&
                listOf("laga", "लगा", "post", "upload", "अपलोड", "daal", "डाल").any { l.contains(it) }
        val contactSave = (l.contains("contact") || l.contains("कॉन्टैक्ट") || l.contains("कांटेक्ट")) &&
                (l.contains("save") || l.contains("सेव"))
        val photoEdit = l.contains("edit") && (l.contains("photo") || l.contains("फोटो") || l.contains("pic"))
        return compound || download || story || contactSave || photoEdit
    }

    /** Anything that sounds like "do something on the phone" that no fixed macro/engine handled. */
    fun shouldHandle(prompt: String): Boolean {
        val l = prompt.lowercase(Locale.ROOT).trim() + " "
        val isQuestion = questionStarts.any { l.startsWith(it) } && imperative.none { l.contains(it) }
        return !isQuestion && verbCount(l) >= 1
    }

    // ------------------------------------------------------------------ public API

    fun start(context: Context, goal: String, onFinished: (success: Boolean, message: String) -> Unit) {
        cancel()
        cancelFlag = false
        job = scope.launch {
            val result = try {
                run(context, goal)
            } catch (e: CancellationException) {
                false to "Kaam beech mein rok diya gaya."
            } catch (e: Exception) {
                false to "Kaam beech mein ruk gaya: ${e.message}"
            }
            onFinished(result.first, result.second)
        }
    }

    fun cancel() {
        cancelFlag = true
        job?.cancel()
        job = null
    }

    // ------------------------------------------------------------------ the loop

    private class UiEl(val idx: Int, val role: String, val label: String, val cx: Float, val cy: Float)

    private data class Step(val action: String, val detail: String, val result: String)

    suspend fun run(context: Context, goal: String): Pair<Boolean, String> {
        val ctx = context.applicationContext
        PhoneKnowledgeStore.init(ctx)
        cancelFlag = false

        val svc = MuskanAccessibilityService.instance
        if (svc == null) {
            MuskanAccessibilityService.openAccessibilitySettings(ctx)
            return false to "Sultan, Accessibility Service band hai. Settings mein Muskan Automation ON karein, phir dobara bolein."
        }

        val viz = AgentTouchVisualizer.getInstance(ctx)
        viz.show()
        val dm = ctx.resources.displayMetrics
        val history = ArrayList<Step>()
        val doneActions = ArrayList<String>()       // for routine learning
        var needLook = false
        var lastSig = ""
        var sameCount = 0
        var okActions = 0

        val system = buildSystemPrompt()

        try {
            for (stepNo in 1..MAX_STEPS) {
                if (cancelFlag) return false to "Kaam rok diya gaya."

                // 1) LOOK
                val root = svc.rootInActiveWindow
                val els = ArrayList<UiEl>()
                collect(root, els, dm.widthPixels, dm.heightPixels, false)
                val pkg = root?.packageName?.toString().orEmpty()
                val keyboard = ScreenPerceptionEngine.captureScreenSnapshot().isKeyboardVisible
                val sig = pkg + "|" + els.take(40).joinToString("|") { it.label }.hashCode()
                sameCount = if (sig == lastSig) sameCount + 1 else 0
                lastSig = sig

                if (sameCount >= 6) return false to "Screen par koi badlaav nahi aa raha, isliye kaam rok diya. Pehle ke steps: " +
                        history.takeLast(3).joinToString("; ") { "${it.action} ${it.detail}" }

                val wantImage = needLook || els.size < 8 || sameCount >= 1
                val image = if (wantImage) screenshotBase64(svc) else null
                needLook = false

                VoiceSessionManager.updateAgenticExecution(
                    running = true, title = goal.take(40), step = stepNo, total = MAX_STEPS,
                    statusText = "Soch rahi hoon (step $stepNo)…"
                )

                // 2) THINK  (knowledge is matched to the goal AND the app now on screen)
                val knowledge = PhoneKnowledgeStore.promptContext(goal, pkg)
                val user = buildString {
                    append("GOAL FROM SULTAN: ").append(goal).append("\n\n")
                    append(knowledge).append("\n")
                    if (history.isNotEmpty()) {
                        append("ACTIONS SO FAR (latest last):\n")
                        history.takeLast(12).forEachIndexed { i, s ->
                            append("${history.size - history.takeLast(12).size + i + 1}. ${s.action} ${s.detail} -> ${s.result}\n")
                        }
                        append("\n")
                    }
                    if (sameCount >= 1) append("WARNING: the screen did not change after your last action. Try something different.\n")
                    append("SCREEN NOW: app=$pkg keyboard=${if (keyboard) "visible" else "hidden"} size=${dm.widthPixels}x${dm.heightPixels}\n")
                    if (els.isEmpty()) append("(no readable elements; use the screenshot)\n")
                    els.forEach { append("[${it.idx}] ${it.role} \"${it.label}\" @${it.cx.toInt()},${it.cy.toInt()}\n") }
                    if (image != null) append("\n(A screenshot of the current screen is attached.)\n")
                    append("\nGive the single next action as JSON.")
                }

                val raw = AgentLlm.generate(system, user, listOfNotNull(image))
                    .getOrElse { return false to (it.message ?: "AI se jawab nahi mila.") }
                val cmd = parseJson(raw)
                if (cmd == null) {
                    history.add(Step("(invalid reply)", "", "reply was not JSON; answer with one JSON object only"))
                    if (history.count { it.action == "(invalid reply)" } >= 4) return false to "AI ka jawab samajh nahi aaya."
                    continue
                }

                val action = cmd.optString("action").lowercase(Locale.ROOT).trim()
                val thought = cmd.optString("thought").take(90)
                if (thought.isNotBlank()) {
                    VoiceSessionManager.updateAgenticExecution(
                        running = true, title = goal.take(40), step = stepNo, total = MAX_STEPS, statusText = thought
                    )
                }

                // 3) DO
                when (action) {
                    "done" -> {
                        if (okActions == 0) {
                            history.add(Step("done", "", "rejected: nothing was done yet"))
                            continue
                        }
                        PhoneKnowledgeStore.recordRoutine(goal, doneActions.take(30))
                        return true to cmd.optString("summary").ifBlank { "Kaam ho gaya, Sultan." }
                    }
                    "fail" -> return false to cmd.optString("reason").ifBlank { "Kaam poora nahi ho paya." }
                    "ask_user" -> return false to cmd.optString("question").ifBlank { "Sultan, mujhe aapki madad chahiye." }
                    "look" -> { needLook = true; history.add(Step("look", "", "ok")); continue }
                }

                val exec = execute(ctx, svc, viz, action, cmd, els)
                val ok = exec.ok
                history.add(Step(action, exec.detail, exec.result))
                if (exec.result.startsWith("cancelled: owner denied")) {
                    return false to "Owner ne permission reject kar di, action cancel kar diya gaya."
                }
                if (ok) {
                    okActions++
                    if (action != "wait" && action != "look") doneActions.add("$action ${exec.detail}".trim())
                }
                delay(Random.nextLong(500, 800))   // let the app react before looking again
            }
            return false to "Itne steps mein kaam poora nahi ho paya. Ab tak: " +
                    history.takeLast(3).joinToString("; ") { "${it.action} ${it.detail}" }
        } finally {
            VoiceSessionManager.updateAgenticExecution(false, null, 0, 0, null)
        }
    }

    // ------------------------------------------------------------------ actions

    private data class Exec(val ok: Boolean, val detail: String, val result: String)

    /**
     * Checks whether a proposed [UniversalPhoneAgent] step triggers a sensitive outbound
     * action (`CALL_PHONE`, `SEND_SMS`, or final WhatsApp send). When triggered, suspends
     * on [OwnerApprovalGate.requestSensitiveActionApproval] and returns `false` if denied.
     */
    internal suspend fun awaitApprovalIfSensitive(
        action: String,
        cmd: JSONObject,
        targetLabel: String?,
        foregroundPkg: String
    ): Pair<Boolean, String?> {
        val pkgLower = foregroundPkg.lowercase(Locale.ROOT)
        val labelLower = targetLabel.orEmpty().lowercase(Locale.ROOT)
        val url = cmd.optString("url").trim()
        val urlLower = url.lowercase(Locale.ROOT)

        val sensitiveRequest: Triple<SensitiveActionType, String, String>? = when {
            action == "call_phone" -> {
                val target = cmd.optString("number").ifBlank { cmd.optString("recipient").ifBlank { "Phone target" } }
                Triple(SensitiveActionType.CALL_PHONE, target, "Sultan, '$target' par phone call lagane ki approval chahiye.")
            }
            action == "open_url" && urlLower.startsWith("tel:") -> {
                val target = url.substringAfter(":").ifBlank { "Phone target" }
                Triple(SensitiveActionType.CALL_PHONE, target, "Sultan, '$target' par phone call lagane ki approval chahiye.")
            }
            action == "send_sms" -> {
                val target = cmd.optString("number").ifBlank { cmd.optString("recipient").ifBlank { "SMS recipient" } }
                val body = cmd.optString("text").ifBlank { cmd.optString("message") }
                Triple(SensitiveActionType.SEND_SMS, target, "Sultan, '$target' ko SMS bhejne ki approval chahiye${if (body.isNotBlank()) ": \"$body\"" else "."}")
            }
            action == "open_url" && (urlLower.startsWith("sms:") || urlLower.startsWith("smsto:")) -> {
                val target = url.substringAfter(":").substringBefore("?").ifBlank { "SMS recipient" }
                Triple(SensitiveActionType.SEND_SMS, target, "Sultan, '$target' ko SMS compose/send karne ki approval chahiye.")
            }
            pkgLower.contains("whatsapp") &&
                action in setOf("tap", "tap_text", "tap_xy") &&
                (labelLower.contains("send") || labelLower.contains("bhejo") || labelLower.contains("भेजो")) -> {
                Triple(SensitiveActionType.WHATSAPP_SEND, "WhatsApp Chat", "Sultan, WhatsApp par final Send button dabane ke liye approval chahiye.")
            }
            (pkgLower.contains("messaging") || pkgLower.contains("mms") || pkgLower.contains("sms")) &&
                action in setOf("tap", "tap_text", "tap_xy") &&
                (labelLower.contains("send") || labelLower.contains("sms") || labelLower.contains("bhejo")) -> {
                Triple(SensitiveActionType.SEND_SMS, "SMS Conversation", "Sultan, SMS final Send button dabane ke liye approval chahiye.")
            }
            (pkgLower.contains("dialer") || pkgLower.contains("telecom")) &&
                action in setOf("tap", "tap_text", "tap_xy") &&
                (labelLower.contains("call") || labelLower.contains("dial") || labelLower.contains("कॉल")) -> {
                Triple(SensitiveActionType.CALL_PHONE, targetLabel.orEmpty().ifBlank { "Dialer" }, "Sultan, dialer par Call button dabane ke liye approval chahiye.")
            }
            else -> null
        }

        if (sensitiveRequest == null) return true to null

        val (type, recipient, summary) = sensitiveRequest
        val preview = cmd.optString("text").ifBlank {
            cmd.optString("message").ifBlank { url.ifBlank { targetLabel } }
        }
        val approved = OwnerApprovalGate.requestSensitiveActionApproval(
            actionType = type,
            recipient = recipient,
            summary = summary,
            payloadPreview = preview,
            technicalDetails = "UniversalPhoneAgent action=$action pkg=$foregroundPkg target=$targetLabel"
        )
        return if (approved) {
            true to null
        } else {
            false to "cancelled: owner denied ${type.label} approval"
        }
    }

    private suspend fun execute(
        ctx: Context, svc: MuskanAccessibilityService, viz: AgentTouchVisualizer,
        action: String, cmd: JSONObject, els: List<UiEl>
    ): Exec {
        val dm = ctx.resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val foregroundPkg = svc.rootInActiveWindow?.packageName?.toString().orEmpty()

        fun target(): Triple<Float, Float, String>? {
            if (cmd.has("index")) {
                val e = els.firstOrNull { it.idx == cmd.optInt("index", -1) } ?: return null
                return Triple(e.cx, e.cy, e.label.take(30))
            }
            if (cmd.has("x") && cmd.has("y")) {
                return Triple(cmd.optDouble("x").toFloat().coerceIn(1f, w - 1), cmd.optDouble("y").toFloat().coerceIn(1f, h - 1), "(${cmd.optInt("x")},${cmd.optInt("y")})")
            }
            val t = cmd.optString("text").lowercase(Locale.ROOT)
            if (t.isNotBlank()) {
                val e = els.firstOrNull { it.label.lowercase(Locale.ROOT) == t }
                    ?: els.firstOrNull { it.label.lowercase(Locale.ROOT).contains(t) } ?: return null
                return Triple(e.cx, e.cy, e.label.take(30))
            }
            return null
        }

        return try {
            when (action) {
                "open_app" -> {
                    val name = cmd.optString("name")
                    val launched = MuskanAccessibilityService.launchAppByName(ctx, name) || launchByLabel(ctx, name)
                    if (!launched) return Exec(false, name, "failed: app '$name' not installed")
                    delay(1900)
                    val pkg = svc.rootInActiveWindow?.packageName?.toString().orEmpty()
                    Exec(true, name, "ok: launched, foreground app is now $pkg")
                }
                "tap", "tap_text", "tap_xy" -> {
                    val t = target() ?: return Exec(false, cmd.toString().take(50), "failed: target not found on screen")
                    val (approved, denialReason) = awaitApprovalIfSensitive(action, cmd, t.third, foregroundPkg)
                    if (!approved) return Exec(false, "'${t.third}'", denialReason ?: "cancelled: owner denied approval")
                    val ok = humanTap(ctx, svc, viz, t.first, t.second, "Tap: ${t.third}")
                    Exec(ok, "'${t.third}'", if (ok) "ok: tapped" else "failed: gesture rejected")
                }
                "double_tap" -> {
                    val t = target() ?: return Exec(false, cmd.toString().take(50), "failed: target not found on screen")
                    val travel = viz.humanMoveTo(t.first, t.second, "Double tap: ${t.third}")
                    delay(travel + Random.nextLong(60, 140))
                    viz.press()
                    AgentTouchVisualizer.markAgentAction()
                    val ok = svc.dispatchDoubleTap(t.first, t.second)
                    delay(Random.nextLong(350, 550))
                    Exec(ok, "'${t.third}'", if (ok) "ok: double tapped" else "failed: gesture rejected")
                }
                "long_press" -> {
                    val t = target() ?: return Exec(false, "", "failed: target not found")
                    val d = viz.humanMoveTo(t.first, t.second, "Long press")
                    delay(d + 100)
                    viz.press()
                    AgentTouchVisualizer.markAgentAction()
                    val ok = svc.dispatchCoordinateLongPress(t.first, t.second, 700L)
                    delay(900)
                    Exec(ok, "'${t.third}'", if (ok) "ok: long pressed" else "failed")
                }
                "type" -> {
                    val text = cmd.optString("text")
                    if (text.isBlank()) return Exec(false, "", "failed: empty text")
                    if (cmd.has("index") || (cmd.has("x") && cmd.has("y"))) {
                        val t = target() ?: return Exec(false, "", "failed: field not found")
                        humanTap(ctx, svc, viz, t.first, t.second, "Field: ${t.third}")
                        delay(450)
                    }
                    typeHuman(ctx, svc, viz, text)
                }
                "enter" -> {
                    AgentTouchVisualizer.markAgentAction()
                    val ok = svc.submitFocusedTextField()
                    delay(700)
                    Exec(ok, "", if (ok) "ok: enter/search pressed" else "failed: no focused field to submit")
                }
                "scroll" -> {
                    val dir = cmd.optString("direction", "down").lowercase(Locale.ROOT)
                    val j = { (Random.nextFloat() - 0.5f) * 0.05f }
                    val (x1, y1, x2, y2) = when (dir) {
                        "up" -> listOf(w * (0.5f + j()), h * 0.30f, w * (0.5f + j()), h * 0.72f)
                        "left" -> listOf(w * 0.25f, h * (0.5f + j()), w * 0.80f, h * (0.5f + j()))
                        "right" -> listOf(w * 0.80f, h * (0.5f + j()), w * 0.25f, h * (0.5f + j()))
                        else -> listOf(w * (0.5f + j()), h * 0.72f, w * (0.5f + j()), h * 0.30f)
                    }
                    humanSwipe(svc, viz, x1, y1, x2, y2, "Scroll $dir")
                    Exec(true, dir, "ok: scrolled $dir")
                }
                "swipe" -> {
                    humanSwipe(svc, viz,
                        cmd.optDouble("x1").toFloat(), cmd.optDouble("y1").toFloat(),
                        cmd.optDouble("x2").toFloat(), cmd.optDouble("y2").toFloat(), "Swipe")
                    Exec(true, "", "ok: swiped")
                }
                "back" -> { AgentTouchVisualizer.markAgentAction(); svc.triggerBack(); delay(600); Exec(true, "", "ok: back") }
                "home" -> { AgentTouchVisualizer.markAgentAction(); svc.triggerHome(); delay(700); Exec(true, "", "ok: home") }
                "recents" -> { AgentTouchVisualizer.markAgentAction(); svc.triggerRecents(); delay(700); Exec(true, "", "ok: recents") }
                "notifications", "open_notifications" -> {
                    AgentTouchVisualizer.markAgentAction()
                    val ok = svc.triggerNotifications()
                    delay(800)
                    Exec(ok, "", if (ok) "ok: notifications shade opened" else "failed")
                }
                "quick_settings", "open_quick_settings" -> {
                    AgentTouchVisualizer.markAgentAction()
                    val ok = svc.triggerQuickSettings()
                    delay(800)
                    Exec(ok, "", if (ok) "ok: control center / quick settings opened" else "failed")
                }
                "wait" -> {
                    val ms = cmd.optLong("ms", 1500L).coerceIn(300L, 6000L)
                    delay(ms); Exec(true, "${ms}ms", "ok: waited")
                }
                "open_url" -> {
                    val url = cmd.optString("url")
                    val (approved, denialReason) = awaitApprovalIfSensitive(action, cmd, url, foregroundPkg)
                    if (!approved) return Exec(false, url.take(60), denialReason ?: "cancelled: owner denied approval")
                    val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    ctx.startActivity(i)
                    delay(2000)
                    Exec(true, url.take(60), "ok: opened")
                }
                "call_phone" -> {
                    val number = cmd.optString("number").ifBlank { cmd.optString("recipient") }
                    val (approved, denialReason) = awaitApprovalIfSensitive(action, cmd, number, foregroundPkg)
                    if (!approved) return Exec(false, number, denialReason ?: "cancelled: owner denied approval")
                    val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    ctx.startActivity(i)
                    delay(1500)
                    Exec(true, number, "ok: dialer opened")
                }
                "send_sms" -> {
                    val number = cmd.optString("number").ifBlank { cmd.optString("recipient") }
                    val body = cmd.optString("text").ifBlank { cmd.optString("message") }
                    val (approved, denialReason) = awaitApprovalIfSensitive(action, cmd, number, foregroundPkg)
                    if (!approved) return Exec(false, number, denialReason ?: "cancelled: owner denied approval")
                    val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply {
                        putExtra("sms_body", body)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    ctx.startActivity(i)
                    delay(1500)
                    Exec(true, number, "ok: SMS composer opened")
                }
                "save_contact" -> {
                    val i = Intent(ContactsContract.Intents.Insert.ACTION).apply {
                        type = ContactsContract.RawContacts.CONTENT_TYPE
                        putExtra(ContactsContract.Intents.Insert.NAME, cmd.optString("name"))
                        putExtra(ContactsContract.Intents.Insert.PHONE, cmd.optString("number"))
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    ctx.startActivity(i)
                    delay(1800)
                    Exec(true, cmd.optString("name"), "ok: contact editor opened with name and number filled; now tap its Save button")
                }
                else -> Exec(false, action, "failed: unknown action '$action'")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Exec(false, action, "failed: ${e.message}")
        }
    }

    private suspend fun humanTap(ctx: Context, svc: MuskanAccessibilityService, viz: AgentTouchVisualizer, x: Float, y: Float, label: String): Boolean {
        val travel = viz.humanMoveTo(x, y, label)
        delay(travel + Random.nextLong(60, 140))
        viz.press()
        delay(Random.nextLong(50, 95))
        AgentTouchVisualizer.markAgentAction()
        val ok = svc.dispatchCoordinateTap(x, y, Random.nextLong(55, 100), animatePointer = false)
        delay(Random.nextLong(250, 450))
        return ok
    }

    private suspend fun humanSwipe(svc: MuskanAccessibilityService, viz: AgentTouchVisualizer, x1: Float, y1: Float, x2: Float, y2: Float, label: String) {
        val travel = viz.humanMoveTo(x1, y1, label)
        delay(travel + Random.nextLong(60, 140))
        viz.press()
        val dur = Random.nextLong(360, 520)
        AgentTouchVisualizer.markAgentAction()
        svc.dispatchHumanSwipe(x1, y1, x2, y2, dur)
        delay(dur + 450)
    }

    private suspend fun typeHuman(ctx: Context, svc: MuskanAccessibilityService, viz: AgentTouchVisualizer, text: String): Exec {
        val root = svc.rootInActiveWindow
        val node = root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
            ?: root?.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY)?.takeIf { it.isEditable }
        if (node != null && node.isPassword) {
            return Exec(false, "", "blocked: this is a password field. Do not type passwords; use ask_user.")
        }
        if (node != null) {
            val r = Rect(); node.getBoundsInScreen(r)
            viz.showAction(r.exactCenterX(), r.exactCenterY(), "Typing…")
            AgentTouchVisualizer.markAgentAction()
            val fullArgs = android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, fullArgs)) {
                delay(280)
                return Exec(true, "'${text.take(30)}'", "ok: text is in the field")
            }
        }
        AgentTouchVisualizer.markAgentAction()
        val res = ScreenPerceptionEngine.executeVerifiedType(text, timeoutMs = 2500L)
        delay(300)
        return if (res.isSuccess) Exec(true, "'${text.take(30)}'", "ok: text is in the field")
        else Exec(false, "'${text.take(30)}'", "failed: ${res.message}")
    }

    private fun launchByLabel(ctx: Context, name: String): Boolean {
        if (name.isBlank()) return false
        return try {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val match = pm.queryIntentActivities(i, 0).firstOrNull {
                it.loadLabel(pm).toString().lowercase(Locale.ROOT).contains(name.lowercase(Locale.ROOT))
            } ?: return false
            val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(launch)
            true
        } catch (_: Exception) { false }
    }

    // ------------------------------------------------------------------ perception helpers

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<UiEl>, sw: Int, sh: Int, clickableAncestor: Boolean) {
        if (node == null || out.size >= 70) return
        if (node.isVisibleToUser) {
            val label = (node.text?.toString()?.takeIf { it.isNotBlank() }
                ?: node.contentDescription?.toString()?.takeIf { it.isNotBlank() }
                ?: (if (android.os.Build.VERSION.SDK_INT >= 26) node.hintText?.toString() else null).orEmpty()).replace("\n", " ").take(60)
            val r = Rect(); node.getBoundsInScreen(r)
            val cx = r.exactCenterX(); val cy = r.exactCenterY()
            val onScreen = r.width() > 3 && r.height() > 3 && cx in 0f..sw.toFloat() && cy in 0f..sh.toFloat()
            val role = when {
                node.isEditable -> "edit"
                node.isClickable || clickableAncestor -> "btn"
                node.isScrollable -> "scroll"
                else -> "text"
            }
            if (onScreen && (label.isNotBlank() || node.isEditable || node.isClickable || node.isScrollable)) {
                val dup = out.any { it.label == label && Math.abs(it.cx - cx) < 6 && Math.abs(it.cy - cy) < 6 }
                if (!dup) out.add(UiEl(out.size, role, label, cx, cy))
            }
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), out, sw, sh, clickableAncestor || node.isClickable)
    }

    private suspend fun screenshotBase64(svc: MuskanAccessibilityService): String? {
        return withTimeoutOrNull(4500L) {
            suspendCancellableCoroutine<String?> { cont ->
                svc.takeScreenCaptureBitmap { bmp ->
                    if (!cont.isActive) return@takeScreenCaptureBitmap
                    if (bmp == null) { cont.resumeWith(Result.success(null)); return@takeScreenCaptureBitmap }
                    try {
                        val scale = 1024f / maxOf(bmp.width, bmp.height)
                        val scaled = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
                        val bos = ByteArrayOutputStream()
                        scaled.compress(Bitmap.CompressFormat.JPEG, 55, bos)
                        cont.resumeWith(Result.success(Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)))
                    } catch (_: Exception) {
                        cont.resumeWith(Result.success(null))
                    }
                }
            }
        }
    }

    private fun parseJson(raw: String): JSONObject? {
        var s = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val a = s.indexOf('{'); val b = s.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        s = s.substring(a, b + 1)
        return try { JSONObject(s) } catch (_: Exception) { null }
    }

    private fun buildSystemPrompt(): String = """
You are Muskan, Sultan's personal phone assistant. Sultan gives you ONLY the goal; you work out how to do it yourself, exactly like a friend who is handed his phone. You operate the real phone one action at a time by looking at the screen.

Reply with ONE JSON object and nothing else:
{"thought":"very short reason","action":"<name>", ...arguments}

Actions:
- open_app {"name":"instagram"}            open an installed app by its name
- tap {"index":N}                          tap element N from the SCREEN list (preferred)
- tap_text {"text":"Reels"}                tap the element whose label matches
- tap_xy {"x":540,"y":1200}                tap coordinates (use with the screenshot or Redmi 13 5G notes when the list lacks the target)
- double_tap {"index":N} or {"x":540,"y":1100}  double-tap to like a Reel/Short or seek +10s/-10s in YouTube
- long_press {"index":N} or {"x":540,"y":2255}  long-press an element or coordinate
- type {"text":"...","index":N}            type into a field (index or x,y optional: taps that field first). Replaces the field's content.
- enter {}                                 press Search/Send/Enter on the keyboard (or Gboard action key)
- scroll {"direction":"down"}              down = reveal content below, up = above, left/right likewise
- swipe {"x1":..,"y1":..,"x2":..,"y2":..}
- back {}   home {}   recents {}
- notifications {}                         open the Notification Shade directly
- quick_settings {}                        open the HyperOS Control Center / Quick Settings directly
- wait {"ms":1500}                         let a screen finish loading
- look {}                                  get a screenshot next step
- open_url {"url":"https://..."}           also https://wa.me/<number with country code>?text=<message>, tel:, sms:
- save_contact {"name":"..","number":".."} opens the contact editor already filled; then tap its Save button
- done {"summary":"one short Hinglish sentence"}
- fail {"reason":"honest short Hinglish reason"}
- ask_user {"question":"short Hinglish question"}

Rules:
1. One action per reply. After each action you get the new screen. Never assume an action worked; read the next screen.
2. Say done ONLY when the screen proves the goal is complete (message visibly sent, video playing, note saved, story posted, download visible as finished/started). Otherwise keep going or fail honestly. Never claim what the screen does not show.
3. Dismiss obstacles yourself: cookie/notification pop-ups ("Not now", "Skip", "Later"), tutorials, update prompts, ads (tap Skip / the X). Allow ordinary app permissions needed for the goal.
4. If a screen needs a login, password, OTP/verification code, CAPTCHA, payment, card details, or a purchase/subscription: STOP and use ask_user. Never type passwords or OTPs. Never buy or subscribe.
5. Movies/shows/music: use legal sources only (YouTube Movies / free-with-ads, Prime Video, Netflix, JioHotstar, Google Play, official apps, official free sites). Do not use torrent or piracy sites or "free download" sites; if the title is only available paid, tell Sultan via ask_user or fail with the real reason.
6. Posting stories/messages that Sultan asked for is allowed. Keep generated captions/messages friendly, short and harmless unless he gave exact words. Do not message anyone Sultan did not name.
7. To send a WhatsApp message, prefer open_url with wa.me and then tap the Send button. To search inside an app: tap the search field, type, then enter.
8. If Sultan's TAUGHT notes, the PHONE NOTES (Redmi 13 5G / HyperOS) or a PREVIOUS ROUTINE describe how to do something on this phone, follow that. Their coordinates were written for a 1080x2460 screen: compare with the real "size=" in the SCREEN line and scale, and always prefer an on-screen element label/index over a remembered coordinate. Always verify against the actual screen.
9. Be efficient: do not repeat a failed action more than twice; change approach (different element, scroll, use the screenshot, go back).
""".trimIndent()
}
