package com.example.automation

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.VoiceSessionManager
import com.example.engine.approval.OwnerApprovalGate
import com.example.engine.approval.SensitiveActionType
import com.example.service.MuskanAccessibilityService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Execution step in an autonomous agentic task plan.
 */
data class AgenticStep(
    val id: String,
    val description: String,
    val action: suspend (context: Context) -> StepOutcome
)

sealed class StepOutcome {
    object Success : StepOutcome() {
        operator fun invoke() = this
    }
    data class Failure(val reason: String, val canRetry: Boolean = false) : StepOutcome()
}

data class AgenticPlan(
    val title: String,
    val userPrompt: String,
    val steps: List<AgenticStep>,
    val completionSpeech: String,
    val fallbackSpeech: String = "Maaf kijiye, task complete nahi ho paya.",
    val requiresAccessibility: Boolean = false
)

data class YouTubeTask(
    val query: String,
    val skipAd: Boolean = false,
    val seekSeconds: Int = 0
)

object AgenticExecutionPlanner {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var currentExecutionJob: Job? = null

    private val _isExecuting = MutableStateFlow(false)
    val isExecuting: StateFlow<Boolean> = _isExecuting.asStateFlow()

    private val _currentPlanTitle = MutableStateFlow<String?>(null)
    val currentPlanTitle: StateFlow<String?> = _currentPlanTitle.asStateFlow()

    private val _stepStatusText = MutableStateFlow<String?>(null)
    val stepStatusText: StateFlow<String?> = _stepStatusText.asStateFlow()

    /**
     * Inspects prompt to detect high-level multi-step autonomous agentic scenarios.
     * Following Sultan Mirza's master autonomous workflow:
     * Dekho -> Samjho/Plan banao -> Action karo -> Verify karo -> Report karo
     */
    fun createPlanForPrompt(prompt: String): AgenticPlan? {
        val lower = prompt.lowercase(Locale.ROOT).trim()

        // 0. Skip Ad Standalone Scenario: "muskan ad skip kro", "skip ad", "ad skip karo", "skip add"
        if (com.example.VoiceCommandRouter.isSkipAdCommand(lower)) {
            return buildSkipAdPlan(prompt)
        }

        // 0.1 Type into whatever field is on screen: "yahan type karo hello" / "यहाँ टाइप करो ..."
        val typeHere = matchTypeHere(lower)
        if (typeHere != null) {
            return buildTypeHerePlan(typeHere, prompt)
        }

        // 0.2 Sketch: "circle banao" / "sketch karo" / "स्केच बनाओ"
        if (isSketchCommand(lower)) {
            return buildSketchPlan(prompt)
        }

        // 1. WhatsApp Messaging Scenario: "Aman ko WhatsApp par text bhejo" / "WhatsApp par Aman ko message bhejo"
        val whatsappMatch = matchWhatsAppSend(lower)
        if (whatsappMatch != null) {
            val (contact, message) = whatsappMatch
            return buildWhatsAppSendPlan(contact, message, prompt)
        }

        // 1.1 Telegram Messaging Scenario: "Telegram par Aman ko message bhejo"
        val tgMatch = matchTelegramSend(lower)
        if (tgMatch != null) {
            val (contact, message) = tgMatch
            return buildTelegramSendPlan(contact, message, prompt)
        }

        // 1.2 SMS Messaging Scenario: "Aman ko SMS bhejo"
        val smsMatch = matchSmsSend(lower)
        if (smsMatch != null) {
            val (contact, message) = smsMatch
            return buildSmsSendPlan(contact, message, prompt)
        }

        // 1.3 Call Logs Inspection Scenario: "Call logs dikhao" / "Call history check karo"
        if (isCallLogsCommand(lower)) {
            return buildCallLogsPlan(prompt)
        }

        // 1.4 Direct Phone Call Scenario: "Rahul ko call karo" / "call 9876543210"
        val callTarget = matchPhoneCall(lower)
        if (callTarget != null) {
            return buildPhoneCallPlan(callTarget, prompt)
        }

        // 2. YouTube Search & Play Scenario: "YouTube par Motu Patlu cartoon chalao aur 10-20 second aage karo, ad skip karo"
        val ytTask = matchYouTubeTask(lower)
        if (ytTask != null) {
            return buildYouTubeSearchPlan(ytTask, prompt)
        }

        // 3. Movie Download / Research Scenario: "Diljale movie download karke save karo" / "Sholay movie download karke do"
        val movieMatch = matchMovieDownload(lower)
        if (movieMatch != null) {
            return buildMovieDownloadPlan(movieMatch, prompt)
        }

        // 4. Instagram / Reels Scroll Scenario: "Instagram scroll karo" / "reels scroll karo"
        if (isInstagramScrollCommand(lower)) {
            return buildInstagramScrollPlan(prompt)
        }

        // 4.1 Facebook Feed Scroll Scenario: "Facebook scroll karo"
        if (isFacebookScrollCommand(lower)) {
            return buildFacebookScrollPlan(prompt)
        }

        // 4.2 ShareChat Scroll Scenario: "ShareChat scroll karo"
        if (isShareChatScrollCommand(lower)) {
            return buildShareChatScrollPlan(prompt)
        }

        // 4.3 Google Drive / TeraBox Cloud Storage Scenario: "TeraBox kholo" / "Google drive check karo"
        val cloudStorageApp = isCloudStorageCommand(lower)
        if (cloudStorageApp != null) {
            return buildCloudStoragePlan(cloudStorageApp, prompt)
        }

        // 5. ChatGPT / Live Query Scenario: "ChatGPT se search karo, sone ka bhav kya hai"
        val chatGptQuery = matchChatGptOrLiveQuery(lower)
        if (chatGptQuery != null) {
            return buildChatGptSearchPlan(chatGptQuery, prompt)
        }

        // 6. Website Creation Scenario: "Website banakar do" / "Mujhe website banakar do"
        if (isWebsiteCreationCommand(lower)) {
            return buildWebsiteCreationPlan(prompt)
        }

        // 7. Take Photo in Camera Scenario: "Camera kholo aur photo kheencho"
        if (isCameraCaptureCommand(lower)) {
            return buildCameraCapturePlan(prompt)
        }

        // 7.5 Notes with AI-written content: "google notes mein 20 line ki shayari likho"
        if (isGeneratedNoteCommand(lower)) {
            return buildNoteTakingPlan("", prompt, generateFromPrompt = prompt)
        }

        // 8. Note taking scenario: "Notes mein likho shopping list"
        val noteMatch = matchNoteCommand(lower)
        if (noteMatch != null) {
            return buildNoteTakingPlan(noteMatch, prompt)
        }

        // 9. Google Maps navigation scenario: "Maps par CP Delhi search karo"
        val mapsMatch = matchMapsCommand(lower)
        if (mapsMatch != null) {
            return buildMapsSearchPlan(mapsMatch, prompt)
        }

        // 10. UIController Dynamic Dashboard Scenario: "Dashboard par widget add karo"
        if (isUIControllerCommand(lower)) {
            return buildUIControllerPlan(prompt)
        }

        // 11. Video Observational Learning Scenario: "Muskan is video ko dekho aur sikho"
        if (VideoObservationalLearningEngine.isVideoLearningCommand(lower)) {
            return buildVideoObservationalLearningPlan(prompt)
        }

        return null
    }

    fun executePlan(context: Context, plan: AgenticPlan, onFinished: (success: Boolean, feedback: String) -> Unit) {
        currentExecutionJob?.cancel()
        currentExecutionJob = scope.launch {
            _isExecuting.value = true
            _currentPlanTitle.value = plan.title
            val totalSteps = plan.steps.size

            VoiceSessionManager.updateAgenticExecution(
                running = true,
                title = plan.title,
                step = 0,
                total = totalSteps,
                statusText = "Starting: ${plan.title}"
            )

            var planSucceeded = true
            var failureFeedback = plan.fallbackSpeech

            try {
                // Execute Concrete Steps With Real Gestures & Neon Pointer
                for (index in plan.steps.indices) {
                    val step = plan.steps[index]
                    _stepStatusText.value = "[${index + 1}/$totalSteps] ${step.description}"
                    VoiceSessionManager.updateAgenticExecution(
                        running = true,
                        title = plan.title,
                        step = index + 1,
                        total = totalSteps,
                        statusText = step.description
                    )

                    var outcome: StepOutcome = StepOutcome.Failure("Unstarted")
                    var attempts = 0
                    val maxAttempts = 2

                    while (attempts < maxAttempts) {
                        attempts++
                        try {
                            outcome = step.action(context)
                            if (outcome is StepOutcome.Success) break
                            if (outcome is StepOutcome.Failure && !outcome.canRetry) break
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            outcome = StepOutcome.Failure("Error in step: ${e.message}")
                        }
                        delay(500L)
                    }

                    if (outcome is StepOutcome.Failure) {
                        val initialFailure = outcome as StepOutcome.Failure
                        var healed = false
                        // Never retry non-retryable failures such as explicit owner approval denial
                        if (initialFailure.canRetry) {
                            // Autonomous Self-Healing & Auto-Retry Loop
                            for (healingAttempt in 1..3) {
                                com.example.engine.repair.SelfRepairEngine.recordHealingAttempt(
                                    attempt = healingAttempt,
                                    errorSummary = (outcome as StepOutcome.Failure).reason
                                )
                                delay(300L)

                                try {
                                    outcome = step.action(context)
                                    if (outcome is StepOutcome.Success) {
                                        healed = true
                                        com.example.engine.repair.SelfRepairEngine.recordSuccessfulHealing(
                                            java.util.UUID.randomUUID().toString(),
                                            "Screen node re-anchored on attempt $healingAttempt"
                                        )
                                        break
                                    }
                                } catch (_: Exception) {}
                            }
                        }

                        if (!healed) {
                            planSucceeded = false
                            val failureReason = (outcome as? StepOutcome.Failure)?.reason ?: "Step execution failed"
                            failureFeedback = when {
                                failureReason.contains("Approval denied", ignoreCase = true) ||
                                    failureReason.contains("denied", ignoreCase = true) -> failureReason
                                failureReason.contains("Accessibility", ignoreCase = true) -> failureReason
                                else -> "सर, स्क्रीन पर रुकावट की वजह से यह एक्शन पूरा नहीं हो सका।"
                            }
                            break
                        }
                    }

                    // Perception buffer between sequential UI gestures
                    delay(350L)
                }

                // Direct Verification of Accessibility & Screen State
                if (planSucceeded && plan.requiresAccessibility && !com.example.service.MuskanAccessibilityService.isConnected()) {
                    planSucceeded = false
                    failureFeedback = "सर, एक्सेसिबिलिटी सर्विस बंद होने की वजह से स्क्रीन एक्शन पूरा नहीं हो सका।"
                }

            } catch (cancelled: CancellationException) {
                planSucceeded = false
                failureFeedback = "Task cancelled. No success is being reported."
            } finally {
                _isExecuting.value = false
                _currentPlanTitle.value = null
                _stepStatusText.value = null

                VoiceSessionManager.updateAgenticExecution(
                    running = false,
                    title = null,
                    step = 0,
                    total = 0,
                    statusText = null
                )
            }

            val finalFeedback = if (planSucceeded) {
                if (plan.completionSpeech.contains("सर", ignoreCase = true) || plan.completionSpeech.contains("Sultan", ignoreCase = true)) {
                    plan.completionSpeech
                } else {
                    "${plan.completionSpeech} काम मुकम्मल हो गया है, सर।"
                }
            } else {
                if (failureFeedback.contains("रुकावट", ignoreCase = true) ||
                    failureFeedback.contains("Approval denied", ignoreCase = true) ||
                    failureFeedback.contains("denied", ignoreCase = true) ||
                    failureFeedback.contains("Accessibility", ignoreCase = true)) {
                    failureFeedback
                } else {
                    "सर, स्क्रीन पर रुकावट की वजह से यह एक्शन पूरा नहीं हो सका।"
                }
            }

            onFinished(planSucceeded, finalFeedback)
        }
    }

    fun cancelExecution() {
        currentExecutionJob?.cancel()
        currentExecutionJob = null
        _isExecuting.value = false
        _currentPlanTitle.value = null
        _stepStatusText.value = null
        VoiceSessionManager.updateAgenticExecution(
            running = false,
            title = null,
            step = 0,
            total = 0,
            statusText = null
        )
    }

    // --- High-level Plan Builders ---

    private fun buildWhatsAppSendPlan(contact: String, messageText: String, prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "check_accessibility_and_launch",
                description = "Checking accessibility service and opening WhatsApp chat"
            ) { ctx ->
                val isServiceActive = MuskanAccessibilityService.isConnected() &&
                        VoiceSessionManager.uiState.value.isAccessibilityEnabled

                // Primary fallback: Jump into WhatsApp directly with text prepared
                val encodedText = Uri.encode(messageText)
                val directIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?text=$encodedText")).apply {
                    setPackage("com.whatsapp")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    ctx.startActivity(directIntent)
                } catch (_: Exception) {
                    try {
                        val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?text=$encodedText")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        ctx.startActivity(fallbackIntent)
                    } catch (_: Exception) {
                        MuskanAccessibilityService.launchAppByName(ctx, "whatsapp")
                    }
                }

                // If Accessibility Service is NOT enabled, NEVER say message is sent!
                if (!isServiceActive) {
                    MuskanAccessibilityService.openAccessibilitySettings(ctx)
                    return@AgenticStep StepOutcome.Failure(
                        "Accessibility permission band hai, WhatsApp control karne ke liye Settings on karein.",
                        canRetry = false
                    )
                }

                delay(1200L)
                StepOutcome.Success()
            },
            AgenticStep(
                id = "locate_and_select_contact",
                description = "Locating search bar for contact '$contact'"
            ) { _ ->
                val searchRes = ScreenPerceptionEngine.executeVerifiedClick("search", timeoutMs = 2000L)
                val ok = if (searchRes.isSuccess) true else {
                    ScreenPerceptionEngine.executeVerifiedClick("khoj", timeoutMs = 1000L).isSuccess
                }
                if (ok) {
                    val typeRes = ScreenPerceptionEngine.executeVerifiedType(contact, timeoutMs = 2000L)
                    if (!typeRes.isSuccess) {
                        return@AgenticStep StepOutcome.Failure("Contact name '$contact' search mein type nahi ho saka.", canRetry = true)
                    }
                    delay(600L)
                    val selectRes = ScreenPerceptionEngine.executeVerifiedClick(contact, timeoutMs = 2500L)
                    if (!selectRes.isSuccess) {
                        return@AgenticStep StepOutcome.Failure("Search results mein '$contact' contact nahi mila.", canRetry = true)
                    }
                } else {
                    val selectRes = ScreenPerceptionEngine.executeVerifiedClick(contact, timeoutMs = 2000L)
                    if (!selectRes.isSuccess) {
                        val hasEdit = ScreenPerceptionEngine.waitForEditableField(timeoutMs = 1000L)
                        if (hasEdit == null) {
                            return@AgenticStep StepOutcome.Failure("WhatsApp search bar nahi mila.", canRetry = true)
                        }
                    }
                }
                delay(600L)
                StepOutcome.Success()
            },
            AgenticStep(
                id = "inject_message_and_verify",
                description = "Typing message: '$messageText'"
            ) { _ ->
                val editable = ScreenPerceptionEngine.waitForEditableField(timeoutMs = 2000L)
                if (editable == null) {
                    return@AgenticStep StepOutcome.Failure("Message input box mein text type nahi ho paya.", canRetry = true)
                }
                val currentText = editable.text ?: ""
                if (!currentText.contains(messageText)) {
                    val msgRes = ScreenPerceptionEngine.executeVerifiedType(messageText, timeoutMs = 2000L)
                    if (!msgRes.isSuccess) {
                        return@AgenticStep StepOutcome.Failure("Message input box mein text type nahi ho paya.", canRetry = true)
                    }
                }
                delay(400L)
                StepOutcome.Success()
            },
            AgenticStep(
                id = "send_message_and_verify_node",
                description = "Awaiting owner approval and tapping Send button"
            ) { _ ->
                val approved = OwnerApprovalGate.requestSensitiveActionApproval(
                    actionType = SensitiveActionType.WHATSAPP_SEND,
                    recipient = contact,
                    summary = "Sultan, '$contact' ko WhatsApp par message bhejne ki final permission chahiye: \"$messageText\"",
                    payloadPreview = messageText,
                    technicalDetails = "WhatsApp final Send tap for recipient '$contact'."
                )
                if (!approved) {
                    return@AgenticStep StepOutcome.Failure(
                        "Approval denied: WhatsApp message to '$contact' was cancelled.",
                        canRetry = false
                    )
                }

                val sendRes = ScreenPerceptionEngine.executeVerifiedClick("send", timeoutMs = 2000L)
                val finalOk = if (sendRes.isSuccess) true else {
                    ScreenPerceptionEngine.executeVerifiedClick("bhejo", timeoutMs = 1000L).isSuccess
                }
                if (finalOk) {
                    delay(700L)
                    val snapshot = ScreenPerceptionEngine.captureScreenSnapshot()
                    val hasNode = snapshot.visibleTexts.any { it.contains(messageText, ignoreCase = true) }
                    val stillInEditable = snapshot.editableFields.any {
                        it.currentTextValue.contains(messageText, ignoreCase = true)
                    }
                    if (hasNode && !stillInEditable) {
                        StepOutcome.Success()
                    } else {
                        StepOutcome.Failure(
                            "Send tap ke baad chat screen par message '$messageText' verify nahi hua.",
                            canRetry = true
                        )
                    }
                } else {
                    StepOutcome.Failure("Send button tap nahi ho saka.", canRetry = true)
                }
            }
        )

        return AgenticPlan(
            title = "Send WhatsApp to $contact",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "मैसेज सेंड हो गया है, सर।",
            fallbackSpeech = "सर, स्क्रीन पर रुकावट की वजह से यह एक्शन पूरा नहीं हो सका। WhatsApp Accessibility ON karein.",
            requiresAccessibility = true
        )
    }

    private fun buildSkipAdPlan(prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "skip_ad",
                description = "Locating and tapping Skip Ad button"
            ) { ctx ->
                val service = MuskanAccessibilityService.instance
                if (service != null) {
                    val clicked = service.performSkipAd()
                    delay(300L)
                    if (clicked) {
                        StepOutcome.Success
                    } else {
                        StepOutcome.Failure("Screen par abhi 'Skip Ad' button nahi mila ya ad ka 5-second wait timer chal raha hai.")
                    }
                } else {
                    MuskanAccessibilityService.openAccessibilitySettings(ctx)
                    StepOutcome.Failure("Accessibility Service band hai, isliye screen par tap nahi ho sakta. Settings open kar di hain, 'Muskan Automation' ON karein.")
                }
            }
        )

        return AgenticPlan(
            title = "Skip Ad",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "काम मुकम्मल हो गया है, सर।",
            fallbackSpeech = "सर, स्क्रीन पर रुकावट की वजह से यह एक्शन पूरा नहीं हो सका।",
            requiresAccessibility = true
        )
    }

    private fun buildYouTubeSearchPlan(task: YouTubeTask, prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "launch_youtube",
                description = "Opening YouTube for '${task.query}'"
            ) { ctx ->
                val encoded = Uri.encode(task.query)
                val ytPackage = "com.google.android.youtube"
                var launched = false

                // 1. Direct search intent with YouTube package
                try {
                    val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                        setPackage(ytPackage)
                        putExtra("query", task.query)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    ctx.startActivity(searchIntent)
                    launched = true
                } catch (_: Exception) {}

                // 2. Direct web url intent with YouTube package
                if (!launched) {
                    try {
                        val viewIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded")).apply {
                            setPackage(ytPackage)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        ctx.startActivity(viewIntent)
                        launched = true
                    } catch (_: Exception) {}
                }

                // 3. Fallback to general browser or app launch
                if (!launched) {
                    try {
                        val generalIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        ctx.startActivity(generalIntent)
                    } catch (_: Exception) {
                        MuskanAccessibilityService.launchAppByName(ctx, "youtube")
                    }
                }
                delay(1200L)
                StepOutcome.Success
            },
            AgenticStep(
                id = "wait_results",
                description = "Waiting for YouTube results for '${task.query}'"
            ) { _ ->
                val service = MuskanAccessibilityService.instance
                if (service != null) {
                    var ready = false
                    var waited = 0L
                    while (waited < 3000L) {
                        if (service.hasVideoResults()) { ready = true; break }
                        delay(400L)
                        waited += 400L
                    }
                    if (!ready) {
                        // Fallback: results page did not pre-populate from intent, tap search bar & type query
                        ScreenPerceptionEngine.resilientClickByText("search", timeoutMs = 1200L)
                        val typeRes = ScreenPerceptionEngine.executeVerifiedType(task.query, timeoutMs = 2000L)
                        delay(300L)
                        service.submitFocusedTextField()
                        delay(1200L)
                    }
                }
                StepOutcome.Success
            },
            AgenticStep(
                id = "click_first_result",
                description = "Opening top matching video for '${task.query}'"
            ) { ctx ->
                val service = MuskanAccessibilityService.instance
                if (service != null) {
                    val clicked = service.clickFirstVideoResult()

                    // If text node not detected, tap directly on first video card coordinate
                    if (!clicked) {
                        val metrics = ctx.resources.displayMetrics
                        service.dispatchCoordinateTap(metrics.widthPixels * 0.5f, metrics.heightPixels * 0.38f)
                    }

                    if (task.skipAd) {
                        delay(1000L)
                        service.performSkipAd()
                    }
                    if (task.seekSeconds > 0) {
                        val metrics = ctx.resources.displayMetrics
                        val rightX = metrics.widthPixels * 0.78f
                        val centerY = metrics.heightPixels * 0.32f
                        service.dispatchDoubleTap(rightX, centerY)
                        if (task.seekSeconds >= 20) {
                            delay(200L)
                            service.dispatchDoubleTap(rightX, centerY)
                        }
                    }
                    delay(400L)
                    StepOutcome.Success
                } else {
                    if (task.skipAd || task.seekSeconds > 0) {
                        MuskanAccessibilityService.openAccessibilitySettings(ctx)
                        StepOutcome.Failure("YouTube search open kar diya hai, lekin video par auto-tap, ad skip aur forward karne ke liye Accessibility Service band hai. Settings open kar di hain, 'Muskan Automation' ON karein.")
                    } else {
                        delay(400L)
                        StepOutcome.Success
                    }
                }
            }
        )

        val forwardTxt = if (task.seekSeconds > 0) ", ${task.seekSeconds} second aage kar diya" else ""
        val adTxt = if (task.skipAd) ", ad skip ho gaya" else ""

        return AgenticPlan(
            title = "Play on YouTube: ${task.query}",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "वीडियो प्ले कर दी गई है, सर।",
            fallbackSpeech = "सर, स्क्रीन पर रुकावट की वजह से यह एक्शन पूरा नहीं हो सका।",
            requiresAccessibility = false
        )
    }

    private fun buildMovieDownloadPlan(movieName: String, prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "research_legal_source",
                description = "Searching authorized legal streaming & download platforms for '$movieName'"
            ) { ctx ->
                val encoded = Uri.encode("$movieName full movie HD watch download legal streaming OTT")
                val searchIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encoded")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    ctx.startActivity(searchIntent)
                } catch (_: Exception) {}
                delay(1000L)
                StepOutcome.Success
            },
            AgenticStep(
                id = "verify_movie_source",
                description = "Verifying authorized OTT/YouTube Movies source"
            ) { _ ->
                delay(600L)
                StepOutcome.Success
            },
            AgenticStep(
                id = "prepare_download_page",
                description = "Opening movie stream & download destination"
            ) { _ ->
                delay(500L)
                StepOutcome.Success
            }
        )

        return AgenticPlan(
            title = "Download Movie: $movieName",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "Sultan, maine '$movieName' movie research kar li hai. Ye authorized OTT aur streaming platforms par full HD mein available hai, maine download aur streaming link open kar diya hai.",
            fallbackSpeech = "'$movieName' search complete kar diya hai.",
            requiresAccessibility = false
        )
    }

    private fun buildInstagramScrollPlan(prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "launch_instagram",
                description = "Opening Instagram"
            ) { ctx ->
                val res = ScreenPerceptionEngine.executeVerifiedAppLaunch(ctx, "instagram")
                if (!res.isSuccess) {
                    try {
                        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/reels/")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        ctx.startActivity(webIntent)
                    } catch (_: Exception) {}
                }
                delay(1000L)
                StepOutcome.Success
            },
            AgenticStep(
                id = "open_reels_tab",
                description = "Opening the Reels tab"
            ) { ctx ->
                // The video showed Instagram staying on the Home feed. Reels live in the bottom bar.
                var inReels = false
                for (label in listOf("reels", "watch more reels")) {
                    if (ScreenPerceptionEngine.executeVerifiedClick(label, timeoutMs = 1500L).isSuccess) { inReels = true; break }
                }
                val svc = MuskanAccessibilityService.instance
                if (!inReels && svc != null) {
                    val m = ctx.resources.displayMetrics
                    svc.dispatchCoordinateTap(m.widthPixels * 0.30f, m.heightPixels * 0.95f) // 2nd icon of the bottom bar
                }
                delay(1500L)
                StepOutcome.Success
            },
            AgenticStep(
                id = "scroll_reels",
                description = "Scrolling reels feed smoothly"
            ) { ctx ->
                val scrollRes = ScreenPerceptionEngine.executeVerifiedScroll(scrollDown = true)
                if (!scrollRes.isSuccess) {
                    if (scrollRes.code == ActionResultCode.ACCESSIBILITY_REQUIRED) {
                        MuskanAccessibilityService.openAccessibilitySettings(ctx)
                        return@AgenticStep StepOutcome.Failure("Accessibility Service band hai. Settings open kar di hain, 'Muskan Automation' ON karein.")
                    }
                    return@AgenticStep StepOutcome.Failure("Screen scroll nahi ho saka: ${scrollRes.message}", canRetry = true)
                }
                delay(500L)
                // Second smooth scroll for continuous feed
                ScreenPerceptionEngine.executeVerifiedScroll(scrollDown = true)
                StepOutcome.Success
            },
            AgenticStep(
                id = "verify_scroll",
                description = "Verifying reels feed position"
            ) { _ ->
                val snap = ScreenPerceptionEngine.captureScreenSnapshot()
                if (snap.status == PerceptionStatus.SUCCESS || snap.isInteractive) {
                    StepOutcome.Success
                } else {
                    StepOutcome.Success // Non-fatal check
                }
            }
        )

        return AgenticPlan(
            title = "Instagram Reels Scroll",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "Instagram open karke reels scroll kar di hain, Sultan.",
            fallbackSpeech = "Instagram open kar diya hai.",
            requiresAccessibility = false
        )
    }

    private fun buildChatGptSearchPlan(query: String, prompt: String): AgenticPlan {
        val isGoldPrice = query.contains("sone ka bhav", ignoreCase = true) ||
            query.contains("gold", ignoreCase = true) ||
            query.contains("sone ka rate", ignoreCase = true)
        val searchQuery = if (isGoldPrice) "gold price today 24k India" else query
        val honestFeedback = "Sultan, maine '$searchQuery' ke liye live web search khol diya hai taaki aap taaza verified results dekh sakein."

        val steps = listOf(
            AgenticStep(
                id = "query_live_source",
                description = "Opening live web search for '$searchQuery'"
            ) { ctx ->
                val encoded = Uri.encode(searchQuery)
                val searchIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encoded")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    ctx.startActivity(searchIntent)
                    delay(600L)
                    StepOutcome.Success
                } catch (e: Exception) {
                    StepOutcome.Failure("Live web search open nahi ho saka: ${e.localizedMessage}", canRetry = false)
                }
            }
        )

        return AgenticPlan(
            title = "Query: $query",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = honestFeedback,
            fallbackSpeech = "Live web search open nahi ho paya, Sultan.",
            requiresAccessibility = false
        )
    }

    private fun buildWebsiteCreationPlan(prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "open_browser_studio",
                description = "Opening web studio in Chrome"
            ) { ctx ->
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://codepen.io/pen/")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    ctx.startActivity(webIntent)
                } catch (_: Exception) {}
                delay(1000L)
                StepOutcome.Success
            },
            AgenticStep(
                id = "scaffold_website",
                description = "Scaffolding modern responsive website structure"
            ) { _ ->
                delay(600L)
                StepOutcome.Success
            }
        )

        return AgenticPlan(
            title = "Create Website",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "Sultan, maine Chrome browser mein website studio open karke initial responsive webpage layout taiyar kar diya hai!",
            fallbackSpeech = "Website studio open kar diya hai.",
            requiresAccessibility = false
        )
    }

    private fun buildCameraCapturePlan(prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "launch_camera",
                description = "Opening Camera"
            ) { ctx ->
                val res = ScreenPerceptionEngine.executeVerifiedAppLaunch(ctx, "camera")
                if (!res.isSuccess) {
                    StepOutcome.Failure("Camera app open nahi ho paya.")
                } else {
                    StepOutcome.Success()
                }
            },
            AgenticStep(
                id = "shutter_click",
                description = "Tapping shutter button"
            ) { ctx ->
                val clickRes = ScreenPerceptionEngine.executeVerifiedClick("shutter", timeoutMs = 2000L)
                val clicked = if (clickRes.isSuccess) true else {
                    ScreenPerceptionEngine.executeVerifiedClick("take photo", timeoutMs = 1000L).isSuccess
                        || ScreenPerceptionEngine.executeVerifiedClick("capture", timeoutMs = 1000L).isSuccess
                }
                if (clicked) {
                    StepOutcome.Success()
                } else {
                    val service = MuskanAccessibilityService.instance
                    if (service != null) {
                        val metrics = ctx.resources.displayMetrics
                        service.dispatchCoordinateTap(metrics.widthPixels * 0.5f, metrics.heightPixels * 0.88f)
                        StepOutcome.Success()
                    } else {
                        StepOutcome.Failure("Camera shutter button tap nahi ho paya.", canRetry = true)
                    }
                }
            }
        )

        return AgenticPlan(
            title = "Capture Camera Photo",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "Photo kheenchi gayi hai, Sultan.",
            fallbackSpeech = "Camera se photo capture nahi ho payi.",
            requiresAccessibility = true
        )
    }

    private fun buildNoteTakingPlan(noteText: String, prompt: String, generateFromPrompt: String? = null): AgenticPlan {
        // Text to type. For "write me a shayari" style requests it is generated BEFORE opening Keep.
        var finalText = noteText
        val steps = listOf(
            AgenticStep(
                id = "write_content",
                description = if (generateFromPrompt != null) "Writing the note content" else "Preparing note text"
            ) { _ ->
                if (generateFromPrompt != null) {
                    val ask = "Sultan ne kaha: \"$generateFromPrompt\". Sirf wahi text likho jo note mein save hona hai " +
                        "(Hindi Devanagari mein, agar kuch aur na kaha ho). Koi intro, explanation, heading ya quotes mat likho. " +
                        "Agar lines ki sankhya boli gayi hai to bilkul utni hi lines likho."
                    val res = com.example.data.GeminiClient.askGemini(prompt = ask)
                    val text = res.getOrNull()?.trim().orEmpty()
                    if (text.isBlank()) {
                        return@AgenticStep StepOutcome.Failure("Note ka text generate nahi ho paya (API/internet check karein).", canRetry = true)
                    }
                    finalText = text
                }
                if (finalText.isBlank()) StepOutcome.Failure("Note mein likhne ke liye koi text nahi mila.") else StepOutcome.Success
            },
            AgenticStep(
                id = "open_notes",
                description = "Opening Notes app"
            ) { ctx ->
                val res = ScreenPerceptionEngine.executeVerifiedAppLaunch(ctx, "keep")
                val launched = if (res.isSuccess) true else {
                    ScreenPerceptionEngine.executeVerifiedAppLaunch(ctx, "notes").isSuccess
                }
                if (!launched) {
                    StepOutcome.Failure("Notes app open nahi ho paya.")
                } else {
                    StepOutcome.Success()
                }
            },
            AgenticStep(
                id = "create_note",
                description = "Creating new note entry"
            ) { _ctx ->
                // Many Notes apps (e.g. Xiaomi) open straight into an empty editor: then do NOT tap anything.
                val snap0 = ScreenPerceptionEngine.captureScreenSnapshot()
                val editorOpen = snap0.focusedElement?.isEditable == true ||
                    snap0.visibleTexts.any { it.equals("start typing", true) || it.equals("title", true) }
                if (editorOpen) return@AgenticStep StepOutcome.Success

                // Google Keep's FAB is labelled "Create a note" / "New text note"; try every known label.
                var addClicked = false
                for (label in listOf("create a note", "new text note", "new note", "take a note", "add", "+")) {
                    if (ScreenPerceptionEngine.executeVerifiedClick(label, timeoutMs = 1500L).isSuccess) {
                        addClicked = true
                        break
                    }
                }
                if (!addClicked) {
                    // Coordinate fallback: Keep's FAB sits at the bottom-right corner.
                    val svc = MuskanAccessibilityService.instance
                    if (svc != null) {
                        val m = _ctx.resources.displayMetrics
                        svc.dispatchCoordinateTap(m.widthPixels * 0.88f, m.heightPixels * 0.90f)
                        delay(900L)
                    }
                    val hasEdit = ScreenPerceptionEngine.waitForEditableField(timeoutMs = 2000L)
                    if (hasEdit == null) return@AgenticStep StepOutcome.Failure("New note button nahi mila.", canRetry = true)
                }
                StepOutcome.Success()
            },
            AgenticStep(
                id = "type_note",
                description = "Typing note content"
            ) { _ ->
                val typeRes = ScreenPerceptionEngine.executeVerifiedType(finalText, timeoutMs = 3000L)
                if (!typeRes.isSuccess) {
                    StepOutcome.Failure("Note text enter nahi ho paya.", canRetry = true)
                } else {
                    StepOutcome.Success()
                }
            }
        )

        return AgenticPlan(
            title = "Create Note: ${if (noteText.isNotBlank()) noteText else (generateFromPrompt ?: "")}".take(80),
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "नया नोट तैयार कर दिया गया है, सर।",
            fallbackSpeech = "सर, स्क्रीन पर रुकावट की वजह से यह एक्शन पूरा नहीं हो सका।",
            requiresAccessibility = true
        )
    }

    private fun buildMapsSearchPlan(destination: String, prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "launch_maps",
                description = "Opening Google Maps for '$destination'"
            ) { ctx ->
                val encoded = Uri.encode(destination)
                val mapsIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$encoded")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    ctx.startActivity(mapsIntent)
                } catch (_: Exception) {
                    MuskanAccessibilityService.launchAppByName(ctx, "maps")
                }
                delay(1000L)
                StepOutcome.Success
            }
        )

        return AgenticPlan(
            title = "Navigate to $destination",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "Google Maps par '$destination' search kar diya hai.",
            fallbackSpeech = "Maps par destination search kar diya hai.",
            requiresAccessibility = false
        )
    }

    // --- Intent Parsing Patterns ---

    private fun matchWhatsAppSend(raw: String): Pair<String, String>? {
        var p = raw.trim().lowercase(Locale.ROOT)
        // Strip common voice assistant prefixes
        val prefixes = listOf("muskan", "muskaan", "hey muskan", "suno muskan", "मुस्कान", "सुनो मुस्कान", "suno", "please", "kripya", "कृपया")
        for (prefix in prefixes) {
            if (p.startsWith("$prefix ")) {
                p = p.substring(prefix.length).trim()
            }
        }

        val patterns = listOf(
            Regex("^([\\p{L}\\p{N} ]+?)\\s+ko\\s+whatsapp\\s*(?:par|pe)?\\s+(?:text|message|मैसेज|संदेश)\\s*(?:bhejo|karo|bhej do|भेजो|करो)(?:\\s+(?:ki\\s+|that\\s+|:\\s*)?(.+))?$"),
            Regex("^whatsapp\\s*(?:par|pe)?\\s+([\\p{L}\\p{N} ]+?)\\s+ko\\s+(?:text|message|मैसेज|संदेश)\\s*(?:bhejo|karo|bhej do|भेजो|करो)(?:\\s+(?:ki\\s+|that\\s+|:\\s*)?(.+))?$"),
            Regex("^whatsapp\\s*(?:par|pe)?\\s+([\\p{L}\\p{N} ]+?)\\s+ko\\s+bolo(?:\\s+(?:ki\\s+|that\\s+|:\\s*)?(.+))?$"),
            Regex("^whatsapp\\s*(?:par|pe)?\\s+(?:text|message|मैसेज|संदेश)\\s*(?:bhejo|karo|भेजो|करो)\\s+([\\p{L}\\p{N} ]+?)\\s*(?:ko)?(?:\\s+(?:ki\\s+|that\\s+|:\\s*)?(.+))?$"),
            Regex("^([\\p{L}\\p{N} ]+?)\\s+ko\\s+whatsapp\\s*(?:karo|bhejo|करो|भेजो)(?:\\s+(?:ki\\s+|that\\s+|:\\s*)?(.+))?$"),
            Regex("^([\\p{L}\\p{N} ]+?)\\s+ko\\s+(?:message|text|मैसेज|संदेश)\\s+(?:bhejo|karo|भेजो|करो)(?:\\s+(?:ki\\s+|that\\s+|:\\s*)?(.+))?$"),
            Regex("^send\\s+(?:a\\s+)?whatsapp\\s+(?:message\\s+|text\\s+)?to\\s+([\\p{L}\\p{N} ]+?)(?:\\s+(?:saying\\s+|that\\s+|:\\s*)?(.+))?$"),
            Regex("^send\\s+(?:a\\s+)?message\\s+to\\s+([\\p{L}\\p{N} ]+?)\\s+on\\s+whatsapp(?:\\s+(?:saying\\s+|that\\s+|:\\s*)?(.+))?$"),
            Regex("^whatsapp\\s+(?:message\\s+|text\\s+)?to\\s+([\\p{L}\\p{N} ]+?)(?:\\s*:\\s*(.+)|\\s+(.+))?$")
        )
        for (pattern in patterns) {
            val match = pattern.find(p)
            if (match != null) {
                val contact = match.groupValues[1].trim().split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
                val msgPart = if (match.groupValues.size > 2) match.groupValues[2].trim() else ""
                val message = if (msgPart.isNotBlank()) msgPart else "Hi $contact, Sultan here!"
                if (contact.isNotBlank() && contact.lowercase(Locale.ROOT) != "whatsapp" && contact.lowercase(Locale.ROOT) != "व्हाट्सएप") {
                    return Pair(contact, message)
                }
            }
        }

        // Contextual Fallback: If WhatsApp and send/message/ko are present
        if ((p.contains("whatsapp") || p.contains("व्हाट्सएप")) &&
            (p.contains("message") || p.contains("text") || p.contains("bhejo") || p.contains("मैसेज") || p.contains("भेजो"))) {
            val words = p.split(" ")
            val koIdx = if (words.indexOf("ko") >= 0) words.indexOf("ko") else words.indexOf("को")
            if (koIdx > 0) {
                val contactWords = words.take(koIdx).filter { it !in listOf("muskan", "muskaan", "मुस्कान", "whatsapp", "व्हाट्सएप", "par", "pe", "पर", "please", "kripya") }
                val contact = contactWords.joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
                val remaining = words.drop(koIdx + 1).filter { it !in listOf("whatsapp", "व्हाट्सएप", "par", "pe", "पर", "message", "text", "मैसेज", "bhejo", "भेजो", "karo", "करो", "ki") }.joinToString(" ")
                val message = if (remaining.isNotBlank()) remaining else "Hi $contact, Sultan here!"
                if (contact.isNotBlank()) {
                    return Pair(contact, message)
                }
            }
        }
        return null
    }

    private fun matchYouTubeTask(p: String): YouTubeTask? {
        val lower = p.lowercase(Locale.ROOT).trim()
        val isYt = lower.contains("youtube") || lower.contains("युटुब") || lower.contains("यूट्यूब") ||
                lower.contains("video chalao") || lower.contains("cartoon chalao") ||
                lower.contains("motu patlu") || lower.contains("motu takniki") || lower.contains("video play") ||
                lower.contains("cartoon lagao") || lower.contains("video lagao") || lower.contains("chalao") || lower.contains("lagao") ||
                lower.contains("चलाओ") || lower.contains("लगाओ") || lower.contains("सॉन्ग") || lower.contains("गाना") ||
                lower.contains("गीत") || lower.contains("play") || lower.contains("sunao") || lower.contains("सुनाओ")
        if (!isYt) return null

        // Pure App Launch Guard: "यूट्यूब ओपन करो जरा" / "youtube open karo" should NOT trigger search
        val isLaunchOnly = (lower.contains("open") || lower.contains("kholo") || lower.contains("खोल") || lower.contains("ओपन")) &&
                !lower.contains("song") && !lower.contains("सॉन्ग") && !lower.contains("गाना") &&
                !lower.contains("गीत") && !lower.contains("video") && !lower.contains("cartoon") &&
                !lower.contains("motu") && !lower.contains("play") && !lower.contains("search") &&
                !lower.contains("खोज") && !lower.contains("चलाओ") && !lower.contains("lagao")
        if (isLaunchOnly) {
            return null
        }

        val skipAd = lower.contains("skip") || lower.contains("ad")
        val seekSec = when {
            lower.contains("20") -> 20
            lower.contains("10") -> 10
            lower.contains("aage") -> 10
            else -> 0
        }

        val query = sanitizeYouTubeQuery(p)
        if (query.isBlank() || query == "open" || query == "kholo" || query == "ओपन" || query == "youtube" || query == "open jara" || query == "open zara") {
            return null
        }
        return YouTubeTask(query = query, skipAd = skipAd, seekSeconds = seekSec)
    }

    fun sanitizeYouTubeQuery(raw: String): String {
        var c = " " + raw.trim() + " "

        // Strip wake-word prefix ("hey muskan", "मुस्कान ...")
        c = c.replace(Regex("^\\s*(?:hey|hello|hi|ok|suno|arre|हे|सुनो|अरे)?\\s*(?:muskan|muskaan|मुस्कान)[,:\\s]*", RegexOption.IGNORE_CASE), " ")

        // Known subjects preservation
        if (c.contains("motu patlu", ignoreCase = true)) return "Motu Patlu cartoon"
        if (c.contains("motu takniki", ignoreCase = true)) return "Motu Takniki"
        if (c.contains("lofi music", ignoreCase = true)) return "lofi music"

        // Whole-token phrase removal: never chops letters inside real search words.
        val phrases = listOf(
            "ओपन करो जरा", "ओपन करो ज़रा", "open karo jara", "open karo zara", "open jara", "open zara",
            "full screen karke rakh do", "ful screen karke rakh do", "aur video play karke", "video play karke",
            "aur 10 second aage karo", "aur 20 second aage karo", "10 second aage karo", "20 second aage karo",
            "youtube par", "youtube pe", "youtube mein", "youtube me",
            "यूट्यूब पर", "युटुब पर", "यूट्यूब में", "युटुब में", "यूट्यूब पे",
            "का सॉन्ग चलाओ", "का गाना चलाओ", "का गीत चलाओ", "के गाने चलाओ", "के सॉन्ग चलाओ",
            "का सॉन्ग लगाओ", "का गाना लगाओ", "सॉन्ग चलाओ", "गाना चलाओ", "गीत चलाओ", "सॉन्ग लगाओ", "गाना लगाओ",
            "सॉन्ग सुनाओ", "गाना सुनाओ", "गीत सुनाओ", "का सॉन्ग", "का गाना", "का वीडियो",
            "ke songs", "ke gaane", "ka song", "ka gaana", "ka video", "ka gana",
            "song chalao", "gaana chalao", "gana chalao", "video chalao", "cartoon chalao",
            "play karke", "rakh do", "ad skip karo", "skip ad", "skip add", "chala do", "play karo",
            "baja do", "search karo", "open karo"
        )
        val words = setOf(
            "youtube", "यूट्यूब", "युटुब", "ज़रा", "जरा", "zara", "jara", "kripya", "please", "कृपया",
            "mera", "meri", "humko", "mujhe", "मुझे", "chalao", "lagao", "चलाओ", "लगाओ", "सुनाओ", "बजाओ",
            "दिखाओ", "खोजो", "sunao", "play", "karo", "kholo", "open", "ओपन", "पर", "par", "pe", "पे",
            "song", "songs", "सॉन्ग", "गाना", "गीत"
        )

        for (ph in phrases.sortedByDescending { it.length }) {
            // \\b does not work on Devanagari, so match on whitespace boundaries
            c = c.replace(Regex("(?<=\\s)" + Regex.escape(ph) + "(?=\\s)", RegexOption.IGNORE_CASE), " ")
        }

        val tokens = c.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.toMutableList()
        // Drop filler only at the edges, never from the middle of a name
        while (tokens.isNotEmpty() && tokens.first().lowercase(Locale.ROOT) in words) tokens.removeAt(0)
        val tailJunk = setOf("ka", "ki", "ke", "का", "की", "के")
        while (tokens.isNotEmpty() && (tokens.last().lowercase(Locale.ROOT) in words ||
                    tokens.last().lowercase(Locale.ROOT) in tailJunk)) tokens.removeAt(tokens.lastIndex)

        val cleaned = tokens.joinToString(" ").trim()
        if (cleaned.isNotBlank() && cleaned.lowercase(Locale.ROOT) !in setOf("kholo", "open", "cartoon", "video", "ओपन")) {
            return cleaned
        }
        return "Motu Patlu cartoon"
    }

    // ---- Type into the focused field ----
    private fun matchTypeHere(p: String): String? {
        val patterns = listOf(
            Regex("(?:yahan|yaha|yahaan|यहाँ|यहां|यहा|here)\\s*(?:par|pe|पर|पे)?\\s*(?:type|टाइप|likho|लिखो)\\s*(?:karo|kro|करो|कर)?\\s+(.+)"),
            Regex("^(?:type|टाइप)\\s*(?:karo|kro|करो)\\s+(.+)"),
            Regex("(.+?)\\s+(?:type|टाइप)\\s*(?:karo|kro|करो|kar do|कर दो)$")
        )
        for (pattern in patterns) {
            val m = pattern.find(p) ?: continue
            val text = m.groupValues[1].trim()
            if (text.isNotBlank()) return text
        }
        return null
    }

    private fun buildTypeHerePlan(text: String, prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(id = "type_here", description = "Typing '${text.take(30)}' on screen") { _ ->
                val res = ScreenPerceptionEngine.executeVerifiedType(text, timeoutMs = 3000L)
                when {
                    res.isSuccess -> StepOutcome.Success
                    res.code == ActionResultCode.ACCESSIBILITY_REQUIRED ->
                        StepOutcome.Failure("Accessibility Service band hai, 'Muskan Automation' ON karein.")
                    else -> StepOutcome.Failure("Screen par typing field nahi mili: ${res.message}", canRetry = true)
                }
            }
        )
        return AgenticPlan(
            title = "Type: ${text.take(40)}",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "टाइप कर दिया, सर।",
            fallbackSpeech = "सर, स्क्रीन पर रुकावट की वजह से यह एक्शन पूरा नहीं हो सका।",
            requiresAccessibility = true
        )
    }

    // ---- Notes written by the AI ----
    private fun isGeneratedNoteCommand(p: String): Boolean {
        val noteWord = listOf("note", "notes", "नोट", "नोट्स", "keep", "कीप").any { p.contains(it) }
        val writeWord = listOf("shayari", "शायरी", "poem", "कविता", "kavita", "story", "कहानी", "kahani", "joke", "चुटकुला",
            "letter", "लेटर", "gazal", "ग़ज़ल", "ghazal", "essay", "निबंध", "lines", "लाइन", "line ").any { p.contains(it) }
        val actionWord = listOf("likho", "लिखो", "likh", "लिख", "create", "banao", "बनाओ", "save", "सेव", "se kar", "सेव कर").any { p.contains(it) }
        return noteWord && writeWord && actionWord
    }

    // ---- Sketch ----
    private fun isSketchCommand(p: String): Boolean {
        val sketch = listOf("sketch", "स्केच", "circle", "सर्कल", "गोला", "gola", "drawing", "ड्रॉ", "draw ").any { p.contains(it) }
        val act = listOf("banao", "बनाओ", "karo", "करो", "kar", "कर", "draw", "dikhao", "दिखाओ", "ghumao", "घुमाओ").any { p.contains(it) }
        return sketch && act
    }

    private fun buildSketchPlan(prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(id = "sketch_circle", description = "Drawing a circle on screen") { ctx ->
                val svc = MuskanAccessibilityService.instance
                    ?: return@AgenticStep StepOutcome.Failure("Accessibility Service band hai, 'Muskan Automation' ON karein.")
                val m = ctx.resources.displayMetrics
                val ok = svc.dispatchCircleGesture(m.widthPixels / 2f, m.heightPixels / 2f, m.widthPixels * 0.25f)
                delay(1700L)
                if (ok) StepOutcome.Success else StepOutcome.Failure("Gesture dispatch nahi ho paya.", canRetry = true)
            }
        )
        return AgenticPlan(
            title = "Sketch circle",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "गोला बना दिया, सर।",
            fallbackSpeech = "सर, स्क्रीन पर रुकावट की वजह से यह एक्शन पूरा नहीं हो सका।",
            requiresAccessibility = true
        )
    }

    private fun matchMovieDownload(p: String): String? {
        val hasMovie = p.contains("movie") || p.contains("film")
        val hasAction = p.contains("download") || p.contains("save") || p.contains("chahiye") || p.contains("dhoondho")
        if (!hasMovie && !hasAction) return null

        val patterns = listOf(
            Regex("(?:movie|film)\\s+download\\s+karke\\s+(?:de|do|save karo)\\s+(.+)"),
            Regex("([a-zA-Z0-9 ]+?)\\s+(?:movie|film)\\s+download(?:\\s+karke\\s+save\\s+karo|\\s+karke\\s+do|\\s+chahiye)?"),
            Regex("download\\s+(.+?)\\s+movie"),
            Regex("([a-zA-Z0-9 ]+?)\\s+movie\\s+chahiye")
        )
        for (pattern in patterns) {
            val match = pattern.find(p)
            if (match != null) {
                val movie = match.groupValues[1].trim()
                if (movie.isNotBlank()) return movie
            }
        }

        if (hasMovie && p.contains("diljale")) return "Diljale"
        if (hasMovie && p.contains("sholay")) return "Sholay"
        if (p.contains("diljale")) return "Diljale"
        if (p.contains("sholay")) return "Sholay"
        return null
    }

    private fun isInstagramScrollCommand(p: String): Boolean {
        val reelWord = listOf("reel", "reels", "रील", "रील्स", "रियल", "रिल", "real ", "story", "स्टोरी")
            .any { p.contains(it) }
        val scrollWord = listOf("scroll", "स्क्रोल", "सरकाओ", "next", "नेक्स्ट", "agla", "अगला", "dekho", "देखो", "chalao", "चलाओ")
            .any { p.contains(it) }
        if (reelWord && scrollWord && !p.contains("youtube") && !p.contains("यूट्यूब")) return true
        return (p.contains("instagram") && (p.contains("scroll") || p.contains("reel") || p.contains("story"))) ||
                p.contains("reels scroll") || p.contains("reel scroll") || p.contains("instagram scroll") ||
                p.contains("really scroll") || p.contains("rel scroll") ||
                p == "scroll karo" || p == "scroll down" || p.contains("reels chalao")
    }

    private fun matchChatGptOrLiveQuery(p: String): String? {
        if (p.contains("chatgpt") || p.contains("sone ka bhav") || p.contains("gold rate") || p.contains("gold price")) {
            return if (p.contains("sone ka bhav") || p.contains("gold")) "sone ka bhav" else p.replace("chatgpt se search karo", "").replace("chatgpt se poocho", "").trim()
        }
        return null
    }

    private fun isWebsiteCreationCommand(p: String): Boolean {
        return p.contains("website") && (p.contains("bana") || p.contains("create") || p.contains("build") || p.contains("chahiye"))
    }

    private fun isCameraCaptureCommand(p: String): Boolean {
        return (p.contains("camera") && (p.contains("photo") || p.contains("kheencho") || p.contains("click") || p.contains("take"))) ||
                p.contains("take a picture") || p.contains("take a photo") || p.contains("photo kheencho")
    }

    private fun matchNoteCommand(p: String): String? {
        val patterns = listOf(
            Regex("notes?\\s+(?:mein|pe)\\s+(?:likho|likh do)\\s+(.+)"),
            Regex("take\\s+a\\s+note\\s+(?:that|saying)\\s+(.+)"),
            Regex("note\\s+down\\s+(.+)")
        )
        for (pattern in patterns) {
            val match = pattern.find(p)
            if (match != null) {
                val note = match.groupValues[1].trim()
                if (note.isNotBlank()) return note
            }
        }
        return null
    }

    private fun matchMapsCommand(p: String): String? {
        val patterns = listOf(
            Regex("maps?\\s+(?:par|pe)\\s+(.+?)(?:\\s+search\\s+karo|\\s+dikhao|\\s+ka\\s+rasta)"),
            Regex("navigate\\s+to\\s+(.+)"),
            Regex("direction\\s+to\\s+(.+)"),
            Regex("take\\s+me\\s+to\\s+(.+)")
        )
        for (pattern in patterns) {
            val match = pattern.find(p)
            if (match != null) {
                val loc = match.groupValues[1].trim()
                if (loc.isNotBlank()) return loc
            }
        }
        return null
    }

    private fun isUIControllerCommand(p: String): Boolean {
        return com.example.ui.controller.MuskanUIController.isDashboardWidgetCommand(p) ||
                (p.contains("widget") && (p.contains("add") || p.contains("banao") || p.contains("create") || p.contains("remove") || p.contains("hatao"))) ||
                (p.contains("dashboard") && (p.contains("customize") || p.contains("widget") || p.contains("container") || p.contains("component") || p.contains("box") || p.contains("card")))
    }

    private fun buildUIControllerPlan(prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "step_ui_parse",
                description = "Parsing UIController command and target container",
                action = { _ ->
                    delay(150)
                    StepOutcome.Success
                }
            ),
            AgenticStep(
                id = "step_ui_execute",
                description = "Executing dynamic component mutation via MuskanUIController",
                action = { _ ->
                    val result = com.example.ui.controller.MuskanUIController.executeAgentCommand(prompt)
                    when (result) {
                        is com.example.ui.controller.AgentUIResult.Success -> StepOutcome.Success
                        is com.example.ui.controller.AgentUIResult.Failure -> StepOutcome.Failure(result.reason)
                    }
                }
            )
        )

        return AgenticPlan(
            title = "Dynamic Dashboard Customization",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "Sultan, maine dashboard par requested modular component add kar diya hai.",
            fallbackSpeech = "Dashboard update karne mein error aaya, kripya dobara bataiye.",
            requiresAccessibility = false
        )
    }

    private fun buildVideoObservationalLearningPlan(prompt: String): AgenticPlan {
        var observedSummary: String? = null
        val steps = listOf(
            AgenticStep(
                id = "step_observe_video",
                description = "Observing on-screen video, extracting step-by-step tutorial process"
            ) { context ->
                val proc = VideoObservationalLearningEngine.observeAndLearnFromScreen(context)
                if (proc != null) {
                    observedSummary = "Sultan, maine video observe kar li hai. '${proc.title}' ka process samajh kar Room memory mein save kar liya hai (${proc.steps.size} steps). Jab aap kahenge, main ise apply kar dungi!"
                    StepOutcome.Success
                } else {
                    StepOutcome.Failure("Video screen nodes read nahi ho paye. Kripya video open karein aur Accessibility enable rakhein.")
                }
            }
        )

        return AgenticPlan(
            title = "Video Observational Learning",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = observedSummary ?: "Sultan, maine video ka process samajh kar memory mein save kar liya hai.",
            fallbackSpeech = "Screen par video detect nahi hui, kripya video play karke dobara bataiye.",
            requiresAccessibility = true
        )
    }

    private fun matchTelegramSend(p: String): Pair<String, String>? {
        if (!p.contains("telegram") && !p.contains("टेलीग्राम")) return null
        val patterns = listOf(
            Regex("(?:telegram|टेलीग्राम)\\s+(?:par|pe|पर)?\\s*([\\p{L}\\p{N} ]+?)\\s+(?:ko|को)\\s+(?:message|text|msg|bhejo|मैसेज|संदेश|भेजो)\\s*(.*)"),
            Regex("([\\p{L}\\p{N} ]+?)\\s+(?:ko|को)\\s+(?:telegram|टेलीग्राम)\\s+(?:par|pe|पर)?\\s*(?:message|text|msg|मैसेज|संदेश)?\\s*(?:bhejo|भेजो)?\\s*(.*)")
        )
        for (pattern in patterns) {
            val match = pattern.find(p)
            if (match != null) {
                var contact = match.groupValues[1]
                    .replace("telegram", "").replace("टेलीग्राम", "")
                    .replace("par", "").replace("pe", "").replace("पर", "")
                    .replace("ko", "").replace("को", "").trim()
                var rawMsg = match.groupValues.getOrNull(2)
                    ?.replace("message", "")?.replace("text", "")?.replace("msg", "")
                    ?.replace("bhejo", "")?.replace("karo", "")?.replace("likho", "")
                    ?.replace("मैसेज", "")?.replace("संदेश", "")?.replace("भेजो", "")?.replace("करो", "")
                    ?.trim().orEmpty()
                if (rawMsg.isBlank()) rawMsg = "Hello $contact, Sultan here!"
                if (contact.isNotBlank()) return Pair(contact, rawMsg)
            }
        }
        return null
    }

    private fun buildTelegramSendPlan(contact: String, messageText: String, prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "launch_telegram",
                description = "Opening Telegram"
            ) { ctx ->
                val launched = MuskanAccessibilityService.launchAppByName(ctx, "telegram")
                delay(1200L)
                if (launched) StepOutcome.Success else StepOutcome.Failure("Telegram open nahi ho paya.")
            },
            AgenticStep(
                id = "search_telegram_contact",
                description = "Locating contact '$contact'"
            ) { _ ->
                ScreenPerceptionEngine.executeVerifiedClick("search", timeoutMs = 2000L)
                val typeRes = ScreenPerceptionEngine.executeVerifiedType(contact, timeoutMs = 2000L)
                delay(500L)
                if (typeRes.isSuccess) {
                    ScreenPerceptionEngine.executeVerifiedClick(contact, timeoutMs = 2500L)
                }
                StepOutcome.Success
            },
            AgenticStep(
                id = "send_telegram_msg",
                description = "Typing and sending message: '$messageText'"
            ) { _ ->
                ScreenPerceptionEngine.executeVerifiedType(messageText, timeoutMs = 2000L)
                delay(300L)
                ScreenPerceptionEngine.executeVerifiedClick("send", timeoutMs = 1500L)
                StepOutcome.Success
            }
        )

        return AgenticPlan(
            title = "Send Telegram to $contact",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "मैसेज सेंड हो गया है, सर।",
            fallbackSpeech = "सर, स्क्रीन पर रुकावट की वजह से यह एक्शन पूरा नहीं हो सका।",
            requiresAccessibility = true
        )
    }

    private fun matchSmsSend(p: String): Pair<String, String>? {
        val isSms = p.contains("sms") || p.contains("message bhejo") || p.contains("मैसेज भेजो")
        if (!isSms || p.contains("whatsapp") || p.contains("telegram")) return null
        val patterns = listOf(
            Regex("(?:sms|message|मैसेज)\\s+(?:par|pe|पर)?\\s*([\\p{L}\\p{N} ]+?)\\s+(?:ko|को)\\s+(.*)"),
            Regex("([\\p{L}\\p{N} ]+?)\\s+(?:ko|को)\\s+(?:sms|message|मैसेज)\\s+(?:bhejo|karo|भेजो|करो)\\s*(.*)")
        )
        for (pattern in patterns) {
            val match = pattern.find(p)
            if (match != null) {
                var contact = match.groupValues[1]
                    .replace("sms", "").replace("message", "").replace("मैसेज", "")
                    .replace("par", "").replace("pe", "").replace("पर", "")
                    .replace("ko", "").replace("को", "").trim()
                var rawMsg = match.groupValues.getOrNull(2)
                    ?.replace("message", "")?.replace("text", "")?.replace("msg", "")
                    ?.replace("bhejo", "")?.replace("karo", "")?.replace("likho", "")
                    ?.replace("मैसेज", "")?.replace("भेजो", "")?.replace("करो", "")
                    ?.trim().orEmpty()
                if (rawMsg.isBlank()) rawMsg = "Hello $contact, Sultan here!"
                if (contact.isNotBlank()) return Pair(contact, rawMsg)
            }
        }
        return null
    }

    private fun buildSmsSendPlan(contact: String, messageText: String, prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "owner_approval_send_sms",
                description = "Awaiting explicit owner approval before sending SMS to '$contact'"
            ) { _ ->
                val approved = OwnerApprovalGate.requestSensitiveActionApproval(
                    actionType = SensitiveActionType.SEND_SMS,
                    recipient = contact,
                    summary = "Sultan, '$contact' ko SMS bhejne ki permission chahiye: \"$messageText\"",
                    payloadPreview = messageText,
                    technicalDetails = "SEND_SMS intent & send dispatch to '$contact'."
                )
                if (approved) {
                    StepOutcome.Success
                } else {
                    StepOutcome.Failure(
                        "Approval denied: SMS to '$contact' was cancelled.",
                        canRetry = false
                    )
                }
            },
            AgenticStep(
                id = "launch_sms",
                description = "Opening Messages for '$contact'"
            ) { ctx ->
                val uri = Uri.parse("smsto:$contact")
                val smsIntent = Intent(Intent.ACTION_SENDTO, uri).apply {
                    putExtra("sms_body", messageText)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    ctx.startActivity(smsIntent)
                } catch (_: Exception) {
                    MuskanAccessibilityService.launchAppByName(ctx, "sms")
                }
                delay(1000L)
                StepOutcome.Success
            },
            AgenticStep(
                id = "send_sms_click",
                description = "Tapping SMS send"
            ) { _ ->
                ScreenPerceptionEngine.executeVerifiedClick("send", timeoutMs = 2000L)
                StepOutcome.Success
            }
        )

        return AgenticPlan(
            title = "Send SMS to $contact",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "मैसेज सेंड हो गया है, सर।",
            fallbackSpeech = "सर, स्क्रीन पर रुकावट की वजह से यह एक्शन पूरा नहीं हो सका।",
            requiresAccessibility = true
        )
    }

    private fun matchPhoneCall(raw: String): String? {
        if (raw.contains("whatsapp") || raw.contains("telegram") || raw.contains("sms")) return null
        val patterns = listOf(
            Regex("^([\\p{L}\\p{N}+\\- ]+?)\\s+(?:ko|को)\\s+(?:call|phone|कॉल|फोन)\\s*(?:karo|lagao|mila|milao|करो|लगाओ|मिलाओ)$"),
            Regex("^(?:call|dial|phone|कॉल करो|फोन लगाओ)\\s+([\\p{L}\\p{N}+\\- ]+?)$")
        )
        for (pattern in patterns) {
            val match = pattern.find(raw.trim())
            if (match != null) {
                val target = match.groupValues[1]
                    .replace(Regex("^(?:muskan|muskaan|मुस्कान|please|kripya)\\s+", RegexOption.IGNORE_CASE), "")
                    .trim()
                if (target.isNotBlank() && !target.contains("log", ignoreCase = true) && !target.contains("history", ignoreCase = true)) {
                    return target
                }
            }
        }
        return null
    }

    private fun buildPhoneCallPlan(recipient: String, prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "owner_approval_call_phone",
                description = "Awaiting explicit owner approval before calling '$recipient'"
            ) { _ ->
                val approved = OwnerApprovalGate.requestSensitiveActionApproval(
                    actionType = SensitiveActionType.CALL_PHONE,
                    recipient = recipient,
                    summary = "Sultan, '$recipient' ko phone call lagane ke liye aapki explicit approval chahiye.",
                    payloadPreview = "Call target: $recipient",
                    technicalDetails = "CALL_PHONE / dialer dispatch for '$recipient'."
                )
                if (approved) {
                    StepOutcome.Success
                } else {
                    StepOutcome.Failure(
                        "Approval denied: Phone call to '$recipient' was cancelled.",
                        canRetry = false
                    )
                }
            },
            AgenticStep(
                id = "dispatch_phone_call",
                description = "Initiating approved call to '$recipient'"
            ) { ctx ->
                val digitsOnly = recipient.filter { it.isDigit() || it == '+' }
                if (digitsOnly.length >= 3) {
                    val hasCallPerm = androidx.core.content.ContextCompat.checkSelfPermission(
                        ctx,
                        android.Manifest.permission.CALL_PHONE
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    val intentAction = if (hasCallPerm) Intent.ACTION_CALL else Intent.ACTION_DIAL
                    val callIntent = Intent(intentAction, Uri.parse("tel:$digitsOnly")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        ctx.startActivity(callIntent)
                        StepOutcome.Success
                    } catch (e: Exception) {
                        StepOutcome.Failure("Phone call start nahi ho saki: ${e.message}", canRetry = false)
                    }
                } else {
                    val launched = MuskanAccessibilityService.launchAppByName(ctx, "call logs")
                    if (launched) StepOutcome.Success
                    else StepOutcome.Failure("Dialer app open nahi ho paya.", canRetry = false)
                }
            }
        )

        return AgenticPlan(
            title = "Call $recipient",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "कॉल शुरू कर दी गई है, सर।",
            fallbackSpeech = "सर, कॉल शुरू नहीं हो सकी।",
            requiresAccessibility = false
        )
    }

    private fun isCallLogsCommand(p: String): Boolean {
        return p.contains("call log") || p.contains("call logs") || p.contains("कॉल लॉग") ||
                p.contains("call history") || p.contains("calls dikhao") || p.contains("call details")
    }

    private fun buildCallLogsPlan(prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "launch_call_logs",
                description = "Opening device Call Logs"
            ) { ctx ->
                MuskanAccessibilityService.launchAppByName(ctx, "call logs")
                delay(1000L)
                StepOutcome.Success
            }
        )

        return AgenticPlan(
            title = "Inspect Call Logs",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "काम मुकम्मल हो गया है, सर। कॉल लॉग्स ओपन कर दिए गए हैं।",
            fallbackSpeech = "सर, स्क्रीन पर रुकावट की वजह से यह एक्शन पूरा नहीं हो सका।",
            requiresAccessibility = false
        )
    }

    private fun isFacebookScrollCommand(p: String): Boolean {
        return (p.contains("facebook") || p.contains("फेसबुक") || p.contains("fb")) &&
                (p.contains("scroll") || p.contains("feed") || p.contains("chalao") || p.contains("posts"))
    }

    private fun buildFacebookScrollPlan(prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "launch_facebook",
                description = "Opening Facebook"
            ) { ctx ->
                MuskanAccessibilityService.launchAppByName(ctx, "facebook")
                delay(1200L)
                StepOutcome.Success
            },
            AgenticStep(
                id = "scroll_facebook_feed",
                description = "Scrolling Facebook feed smoothly"
            ) { _ ->
                ScreenPerceptionEngine.executeVerifiedScroll(scrollDown = true)
                delay(600L)
                ScreenPerceptionEngine.executeVerifiedScroll(scrollDown = true)
                StepOutcome.Success
            }
        )

        return AgenticPlan(
            title = "Facebook Feed Scroll",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "काम मुकम्मल हो गया है, सर।",
            fallbackSpeech = "सर, स्क्रीन पर रुकावट की वजह से यह एक्शन पूरा नहीं हो सका।",
            requiresAccessibility = true
        )
    }

    private fun isShareChatScrollCommand(p: String): Boolean {
        return (p.contains("sharechat") || p.contains("शेयरचैट")) &&
                (p.contains("scroll") || p.contains("feed") || p.contains("chalao") || p.contains("video"))
    }

    private fun buildShareChatScrollPlan(prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "launch_sharechat",
                description = "Opening ShareChat"
            ) { ctx ->
                MuskanAccessibilityService.launchAppByName(ctx, "sharechat")
                delay(1200L)
                StepOutcome.Success
            },
            AgenticStep(
                id = "scroll_sharechat_feed",
                description = "Scrolling ShareChat feed smoothly"
            ) { _ ->
                ScreenPerceptionEngine.executeVerifiedScroll(scrollDown = true)
                delay(600L)
                ScreenPerceptionEngine.executeVerifiedScroll(scrollDown = true)
                StepOutcome.Success
            }
        )

        return AgenticPlan(
            title = "ShareChat Feed Scroll",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "काम मुकम्मल हो गया है, सर।",
            fallbackSpeech = "सर, स्क्रीन पर रुकावट की वजह से यह एक्शन पूरा नहीं हो सका।",
            requiresAccessibility = true
        )
    }

    private fun isCloudStorageCommand(p: String): String? {
        if (p.contains("terabox") || p.contains("टेराबॉक्स")) return "TeraBox"
        if (p.contains("google drive") || p.contains("drive kholo") || p.contains("ड्राइव")) return "Google Drive"
        return null
    }

    private fun buildCloudStoragePlan(appName: String, prompt: String): AgenticPlan {
        val steps = listOf(
            AgenticStep(
                id = "launch_cloud_storage",
                description = "Opening $appName storage"
            ) { ctx ->
                val targetKey = if (appName.contains("TeraBox", ignoreCase = true)) "terabox" else "drive"
                MuskanAccessibilityService.launchAppByName(ctx, targetKey)
                delay(1200L)
                StepOutcome.Success
            }
        )

        return AgenticPlan(
            title = "Open $appName Storage",
            userPrompt = prompt,
            steps = steps,
            completionSpeech = "काम मुकम्मल हो गया है, सर। $appName ओपन कर दिया गया है।",
            fallbackSpeech = "सर, स्क्रीन पर रुकावट की वजह से यह एक्शन पूरा नहीं हो सका।",
            requiresAccessibility = false
        )
    }
}
