package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.BatterySaver
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.VoiceUiState
import com.example.ui.theme.HudBorder
import com.example.ui.theme.HudCardBg
import com.example.ui.theme.HudCyan
import com.example.ui.theme.HudEmerald
import com.example.ui.theme.HudMagenta
import com.example.ui.theme.HudPurple
import com.example.ui.theme.HudTextDim
import com.example.ui.theme.HudTextPrimary
import com.example.ui.theme.HudTextSecondary
import com.example.ui.theme.HudVoid

/**
 * Consolidated Master Settings Hub.
 * Reconnects ALL existing project files, modular engines, and future tools
 * into a structured, futuristic control center.
 */
@Composable
fun MasterSettingsHubScreen(
    uiState: VoiceUiState,
    context: Context,
    onOpenApiManager: () -> Unit,
    onOpenVoiceSettings: () -> Unit,
    onOpenBiometrics: () -> Unit,
    onOpenApprovals: () -> Unit,
    onOpenTerminal: () -> Unit,
    onOpenProjects: () -> Unit,
    onOpenMasterDashboard: () -> Unit,
    onOpenMemoryManager: () -> Unit,
    onOpenBatteryTutorial: () -> Unit,
    onOpenAccessibility: () -> Unit,
    onOpenPermissionsAndIntegrations: () -> Unit,
    onToggleWakeWord: () -> Unit,
    onToggleFloatingBubble: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(HudVoid)
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "SETTINGS & SYSTEM HUB",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = HudCyan,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "All project modules & future tools reconnected",
                    fontSize = 11.sp,
                    color = HudTextSecondary
                )
            }
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF0C2238),
                border = BorderStroke(0.8.dp, HudCyan)
            ) {
                Text(
                    text = "13 DEPTS",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = HudCyan,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Section 0: Permissions, System Roles & Connected Integrations (Blueprint Section 8)
        SettingsCategoryCard(
            categoryTitle = "PERMISSIONS, ROLES & OAUTH INTEGRATIONS",
            items = listOf(
                SettingsHubItem(
                    icon = Icons.Default.Security,
                    title = "Gmail, Meta Graph, Call Screening & Permissions",
                    subtitle = "Encrypted OAuth tokens • Google Drive SAF Backup • Calendar/Call/SMS Grants",
                    tint = HudEmerald,
                    onClick = onOpenPermissionsAndIntegrations
                )
            )
        )

        // Section 1: AI & API Configuration
        SettingsCategoryCard(
            categoryTitle = "AI & API MANAGEMENT",
            items = listOf(
                SettingsHubItem(
                    icon = Icons.Default.Key,
                    title = "Google AI Studio & Gemini Keys",
                    subtitle = "ApiManagementDialog • KeyRotationPool • SecurePreferences",
                    tint = HudCyan,
                    onClick = onOpenApiManager
                ),
                SettingsHubItem(
                    icon = Icons.Default.SmartToy,
                    title = "Model Parameters & Orchestrator",
                    subtitle = "EngineOrchestrator • MuskanPersonalityEngine (Hinglish/EN)",
                    tint = HudPurple,
                    onClick = onOpenVoiceSettings
                )
            )
        )

        // Section 2: Voice, DSP & Sultan Biometrics
        SettingsCategoryCard(
            categoryTitle = "VOICE, DSP & BIOMETRICS",
            items = listOf(
                SettingsHubItem(
                    icon = Icons.Default.Tune,
                    title = "Voice Pitch, Speed & Wake Word",
                    subtitle = "Pitch/Rate calibration • Standby detection (${if (uiState.isWakeWordStandby) "Active" else "Off"})",
                    tint = HudEmerald,
                    onClick = onOpenVoiceSettings
                ),
                SettingsHubItem(
                    icon = Icons.Default.Fingerprint,
                    title = "Sultan Mirza Voice Profile Enrollment",
                    subtitle = "VoiceBiometricsEngine • BiometricAudioStreamManager (16kHz)",
                    tint = HudCyan,
                    onClick = onOpenBiometrics
                )
            )
        )

        // Section 3: Approvals & Rollback Vault
        SettingsCategoryCard(
            categoryTitle = "CODE APPROVALS & ROLLBACK VAULT",
            items = listOf(
                SettingsHubItem(
                    icon = Icons.Default.CheckCircle,
                    title = "Staged Drafts & Change Review",
                    subtitle = "SelfDevelopmentEngine • loadDraftFilesForReview • Approval Gate",
                    tint = HudCyan,
                    onClick = onOpenApprovals
                ),
                SettingsHubItem(
                    icon = Icons.Default.Security,
                    title = "SHA-256 Pre-Change Snapshots & Rollback",
                    subtitle = "ProjectWorkspaceManager • rollbackToSnapshot • Displaced Copies",
                    tint = HudMagenta,
                    onClick = onOpenApprovals
                )
            )
        )

        // Section 4: Live Terminal & Developer Tools
        SettingsCategoryCard(
            categoryTitle = "LIVE TERMINAL & WORKSPACE TOOLS",
            items = listOf(
                SettingsHubItem(
                    icon = Icons.Default.Terminal,
                    title = "Termux-Inspired Developer Shell",
                    subtitle = "WorkspaceTerminalEngine • status, ls, cat, find, grep, verify",
                    tint = HudCyan,
                    onClick = onOpenTerminal
                ),
                SettingsHubItem(
                    icon = Icons.Default.Android,
                    title = "APK & DEX Inspection Engine",
                    subtitle = "ApkInspectionEngine • Permissions, DEX count, Native ABIs",
                    tint = HudEmerald,
                    onClick = onOpenProjects
                ),
                SettingsHubItem(
                    icon = Icons.Default.Folder,
                    title = "Source ZIP Workspace Manager",
                    subtitle = "ProjectWorkspaceManager • Import/Export source trees",
                    tint = HudPurple,
                    onClick = onOpenProjects
                )
            )
        )

        // Section 5: Master Autonomous Dashboards & Dynamic UI
        SettingsCategoryCard(
            categoryTitle = "MASTER DASHBOARDS & CONTROL",
            items = listOf(
                SettingsHubItem(
                    icon = Icons.Default.Dashboard,
                    title = "Muskaan Master Autonomous Dashboard",
                    subtitle = "MuskaanMasterDashboard • 128 modular engine control room",
                    tint = HudPurple,
                    onClick = onOpenMasterDashboard
                ),
                SettingsHubItem(
                    icon = Icons.Default.Widgets,
                    title = "Dynamic Dashboard Widgets & UIController",
                    subtitle = "MuskanUIController • Component registration & live card mutation",
                    tint = HudEmerald,
                    onClick = onOpenMasterDashboard
                )
            )
        )

        // Section 6: Cloud Memory, Drive Backup & System Automation
        SettingsCategoryCard(
            categoryTitle = "CLOUD BACKUP & AUTOMATION",
            items = listOf(
                SettingsHubItem(
                    icon = Icons.Default.Cloud,
                    title = "Google Drive Auto-Sync & Firebase Memory",
                    subtitle = "GoogleDriveBackupEngine • FirebaseMemoryManagerDialog",
                    tint = HudCyan,
                    onClick = onOpenMemoryManager
                ),
                SettingsHubItem(
                    icon = Icons.Default.Accessibility,
                    title = "Accessibility Automation Service",
                    subtitle = "MuskanAccessibilityService • Screen perception & touch interaction",
                    tint = HudMagenta,
                    onClick = onOpenAccessibility
                ),
                SettingsHubItem(
                    icon = Icons.Default.BatterySaver,
                    title = "Battery Optimization White-listing",
                    subtitle = "BatteryOptimizationTutorialDialog • Unrestricted background running",
                    tint = HudEmerald,
                    onClick = onOpenBatteryTutorial
                )
            )
        )

        // Section 7: Diagnostics & Architecture Status
        SettingsCategoryCard(
            categoryTitle = "DIAGNOSTICS & SYSTEM LOCKS",
            items = listOf(
                SettingsHubItem(
                    icon = Icons.Default.NetworkCheck,
                    title = "Network Diagnostics & Health Engine",
                    subtitle = "NetworkDiagnosticsEngine • Ping latency, SSL & DNS health",
                    tint = HudCyan,
                    onClick = onOpenVoiceSettings
                ),
                SettingsHubItem(
                    icon = Icons.Default.Cloud,
                    title = "WebSocket & WebRTC Signaling Bridge",
                    subtitle = "MuskanWebSocketBridge • WebRtcSignalingManager (SDP Offer/Answer & Trickle ICE)",
                    tint = HudPurple,
                    onClick = onOpenTerminal
                ),
                SettingsHubItem(
                    icon = Icons.Default.CheckCircle,
                    title = "Automated Unit & Robolectric Test Suite",
                    subtitle = "All 13 Blueprint Departments • Approval Gate • Offline Qwen3 • OCR • CRM",
                    tint = HudEmerald,
                    onClick = onOpenTerminal
                )
            )
        )

        Spacer(modifier = Modifier.height(20.dp))
    }
}

private data class SettingsHubItem(
    val icon: ImageVector,
    val title: String,
    val subtitle: String,
    val tint: Color,
    val onClick: () -> Unit
)

@Composable
private fun SettingsCategoryCard(
    categoryTitle: String,
    items: List<SettingsHubItem>
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = categoryTitle,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = HudCyan,
            letterSpacing = 0.5.sp
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF071221)),
            border = BorderStroke(0.8.dp, HudBorder)
        ) {
            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                items.forEachIndexed { index, item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = item.onClick)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF0C2238))
                                    .border(1.dp, item.tint.copy(alpha = 0.5f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.title,
                                    tint = item.tint,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = item.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = HudTextPrimary
                                )
                                Text(
                                    text = item.subtitle,
                                    fontSize = 10.sp,
                                    color = HudTextSecondary,
                                    lineHeight = 13.sp
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = HudTextDim,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    if (index < items.size - 1) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(0.5.dp)
                                .background(Color(0xFF132742))
                                .padding(horizontal = 14.dp)
                        )
                    }
                }
            }
        }
    }
}
