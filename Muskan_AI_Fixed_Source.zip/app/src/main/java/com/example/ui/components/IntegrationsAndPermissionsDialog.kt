package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.engine.backup.GoogleDriveBackupEngine
import com.example.engine.email.EmailEngine
import com.example.engine.social.SocialMediaEngine
import com.example.service.MuskanCallScreeningService
import com.example.ui.theme.HudBorder
import com.example.ui.theme.HudCyan
import com.example.ui.theme.HudEmerald
import com.example.ui.theme.HudMagenta
import com.example.ui.theme.HudPurple
import com.example.ui.theme.HudTextPrimary
import com.example.ui.theme.HudTextSecondary
import com.example.ui.theme.HudVoid
import kotlinx.coroutines.launch

private data class RuntimePermissionSpec(
    val title: String,
    val description: String,
    val permissions: Array<String>,
    val icon: ImageVector
)

/**
 * Unified Blueprint Section 8 Control Center:
 * 1. Encrypted OAuth2 token management for Gmail (Dept 05) & Meta Graph API (Dept 01).
 * 2. Direct Android SAF Google Drive Backup / Restore streaming.
 * 3. Live Android 10+ Call Screening Role (Dept 08) & on-demand Runtime Permissions for
 *    Calendar (Dept 09), Phone Call, SMS, Contacts, Camera, Microphone, and Notifications.
 */
@Composable
fun IntegrationsAndPermissionsDialog(
    context: Context,
    onDismiss: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var refreshTick by remember { mutableIntStateOf(0) }
    var statusBanner by remember { mutableStateOf<String?>(null) }

    var gmailInput by remember { mutableStateOf("") }
    var hasGmailToken by remember(refreshTick) {
        mutableStateOf(runCatching { EmailEngine.getOAuthAccessToken(context) != null }.getOrDefault(false))
    }

    var metaInput by remember { mutableStateOf("") }
    var hasMetaToken by remember(refreshTick) {
        mutableStateOf(runCatching { SocialMediaEngine.getMetaOAuthToken(context) != null }.getOrDefault(false))
    }

    var callScreeningHeld by remember(refreshTick) {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MuskanCallScreeningService.isCallScreeningRoleHeld(context)
            } else {
                false
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        refreshTick++
        val grantedCount = results.values.count { it }
        statusBanner = if (grantedCount == results.size) {
            "Permission granted successfully."
        } else {
            "Some permissions were denied. Fallback intents remain active."
        }
    }

    val roleLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        refreshTick++
        val nowHeld = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MuskanCallScreeningService.isCallScreeningRoleHeld(context)
        } else {
            false
        }
        callScreeningHeld = nowHeld
        statusBanner = if (nowHeld) {
            "Muskan is now active as your Default Caller ID & Spam Screening app."
        } else {
            "Call Screening role was not granted. You can enable it anytime in Default Apps."
        }
    }

    val driveSaveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri = result.data?.data ?: return@rememberLauncherForActivityResult
        coroutineScope.launch {
            val ok = runCatching {
                context.contentResolver.openOutputStream(uri)?.let { out ->
                    GoogleDriveBackupEngine.writeBackupToStream(context, out)
                } ?: false
            }.getOrDefault(false)
            statusBanner = if (ok) {
                "Backup JSON saved to Google Drive / selected storage."
            } else {
                "Could not write backup file to selected destination."
            }
        }
    }

    val driveRestoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri = result.data?.data ?: return@rememberLauncherForActivityResult
        coroutineScope.launch {
            val ok = runCatching {
                context.contentResolver.openInputStream(uri)?.let { input ->
                    GoogleDriveBackupEngine.restoreFromStream(context, input)
                } ?: false
            }.getOrDefault(false)
            statusBanner = if (ok) {
                "Memories and conversation turns restored from backup."
            } else {
                "Failed to parse or restore backup JSON."
            }
        }
    }

    val permissionSpecs = remember {
        buildList {
            add(
                RuntimePermissionSpec(
                    title = "Calendar Access (Dept 09)",
                    description = "Read upcoming meetings, check conflicts, and schedule events.",
                    permissions = arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR),
                    icon = Icons.Default.CalendarMonth
                )
            )
            add(
                RuntimePermissionSpec(
                    title = "Phone Calling (Dept 08)",
                    description = "Place owner-approved calls directly (falls back to Dialer if off).",
                    permissions = arrayOf(Manifest.permission.CALL_PHONE),
                    icon = Icons.Default.Call
                )
            )
            add(
                RuntimePermissionSpec(
                    title = "SMS Follow-Ups (Dept 02 & 08)",
                    description = "Send owner-approved SMS replies and missed-call follow-ups.",
                    permissions = arrayOf(Manifest.permission.SEND_SMS),
                    icon = Icons.Default.Sms
                )
            )
            add(
                RuntimePermissionSpec(
                    title = "Contacts Lookup",
                    description = "Resolve contact names for WhatsApp, Calls, and SMS.",
                    permissions = arrayOf(Manifest.permission.READ_CONTACTS),
                    icon = Icons.Default.Contacts
                )
            )
            add(
                RuntimePermissionSpec(
                    title = "Microphone (Dept 07)",
                    description = "Hands-free wake-word, speech recognition, and Gemini Live.",
                    permissions = arrayOf(Manifest.permission.RECORD_AUDIO),
                    icon = Icons.Default.Mic
                )
            )
            add(
                RuntimePermissionSpec(
                    title = "Camera",
                    description = "Quick camera launch and visual capture workflows.",
                    permissions = arrayOf(Manifest.permission.CAMERA),
                    icon = Icons.Default.CameraAlt
                )
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(
                    RuntimePermissionSpec(
                        title = "Notifications",
                        description = "Foreground voice service and task alerts.",
                        permissions = arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                        icon = Icons.Default.Notifications
                    )
                )
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = HudVoid
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "PERMISSIONS & INTEGRATIONS",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = HudCyan
                        )
                        Text(
                            text = "Encrypted OAuth tokens, Call Screening Role & Android Permissions",
                            fontSize = 11.sp,
                            color = HudTextSecondary
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("close_integrations_dialog_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close permissions and integrations",
                            tint = HudTextPrimary
                        )
                    }
                }

                statusBanner?.let { banner ->
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFF0C2238),
                        border = BorderStroke(1.dp, HudCyan.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = banner,
                            color = HudTextPrimary,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(scrollState),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // 1. Gmail OAuth2 Token Card (Department 05)
                    TokenIntegrationCard(
                        icon = Icons.Default.Email,
                        title = "Gmail REST API v1 (Dept 05)",
                        connected = hasGmailToken,
                        connectedLabel = "Encrypted Token Saved",
                        fallbackLabel = "Fallback: mailto: App",
                        helperText = "Paste a Google OAuth2 Bearer token with gmail.readonly & gmail.send scopes for direct inbox reading and approved sending.",
                        inputValue = gmailInput,
                        onInputChange = { gmailInput = it },
                        placeholder = "ya29.a0...",
                        inputTag = "gmail_token_input",
                        saveTag = "save_gmail_token_button",
                        clearTag = "clear_gmail_token_button",
                        onSave = {
                            if (gmailInput.isNotBlank()) {
                                EmailEngine.setOAuthAccessToken(context, gmailInput.trim())
                                gmailInput = ""
                                refreshTick++
                                statusBanner = "Gmail OAuth token saved securely (AES-256 encrypted)."
                            }
                        },
                        onClear = {
                            EmailEngine.setOAuthAccessToken(context, null)
                            refreshTick++
                            statusBanner = "Gmail token cleared. EmailEngine switched to mailto: fallback."
                        }
                    )

                    // 2. Meta Graph API Token Card (Department 01)
                    TokenIntegrationCard(
                        icon = Icons.Default.Share,
                        title = "Meta Graph API v21.0 (Dept 01)",
                        connected = hasMetaToken,
                        connectedLabel = "Encrypted Token Saved",
                        fallbackLabel = "Fallback: Share Intent",
                        helperText = "Paste an Instagram Business/Creator or Facebook Page OAuth2 token for direct comment reading & approved publishing.",
                        inputValue = metaInput,
                        onInputChange = { metaInput = it },
                        placeholder = "EAAG...",
                        inputTag = "meta_token_input",
                        saveTag = "save_meta_token_button",
                        clearTag = "clear_meta_token_button",
                        onSave = {
                            if (metaInput.isNotBlank()) {
                                SocialMediaEngine.setMetaOAuthToken(context, metaInput.trim())
                                metaInput = ""
                                refreshTick++
                                statusBanner = "Meta Graph OAuth token saved securely (AES-256 encrypted)."
                            }
                        },
                        onClear = {
                            SocialMediaEngine.setMetaOAuthToken(context, null)
                            refreshTick++
                            statusBanner = "Meta token cleared. SocialMediaEngine switched to Share Intent handoff."
                        }
                    )

                    // 3. Google Drive SAF Export / Restore Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF071221)),
                        border = BorderStroke(0.8.dp, HudBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "GOOGLE DRIVE BACKUP & RESTORE (SAF)",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = HudCyan
                            )
                            Text(
                                text = "Export or restore Room memories and conversation history directly via Android's Storage Access Framework (select Google Drive in the picker).",
                                fontSize = 11.sp,
                                color = HudTextSecondary
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        driveSaveLauncher.launch(GoogleDriveBackupEngine.createDriveSaveIntent())
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("drive_export_backup_button"),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0E7490))
                                ) {
                                    Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text("Export JSON", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = {
                                        driveRestoreLauncher.launch(GoogleDriveBackupEngine.createDriveRestoreIntent())
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("drive_restore_backup_button")
                                ) {
                                    Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp), tint = HudCyan)
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text("Restore", fontSize = 12.sp, color = HudCyan, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // 4. Android 10+ Call Screening System Role (Department 08)
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF071221)),
                        border = BorderStroke(0.8.dp, if (callScreeningHeld) HudEmerald else HudBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Security, contentDescription = null, tint = HudPurple, modifier = Modifier.size(18.dp))
                                    Text(
                                        text = "Call Screening Role (Dept 08)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = HudTextPrimary
                                    )
                                }
                                StatusPill(
                                    text = if (callScreeningHeld) "ACTIVE" else "NOT SET",
                                    color = if (callScreeningHeld) HudEmerald else HudMagenta
                                )
                            }
                            Text(
                                text = "Required on Android 10+ so MuskanCallScreeningService can screen incoming spam/scam calls live.",
                                fontSize = 11.sp,
                                color = HudTextSecondary
                            )
                            if (!callScreeningHeld && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                Button(
                                    onClick = {
                                        val intent = MuskanCallScreeningService.createRequestCallScreeningRoleIntent(context)
                                        if (intent != null) {
                                            roleLauncher.launch(intent)
                                        } else {
                                            statusBanner = "Call Screening role is unavailable or already active on this device."
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("request_call_screening_role_button"),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6D28D9))
                                ) {
                                    Text("Set Muskan as Default Call Screener", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // 5. Runtime Permissions Matrix (All Manifest Dangerous Permissions)
                    Text(
                        text = "ANDROID RUNTIME PERMISSIONS",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = HudCyan
                    )

                    permissionSpecs.forEach { spec ->
                        val isGranted = remember(refreshTick, spec) {
                            spec.permissions.all { perm ->
                                ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
                            }
                        }
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF071221)),
                            border = BorderStroke(0.8.dp, if (isGranted) HudEmerald.copy(alpha = 0.45f) else HudBorder)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = spec.icon,
                                        contentDescription = spec.title,
                                        tint = if (isGranted) HudEmerald else HudCyan,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Column {
                                        Text(
                                            text = spec.title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = HudTextPrimary
                                        )
                                        Text(
                                            text = spec.description,
                                            fontSize = 10.sp,
                                            color = HudTextSecondary
                                        )
                                    }
                                }
                                if (isGranted) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Granted",
                                        tint = HudEmerald,
                                        modifier = Modifier.size(22.dp)
                                    )
                                } else {
                                    Button(
                                        onClick = { permissionLauncher.launch(spec.permissions) },
                                        modifier = Modifier.height(48.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0E7490))
                                    ) {
                                        Text("Grant", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
private fun TokenIntegrationCard(
    icon: ImageVector,
    title: String,
    connected: Boolean,
    connectedLabel: String,
    fallbackLabel: String,
    helperText: String,
    inputValue: String,
    onInputChange: (String) -> Unit,
    placeholder: String,
    inputTag: String,
    saveTag: String,
    clearTag: String,
    onSave: () -> Unit,
    onClear: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF071221)),
        border = BorderStroke(0.8.dp, if (connected) HudEmerald else HudBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(icon, contentDescription = null, tint = HudCyan, modifier = Modifier.size(18.dp))
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = HudTextPrimary)
                }
                StatusPill(
                    text = if (connected) connectedLabel else fallbackLabel,
                    color = if (connected) HudEmerald else Color(0xFFF59E0B)
                )
            }

            Text(helperText, fontSize = 11.sp, color = HudTextSecondary)

            OutlinedTextField(
                value = inputValue,
                onValueChange = onInputChange,
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                placeholder = { Text(placeholder, color = HudTextSecondary, fontSize = 12.sp) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(inputTag),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = HudCyan,
                    unfocusedBorderColor = HudBorder,
                    focusedTextColor = HudTextPrimary,
                    unfocusedTextColor = HudTextPrimary
                )
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onSave,
                    enabled = inputValue.isNotBlank(),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag(saveTag),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
                ) {
                    Text("Save Encrypted", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                if (connected) {
                    OutlinedButton(
                        onClick = onClear,
                        modifier = Modifier
                            .height(48.dp)
                            .testTag(clearTag)
                    ) {
                        Text("Clear", color = Color(0xFFF43F5E), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusPill(text: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.16f),
        border = BorderStroke(0.8.dp, color.copy(alpha = 0.7f))
    ) {
        Text(
            text = text,
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
        )
    }
}
