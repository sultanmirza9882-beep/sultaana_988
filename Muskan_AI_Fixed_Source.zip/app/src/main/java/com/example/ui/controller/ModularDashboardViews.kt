package com.example.ui.controller

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.engine.EngineExecutionManager
import com.example.engine.network.NetworkDiagnosticsEngine
import com.example.ui.theme.AccentLightingManager
import com.example.ui.theme.HudBorder
import com.example.ui.theme.HudCardBg
import com.example.ui.theme.HudCyan
import com.example.ui.theme.HudEmerald
import com.example.ui.theme.HudMagenta
import com.example.ui.theme.HudSurface
import com.example.ui.theme.HudSurfaceVariant
import com.example.ui.theme.HudTextDim
import com.example.ui.theme.HudTextPrimary
import com.example.ui.theme.HudTextSecondary
import com.example.ui.theme.HudVoid
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

/**
 * Renders a Modular Dashboard Container Card with expandable content,
 * control menu, and its nested modular components.
 */
@Composable
fun ModularDashboardContainerCard(
    container: DashboardContainer,
    controller: UIController,
    activeAccent: Color,
    onAddComponentRequest: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("container_${container.id}"),
        shape = RoundedCornerShape(14.dp),
        color = HudCardBg,
        border = BorderStroke(1.dp, activeAccent.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
            // Container Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(activeAccent.copy(alpha = 0.15f))
                            .border(1.dp, activeAccent.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = resolveContainerIcon(container.iconName),
                            contentDescription = container.title,
                            tint = activeAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = container.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = HudTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            container.badge?.let { badgeText ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(activeAccent.copy(alpha = 0.15f))
                                        .border(0.5.dp, activeAccent.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = badgeText,
                                        color = activeAccent,
                                        fontSize = 8.5.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                        container.description?.let { desc ->
                            Text(
                                text = desc,
                                style = MaterialTheme.typography.bodySmall,
                                color = HudTextSecondary,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // Controls: Add Component, More Menu, Expand/Collapse
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { onAddComponentRequest(container.id) },
                        modifier = Modifier.size(32.dp).testTag("btn_add_comp_${container.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add component",
                            tint = activeAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Box {
                        IconButton(
                            onClick = { menuExpanded = true },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Container settings",
                                tint = HudTextDim,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false },
                            modifier = Modifier.background(HudSurface)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Add Component", color = HudTextPrimary) },
                                onClick = {
                                    menuExpanded = false
                                    onAddComponentRequest(container.id)
                                },
                                leadingIcon = { Icon(Icons.Default.Add, null, tint = activeAccent) }
                            )
                            if (!container.isSystemProtected) {
                                DropdownMenuItem(
                                    text = { Text("Remove Container", color = Color(0xFFEF4444)) },
                                    onClick = {
                                        menuExpanded = false
                                        controller.removeContainer(container.id)
                                    },
                                    leadingIcon = { Icon(Icons.Default.Delete, null, tint = Color(0xFFEF4444)) }
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = { controller.setContainerExpanded(container.id, !container.isExpanded) },
                        modifier = Modifier.size(32.dp).testTag("btn_toggle_expand_${container.id}")
                    ) {
                        Icon(
                            imageVector = if (container.isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = if (container.isExpanded) "Collapse" else "Expand",
                            tint = HudTextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Expanded Component List
            AnimatedVisibility(
                visible = container.isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (container.components.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = HudSurface,
                            border = BorderStroke(1.dp, HudBorder),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "No components in container. Tap + to add one.",
                                    color = HudTextDim,
                                    fontSize = 11.5.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    } else {
                        container.components.sortedBy { it.order }.forEach { component ->
                            ModularComponentCard(
                                component = component,
                                controller = controller,
                                activeAccent = activeAccent
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Renders individual modular components according to their ComponentType.
 */
@Composable
fun ModularComponentCard(
    component: ModularDashboardComponent,
    controller: UIController,
    activeAccent: Color,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = HudSurface,
        border = BorderStroke(1.dp, HudBorder),
        modifier = modifier
            .fillMaxWidth()
            .testTag("component_${component.id}")
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(10.dp)) {
            // Component Title Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(activeAccent)
                    )
                    Text(
                        text = component.title,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = HudTextPrimary,
                        fontSize = 11.5.sp
                    )
                    Text(
                        text = "• ${component.type.name}",
                        color = HudTextDim,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                IconButton(
                    onClick = { controller.removeComponent(component.id) },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Remove component",
                        tint = HudTextDim,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Body based on component type
            when (component.type) {
                ComponentType.METRIC_CARD -> {
                    MetricCardView(component, activeAccent)
                }
                ComponentType.TELEMETRY_GAUGE -> {
                    TelemetryGaugeView(component, activeAccent)
                }
                ComponentType.ACTION_BUTTON_ROW -> {
                    ActionButtonRowView(
                        component = component,
                        activeAccent = activeAccent,
                        onActionClicked = { actionId ->
                            handleModularActionClick(context, coroutineScope, actionId)
                        }
                    )
                }
                ComponentType.KEY_VALUE_LIST -> {
                    KeyValueListView(component, activeAccent)
                }
                ComponentType.LOG_STREAM -> {
                    LogStreamView(component, activeAccent)
                }
                ComponentType.STATUS_BANNER -> {
                    StatusBannerView(component, activeAccent)
                }
                ComponentType.AI_GENERATED_NOTE -> {
                    AiGeneratedNoteView(component, activeAccent)
                }
                ComponentType.PROGRESS_INDICATOR -> {
                    ProgressIndicatorView(component, activeAccent)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Component View Implementations
// -------------------------------------------------------------

@Composable
fun MetricCardView(component: ModularDashboardComponent, activeAccent: Color) {
    val value = component.dataPayload["value"] ?: "N/A"
    val subtitle = component.dataPayload["subtitle"]
    val status = component.dataPayload["status"]

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = activeAccent,
                fontFamily = FontFamily.Monospace,
                fontSize = 18.sp
            )
            subtitle?.let {
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodySmall,
                    color = HudTextSecondary,
                    fontSize = 10.5.sp
                )
            }
        }

        status?.let {
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = if (it.contains("ONLINE", true) || it.contains("VERIFIED", true) || it.contains("OPERATIONAL", true))
                    HudEmerald.copy(alpha = 0.2f)
                else activeAccent.copy(alpha = 0.2f),
                border = BorderStroke(
                    0.5.dp,
                    if (it.contains("ONLINE", true) || it.contains("VERIFIED", true) || it.contains("OPERATIONAL", true))
                        HudEmerald
                    else activeAccent
                )
            ) {
                Text(
                    text = it,
                    color = if (it.contains("ONLINE", true) || it.contains("VERIFIED", true) || it.contains("OPERATIONAL", true))
                        HudEmerald
                    else activeAccent,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
fun TelemetryGaugeView(component: ModularDashboardComponent, activeAccent: Color) {
    val valueStr = component.dataPayload["value"] ?: "0"
    val maxStr = component.dataPayload["max"] ?: "100"
    val unit = component.dataPayload["unit"] ?: ""
    val subtitle = component.dataPayload["subtitle"]

    val value = valueStr.filter { it.isDigit() || it == '.' }.toFloatOrNull() ?: 0f
    val max = maxStr.filter { it.isDigit() || it == '.' }.toFloatOrNull() ?: 100f
    val progress = (value / max.coerceAtLeast(1f)).coerceIn(0f, 1f)

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$valueStr $unit",
                color = activeAccent,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = "Target: <$maxStr $unit",
                color = HudTextDim,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = activeAccent,
            trackColor = HudSurfaceVariant
        )

        subtitle?.let {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = it,
                color = HudTextSecondary,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun ActionButtonRowView(
    component: ModularDashboardComponent,
    activeAccent: Color,
    onActionClicked: (String) -> Unit
) {
    // Collect action items from payload (action_1_label, action_1_id, etc.)
    val actions = remember(component.dataPayload) {
        val list = mutableListOf<Pair<String, String>>()
        for (i in 1..8) {
            val label = component.dataPayload["action_${i}_label"]
            val id = component.dataPayload["action_${i}_id"]
            if (label != null && id != null) {
                list.add(label to id)
            }
        }
        if (list.isEmpty()) {
            list.add("Run Diagnostics" to "run_network_diagnostics")
            list.add("Test Engines" to "test_all_engines")
        }
        list
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        actions.forEach { (label, id) ->
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = activeAccent.copy(alpha = 0.15f),
                border = BorderStroke(1.dp, activeAccent.copy(alpha = 0.6f)),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onActionClicked(id) }
                    .testTag("btn_action_$id")
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = activeAccent,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = label,
                        color = activeAccent,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun KeyValueListView(component: ModularDashboardComponent, activeAccent: Color) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        component.dataPayload.forEach { (key, value) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(HudSurfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = key,
                    color = HudTextSecondary,
                    fontSize = 10.5.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = value,
                    color = activeAccent,
                    fontSize = 10.5.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun LogStreamView(component: ModularDashboardComponent, activeAccent: Color) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = HudVoid,
        border = BorderStroke(0.5.dp, HudBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            component.dataPayload.values.forEach { logLine ->
                Row(
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "›",
                        color = activeAccent,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = logLine,
                        color = HudTextPrimary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
fun StatusBannerView(component: ModularDashboardComponent, activeAccent: Color) {
    val title = component.dataPayload["title"] ?: component.title
    val message = component.dataPayload["message"] ?: ""
    val severity = component.dataPayload["severity"] ?: "INFO"

    val borderColor = if (severity.equals("WARNING", true)) HudMagenta else activeAccent

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = borderColor.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, borderColor.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = if (severity.equals("WARNING", true)) Icons.Default.Warning else Icons.Default.CheckCircle,
                contentDescription = null,
                tint = borderColor,
                modifier = Modifier.size(16.dp)
            )
            Column {
                Text(
                    text = title,
                    color = borderColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                if (message.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = message,
                        color = HudTextPrimary,
                        fontSize = 10.5.sp
                    )
                }
            }
        }
    }
}

@Composable
fun AiGeneratedNoteView(component: ModularDashboardComponent, activeAccent: Color) {
    val author = component.dataPayload["author"] ?: "Muskan AI"
    val body = component.dataPayload["body"] ?: ""
    val timestamp = component.dataPayload["timestamp"] ?: "Live"

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = HudSurfaceVariant,
        border = BorderStroke(1.dp, activeAccent.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = activeAccent,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = author,
                        color = activeAccent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = timestamp,
                    color = HudTextDim,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = body,
                color = HudTextPrimary,
                fontSize = 11.5.sp,
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
fun ProgressIndicatorView(component: ModularDashboardComponent, activeAccent: Color) {
    val progress = (component.dataPayload["progress"]?.toFloatOrNull() ?: 50f) / 100f
    val label = component.dataPayload["label"] ?: "${(progress * 100).toInt()}% Complete"

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label,
            color = HudTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = activeAccent,
            trackColor = HudSurfaceVariant
        )
    }
}

// -------------------------------------------------------------
// Interactive Dialogs for Adding Containers & Components
// -------------------------------------------------------------

@Composable
fun AddContainerDialog(
    onDismiss: () -> Unit,
    onAdd: (DashboardContainer) -> Unit,
    activeAccent: Color
) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var badge by remember { mutableStateOf("DYNAMIC") }
    var selectedIcon by remember { mutableStateOf("Widgets") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = HudCardBg,
            border = BorderStroke(1.dp, activeAccent)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "ADD MODULAR CONTAINER",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = HudTextPrimary,
                    fontFamily = FontFamily.Monospace
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Container Title") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = HudTextPrimary,
                        unfocusedTextColor = HudTextPrimary,
                        focusedBorderColor = activeAccent,
                        unfocusedBorderColor = HudBorder
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("input_container_title")
                )

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Description") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = HudTextPrimary,
                        unfocusedTextColor = HudTextPrimary,
                        focusedBorderColor = activeAccent,
                        unfocusedBorderColor = HudBorder
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("input_container_desc")
                )

                OutlinedTextField(
                    value = badge,
                    onValueChange = { badge = it },
                    label = { Text("Status Badge (e.g. AI, TELEMETRY)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = HudTextPrimary,
                        unfocusedTextColor = HudTextPrimary,
                        focusedBorderColor = activeAccent,
                        unfocusedBorderColor = HudBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        border = BorderStroke(1.dp, HudBorder)
                    ) {
                        Text("Cancel", color = HudTextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                onAdd(
                                    DashboardContainer(
                                        id = "container_${UUID.randomUUID().toString().take(6)}",
                                        title = title.trim(),
                                        description = desc.ifBlank { null },
                                        iconName = selectedIcon,
                                        badge = badge.ifBlank { null }
                                    )
                                )
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = activeAccent),
                        modifier = Modifier.testTag("btn_confirm_add_container")
                    ) {
                        Text("Create Container", color = HudVoid, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AddComponentDialog(
    containerId: String,
    onDismiss: () -> Unit,
    onAdd: (ModularDashboardComponent) -> Unit,
    activeAccent: Color
) {
    var title by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(ComponentType.METRIC_CARD) }
    var primaryValue by remember { mutableStateOf("98%") }
    var subtitle by remember { mutableStateOf("Live dynamic telemetry") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = HudCardBg,
            border = BorderStroke(1.dp, activeAccent)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "ADD MODULAR COMPONENT",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = HudTextPrimary,
                    fontFamily = FontFamily.Monospace
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Component Title") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = HudTextPrimary,
                        unfocusedTextColor = HudTextPrimary,
                        focusedBorderColor = activeAccent,
                        unfocusedBorderColor = HudBorder
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("input_component_title")
                )

                Text(
                    text = "Component Type:",
                    color = HudTextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )

                // Type Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(
                        ComponentType.METRIC_CARD,
                        ComponentType.TELEMETRY_GAUGE,
                        ComponentType.STATUS_BANNER,
                        ComponentType.AI_GENERATED_NOTE
                    ).forEach { type ->
                        val isSelected = selectedType == type
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSelected) activeAccent.copy(alpha = 0.2f) else HudSurface,
                            border = BorderStroke(1.dp, if (isSelected) activeAccent else HudBorder),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedType = type }
                        ) {
                            Text(
                                text = type.name.split("_").first(),
                                color = if (isSelected) activeAccent else HudTextSecondary,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(vertical = 6.dp, horizontal = 2.dp)
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = primaryValue,
                    onValueChange = { primaryValue = it },
                    label = { Text("Value / Content") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = HudTextPrimary,
                        unfocusedTextColor = HudTextPrimary,
                        focusedBorderColor = activeAccent,
                        unfocusedBorderColor = HudBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = subtitle,
                    onValueChange = { subtitle = it },
                    label = { Text("Subtitle / Details") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = HudTextPrimary,
                        unfocusedTextColor = HudTextPrimary,
                        focusedBorderColor = activeAccent,
                        unfocusedBorderColor = HudBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Cancel", color = HudTextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                onAdd(
                                    ModularDashboardComponent(
                                        id = "comp_${UUID.randomUUID().toString().take(6)}",
                                        containerId = containerId,
                                        title = title.trim(),
                                        type = selectedType,
                                        dataPayload = mapOf(
                                            "value" to primaryValue,
                                            "body" to primaryValue,
                                            "subtitle" to subtitle,
                                            "status" to "VERIFIED"
                                        )
                                    )
                                )
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = activeAccent),
                        modifier = Modifier.testTag("btn_confirm_add_component")
                    ) {
                        Text("Add to Container", color = HudVoid, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Helper Methods
// -------------------------------------------------------------

fun resolveContainerIcon(iconName: String): ImageVector {
    return when (iconName.lowercase(Locale.ROOT)) {
        "speed" -> Icons.Default.Speed
        "questionanswer" -> Icons.Default.QuestionAnswer
        "bolt" -> Icons.Default.Bolt
        "widgets" -> Icons.Default.Widgets
        "tune" -> Icons.Default.Tune
        "settings" -> Icons.Default.Settings
        else -> Icons.Default.Widgets
    }
}

private fun handleModularActionClick(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    actionId: String
) {
    when (actionId) {
        "run_network_diagnostics" -> {
            scope.launch {
                Toast.makeText(context, "Executing direct network probing...", Toast.LENGTH_SHORT).show()
                NetworkDiagnosticsEngine.runDirectDiagnostics(context)
            }
        }
        "test_all_engines" -> {
            scope.launch {
                Toast.makeText(context, "Testing all 128 Modular Engines...", Toast.LENGTH_SHORT).show()
                EngineExecutionManager.testAllEngines(context)
            }
        }
        "cycle_accent_lighting" -> {
            val newTheme = AccentLightingManager.cycleNextTheme()
            Toast.makeText(context, "Accent switched to ${newTheme.displayName}", Toast.LENGTH_SHORT).show()
        }
        else -> {
            Toast.makeText(context, "Action triggered: $actionId", Toast.LENGTH_SHORT).show()
        }
    }
}
