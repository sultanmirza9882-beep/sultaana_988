package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.AssistantState
import com.example.ui.theme.MkAmber
import com.example.ui.theme.MkCoral
import com.example.ui.theme.MkCream
import com.example.ui.theme.MkCreamDim
import com.example.ui.theme.MkInk
import com.example.ui.theme.MkInkDeep
import com.example.ui.theme.MkInkLine
import com.example.ui.theme.MkInkRaised
import com.example.ui.theme.MkMint
import com.example.ui.theme.MkViolet

/** Slim header: round menu button, the name "Muskan", and a small capsule of quick actions. */
@Composable
fun MuskanHeader(
    state: AssistantState,
    isMuted: Boolean,
    onMenu: () -> Unit,
    onToggleMute: () -> Unit,
    onKey: () -> Unit,
    onSettings: () -> Unit
) {
    val dot = when {
        isMuted -> MkCreamDim
        state == AssistantState.LISTENING -> MkMint
        state == AssistantState.SPEAKING -> MkCoral
        state == AssistantState.PROCESSING -> MkViolet
        else -> MkAmber
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MkInk)
            .statusBarsPadding()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RoundIconButton(Icons.Default.Menu, "Menu", MkCream, Modifier.testTag("drawer_menu_button"), onMenu)
        Spacer(Modifier.width(12.dp))
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Muskan", color = MkCream, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp)
            Box(Modifier.size(9.dp).clip(CircleShape).background(dot))
        }
        val capsule = RoundedCornerShape(22.dp)
        Row(
            modifier = Modifier
                .clip(capsule)
                .background(MkInkRaised)
                .border(1.dp, MkInkLine, capsule)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CapsuleIcon(
                if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                "Mic", if (isMuted) MkCoral else MkMint, Modifier, onToggleMute
            )
            CapsuleIcon(Icons.Default.Key, "API Key", MkAmber, Modifier, onKey)
            CapsuleIcon(Icons.Default.Settings, "Settings", MkCream, Modifier.testTag("settings_button"), onSettings)
        }
    }
}

@Composable
private fun RoundIconButton(icon: ImageVector, desc: String, tint: androidx.compose.ui.graphics.Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(MkInkRaised)
            .border(1.dp, MkInkLine, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = desc, tint = tint, modifier = Modifier.size(21.dp))
    }
}

@Composable
private fun CapsuleIcon(icon: ImageVector, desc: String, tint: androidx.compose.ui.graphics.Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = desc, tint = tint, modifier = Modifier.size(20.dp))
    }
}

/**
 * Floating dock. The selected item expands into a coral pill with its label;
 * the centre item is a raised bot button that opens Chat.
 */
@Composable
fun MuskanDock(
    selected: MuskanTab,
    pendingCount: Int,
    onSelect: (MuskanTab) -> Unit
) {
    val shape = RoundedCornerShape(34.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(MkInkDeep)
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(66.dp)
                .shadow(14.dp, shape, spotColor = MkCoral)
                .clip(shape)
                .background(MkInkRaised)
                .border(1.dp, MkInkLine, shape)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            DockItem(MuskanTab.HOME, "Home", selected == MuskanTab.HOME, 0, onSelect)
            DockItem(MuskanTab.PROJECTS, "Projects", selected == MuskanTab.PROJECTS, pendingCount, onSelect)

            // centre bot orb
            val chatOn = selected == MuskanTab.CHAT
            Box(
                modifier = Modifier
                    .offset(y = (-12).dp)
                    .size(58.dp)
                    .shadow(12.dp, CircleShape, spotColor = MkCoral)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            if (chatOn) listOf(MkCoral, MkAmber) else listOf(MkCoral.copy(alpha = 0.85f), MkViolet.copy(alpha = 0.85f))
                        )
                    )
                    .border(3.dp, MkInkDeep, CircleShape)
                    .clickable { onSelect(MuskanTab.CHAT) },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = MuskanTab.CHAT.icon,
                    contentDescription = "Muskan",
                    tint = MkInkDeep,
                    modifier = Modifier.size(30.dp)
                )
            }

            DockItem(MuskanTab.TOOLS, "Tools", selected == MuskanTab.TOOLS, 0, onSelect)
            DockItem(MuskanTab.SETTINGS, "Settings", selected == MuskanTab.SETTINGS, 0, onSelect)
        }
    }
}

@Composable
private fun DockItem(
    tab: MuskanTab,
    label: String,
    isSelected: Boolean,
    badge: Int,
    onSelect: (MuskanTab) -> Unit
) {
    val tint = if (isSelected) MkInkDeep else MkCreamDim
    Row(
        modifier = Modifier
            .height(44.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(if (isSelected) MkCoral else androidx.compose.ui.graphics.Color.Transparent)
            .clickable { onSelect(tab) }
            .padding(horizontal = if (isSelected) 14.dp else 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (badge > 0) {
            BadgedBox(badge = { Badge { Text("$badge") } }) {
                Icon(tab.icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
            }
        } else {
            Icon(tab.icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
        }
        if (isSelected) {
            Text(label, color = tint, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}
