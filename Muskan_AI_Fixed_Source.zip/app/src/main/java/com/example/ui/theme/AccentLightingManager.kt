package com.example.ui.theme

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import com.example.AssistantState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AccentLightingTheme(
    val displayName: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val glowColor: Color,
    val hexCode: String
) {
    CYBER_CYAN(
        displayName = "Cyber Cyan",
        primaryColor = Color(0xFF00E5FF),
        secondaryColor = Color(0xFF0284C7),
        glowColor = Color(0x3300E5FF),
        hexCode = "#00E5FF"
    ),
    EMERALD_MATRIX(
        displayName = "Emerald Matrix",
        primaryColor = Color(0xFF10B981),
        secondaryColor = Color(0xFF059669),
        glowColor = Color(0x3310B981),
        hexCode = "#10B981"
    ),
    NEON_PURPLE(
        displayName = "Neon Purple",
        primaryColor = Color(0xFFA855F7),
        secondaryColor = Color(0xFF7C3AED),
        glowColor = Color(0x33A855F7),
        hexCode = "#A855F7"
    ),
    ELECTRIC_MAGENTA(
        displayName = "Electric Magenta",
        primaryColor = Color(0xFFEC4899),
        secondaryColor = Color(0xFFDB2777),
        glowColor = Color(0x33EC4899),
        hexCode = "#EC4899"
    ),
    SOLAR_AMBER(
        displayName = "Solar Amber",
        primaryColor = Color(0xFFF59E0B),
        secondaryColor = Color(0xFFD97706),
        glowColor = Color(0x33F59E0B),
        hexCode = "#F59E0B"
    ),
    CRIMSON_CORE(
        displayName = "Crimson Core",
        primaryColor = Color(0xFFEF4444),
        secondaryColor = Color(0xFFDC2626),
        glowColor = Color(0x33EF4444),
        hexCode = "#EF4444"
    ),
    DYNAMIC_REACTIVE(
        displayName = "Dynamic Audio Reactive",
        primaryColor = Color(0xFF00E5FF),
        secondaryColor = Color(0xFF10B981),
        glowColor = Color(0x3300E5FF),
        hexCode = "REACTIVE"
    )
}

/**
 * Manages Dynamic UI Accent Lighting across Muskan's Master Dashboard,
 * HUD visualizers, neural connectors, and interactive borders.
 */
object AccentLightingManager {
    private const val PREFS_NAME = "muskan_accent_lighting_prefs"
    private const val KEY_THEME_NAME = "selected_accent_theme"

    private var prefs: SharedPreferences? = null

    private val _currentTheme = MutableStateFlow(AccentLightingTheme.CYBER_CYAN)
    val currentTheme: StateFlow<AccentLightingTheme> = _currentTheme.asStateFlow()

    fun initialize(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedName = prefs?.getString(KEY_THEME_NAME, AccentLightingTheme.CYBER_CYAN.name)
        val theme = try {
            AccentLightingTheme.valueOf(savedName ?: AccentLightingTheme.CYBER_CYAN.name)
        } catch (_: Exception) {
            AccentLightingTheme.CYBER_CYAN
        }
        _currentTheme.value = theme
    }

    fun setAccentTheme(theme: AccentLightingTheme) {
        _currentTheme.value = theme
        prefs?.edit()?.putString(KEY_THEME_NAME, theme.name)?.apply()
    }

    /**
     * Resolves the real-time accent color dynamically based on assistant state
     * or active theme choice.
     */
    fun resolveActiveColor(
        theme: AccentLightingTheme = _currentTheme.value,
        assistantState: AssistantState = AssistantState.IDLE,
        audioLevel: Float = 0f
    ): Color {
        return if (theme == AccentLightingTheme.DYNAMIC_REACTIVE) {
            when (assistantState) {
                AssistantState.LISTENING -> {
                    if (audioLevel > 0.3f) Color(0xFF00E5FF) else Color(0xFF10B981)
                }
                AssistantState.PROCESSING -> Color(0xFFA855F7)
                AssistantState.SPEAKING -> Color(0xFFEC4899)
                AssistantState.ERROR -> Color(0xFFEF4444)
                AssistantState.IDLE -> Color(0xFF00E5FF)
            }
        } else {
            theme.primaryColor
        }
    }

    fun resolveSecondaryColor(
        theme: AccentLightingTheme = _currentTheme.value,
        assistantState: AssistantState = AssistantState.IDLE
    ): Color {
        return if (theme == AccentLightingTheme.DYNAMIC_REACTIVE) {
            when (assistantState) {
                AssistantState.LISTENING -> Color(0xFF059669)
                AssistantState.PROCESSING -> Color(0xFF7C3AED)
                AssistantState.SPEAKING -> Color(0xFFDB2777)
                AssistantState.ERROR -> Color(0xFFDC2626)
                AssistantState.IDLE -> Color(0xFF0284C7)
            }
        } else {
            theme.secondaryColor
        }
    }

    fun cycleNextTheme(): AccentLightingTheme {
        val themes = AccentLightingTheme.values()
        val currentIndex = themes.indexOf(_currentTheme.value)
        val nextIndex = (currentIndex + 1) % themes.size
        val nextTheme = themes[nextIndex]
        setAccentTheme(nextTheme)
        return nextTheme
    }
}
