package com.example.ui

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.example.data.AgentLlm
import com.example.engine.learning.PhoneKnowledgeStore
import com.example.engine.network.MuskanWebSocketBridge
import com.example.engine.network.WebRtcSignalingManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/**
 * Teach Muskan. Everything saved here is injected into the autonomous agent's prompt, so after
 * one lesson she knows how to do it (and does it faster every time).
 *
 *  - Write / paste a note   (e.g. "Redmi mein screenshot lene ke liye ...")
 *  - Import a text file     (.txt / .md / .csv / .json)
 *  - Teach from a video     (a screen recording of you doing the task; Gemini turns it into steps)
 *  - See / delete what she has learned, and refresh the phone profile
 */
class TrainingActivity : ComponentActivity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var listBox: LinearLayout
    private lateinit var status: TextView
    private lateinit var profileText: TextView
    private lateinit var titleInput: EditText
    private lateinit var contentInput: EditText
    private lateinit var saveBtn: Button
    private var editingEntryId: String? = null

    private val bg = Color.parseColor("#0B1220")
    private val card = Color.parseColor("#141E33")
    private val accent = Color.parseColor("#00F0FF")

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importTextFile(uri)
    }
    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) learnFromVideo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PhoneKnowledgeStore.init(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(28), dp(16), dp(28))
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); addView(root) }
        setContentView(scroll)

        root.addView(text("Muskan Training", 24f, Color.WHITE, bold = true))
        root.addView(text("Jo yahan sikhaoge, Muskan use phone chalate waqt yaad rakhegi.", 13f, Color.parseColor("#9FB3C8")))

        // --- write a note
        root.addView(section("1. Naya sabak likho"))
        titleInput = input("Title (jaise: Screenshot kaise lete hain)")
        contentInput = input("Kaise karna hai, step by step likho...", multiline = true)
        root.addView(titleInput)
        root.addView(contentInput)
        saveBtn = button("Save kar do") { saveNote() }
        root.addView(saveBtn)

        // --- import file / video
        root.addView(section("2. File ya video se sikhao"))
        root.addView(button("Text file import karo (.txt .md .csv .json)") {
            pickFile.launch(arrayOf("text/*", "application/json", "application/octet-stream"))
        })
        root.addView(button("Video se sikhao (screen recording)") {
            pickVideo.launch(arrayOf("video/*"))
        })
        status = text("", 13f, accent)
        root.addView(status)

        // --- phone profile
        root.addView(section("3. Phone ki jankari (apne aap)"))
        profileText = text(PhoneKnowledgeStore.deviceProfile(), 12f, Color.parseColor("#C9D6E5"))
        root.addView(profileText)
        root.addView(button("Phone ki jankari refresh karo") {
            profileText.text = PhoneKnowledgeStore.deviceProfile(refresh = true)
        })

        // --- what she knows
        root.addView(section("4. Muskan ko kya aata hai"))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)
        refreshList()

        // --- WebSocket Integration & WebRTC Signaling Live Controls
        MuskanWebSocketBridge.init(this)
        root.addView(section("5. WebSocket & WebRTC Signaling Bridge"))
        val wsUrlInput = input("wss://echo.websocket.events").apply {
            setText(MuskanWebSocketBridge.state.value.serverUrl)
        }
        val rtcRoomInput = input("WebRTC Room ID (jaise: muskan-room-1)").apply {
            setText("muskan-room-1")
        }
        val netStatusText = text(
            "WebSocket: ${MuskanWebSocketBridge.state.value.connectionState.label} • WebRTC: ${WebRtcSignalingManager.status.value.signalingState.label}",
            12f, Color.parseColor("#C9D6E5")
        )
        root.addView(wsUrlInput)
        root.addView(rtcRoomInput)
        root.addView(netStatusText)
        root.addView(button("WebSocket Connect karo") {
            MuskanWebSocketBridge.connect(this, wsUrlInput.text.toString().trim())
            netStatusText.text = "WebSocket connecting to ${MuskanWebSocketBridge.state.value.serverUrl}…"
        })
        root.addView(button("WebRTC Room Join + SDP Offer bhejo") {
            val room = rtcRoomInput.text.toString().trim().ifBlank { "muskan-room-1" }
            WebRtcSignalingManager.joinRoom(room, asInitiator = true)
            WebRtcSignalingManager.createAndSendOffer()
            WebRtcSignalingManager.sendLocalIceCandidate()
            val st = WebRtcSignalingManager.status.value
            netStatusText.text = "WebRTC: ${st.signalingState.label} (Room: ${st.roomId}) • ${st.lastSignalEvent}"
        })
        root.addView(button("WebRTC Loopback Self-Test chalao") {
            val summary = WebRtcSignalingManager.runLoopbackSelfTest(
                rtcRoomInput.text.toString().trim().ifBlank { "muskan-test-room" }
            )
            netStatusText.text = summary
            toast("WebRTC Signaling STABLE verified!")
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    // ------------------------------------------------------------------ actions

    private fun saveNote() {
        val title = titleInput.text.toString().trim()
        val content = contentInput.text.toString().trim()
        if (content.isBlank()) { toast("Pehle kuch likho."); return }
        val finalTitle = title.ifBlank { content.lines().first().take(40) }
        val editId = editingEntryId
        if (editId != null && PhoneKnowledgeStore.update(editId, finalTitle, content)) {
            editingEntryId = null
            saveBtn.text = "Save kar do"
            toast("Sabak update ho gaya.")
        } else {
            editingEntryId = null
            saveBtn.text = "Save kar do"
            PhoneKnowledgeStore.add("note", finalTitle, content)
            toast("Muskan ne seekh liya.")
        }
        titleInput.setText(""); contentInput.setText("")
        refreshList()
    }

    private fun importTextFile(uri: Uri) {
        scope.launch {
            try {
                val (name, body) = withContext(Dispatchers.IO) {
                    var n = "File"
                    contentResolver.query(uri, null, null, null, null)?.use { c ->
                        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (i >= 0 && c.moveToFirst()) n = c.getString(i)
                    }
                    val t = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                    n to t
                }
                if (body.isBlank()) { toast("File khaali ya padhi nahi gayi."); return@launch }
                // long files are split so nothing is lost
                body.chunked(7500).forEachIndexed { i, part ->
                    PhoneKnowledgeStore.add("note", if (i == 0) name else "$name (part ${i + 1})", part)
                }
                toast("File se seekh liya.")
                refreshList()
            } catch (e: Exception) {
                toast("File import nahi hui: ${e.message}")
            }
        }
    }

    private fun learnFromVideo(uri: Uri) {
        status.text = "Video dekh rahi hoon…"
        scope.launch {
            try {
                val frames = withContext(Dispatchers.IO) { extractFrames(uri, 14) }
                if (frames.isEmpty()) { status.text = "Video se frames nahi nikle."; return@launch }
                status.text = "${frames.size} frames mile, samajh rahi hoon…"
                val system = "You analyse screen recordings of an Android phone to write how-to lessons for a phone-operating assistant."
                val user = "These are frames (in time order) from a screen recording of someone using an Android phone. " +
                        "Write the lesson as: first line 'TITLE: <short title>', then a numbered list (max 15 steps) of exactly what is done: " +
                        "app names, button/icon labels and where they are on screen, what is typed, what result shows success. " +
                        "Write in simple Hinglish. Do not invent anything that is not visible."
                val res = AgentLlm.generate(system, user, frames, expectJson = false, maxOutputTokens = 1500)
                val out = res.getOrNull()
                if (out.isNullOrBlank()) {
                    status.text = "Video se seekh nahi paayi: ${res.exceptionOrNull()?.message}"
                    return@launch
                }
                val lines = out.lines()
                val titleLine = lines.firstOrNull { it.trim().startsWith("TITLE:", true) }
                val title = titleLine?.substringAfter(":")?.trim().orEmpty().ifBlank { "Video lesson" }
                val body = lines.filterNot { it === titleLine }.joinToString("\n").trim()
                PhoneKnowledgeStore.add("video", title, body)
                status.text = "Video se seekh liya: $title"
                refreshList()
            } catch (e: Exception) {
                status.text = "Video se seekhna fail: ${e.message}"
            }
        }
    }

    private fun extractFrames(uri: Uri, count: Int): List<String> {
        val r = MediaMetadataRetriever()
        val out = ArrayList<String>()
        try {
            r.setDataSource(this, uri)
            val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: return out
            for (i in 0 until count) {
                val tUs = (durMs * 1000L) * (i + 1) / (count + 1)
                val bmp = r.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                val scale = 720f / maxOf(bmp.width, bmp.height)
                val s = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
                val bos = ByteArrayOutputStream()
                s.compress(Bitmap.CompressFormat.JPEG, 50, bos)
                out.add(Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP))
            }
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
        return out
    }

    private fun refreshList() {
        listBox.removeAllViews()
        val builtin = PhoneKnowledgeStore.builtinCount()
        listBox.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(card)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addView(text("REDMI 13 5G NOTES (built-in) • $builtin hisse yaad hain", 14f, Color.WHITE, bold = true))
            addView(text("Hardware, HyperOS settings, Gboard, WhatsApp/YouTube/Instagram/Facebook, Chrome, aur voice-command examples.", 12f, Color.parseColor("#9FB3C8")))
            addView(Button(context).apply {
                text = "Dobara load karo"; isAllCaps = false
                setOnClickListener { PhoneKnowledgeStore.reloadBuiltin(); toast("Redmi notes dobara load ho gaye."); refreshList() }
            })
        })
        val entries = PhoneKnowledgeStore.all().filter { it.kind != "builtin" }.sortedByDescending { it.createdAt }
        if (entries.isEmpty()) {
            listBox.addView(text("Abhi kuch nahi sikhaya.", 13f, Color.parseColor("#9FB3C8")))
            return
        }
        for (e in entries) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = round(card)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
            }
            val kind = when (e.kind) { "video" -> "VIDEO"; "routine" -> "YAAD (khud seekha)"; else -> "NOTE" }
            row.addView(text("$kind • ${e.title}", 14f, Color.WHITE, bold = true))
            row.addView(text(e.content.take(180).replace("\n", " "), 12f, Color.parseColor("#9FB3C8")))
            val actionsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actionsRow.addView(Button(this).apply {
                text = "Edit karo"; isAllCaps = false
                setOnClickListener {
                    editingEntryId = e.id
                    titleInput.setText(e.title)
                    contentInput.setText(e.content)
                    saveBtn.text = "Update kar do"
                    toast("Upar box mein badlaav karke 'Update kar do' dabayein.")
                }
            })
            actionsRow.addView(Button(this).apply {
                text = "Hatao"; isAllCaps = false
                setOnClickListener {
                    if (editingEntryId == e.id) {
                        editingEntryId = null
                        saveBtn.text = "Save kar do"
                    }
                    PhoneKnowledgeStore.delete(e.id)
                    refreshList()
                }
            })
            row.addView(actionsRow)
            listBox.addView(row)
        }
    }

    // ------------------------------------------------------------------ tiny view helpers

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun round(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(12).toFloat() }

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun section(t: String) = text(t, 16f, accent, bold = true).apply { setPadding(0, dp(22), 0, dp(6)) }

    private fun input(hint: String, multiline: Boolean = false) = EditText(this).apply {
        this.hint = hint
        setHintTextColor(Color.parseColor("#5F7288")); setTextColor(Color.WHITE)
        background = round(card)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        if (multiline) { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; minLines = 5; gravity = Gravity.TOP }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
    }

    private fun button(label: String, onClick: (View) -> Unit) = Button(this).apply {
        text = label; isAllCaps = false
        setOnClickListener(onClick)
    }
}
