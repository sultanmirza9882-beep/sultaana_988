package com.example.ui.screens

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Primary navigation tabs for the Muskan Android application.
 */
enum class MuskanTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    PROJECTS("Projects", Icons.Default.Folder),
    CHAT("Chat", Icons.Default.SmartToy),
    TOOLS("Tools", Icons.Default.Terminal),
    SETTINGS("Settings", Icons.Default.Settings)
}
