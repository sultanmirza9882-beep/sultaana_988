package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.approval.OwnerApprovalGate
import com.example.engine.approval.ProposalStatus
import com.example.engine.dev.ProjectWorkspaceManager
import com.example.engine.dev.SelfDevelopmentEngine
import com.example.ui.theme.HudBorder
import com.example.ui.theme.HudCardBg
import com.example.ui.theme.HudCyan
import com.example.ui.theme.HudEmerald
import com.example.ui.theme.HudMagenta
import com.example.ui.theme.HudPurple
import com.example.ui.theme.HudTextPrimary
import com.example.ui.theme.HudTextSecondary
import com.example.ui.theme.HudVoid
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ApprovalsScreen(
    context: Context,
    pendingDrafts: List<SelfDevelopmentEngine.PendingDraft>,
    reviewDraftId: String?,
    reviewDraftSummary: String,
    reviewDraftFiles: List<Pair<String, String>>,
    reviewBusy: Boolean,
    onRefreshDrafts: () -> Unit,
    onReviewDraft: (SelfDevelopmentEngine.PendingDraft) -> Unit,
    onApproveAndApply: () -> Unit,
    onCancelReview: () -> Unit,
    onRollbackSnapshot: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSection by remember { mutableIntStateOf(0) }
    var snapshots by remember { mutableStateOf(emptyList<ProjectWorkspaceManager.SnapshotInfo>()) }
    val liveActionProposals by OwnerApprovalGate.proposals.collectAsState()
    val pendingSensitiveActions = remember(liveActionProposals) {
        liveActionProposals.filter { it.status == ProposalStatus.PENDING }
    }
    val totalPendingCount = pendingSensitiveActions.size + pendingDrafts.size

    fun refreshSnapshots() {
        snapshots = ProjectWorkspaceManager.listSnapshots(context)
    }

    LaunchedEffect(Unit) {
        refreshSnapshots()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(HudVoid)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TabRow(
            selectedTabIndex = selectedSection,
            containerColor = Color(0xFF07111D),
            contentColor = HudCyan,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedSection]),
                    color = HudCyan
                )
            }
        ) {
            Tab(
                selected = selectedSection == 0,
                onClick = { selectedSection = 0 },
                text = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("Approvals")
                        if (totalPendingCount > 0) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (pendingSensitiveActions.isNotEmpty()) HudMagenta else HudCyan,
                                contentColor = HudVoid
                            ) {
                                Text(
                                    text = "$totalPendingCount",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                }
            )
            Tab(
                selected = selectedSection == 1,
                onClick = {
                    selectedSection = 1
                    refreshSnapshots()
                },
                text = { Text("Snapshots & Rollback (${snapshots.size})") }
            )
        }

        if (selectedSection == 0) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (pendingSensitiveActions.isNotEmpty()) {
                    Text(
                        text = "SENSITIVE ACTION APPROVALS (${pendingSensitiveActions.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = HudMagenta
                    )
                    pendingSensitiveActions.forEach { request ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("sensitive_action_card_${request.id}"),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A0D1C)),
                            border = BorderStroke(1.2.dp, HudMagenta.copy(alpha = 0.8f))
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Warning,
                                            contentDescription = "Sensitive action warning",
                                            tint = HudMagenta,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = request.sensitiveActionType?.label ?: request.category.name,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = HudMagenta
                                        )
                                    }
                                    val timeStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(request.timestamp))
                                    Text(timeStr, fontSize = 10.sp, color = HudTextSecondary, fontFamily = FontFamily.Monospace)
                                }

                                Text(
                                    text = request.title,
                                    fontWeight = FontWeight.Bold,
                                    color = HudTextPrimary,
                                    fontSize = 14.sp
                                )

                                Text(
                                    text = request.hinglishExplanation,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = HudTextSecondary
                                )

                                request.payloadPreview?.takeIf { it.isNotBlank() }?.let { preview ->
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFF0A0F1A),
                                        border = BorderStroke(0.8.dp, HudBorder)
                                    ) {
                                        Text(
                                            text = preview,
                                            modifier = Modifier.padding(10.dp),
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp,
                                            color = HudCyan
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = { OwnerApprovalGate.approveProposal(request.id) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("approve_sensitive_action_button"),
                                        colors = ButtonDefaults.buttonColors(containerColor = HudEmerald, contentColor = HudVoid)
                                    ) {
                                        Icon(imageVector = Icons.Default.Check, contentDescription = "Approve action", modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Approve", fontWeight = FontWeight.Bold)
                                    }

                                    OutlinedButton(
                                        onClick = { OwnerApprovalGate.rejectProposal(request.id, "Denied by owner") },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("deny_sensitive_action_button"),
                                        border = BorderStroke(1.dp, HudMagenta),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = HudMagenta)
                                    ) {
                                        Icon(imageVector = Icons.Default.Close, contentDescription = "Deny action", modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Deny", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "STAGED CODE DRAFTS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = HudCyan
                    )
                    OutlinedButton(
                        onClick = onRefreshDrafts,
                        border = BorderStroke(0.8.dp, HudCyan),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = HudCyan)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Refresh", fontSize = 11.sp)
                    }
                }

                Text(
                    text = "Mandatory Approval Workflow: Drafts are staged in the private workspace. They are never applied to the installed app without explicit approval.",
                    style = MaterialTheme.typography.bodySmall,
                    color = HudTextSecondary
                )

                if (reviewDraftId != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF09182A)),
                        border = BorderStroke(1.2.dp, HudCyan)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "REVIEW BEFORE APPLYING",
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = HudCyan,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "${reviewDraftFiles.size} FILE(S)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = HudEmerald,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Text(
                                text = reviewDraftSummary,
                                fontWeight = FontWeight.SemiBold,
                                color = HudTextPrimary,
                                style = MaterialTheme.typography.bodyMedium
                            )

                            reviewDraftFiles.forEach { (path, content) ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF040A12)),
                                    border = BorderStroke(0.8.dp, HudBorder)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = "📄 $path",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = HudEmerald,
                                            fontSize = 12.sp
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = content.take(600) + if (content.length > 600) "\n… [preview truncated; entire file will be applied]" else "",
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 10.sp,
                                            color = HudTextSecondary,
                                            lineHeight = 14.sp
                                        )
                                    }
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = HudPurple.copy(alpha = 0.12f),
                                border = BorderStroke(0.8.dp, HudPurple.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = HudPurple, modifier = Modifier.size(16.dp))
                                    Text(
                                        text = "A pre-change snapshot with SHA-256 integrity verification will be saved before writing. The installed APK remains unchanged.",
                                        fontSize = 11.sp,
                                        color = HudTextSecondary
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = onApproveAndApply,
                                    enabled = !reviewBusy && reviewDraftFiles.isNotEmpty(),
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = HudCyan, contentColor = HudVoid)
                                ) {
                                    if (reviewBusy) {
                                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = HudVoid, strokeWidth = 2.dp)
                                    } else {
                                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Approve & apply", fontWeight = FontWeight.Bold)
                                    }
                                }

                                OutlinedButton(
                                    onClick = onCancelReview,
                                    modifier = Modifier.weight(1f),
                                    border = BorderStroke(1.dp, HudBorder),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = HudTextSecondary)
                                ) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Cancel")
                                }
                            }
                        }
                    }
                }

                if (pendingDrafts.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No drafts awaiting approval.\nAsk Muskan to make a code change to create a reviewable draft.",
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium,
                            color = HudTextSecondary
                        )
                    }
                } else {
                    pendingDrafts.forEach { draft ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = HudCardBg),
                            border = BorderStroke(1.dp, HudBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = draft.draftId,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        color = HudCyan,
                                        fontWeight = FontWeight.Bold
                                    )
                                    val dateStr = SimpleDateFormat("MMM dd, HH:mm", Locale.US).format(Date(draft.createdAt))
                                    Text(dateStr, fontSize = 11.sp, color = HudTextSecondary, fontFamily = FontFamily.Monospace)
                                }

                                Text(
                                    text = draft.summary,
                                    fontWeight = FontWeight.Bold,
                                    color = HudTextPrimary,
                                    fontSize = 13.sp
                                )

                                Text(
                                    text = "${draft.fileCount} file(s) · Staged draft · Not applied to APK",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = HudTextSecondary
                                )

                                Button(
                                    onClick = { onReviewDraft(draft) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F263E), contentColor = HudCyan),
                                    border = BorderStroke(1.dp, HudCyan.copy(alpha = 0.5f))
                                ) {
                                    Text("Review files", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "RECOVERABLE SNAPSHOT INVENTORY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = HudCyan
                )

                Text(
                    text = "Pre-change snapshots are cryptographically cataloged with SHA-256 inventories before every patch application. You can manually rollback to any verified snapshot.",
                    style = MaterialTheme.typography.bodySmall,
                    color = HudTextSecondary
                )

                if (snapshots.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No snapshots recorded yet.\nSnapshots are generated automatically whenever a reviewed patch is applied.",
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium,
                            color = HudTextSecondary
                        )
                    }
                } else {
                    snapshots.forEach { snap ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = HudCardBg),
                            border = BorderStroke(1.dp, HudBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = snap.name,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = HudEmerald
                                    )
                                    val dateStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(snap.createdAt))
                                    Text(dateStr, fontSize = 11.sp, color = HudTextSecondary, fontFamily = FontFamily.Monospace)
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Text("Files: ${snap.fileCount}", fontSize = 11.sp, color = HudTextSecondary)
                                    Text("Size: ${snap.totalBytes / 1024} KB", fontSize = 11.sp, color = HudTextSecondary)
                                    Text("SHA-256: ${snap.digestSummary}…", fontSize = 11.sp, color = HudCyan, fontFamily = FontFamily.Monospace)
                                }

                                OutlinedButton(
                                    onClick = { onRollbackSnapshot(snap.name) },
                                    border = BorderStroke(1.dp, HudMagenta.copy(alpha = 0.7f)),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = HudMagenta)
                                ) {
                                    Icon(imageVector = Icons.Default.History, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Rollback to this snapshot", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
