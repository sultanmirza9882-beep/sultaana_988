package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppDatabase
import com.example.data.local.TaughtWorkflowEntity
import com.example.data.local.UserMemoryEntity
import com.example.engine.memory.PermanentMemoryEngine
import com.example.engine.workflow.TaughtWorkflowEngine
import com.example.engine.workflow.WorkflowStep
import com.example.engine.workflow.WorkflowStepType
import com.example.ui.theme.HudBorder
import com.example.ui.theme.HudBorderBright
import com.example.ui.theme.HudCardBg
import com.example.ui.theme.HudCyan
import com.example.ui.theme.HudEmerald
import com.example.ui.theme.HudMagenta
import com.example.ui.theme.HudPurple
import com.example.ui.theme.HudSurface
import com.example.ui.theme.HudSurfaceVariant
import com.example.ui.theme.HudTextDim
import com.example.ui.theme.HudTextPrimary
import com.example.ui.theme.HudTextSecondary
import com.example.ui.theme.HudVoid
import kotlinx.coroutines.launch

/**
 * Dedicated Full-Screen Interface for Phase 3: Permanent Memory & Taught Workflows.
 * Allows viewing, adding, editing, executing, and deleting user preferences and automation routines.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermanentMemoryScreen(
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val db = remember { AppDatabase.getDatabase(context) }
    val memories by db.userMemoryDao().getAllMemoriesFlow().collectAsState(initial = emptyList())
    val workflows by db.taughtWorkflowDao().getAllWorkflowsFlow().collectAsState(initial = emptyList())
    val executionState by TaughtWorkflowEngine.executionState.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var showAddMemoryDialog by remember { mutableStateOf(false) }
    var showAddWorkflowDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("permanent_memory_screen"),
        containerColor = HudVoid,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(listOf(HudCyan, HudPurple))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Permanent Memory & Workflows",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = HudTextPrimary
                            )
                            Text(
                                text = "Persistent preferences & automated routines",
                                style = MaterialTheme.typography.labelSmall,
                                color = HudTextSecondary
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("permanent_memory_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = HudCyan
                        )
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = HudEmerald.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, HudEmerald.copy(alpha = 0.4f)),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Sync,
                                contentDescription = null,
                                tint = HudEmerald,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "PERSISTED",
                                color = HudEmerald,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 10.sp
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = HudVoid)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
        ) {
            // Execution Status Banner if a workflow is running
            AnimatedVisibility(visible = executionState.isRunning) {
                Surface(
                    color = HudCyan.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, HudCyan),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = HudCyan)
                        Text(
                            text = executionState.lastExecutedStatus,
                            color = HudCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Tabs: 0 -> Memories, 1 -> Workflows
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = HudVoid,
                contentColor = HudCyan,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = HudCyan
                    )
                }
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = {
                        Text(
                            text = "Memories (${memories.size})",
                            fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTabIndex == 0) HudCyan else HudTextSecondary
                        )
                    }
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = {
                        Text(
                            text = "Workflows (${workflows.size})",
                            fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTabIndex == 1) HudCyan else HudTextSecondary
                        )
                    }
                )
            }

            if (selectedTabIndex == 0) {
                // TAB 0: User Memories & Preferences
                MemoriesTabContent(
                    memories = memories,
                    searchQuery = searchQuery,
                    onSearchChange = { searchQuery = it },
                    onAddClick = { showAddMemoryDialog = true },
                    onDelete = { memoryId ->
                        scope.launch {
                            PermanentMemoryEngine.deleteMemory(context, memoryId)
                        }
                    }
                )
            } else {
                // TAB 1: Taught Workflows
                WorkflowsTabContent(
                    workflows = workflows,
                    onAddClick = { showAddWorkflowDialog = true },
                    onRunWorkflow = { wf ->
                        scope.launch {
                            TaughtWorkflowEngine.executeWorkflow(context, wf)
                        }
                    },
                    onToggleEnabled = { wf ->
                        scope.launch {
                            db.taughtWorkflowDao().updateWorkflow(wf.copy(isEnabled = !wf.isEnabled))
                        }
                    },
                    onDelete = { wf ->
                        scope.launch {
                            db.taughtWorkflowDao().deleteWorkflow(wf)
                        }
                    }
                )
            }
        }
    }

    // Add Memory Dialog
    if (showAddMemoryDialog) {
        AddMemoryDialog(
            onDismiss = { showAddMemoryDialog = false },
            onConfirm = { cat, title, detail ->
                scope.launch {
                    PermanentMemoryEngine.persistMemory(context, cat, title, detail)
                }
                showAddMemoryDialog = false
            }
        )
    }

    // Add Workflow Dialog
    if (showAddWorkflowDialog) {
        AddWorkflowDialog(
            onDismiss = { showAddWorkflowDialog = false },
            onConfirm = { title, trigger, desc, steps ->
                scope.launch {
                    val wf = TaughtWorkflowEntity(
                        title = title,
                        triggerPhrase = trigger,
                        description = desc,
                        stepsJson = TaughtWorkflowEngine.serializeSteps(steps),
                        isEnabled = true
                    )
                    db.taughtWorkflowDao().insertWorkflow(wf)
                }
                showAddWorkflowDialog = false
            }
        )
    }
}

@Composable
private fun MemoriesTabContent(
    memories: List<UserMemoryEntity>,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onAddClick: () -> Unit,
    onDelete: (Long) -> Unit
) {
    val filtered = remember(memories, searchQuery) {
        if (searchQuery.isBlank()) memories
        else memories.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
                it.detail.contains(searchQuery, ignoreCase = true) ||
                it.category.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("Search memories…", color = HudTextDim, fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = HudCyan, modifier = Modifier.size(18.dp)) },
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = HudCyan,
                    unfocusedBorderColor = HudBorder,
                    focusedTextColor = HudTextPrimary,
                    unfocusedTextColor = HudTextPrimary,
                    focusedContainerColor = HudCardBg,
                    unfocusedContainerColor = HudCardBg
                ),
                singleLine = true
            )

            Button(
                onClick = onAddClick,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = HudCyan, contentColor = Color.Black),
                modifier = Modifier.height(50.dp).testTag("add_memory_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add", fontWeight = FontWeight.Bold)
            }
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = HudTextDim,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = "No Memories Stored Yet",
                        fontWeight = FontWeight.Bold,
                        color = HudTextPrimary,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "Say 'Mera naam Sultan Mirza hai' or 'Mujhe coffee pasand hai' to record permanent memories automatically.",
                        color = HudTextSecondary,
                        fontSize = 12.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(filtered, key = { it.id }) { mem ->
                    MemoryCard(mem = mem, onDelete = { onDelete(mem.id) })
                }
            }
        }
    }
}

@Composable
private fun MemoryCard(
    mem: UserMemoryEntity,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = HudCardBg),
        border = BorderStroke(1.dp, HudBorder),
        modifier = Modifier.fillMaxWidth().testTag("memory_card_${mem.id}")
    ) {
        Row(
            modifier = Modifier.padding(14.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val badgeColor = when (mem.category.uppercase()) {
                        "CREATOR" -> HudEmerald
                        "PREFERENCE" -> HudPurple
                        "INSTRUCTION" -> HudCyan
                        else -> HudMagenta
                    }
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = badgeColor.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = mem.category.uppercase(),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = badgeColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = mem.title,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = HudTextPrimary
                    )
                }
                Text(
                    text = mem.detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = HudTextSecondary
                )
            }

            IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Delete, contentDescription = "Delete Memory", tint = HudMagenta, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun WorkflowsTabContent(
    workflows: List<TaughtWorkflowEntity>,
    onAddClick: () -> Unit,
    onRunWorkflow: (TaughtWorkflowEntity) -> Unit,
    onToggleEnabled: (TaughtWorkflowEntity) -> Unit,
    onDelete: (TaughtWorkflowEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Taught Routines & Macros",
                    fontWeight = FontWeight.Bold,
                    color = HudTextPrimary,
                    fontSize = 15.sp
                )
                Text(
                    text = "Say trigger phrase or tap Run",
                    color = HudTextSecondary,
                    fontSize = 11.sp
                )
            }

            Button(
                onClick = onAddClick,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = HudCyan, contentColor = Color.Black),
                modifier = Modifier.testTag("add_workflow_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("New Routine", fontWeight = FontWeight.Bold)
            }
        }

        if (workflows.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("No workflows found.", color = HudTextSecondary)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(workflows, key = { it.id }) { wf ->
                    WorkflowCard(
                        workflow = wf,
                        onRun = { onRunWorkflow(wf) },
                        onToggle = { onToggleEnabled(wf) },
                        onDelete = { onDelete(wf) }
                    )
                }
            }
        }
    }
}

@Composable
private fun WorkflowCard(
    workflow: TaughtWorkflowEntity,
    onRun: () -> Unit,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    val steps = remember(workflow.stepsJson) {
        TaughtWorkflowEngine.deserializeSteps(workflow.stepsJson)
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = HudCardBg),
        border = BorderStroke(1.dp, if (workflow.isEnabled) HudCyan.copy(alpha = 0.35f) else HudBorder),
        modifier = Modifier.fillMaxWidth().testTag("workflow_card_${workflow.id}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(HudCyan.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Route, contentDescription = null, tint = HudCyan, modifier = Modifier.size(16.dp))
                    }
                    Column {
                        Text(
                            text = workflow.title,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = HudTextPrimary
                        )
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = HudEmerald.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "Trigger: \"${workflow.triggerPhrase}\"",
                                fontSize = 10.sp,
                                color = HudEmerald,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Switch(
                    checked = workflow.isEnabled,
                    onCheckedChange = { onToggle() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = HudCyan,
                        uncheckedThumbColor = HudTextDim,
                        uncheckedTrackColor = HudSurfaceVariant
                    ),
                    modifier = Modifier.size(40.dp)
                )
            }

            if (workflow.description.isNotBlank()) {
                Text(
                    text = workflow.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = HudTextSecondary
                )
            }

            // Steps preview
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = HudSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(
                        text = "STEPS (${steps.size}):",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = HudCyan
                    )
                    steps.take(3).forEachIndexed { i, s ->
                        Text(
                            text = "${i + 1}. [${s.type.name}] ${s.target}",
                            fontSize = 11.sp,
                            color = HudTextSecondary
                        )
                    }
                    if (steps.size > 3) {
                        Text(text = "+ ${steps.size - 3} more steps…", fontSize = 10.sp, color = HudTextDim)
                    }
                }
            }

            // Bottom action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Executed ${workflow.executionCount}x",
                    fontSize = 10.sp,
                    color = HudTextDim
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = HudMagenta, modifier = Modifier.size(16.dp))
                    }

                    Button(
                        onClick = onRun,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = HudCyan, contentColor = Color.Black),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp).testTag("run_workflow_button_${workflow.id}")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Run Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun AddMemoryDialog(
    onDismiss: () -> Unit,
    onConfirm: (category: String, title: String, detail: String) -> Unit
) {
    var category by remember { mutableStateOf("PREFERENCE") }
    var title by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Permanent Memory", color = HudTextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category (e.g. PREFERENCE, CREATOR)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title (e.g. Favorite Drink)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = detail,
                    onValueChange = { detail = it },
                    label = { Text("Detail (e.g. Loves hot black coffee)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && detail.isNotBlank()) {
                        onConfirm(category, title, detail)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = HudCyan, contentColor = Color.Black)
            ) {
                Text("Save Memory", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = HudTextSecondary) }
        },
        containerColor = HudCardBg
    )
}

@Composable
private fun AddWorkflowDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, trigger: String, desc: String, steps: List<WorkflowStep>) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var trigger by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var step1App by remember { mutableStateOf("WhatsApp") }
    var step2Speech by remember { mutableStateOf("App khol diya hai, Sultan.") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Teach New Routine / Workflow", color = HudTextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Routine Title (e.g. Morning Routine)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = trigger,
                    onValueChange = { trigger = it },
                    label = { Text("Trigger Voice Phrase (e.g. good morning)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Description") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = step1App,
                    onValueChange = { step1App = it },
                    label = { Text("Step 1 App to Launch (e.g. WhatsApp, YouTube)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = step2Speech,
                    onValueChange = { step2Speech = it },
                    label = { Text("Step 2 Voice Announcement") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && trigger.isNotBlank()) {
                        val steps = listOf(
                            WorkflowStep(WorkflowStepType.SPEAK, step2Speech, 800L),
                            WorkflowStep(WorkflowStepType.LAUNCH_APP, step1App, 1000L)
                        )
                        onConfirm(title, trigger, desc, steps)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = HudCyan, contentColor = Color.Black)
            ) {
                Text("Save Routine", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = HudTextSecondary) }
        },
        containerColor = HudCardBg
    )
}
