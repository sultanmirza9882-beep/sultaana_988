package com.example.ui.controller

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

/**
 * Public UIController API contract for Muskan AI.
 * Enables the AI agent and autonomous subsystems to dynamically add, remove,
 * and modify modular dashboard containers and components.
 */
interface UIController {
    val containersFlow: StateFlow<List<DashboardContainer>>
    val activeComponentCount: StateFlow<Int>
    val eventFlow: SharedFlow<UIControllerEvent>

    fun getContainers(): List<DashboardContainer>
    fun getContainer(id: String): DashboardContainer?

    fun addContainer(container: DashboardContainer): Boolean
    fun removeContainer(containerId: String): Boolean
    fun modifyContainer(containerId: String, update: (DashboardContainer) -> DashboardContainer): Boolean
    fun setContainerExpanded(containerId: String, isExpanded: Boolean)
    fun setContainerVisibility(containerId: String, isVisible: Boolean)
    fun reorderContainers(orderedIds: List<String>)

    fun addComponent(containerId: String, component: ModularDashboardComponent): Boolean
    fun removeComponent(componentId: String): Boolean
    fun modifyComponent(componentId: String, update: (ModularDashboardComponent) -> ModularDashboardComponent): Boolean
    fun updateComponentPayload(componentId: String, key: String, value: String): Boolean

    fun executeAgentCommand(command: String): AgentUIResult
    fun resetToDefaults()
}

/**
 * Singleton implementation of UIController for Muskan AI.
 */
object MuskanUIController : UIController {

    private const val TAG = "MuskanUIController"

    private val _containersFlow = MutableStateFlow<List<DashboardContainer>>(emptyList())
    override val containersFlow: StateFlow<List<DashboardContainer>> = _containersFlow.asStateFlow()

    private val _activeComponentCount = MutableStateFlow(0)
    override val activeComponentCount: StateFlow<Int> = _activeComponentCount.asStateFlow()

    private val _eventFlow = MutableSharedFlow<UIControllerEvent>(extraBufferCapacity = 64)
    override val eventFlow: SharedFlow<UIControllerEvent> = _eventFlow.asSharedFlow()

    private fun logInfo(msg: String) {
        try {
            Log.i(TAG, msg)
        } catch (_: Throwable) {
            println("[$TAG] $msg")
        }
    }

    private fun logWarn(msg: String) {
        try {
            Log.w(TAG, msg)
        } catch (_: Throwable) {
            println("[$TAG WARN] $msg")
        }
    }

    private fun logError(msg: String, e: Throwable? = null) {
        try {
            Log.e(TAG, msg, e)
        } catch (_: Throwable) {
            println("[$TAG ERROR] $msg ${e?.message ?: ""}")
        }
    }

    init {
        seedDefaultContainers()
        recalculateComponentCount()
    }

    override fun getContainers(): List<DashboardContainer> = _containersFlow.value

    override fun getContainer(id: String): DashboardContainer? {
        return _containersFlow.value.find { it.id == id }
    }

    override fun addContainer(container: DashboardContainer): Boolean {
        if (_containersFlow.value.any { it.id == container.id }) {
            logWarn("Container with id ${container.id} already exists")
            return false
        }
        _containersFlow.update { current ->
            val updated = current + container.copy(
                order = if (container.order == 0) current.size else container.order,
                lastModified = System.currentTimeMillis()
            )
            updated.sortedBy { it.order }
        }
        recalculateComponentCount()
        _eventFlow.tryEmit(UIControllerEvent.ContainerAdded(container))
        return true
    }

    override fun removeContainer(containerId: String): Boolean {
        val existing = getContainer(containerId) ?: return false
        if (existing.isSystemProtected) {
            logWarn("Cannot remove protected system container: $containerId")
            return false
        }
        _containersFlow.update { current ->
            current.filter { it.id != containerId }
        }
        recalculateComponentCount()
        _eventFlow.tryEmit(UIControllerEvent.ContainerRemoved(containerId))
        return true
    }

    override fun modifyContainer(
        containerId: String,
        update: (DashboardContainer) -> DashboardContainer
    ): Boolean {
        var found = false
        _containersFlow.update { current ->
            current.map { container ->
                if (container.id == containerId) {
                    found = true
                    update(container).copy(lastModified = System.currentTimeMillis())
                } else {
                    container
                }
            }
        }
        if (found) {
            getContainer(containerId)?.let {
                _eventFlow.tryEmit(UIControllerEvent.ContainerUpdated(it))
            }
        }
        return found
    }

    override fun setContainerExpanded(containerId: String, isExpanded: Boolean) {
        modifyContainer(containerId) { it.copy(isExpanded = isExpanded) }
    }

    override fun setContainerVisibility(containerId: String, isVisible: Boolean) {
        modifyContainer(containerId) { it.copy(isVisible = isVisible) }
    }

    override fun reorderContainers(orderedIds: List<String>) {
        _containersFlow.update { current ->
            val map = current.associateBy { it.id }
            val reordered = mutableListOf<DashboardContainer>()
            orderedIds.forEachIndexed { index, id ->
                map[id]?.let { reordered.add(it.copy(order = index)) }
            }
            // append any containers not in the ordered list
            current.filterNot { it.id in orderedIds }.forEachIndexed { index, container ->
                reordered.add(container.copy(order = orderedIds.size + index))
            }
            reordered
        }
        _eventFlow.tryEmit(UIControllerEvent.ContainersReordered(orderedIds))
    }

    override fun addComponent(containerId: String, component: ModularDashboardComponent): Boolean {
        var added = false
        _containersFlow.update { current ->
            current.map { container ->
                if (container.id == containerId) {
                    if (container.components.any { it.id == component.id }) {
                        container
                    } else {
                        added = true
                        val newComp = component.copy(
                            containerId = containerId,
                            order = if (component.order == 0) container.components.size else component.order,
                            lastModified = System.currentTimeMillis()
                        )
                        container.copy(
                            components = (container.components + newComp).sortedBy { it.order },
                            lastModified = System.currentTimeMillis()
                        )
                    }
                } else {
                    container
                }
            }
        }
        if (added) {
            recalculateComponentCount()
            _eventFlow.tryEmit(UIControllerEvent.ComponentAdded(component))
        }
        return added
    }

    override fun removeComponent(componentId: String): Boolean {
        var removed = false
        _containersFlow.update { current ->
            current.map { container ->
                if (container.components.any { it.id == componentId }) {
                    removed = true
                    container.copy(
                        components = container.components.filter { it.id != componentId },
                        lastModified = System.currentTimeMillis()
                    )
                } else {
                    container
                }
            }
        }
        if (removed) {
            recalculateComponentCount()
            _eventFlow.tryEmit(UIControllerEvent.ComponentRemoved(componentId))
        }
        return removed
    }

    override fun modifyComponent(
        componentId: String,
        update: (ModularDashboardComponent) -> ModularDashboardComponent
    ): Boolean {
        var found = false
        var updatedComponent: ModularDashboardComponent? = null
        _containersFlow.update { current ->
            current.map { container ->
                if (container.components.any { it.id == componentId }) {
                    container.copy(
                        components = container.components.map { comp ->
                            if (comp.id == componentId) {
                                found = true
                                val newComp = update(comp).copy(lastModified = System.currentTimeMillis())
                                updatedComponent = newComp
                                newComp
                            } else {
                                comp
                            }
                        },
                        lastModified = System.currentTimeMillis()
                    )
                } else {
                    container
                }
            }
        }
        updatedComponent?.let {
            _eventFlow.tryEmit(UIControllerEvent.ComponentUpdated(it))
        }
        return found
    }

    override fun updateComponentPayload(componentId: String, key: String, value: String): Boolean {
        return modifyComponent(componentId) { comp ->
            val updatedMap = comp.dataPayload.toMutableMap()
            updatedMap[key] = value
            comp.copy(dataPayload = updatedMap)
        }
    }

    override fun executeAgentCommand(command: String): AgentUIResult {
        val trimmed = command.trim()
        logInfo("Executing Agent UI Command: $trimmed")

        return try {
            when {
                // JSON structure command
                trimmed.startsWith("{") -> executeJsonCommand(JSONObject(trimmed))

                // Direct command keywords
                trimmed.startsWith("add_container:", ignoreCase = true) -> {
                    val raw = trimmed.substringAfter(":").trim()
                    val json = JSONObject(raw)
                    val id = json.optString("id", "container_${UUID.randomUUID().toString().take(6)}")
                    val title = json.optString("title", "New Modular Container")
                    val desc = json.optString("description", "AI spawned container")
                    val icon = json.optString("icon", "Widgets")
                    val badge = json.optString("badge", "AI AGENT")
                    val container = DashboardContainer(
                        id = id,
                        title = title,
                        description = desc,
                        iconName = icon,
                        badge = badge,
                        isSystemProtected = false
                    )
                    if (addContainer(container)) {
                        AgentUIResult.Success("Container '$title' added successfully", id)
                    } else {
                        AgentUIResult.Failure("Container '$id' already exists")
                    }
                }

                trimmed.startsWith("remove_container:", ignoreCase = true) -> {
                    val id = trimmed.substringAfter(":").trim()
                    if (removeContainer(id)) {
                        AgentUIResult.Success("Container '$id' removed", id)
                    } else {
                        AgentUIResult.Failure("Could not remove container '$id' (not found or protected)")
                    }
                }

                trimmed.startsWith("add_component:", ignoreCase = true) -> {
                    val raw = trimmed.substringAfter(":").trim()
                    val json = JSONObject(raw)
                    val containerId = json.optString("containerId", _containersFlow.value.firstOrNull()?.id ?: "")
                    val id = json.optString("id", "comp_${UUID.randomUUID().toString().take(6)}")
                    val title = json.optString("title", "Dynamic Metric")
                    val typeStr = json.optString("type", "METRIC_CARD")
                    val type = try {
                        ComponentType.valueOf(typeStr.uppercase(Locale.ROOT))
                    } catch (e: Exception) {
                        ComponentType.METRIC_CARD
                    }
                    val payload = mutableMapOf<String, String>()
                    val payloadJson = json.optJSONObject("payload")
                    payloadJson?.keys()?.forEach { key ->
                        payload[key] = payloadJson.optString(key)
                    }
                    if (json.has("value")) payload["value"] = json.optString("value")
                    if (json.has("subtitle")) payload["subtitle"] = json.optString("subtitle")
                    if (json.has("status")) payload["status"] = json.optString("status")

                    val comp = ModularDashboardComponent(
                        id = id,
                        containerId = containerId,
                        title = title,
                        type = type,
                        dataPayload = payload
                    )
                    if (addComponent(containerId, comp)) {
                        AgentUIResult.Success("Component '$title' added to container '$containerId'", id)
                    } else {
                        AgentUIResult.Failure("Failed to add component to container '$containerId'")
                    }
                }

                trimmed.startsWith("remove_component:", ignoreCase = true) -> {
                    val id = trimmed.substringAfter(":").trim()
                    if (removeComponent(id)) {
                        AgentUIResult.Success("Component '$id' removed", id)
                    } else {
                        AgentUIResult.Failure("Component '$id' not found")
                    }
                }

                trimmed.startsWith("modify_component:", ignoreCase = true) -> {
                    val raw = trimmed.substringAfter(":").trim()
                    val json = JSONObject(raw)
                    val id = json.getString("id")
                    val success = modifyComponent(id) { comp ->
                        var updated = comp
                        if (json.has("title")) updated = updated.copy(title = json.getString("title"))
                        if (json.has("isEnabled")) updated = updated.copy(isEnabled = json.getBoolean("isEnabled"))
                        val payloadJson = json.optJSONObject("payload")
                        if (payloadJson != null) {
                            val newMap = updated.dataPayload.toMutableMap()
                            payloadJson.keys().forEach { k -> newMap[k] = payloadJson.getString(k) }
                            updated = updated.copy(dataPayload = newMap)
                        }
                        updated
                    }
                    if (success) {
                        AgentUIResult.Success("Component '$id' modified", id)
                    } else {
                        AgentUIResult.Failure("Component '$id' not found")
                    }
                }

                // Natural language dashboard box & widget creation
                isDashboardWidgetCommand(trimmed) -> {
                    val title = extractDynamicTitle(trimmed)
                    val containerId = "container_user_${System.currentTimeMillis()}"
                    val compId = "comp_user_${UUID.randomUUID().toString().take(6)}"

                    val payload = mapOf(
                        "title" to title,
                        "value" to "LIVE",
                        "subtitle" to "Created on Dashboard by Sultan Mirza",
                        "status" to "ACTIVE",
                        "badge" to "DYNAMIC BOX"
                    )

                    val newComp = ModularDashboardComponent(
                        id = compId,
                        containerId = containerId,
                        title = "$title Widget",
                        type = ComponentType.METRIC_CARD,
                        dataPayload = payload,
                        order = 0
                    )

                    val newContainer = DashboardContainer(
                        id = containerId,
                        title = title,
                        description = "Dynamic container created by Sultan Mirza",
                        iconName = "Widgets",
                        badge = "CUSTOM",
                        isSystemProtected = false,
                        components = listOf(newComp),
                        order = 0 // Show at the top of the dashboard
                    )

                    addContainer(newContainer)
                    AgentUIResult.Success("Sultan, maine dashboard par '$title' naam se naya card box add kar diya hai.", containerId)
                }

                // Generic natural language fallback interpretation
                trimmed.contains("widget", ignoreCase = true) && trimmed.contains("add", ignoreCase = true) -> {
                    val title = if (trimmed.contains("battery", ignoreCase = true)) "Battery Monitor"
                    else if (trimmed.contains("cpu", ignoreCase = true) || trimmed.contains("ram", ignoreCase = true)) "Resource Gauge"
                    else if (trimmed.contains("note", ignoreCase = true)) "Agent Memo"
                    else "AI Telemetry Card"

                    val type = if (trimmed.contains("note", ignoreCase = true)) ComponentType.AI_GENERATED_NOTE
                    else if (trimmed.contains("gauge", ignoreCase = true)) ComponentType.TELEMETRY_GAUGE
                    else ComponentType.METRIC_CARD

                    val payload = mapOf(
                        "value" to "ACTIVE 99%",
                        "subtitle" to "Spoken via voice command",
                        "status" to "VERIFIED"
                    )
                    val compId = "comp_ai_${UUID.randomUUID().toString().take(5)}"
                    val targetContainer = _containersFlow.value.firstOrNull { it.id == "container_agent_workspace" }?.id
                        ?: _containersFlow.value.firstOrNull()?.id ?: "container_quick_actions"

                    addComponent(
                        targetContainer,
                        ModularDashboardComponent(
                            id = compId,
                            containerId = targetContainer,
                            title = title,
                            type = type,
                            dataPayload = payload
                        )
                    )
                    AgentUIResult.Success("Dynamically added '$title' to $targetContainer", compId)
                }

                else -> AgentUIResult.Failure("Unrecognized command syntax: $trimmed")
            }
        } catch (e: Exception) {
            logError("Error executing agent UI command", e)
            AgentUIResult.Failure("Command failed: ${e.message}")
        }
    }

    private fun executeJsonCommand(json: JSONObject): AgentUIResult {
        val action = json.optString("action", "")
        return when (action.lowercase(Locale.ROOT)) {
            "add_container" -> {
                val containerObj = json.getJSONObject("container")
                val container = DashboardContainer(
                    id = containerObj.optString("id", "container_${UUID.randomUUID().toString().take(6)}"),
                    title = containerObj.optString("title", "Custom Container"),
                    description = if (containerObj.has("description")) containerObj.optString("description") else null,
                    iconName = containerObj.optString("iconName", "Widgets"),
                    badge = containerObj.optString("badge", "DYNAMIC")
                )
                if (addContainer(container)) AgentUIResult.Success("Container added", container.id)
                else AgentUIResult.Failure("Container already exists")
            }
            "remove_container" -> {
                val id = json.getString("containerId")
                if (removeContainer(id)) AgentUIResult.Success("Container removed", id)
                else AgentUIResult.Failure("Could not remove container")
            }
            "add_component" -> {
                val containerId = json.getString("containerId")
                val compObj = json.getJSONObject("component")
                val type = try {
                    ComponentType.valueOf(compObj.optString("type", "METRIC_CARD").uppercase(Locale.ROOT))
                } catch (e: Exception) {
                    ComponentType.METRIC_CARD
                }
                val payload = mutableMapOf<String, String>()
                val payloadObj = compObj.optJSONObject("dataPayload")
                payloadObj?.keys()?.forEach { k -> payload[k] = payloadObj.getString(k) }

                val comp = ModularDashboardComponent(
                    id = compObj.optString("id", "comp_${UUID.randomUUID().toString().take(6)}"),
                    containerId = containerId,
                    title = compObj.optString("title", "New Component"),
                    type = type,
                    dataPayload = payload
                )
                if (addComponent(containerId, comp)) AgentUIResult.Success("Component added", comp.id)
                else AgentUIResult.Failure("Container not found")
            }
            "remove_component" -> {
                val id = json.getString("componentId")
                if (removeComponent(id)) AgentUIResult.Success("Component removed", id)
                else AgentUIResult.Failure("Component not found")
            }
            else -> AgentUIResult.Failure("Unknown JSON action '$action'")
        }
    }

    fun isDashboardWidgetCommand(p: String): Boolean {
        val lower = p.lowercase(Locale.ROOT).trim()
        return lower.contains("box add") ||
                lower.contains("box banao") ||
                lower.contains("widget add") ||
                lower.contains("widget banao") ||
                lower.contains("widget lagao") ||
                lower.contains("dashboard par box") ||
                lower.contains("dashboard pe box") ||
                lower.contains("dashboard par widget") ||
                lower.contains("dashboard pe widget") ||
                lower.contains("naam likho") ||
                lower.contains("naam likh do") ||
                lower.contains("khali box") ||
                lower.contains("card banao") ||
                lower.contains("card add") ||
                lower.contains("container banao") ||
                lower.contains("container add") ||
                (lower.contains("dashboard") && (lower.contains("box") || lower.contains("widget") || lower.contains("card") || lower.contains("banao") || lower.contains("add"))) ||
                (lower.contains("box") && (lower.contains("banao") || lower.contains("add") || lower.contains("create") || lower.contains("sultana")))
    }

    fun extractDynamicTitle(input: String): String {
        val lower = input.lowercase(Locale.ROOT)
        val blacklisted = setOf("karo", "do", "banao", "add", "ek", "box", "widget", "card", "likho", "naam", "title", "mein", "par", "pe", "jisme", "aur", "ye")

        // 1. Primary prescribed regex: (?i)(?:naam|title|likho)\s+([a-zA-Z0-9_-]+)
        val primaryRegex = Regex("(?i)(?:naam|title|likho)\\s+([a-zA-Z0-9_-]+)")
        val matchPrimary = primaryRegex.find(input)
        if (matchPrimary != null) {
            val candidate = matchPrimary.groupValues[1].trim()
            if (candidate.isNotBlank() && candidate.lowercase(Locale.ROOT) !in blacklisted) {
                return candidate.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
            }
        }

        // 2. Secondary contextual Hindi patterns
        val namePatterns = listOf(
            Regex("(?i)naam\\s+(?:likho|likh\\s+do|rakho|rakh\\s+do|dalo|ho)?\\s*([a-zA-Z0-9_-]+)"),
            Regex("(?i)([a-zA-Z0-9_-]+?)\\s+naam\\s+(?:se|ka)?\\s*(?:box|widget|card)"),
            Regex("(?i)(?:box|widget|card|container)\\s+(?:ka\\s+naam|naam)?\\s*([a-zA-Z0-9_-]+)"),
            Regex("(?i)jiska\\s+naam\\s+([a-zA-Z0-9_-]+)\\s+ho"),
            Regex("(?i)jisme\\s+([a-zA-Z0-9_-]+)\\s+likho")
        )
        for (pat in namePatterns) {
            val match = pat.find(input)
            if (match != null) {
                val candidate = match.groupValues[1].trim()
                if (candidate.isNotBlank() && candidate.lowercase(Locale.ROOT) !in blacklisted) {
                    return candidate.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
                }
            }
        }

        if (lower.contains("sultana")) return "Sultana"
        if (lower.contains("battery")) return "Battery Monitor"
        if (lower.contains("cpu") || lower.contains("ram")) return "Resource Telemetry"
        if (lower.contains("note") || lower.contains("memo")) return "Agent Memo"
        if (lower.contains("khali box") || lower.contains("empty")) return "Empty Widget Box"
        return "Dynamic Card"
    }

    override fun resetToDefaults() {
        seedDefaultContainers()
        recalculateComponentCount()
        _eventFlow.tryEmit(UIControllerEvent.LayoutReset)
    }

    private fun recalculateComponentCount() {
        _activeComponentCount.value = _containersFlow.value.sumOf { it.components.size }
    }

    private fun seedDefaultContainers() {
        val containers = listOf(
            DashboardContainer(
                id = "container_neural_telemetry",
                title = "Neural & Network Telemetry",
                description = "Live network verification, latency telemetry, and API status",
                iconName = "Speed",
                badge = "VERIFIED",
                isSystemProtected = true,
                order = 0,
                components = listOf(
                    ModularDashboardComponent(
                        id = "comp_net_status",
                        containerId = "container_neural_telemetry",
                        title = "Network Health Verification",
                        type = ComponentType.METRIC_CARD,
                        dataPayload = mapOf(
                            "value" to "VERIFIED",
                            "subtitle" to "Direct DNS & Socket Probing",
                            "status" to "ONLINE",
                            "badge" to "SECURE"
                        ),
                        order = 0
                    ),
                    ModularDashboardComponent(
                        id = "comp_net_latency",
                        containerId = "container_neural_telemetry",
                        title = "Gateway Roundtrip Latency",
                        type = ComponentType.TELEMETRY_GAUGE,
                        dataPayload = mapOf(
                            "value" to "28",
                            "max" to "200",
                            "unit" to "ms",
                            "subtitle" to "Google DNS & Gemini Gateway"
                        ),
                        order = 1
                    ),
                    ModularDashboardComponent(
                        id = "comp_engines_metric",
                        containerId = "container_neural_telemetry",
                        title = "Autonomous Engines",
                        type = ComponentType.METRIC_CARD,
                        dataPayload = mapOf(
                            "value" to "128 / 128",
                            "subtitle" to "All Subsystems Functional",
                            "status" to "OPERATIONAL"
                        ),
                        order = 2
                    )
                )
            ),

            DashboardContainer(
                id = "container_dialogue_hub",
                title = "Cognitive Dialogue Stream",
                description = "Active dialogue management and counter-questioning context",
                iconName = "QuestionAnswer",
                badge = "INTERACTIVE",
                isSystemProtected = true,
                order = 1,
                components = listOf(
                    ModularDashboardComponent(
                        id = "comp_dialogue_status",
                        containerId = "container_dialogue_hub",
                        title = "Dialogue Manager State",
                        type = ComponentType.STATUS_BANNER,
                        dataPayload = mapOf(
                            "title" to "Counter-Questioning Engine Active",
                            "message" to "Muskan actively formulates natural counter-questions when intent needs clarification.",
                            "severity" to "INFO"
                        ),
                        order = 0
                    ),
                    ModularDashboardComponent(
                        id = "comp_dialogue_kv",
                        containerId = "container_dialogue_hub",
                        title = "Conversation Context Metrics",
                        type = ComponentType.KEY_VALUE_LIST,
                        dataPayload = mapOf(
                            "Owner" to "Sultan Mirza",
                            "Persona" to "Muskan (Female AI Companion)",
                            "Counter-Questioning" to "ENABLED",
                            "Voice Response" to "LOW LATENCY (<150ms)",
                            "Language" to "Hinglish / English"
                        ),
                        order = 1
                    )
                )
            ),

            DashboardContainer(
                id = "container_quick_actions",
                title = "Modular Control Hub",
                description = "One-tap control actions and diagnostic triggers",
                iconName = "Bolt",
                badge = "COMMANDS",
                isSystemProtected = false,
                order = 2,
                components = listOf(
                    ModularDashboardComponent(
                        id = "comp_action_triggers",
                        containerId = "container_quick_actions",
                        title = "Instant Actions",
                        type = ComponentType.ACTION_BUTTON_ROW,
                        dataPayload = mapOf(
                            "action_1_label" to "Run Network Check",
                            "action_1_id" to "run_network_diagnostics",
                            "action_2_label" to "Test 128 Engines",
                            "action_2_id" to "test_all_engines",
                            "action_3_label" to "Cycle Accent",
                            "action_3_id" to "cycle_accent_lighting"
                        ),
                        order = 0
                    ),
                    ModularDashboardComponent(
                        id = "comp_action_log",
                        containerId = "container_quick_actions",
                        title = "Modular Event Stream",
                        type = ComponentType.LOG_STREAM,
                        dataPayload = mapOf(
                            "entry_1" to "[UIController] Architecture initialized with dynamic container management",
                            "entry_2" to "[NetworkDiagnostics] Direct socket probing verified",
                            "entry_3" to "[EngineRegistry] 128 engines ready for autonomous execution"
                        ),
                        order = 1
                    )
                )
            ),

            DashboardContainer(
                id = "container_agent_workspace",
                title = "AI Agent Dynamic Workspace",
                description = "Playground for AI-spawned widgets and dynamic telemetry",
                iconName = "Widgets",
                badge = "AI EXTENSIBLE",
                isSystemProtected = false,
                order = 3,
                components = listOf(
                    ModularDashboardComponent(
                        id = "comp_ai_welcome_note",
                        containerId = "container_agent_workspace",
                        title = "Muskan Dynamic UI Architecture",
                        type = ComponentType.AI_GENERATED_NOTE,
                        dataPayload = mapOf(
                            "author" to "Muskan AI",
                            "body" to "Hello Sultan! I have full programmatic access to this UIController. I can autonomously add, remove, and update widgets, metric gauges, and custom control containers in real time based on your commands.",
                            "timestamp" to "Live Session"
                        ),
                        order = 0
                    )
                )
            )
        )

        _containersFlow.value = containers
    }
}
