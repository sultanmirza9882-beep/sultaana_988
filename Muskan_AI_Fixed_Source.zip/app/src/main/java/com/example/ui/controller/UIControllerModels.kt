package com.example.ui.controller

import androidx.compose.ui.graphics.Color

/**
 * Types of modular components that can be hosted inside a DashboardContainer.
 */
enum class ComponentType {
    METRIC_CARD,          // Shows primary metric, subtitle, status badge, trend (+/- %)
    TELEMETRY_GAUGE,      // Progress bar or gauge with value, max, unit
    ACTION_BUTTON_ROW,    // List of action buttons with action IDs
    KEY_VALUE_LIST,       // Pairs of key-value parameters
    LOG_STREAM,           // Live scrolling status text or audit entries
    STATUS_BANNER,        // Highlighted notice / alert with severity
    AI_GENERATED_NOTE,    // Freeform Markdown or AI observation note
    PROGRESS_INDICATOR    // Percentage / indeterminate state tracker
}

/**
 * A modular component residing within a DashboardContainer.
 */
data class ModularDashboardComponent(
    val id: String,
    val containerId: String,
    val title: String,
    val type: ComponentType,
    val dataPayload: Map<String, String> = emptyMap(),
    val order: Int = 0,
    val isEnabled: Boolean = true,
    val lastModified: Long = System.currentTimeMillis()
)

/**
 * A modular dashboard container hosting multiple customizable components.
 */
data class DashboardContainer(
    val id: String,
    val title: String,
    val description: String? = null,
    val iconName: String = "Widgets",
    val accentColorHex: String? = null,
    val isVisible: Boolean = true,
    val isExpanded: Boolean = true,
    val order: Int = 0,
    val components: List<ModularDashboardComponent> = emptyList(),
    val badge: String? = null,
    val isSystemProtected: Boolean = false,
    val lastModified: Long = System.currentTimeMillis()
)

/**
 * Events dispatched when the UI structure is mutated.
 */
sealed class UIControllerEvent {
    data class ContainerAdded(val container: DashboardContainer) : UIControllerEvent()
    data class ContainerRemoved(val containerId: String) : UIControllerEvent()
    data class ContainerUpdated(val container: DashboardContainer) : UIControllerEvent()
    data class ComponentAdded(val component: ModularDashboardComponent) : UIControllerEvent()
    data class ComponentRemoved(val componentId: String) : UIControllerEvent()
    data class ComponentUpdated(val component: ModularDashboardComponent) : UIControllerEvent()
    data class ContainersReordered(val containerIds: List<String>) : UIControllerEvent()
    object LayoutReset : UIControllerEvent()
}

/**
 * Outcome of an AI Agent UI command execution.
 */
sealed class AgentUIResult {
    data class Success(val message: String, val affectedId: String? = null) : AgentUIResult()
    data class Failure(val reason: String) : AgentUIResult()
}
