package com.example.ui.components

import android.content.ClipboardManager
import android.content.Context
import com.example.api.ApiProvider
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.api.ApiConfigHelper
import com.example.api.ApiKeySlot
import com.example.api.ExtractedApiKeyResult
import com.example.api.KeyRotationPoolManager
import com.example.api.KeySlotStatus
import com.example.data.GeminiClient
import com.example.ui.theme.HudAmber
import com.example.ui.theme.HudBorder
import com.example.ui.theme.HudBorderBright
import com.example.ui.theme.HudCardBg
import com.example.ui.theme.HudCyan
import com.example.ui.theme.HudEmerald
import com.example.ui.theme.HudMagenta
import com.example.ui.theme.HudPurple
import com.example.ui.theme.HudSurface
import com.example.ui.theme.HudTextDim
import com.example.ui.theme.HudTextPrimary
import com.example.ui.theme.HudTextSecondary
import com.example.ui.theme.HudVoid
import kotlinx.coroutines.launch

/**
 * Universal Multi-Provider API Key Manager & Hybrid 20-Key Auto-Rotation Dashboard:
 * - Slot 0: Custom External Open Slot (Editable input box with quick Save/Paste for Sultan Mirza)
 * - Slots 1 to 19: Background 19-Key Default Pool with Round-Robin failover (<200ms)
 * - Metadata tracking: Status (ACTIVE/EXHAUSTED/INVALID), lastUsed, errorCount, requestsToday.
 * - Clean "Test Connection" button testing endpoint with masked key.
 * - Real-time active key index status indicator.
 */
@Composable
fun ApiManagementDialog(
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val slots by KeyRotationPoolManager.slots.collectAsState()
    val activeIndex by KeyRotationPoolManager.activeSlotIndex.collectAsState()

    val customSlot = slots.getOrNull(0) ?: ApiKeySlot(0, "Slot 0", "", isCustomSlot = true)

    var customInputKey by remember(customSlot.keyString) { mutableStateOf(customSlot.keyString) }
    var isKeyVisible by remember { mutableStateOf(false) }
    var isTestingConnection by remember { mutableStateOf(false) }
    var isVerifyingSlot0 by remember { mutableStateOf(false) }
    var testResultStatus by remember { mutableStateOf<String?>(null) }
    var testResultIsSuccess by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = modifier
                .fillMaxSize()
                .padding(14.dp)
                .testTag("api_management_dialog"),
            shape = RoundedCornerShape(20.dp),
            color = HudVoid,
            border = BorderStroke(1.dp, HudBorderBright)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(HudCardBg)
                                .border(1.dp, HudCyan, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = null,
                                tint = HudCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "HYBRID 20-KEY API MANAGER",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = HudTextPrimary,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "1 Custom Slot + 19 Default Pool • Zero-Delay Auto-Rotation",
                                style = MaterialTheme.typography.labelSmall,
                                color = HudTextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("api_manager_close_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = HudTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Currently Active Slot Indicator Banner
                val activeSlot = slots.getOrNull(activeIndex) ?: customSlot
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = HudCardBg,
                    border = BorderStroke(1.dp, HudCyan.copy(alpha = 0.6f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("active_slot_indicator_banner")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "ACTIVE KEY INDEX: SLOT #$activeIndex",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = HudCyan,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (activeSlot.isCustomSlot) HudPurple.copy(alpha = 0.2f) else HudEmerald.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = if (activeSlot.isCustomSlot) "CUSTOM PRIORITY" else "DEFAULT POOL",
                                        color = if (activeSlot.isCustomSlot) HudPurple else HudEmerald,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        maxLines = 1,
                                        softWrap = false,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = activeSlot.label,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = HudTextPrimary
                            )
                            Text(
                                text = "Model: ${activeSlot.modelId} • Key: ${activeSlot.getMaskedKey()} • Requests Today: ${activeSlot.requestsToday}",
                                style = MaterialTheme.typography.labelSmall,
                                color = HudTextSecondary,
                                fontSize = 9.sp
                            )
                        }

                        // Test Connection Button without exposing key
                        Button(
                            onClick = {
                                isTestingConnection = true
                                testResultStatus = null
                                coroutineScope.launch {
                                    val keyAnalysis = if (customInputKey.isNotBlank()) ApiConfigHelper.analyzeAndCleanKey(customInputKey) else null
                                    val cleanedKey = keyAnalysis?.cleanedKey ?: activeSlot.keyString
                                    val safeModel = ApiConfigHelper.cleanModelId(keyAnalysis?.recommendedModel ?: activeSlot.modelId)
                                    val slotToTest = activeSlot.copy(
                                        keyString = cleanedKey,
                                        modelId = safeModel,
                                        provider = keyAnalysis?.detectedProvider ?: activeSlot.provider
                                    )
                                    if (slotToTest.keyString.isBlank() || ApiKeySlot.isPlaceholderKey(slotToTest.keyString)) {
                                        isTestingConnection = false
                                        testResultIsSuccess = false
                                        testResultStatus = "No active key in Slot #${slotToTest.slotIndex}. Paste your Google AI Studio key below."
                                        return@launch
                                    }
                                    val verification = KeyRotationPoolManager.testConnectionForSlot(slotToTest)
                                    isTestingConnection = false
                                    testResultIsSuccess = verification.isSuccess
                                    testResultStatus = verification.message
                                }
                            },
                            enabled = !isTestingConnection && !isVerifyingSlot0,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = HudCyan,
                                contentColor = HudVoid
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("test_active_connection_btn")
                        ) {
                            if (isTestingConnection) {
                                CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 1.5.dp, color = HudVoid)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Testing…", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            } else {
                                Text("Test Connection", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Test Connection Feedback Snack if present
                if (testResultStatus != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (testResultIsSuccess) HudEmerald.copy(alpha = 0.15f) else HudMagenta.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, if (testResultIsSuccess) HudEmerald else HudMagenta),
                        modifier = Modifier.fillMaxWidth().testTag("test_connection_feedback")
                    ) {
                        Text(
                            text = testResultStatus!!,
                            color = HudTextPrimary,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Scrollable Content
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // SLOT 0: Dedicated Custom External Key Input Field
                    item {
                        val inputAnalysis = remember(customInputKey) { ApiConfigHelper.analyzeAndCleanKey(customInputKey) }

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = HudSurface,
                            border = BorderStroke(1.5.dp, HudCyan),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("custom_slot_0_card")
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "SLOT 0: CUSTOM EXTERNAL KEY",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = HudCyan,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = "Paste ANY external key (Gemini AIzaSy, OpenAI sk-, Groq gsk-, Claude). Priority 1.",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = HudTextSecondary,
                                            fontSize = 9.sp
                                        )
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (customSlot.isAvailable()) HudEmerald.copy(alpha = 0.2f) else HudAmber.copy(alpha = 0.2f)
                                    ) {
                                        Text(
                                            text = if (customSlot.isAvailable()) "PRIORITY ACTIVE" else "NOT CONFIGURED",
                                            color = if (customSlot.isAvailable()) HudEmerald else HudAmber,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                // Key Input field with Quick Paste & Visibility toggle
                                OutlinedTextField(
                                    value = customInputKey,
                                    onValueChange = { customInputKey = it },
                                    label = { Text("Custom External API Key") },
                                    placeholder = { Text("AIzaSy... or sk-...") },
                                    singleLine = true,
                                    visualTransformation = if (isKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                    trailingIcon = {
                                        Row {
                                            IconButton(onClick = { isKeyVisible = !isKeyVisible }) {
                                                Icon(
                                                    imageVector = if (isKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                    contentDescription = "Toggle visibility",
                                                    tint = HudTextSecondary
                                                )
                                            }
                                            // Quick Paste Button
                                            IconButton(
                                                onClick = {
                                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                                    val text = clipboard?.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
                                                    if (text.isNotBlank()) {
                                                        customInputKey = text
                                                    }
                                                },
                                                modifier = Modifier.testTag("custom_key_paste_btn")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.ContentPaste,
                                                    contentDescription = "Paste from clipboard",
                                                    tint = HudCyan
                                                )
                                            }
                                        }
                                    },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = HudCyan,
                                        unfocusedBorderColor = HudBorder,
                                        focusedTextColor = HudTextPrimary,
                                        unfocusedTextColor = HudTextPrimary
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("custom_slot_key_input")
                                )

                                // Real-time Detection Hint & Key Match Status
                                if (inputAnalysis.cleanedKey.isNotBlank()) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = HudEmerald.copy(alpha = 0.12f),
                                        border = BorderStroke(1.dp, HudEmerald.copy(alpha = 0.5f))
                                    ) {
                                        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = null,
                                                    tint = HudEmerald,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Text(
                                                    text = inputAnalysis.hintMessage ?: "Google AI Studio Free Key Format Matched",
                                                    color = HudEmerald,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            val masked = if (inputAnalysis.cleanedKey.length >= 8) {
                                                "${inputAnalysis.cleanedKey.take(5)}••••${inputAnalysis.cleanedKey.takeLast(4)} (${inputAnalysis.cleanedKey.length} chars)"
                                            } else {
                                                "${inputAnalysis.cleanedKey.length} chars"
                                            }
                                            Text(
                                                text = "Matched Key: $masked • All Gemini Versions Supported",
                                                color = HudTextSecondary,
                                                fontSize = 9.sp
                                            )
                                        }
                                    }
                                }

                                // Supported Model Version Selector Chips
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "TARGET MODEL VERSION (Auto-detects or tap to pick):",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = HudTextSecondary,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    val versionOptions = listOf(
                                        Pair("gemini-2.0-flash", "2.0 Flash (Fast)"),
                                        Pair("gemini-1.5-flash", "1.5 Flash"),
                                        Pair("gemini-2.0-flash-lite", "2.0 Lite"),
                                        Pair("gemini-2.5-flash", "2.5 Flash"),
                                        Pair("gemini-1.5-pro", "1.5 Pro")
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        versionOptions.take(3).forEach { (vId, vLabel) ->
                                            val isSelected = (customSlot.modelId == vId)
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (isSelected) HudCyan.copy(alpha = 0.25f) else HudCardBg,
                                                border = BorderStroke(1.dp, if (isSelected) HudCyan else HudBorder),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clickable {
                                                        KeyRotationPoolManager.updateSlotModel(0, vId)
                                                        testResultStatus = "Selected model: $vId"
                                                        testResultIsSuccess = true
                                                    }
                                            ) {
                                                Text(
                                                    text = vLabel,
                                                    color = if (isSelected) HudCyan else HudTextSecondary,
                                                    fontSize = 9.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    textAlign = TextAlign.Center,
                                                    modifier = Modifier.padding(vertical = 4.dp, horizontal = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        versionOptions.drop(3).forEach { (vId, vLabel) ->
                                            val isSelected = (customSlot.modelId == vId)
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (isSelected) HudCyan.copy(alpha = 0.25f) else HudCardBg,
                                                border = BorderStroke(1.dp, if (isSelected) HudCyan else HudBorder),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clickable {
                                                        KeyRotationPoolManager.updateSlotModel(0, vId)
                                                        testResultStatus = "Selected model: $vId"
                                                        testResultIsSuccess = true
                                                    }
                                            ) {
                                                Text(
                                                    text = vLabel,
                                                    color = if (isSelected) HudCyan else HudTextSecondary,
                                                    fontSize = 9.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    textAlign = TextAlign.Center,
                                                    modifier = Modifier.padding(vertical = 4.dp, horizontal = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Auto-Connect & Save Button (Primary)
                                    Button(
                                        onClick = {
                                            if (customInputKey.isNotBlank()) {
                                                isVerifyingSlot0 = true
                                                testResultStatus = null
                                                coroutineScope.launch {
                                                    val result = KeyRotationPoolManager.verifyAndConnectSlot0(customInputKey)
                                                    isVerifyingSlot0 = false
                                                    testResultIsSuccess = result.isSuccess
                                                    testResultStatus = result.message
                                                }
                                            }
                                        },
                                        enabled = customInputKey.isNotBlank() && !isVerifyingSlot0,
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = HudEmerald,
                                            contentColor = HudVoid
                                        ),
                                        modifier = Modifier
                                            .weight(1.3f)
                                            .testTag("custom_key_verify_connect_btn")
                                    ) {
                                        if (isVerifyingSlot0) {
                                            CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 1.5.dp, color = HudVoid)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Connecting…", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        } else {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Auto-Connect & Save", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    // Quick Save Button (Save directly)
                                    Button(
                                        onClick = {
                                            if (customInputKey.isNotBlank()) {
                                                KeyRotationPoolManager.setCustomSlotKey(customInputKey)
                                                testResultStatus = "Connected! Custom Slot 0 saved as Priority 1 (Auto-Failover Active)."
                                                testResultIsSuccess = true
                                            }
                                        },
                                        enabled = customInputKey.isNotBlank() && !isVerifyingSlot0,
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = HudCyan,
                                            contentColor = HudVoid
                                        ),
                                        modifier = Modifier
                                            .weight(0.9f)
                                            .testTag("custom_key_save_btn")
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Save", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    // Clear Button if configured
                                    if (customSlot.keyString.isNotBlank()) {
                                        OutlinedButton(
                                            onClick = {
                                                KeyRotationPoolManager.clearCustomSlot()
                                                customInputKey = ""
                                                testResultStatus = "Custom Slot 0 cleared."
                                                testResultIsSuccess = true
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = HudMagenta),
                                            border = BorderStroke(1.dp, HudMagenta),
                                            modifier = Modifier.testTag("custom_key_clear_btn")
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Section Header: Default Pool
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "HARDCODED DEFAULT POOL (SLOTS 1 TO 19)",
                                style = MaterialTheme.typography.labelSmall,
                                color = HudCyan,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "Round-Robin Auto-Failover",
                                style = MaterialTheme.typography.labelSmall,
                                color = HudTextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }

                    // Slots 1 to 19 List
                    val defaultSlots = slots.drop(1)
                    items(defaultSlots, key = { it.slotIndex }) { slot ->
                        val isCurrentActive = (slot.slotIndex == activeIndex)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isCurrentActive) HudCardBg else HudSurface,
                            border = BorderStroke(1.dp, if (isCurrentActive) HudCyan else HudBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("slot_card_${slot.slotIndex}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = slot.label,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            color = HudTextPrimary
                                        )
                                        if (isCurrentActive) {
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = HudCyan.copy(alpha = 0.2f),
                                                border = BorderStroke(1.dp, HudCyan)
                                            ) {
                                                Text(
                                                    text = "SERVING",
                                                    color = HudCyan,
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    fontFamily = FontFamily.Monospace,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }

                                    Text(
                                        text = "Key: ${slot.getMaskedKey()} • Requests Today: ${slot.requestsToday} • Errors: ${slot.errorCount}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = HudTextDim,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 9.sp
                                    )
                                }

                                // Status Badge
                                val statusBadgeColor = when (slot.status) {
                                    KeySlotStatus.ACTIVE -> HudEmerald
                                    KeySlotStatus.COOLING_DOWN -> HudAmber
                                    KeySlotStatus.EXHAUSTED -> HudMagenta
                                    KeySlotStatus.INVALID -> HudMagenta
                                    KeySlotStatus.NOT_CONFIGURED -> HudTextDim
                                }
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = statusBadgeColor.copy(alpha = 0.15f),
                                    border = BorderStroke(1.dp, statusBadgeColor.copy(alpha = 0.5f))
                                ) {
                                    Text(
                                        text = slot.status.name,
                                        color = statusBadgeColor,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Auto-failover and reset description note
                    item {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = HudCardBg,
                            border = BorderStroke(1.dp, HudBorder.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Security,
                                        contentDescription = null,
                                        tint = HudCyan,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "ZERO-DELAY FAILOVER ARCHITECTURE",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = HudCyan,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 9.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "If Slot 0 encounters HTTP 429 quota exhaustion or timeouts, Muskan rotates instantly (<200ms) to Slots 1-19 in Round-Robin order without voice speech interruption. All counters and exhaustion states auto-refresh daily at 00:00 AM.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = HudTextSecondary,
                                    fontSize = 9.sp,
                                    lineHeight = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
