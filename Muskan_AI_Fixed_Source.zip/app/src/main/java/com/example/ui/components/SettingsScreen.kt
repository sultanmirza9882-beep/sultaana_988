package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.VoiceUiState
import com.example.engine.llm.QwenOfflineModelManager
import com.example.ui.theme.HudBorder
import com.example.ui.theme.HudBorderBright
import com.example.ui.theme.HudCardBg
import com.example.ui.theme.HudCyan
import com.example.ui.theme.HudEmerald
import com.example.ui.theme.HudMagenta
import com.example.ui.theme.HudPurple
import com.example.ui.theme.HudSurface
import com.example.ui.theme.HudSurfaceVariant
import com.example.ui.theme.HudTextDim
import com.example.ui.theme.HudTextPrimary
import com.example.ui.theme.HudTextSecondary
import com.example.ui.theme.HudVoid
import java.util.Locale

/**
 * Dedicated Full-Screen Settings Interface for Muskan Voice Assistant.
 * Allows Sultan Mirza to:
 *  1. Dual-Brain AI Architecture: Toggle Force Offline Brain (Qwen3 1.7B) vs Dual-Brain Auto Mode.
 *  2. Qwen3 On-Device Model Manager: Download, pause, resume, and scan 1.7B GGUF model (~1.28 GB).
 *  3. Toggle Wake-Word Detection ("Muskan") and view listening state.
 *  4. Finely adjust Voice Speed (Speech Rate) preferences with interactive slider and quick presets.
 *  5. Finely adjust Voice Pitch (Tone & Timber) preferences with interactive slider and quick presets.
 *  6. Test live speech synthesis output immediately with adjusted parameters.
 *  7. Select tuned conversational voice presets (Natural Hinglish, Warm & Gentle, Expressive & Fast).
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    uiState: VoiceUiState,
    onBack: () -> Unit,
    onToggleWakeWord: () -> Unit,
    onUpdateSpeechRate: (Float) -> Unit,
    onUpdateSpeechPitch: (Float) -> Unit,
    onSetVoicePreset: (String) -> Unit,
    onTestVoice: () -> Unit,
    onResetVoiceDefaults: () -> Unit,
    onToggleMute: () -> Unit = {},
    onToggleForceOfflineBrain: () -> Unit = {},
    onStartQwenDownload: () -> Unit = {},
    onPauseQwenDownload: () -> Unit = {},
    onScanQwenModel: () -> Unit = {},
    onToggleThinkingMode: () -> Unit = {},
    onOpenPermanentMemory: () -> Unit = {}
) {
    BackHandler { onBack() }

    val qwenState by QwenOfflineModelManager.state.collectAsState()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("settings_screen"),
        containerColor = HudVoid,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(listOf(HudCyan, HudPurple))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Settings & Voice",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = HudTextPrimary
                            )
                            Text(
                                text = "Dual-Brain, wake-word, speed & pitch calibration",
                                style = MaterialTheme.typography.labelSmall,
                                color = HudTextSecondary
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("settings_screen_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Navigate Back",
                            tint = HudCyan
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onResetVoiceDefaults,
                        modifier = Modifier.testTag("settings_screen_reset_top_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset to Defaults",
                            tint = HudTextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = HudVoid
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 12.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Status Overview Banner
            StatusOverviewBanner(uiState = uiState)

            // Section 1: Dual-Brain AI Architecture
            DualBrainCard(
                uiState = uiState,
                qwenState = qwenState,
                onToggleForceOffline = onToggleForceOfflineBrain
            )

            // Section 2: Qwen3 1.7B On-Device Model Manager
            QwenModelManagerCard(
                qwenState = qwenState,
                onStartDownload = onStartQwenDownload,
                onPauseDownload = onPauseQwenDownload,
                onScanModel = onScanQwenModel,
                onToggleThinking = onToggleThinkingMode
            )

            // Section 3: Permanent Memory & Workflows
            PermanentMemoryCard(
                onOpenPermanentMemory = onOpenPermanentMemory
            )

            // Section 4: Wake-Word Detection
            WakeWordCard(
                uiState = uiState,
                onToggleWakeWord = onToggleWakeWord
            )

            // Section 4: Voice Speed (Speech Rate) Preference
            VoiceSpeedCard(
                speedRate = uiState.speechRate,
                onSpeedChange = onUpdateSpeechRate
            )

            // Section 5: Voice Pitch Preference
            VoicePitchCard(
                pitch = uiState.speechPitch,
                onPitchChange = onUpdateSpeechPitch
            )

            // Section 6: Live Audio Preview & Reset
            VoicePreviewCard(
                uiState = uiState,
                onTestVoice = onTestVoice,
                onResetDefaults = onResetVoiceDefaults
            )

            // Section 7: Conversational Voice Presets
            VoicePresetsCard(
                currentPreset = uiState.voicePresetName,
                onPresetSelect = onSetVoicePreset
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun StatusOverviewBanner(uiState: VoiceUiState) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = HudCardBg),
        border = BorderStroke(1.dp, HudBorderBright.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "ACTIVE CALIBRATION",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = HudCyan,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusPill(
                    label = "CALIBRATION",
                    value = "MUSKAN 1.0x",
                    color = HudCyan
                )
                StatusPill(
                    label = "CADENCE",
                    value = String.format(Locale.US, "%.2fx", uiState.speechRate),
                    color = HudEmerald
                )
                StatusPill(
                    label = "TONE",
                    value = String.format(Locale.US, "%.2fx", uiState.speechPitch),
                    color = HudPurple
                )
                StatusPill(
                    label = "BRAIN",
                    value = if (uiState.isOfflineBrainForced) "OFFLINE" else "DUAL AUTO",
                    color = if (uiState.isOfflineBrainForced) HudEmerald else HudCyan
                )
            }
        }
    }
}

@Composable
private fun DualBrainCard(
    uiState: VoiceUiState,
    qwenState: QwenOfflineModelManager.OfflineModelState,
    onToggleForceOffline: () -> Unit
) {
    val isOfflineForced = uiState.isOfflineBrainForced
    val borderColor = if (isOfflineForced) HudEmerald.copy(alpha = 0.5f) else HudCyan.copy(alpha = 0.35f)

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = HudCardBg),
        border = BorderStroke(1.dp, borderColor),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dual_brain_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                if (isOfflineForced) HudEmerald.copy(alpha = 0.2f) else HudCyan.copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isOfflineForced) Icons.Default.CloudOff else Icons.Default.Psychology,
                            contentDescription = null,
                            tint = if (isOfflineForced) HudEmerald else HudCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Dual-Brain AI Architecture",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = HudTextPrimary
                        )
                        Text(
                            text = if (isOfflineForced) {
                                "100% On-Device Offline Brain (Zero Cloud)"
                            } else {
                                "Hybrid Auto (Gemini Cloud + Qwen3 Offline)"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isOfflineForced) HudEmerald else HudCyan
                        )
                    }
                }

                Switch(
                    checked = isOfflineForced,
                    onCheckedChange = { onToggleForceOffline() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = HudEmerald,
                        uncheckedThumbColor = HudTextDim,
                        uncheckedTrackColor = HudSurfaceVariant
                    ),
                    modifier = Modifier.testTag("settings_force_offline_switch")
                )
            }

            HorizontalDivider(color = HudBorder.copy(alpha = 0.5f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isOfflineForced) HudEmerald else HudCyan)
                )
                Text(
                    text = if (isOfflineForced) {
                        "Active Mode: Force Offline ON • No API Keys or Internet required"
                    } else {
                        "Active Mode: Auto Failover (<300ms) • Cloud primary with on-device safety net"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isOfflineForced) HudEmerald else HudCyan,
                    fontWeight = FontWeight.Medium
                )
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = HudSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "ZERO-DELAY FAILOVER ARCHITECTURE:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = HudCyan
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "In Auto mode, Muskan consults Gemini 2.0/2.5 Flash for multimodal live reasoning. If network drops, timeout occurs, or HTTP 429 quota exhaustion strikes, Muskan switches to Qwen3 1.7B in <300ms without user interruption.",
                        style = MaterialTheme.typography.bodySmall,
                        color = HudTextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun QwenModelManagerCard(
    qwenState: QwenOfflineModelManager.OfflineModelState,
    onStartDownload: () -> Unit,
    onPauseDownload: () -> Unit,
    onScanModel: () -> Unit,
    onToggleThinking: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = HudCardBg),
        border = BorderStroke(1.dp, if (qwenState.isDownloaded) HudEmerald.copy(alpha = 0.4f) else HudBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("qwen_model_manager_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                if (qwenState.isDownloaded) HudEmerald.copy(alpha = 0.2f) else HudPurple.copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Memory,
                            contentDescription = null,
                            tint = if (qwenState.isDownloaded) HudEmerald else HudPurple,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Qwen3 1.7B On-Device Brain",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = HudTextPrimary
                        )
                        Text(
                            text = "Snapdragon 4 Gen 2 • 8 GB RAM • 4-bit GGUF",
                            style = MaterialTheme.typography.bodySmall,
                            color = HudTextSecondary
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (qwenState.isDownloaded) HudEmerald.copy(alpha = 0.15f) else HudPurple.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, if (qwenState.isDownloaded) HudEmerald.copy(alpha = 0.4f) else HudPurple.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = if (qwenState.isDownloaded) "READY" else if (qwenState.isDownloading) "DOWNLOADING" else "AVAILABLE",
                        color = if (qwenState.isDownloaded) HudEmerald else if (qwenState.isDownloading) HudCyan else HudPurple,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Status details
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = HudSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "STATUS & SPECIFICATIONS:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = HudCyan
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = qwenState.statusMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = HudTextSecondary
                    )
                }
            }

            // Download Progress Bar if downloading or partially downloaded
            if (qwenState.isDownloading || (qwenState.downloadProgress > 0f && !qwenState.isDownloaded)) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    LinearProgressIndicator(
                        progress = { qwenState.downloadProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = HudCyan,
                        trackColor = HudSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${(qwenState.downloadProgress * 100).toInt()}% downloaded",
                            fontSize = 11.sp,
                            color = HudCyan,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${qwenState.downloadedBytes / (1024 * 1024)} MB / ${qwenState.totalBytes / (1024 * 1024)} MB",
                            fontSize = 11.sp,
                            color = HudTextDim
                        )
                    }
                }
            }

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (qwenState.isDownloading) {
                    Button(
                        onClick = onPauseDownload,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = HudMagenta,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("qwen_pause_download_button")
                    ) {
                        Icon(Icons.Default.Pause, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Pause Download", fontWeight = FontWeight.Bold)
                    }
                } else if (!qwenState.isDownloaded) {
                    Button(
                        onClick = onStartDownload,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = HudCyan,
                            contentColor = Color.Black
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("qwen_start_download_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            if (qwenState.downloadProgress > 0f) "Resume Download" else "Download Model (~1.28 GB)",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                OutlinedButton(
                    onClick = onScanModel,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, HudBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = HudTextSecondary
                    ),
                    modifier = Modifier.testTag("qwen_scan_model_button")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Scan Storage")
                }
            }

            HorizontalDivider(color = HudBorder.copy(alpha = 0.5f))

            // Thinking Mode Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Chain-of-Thought Reasoning (<think>)",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = HudTextPrimary
                    )
                    Text(
                        text = "Allows Qwen3 to reason step-by-step internally before synthesizing the final response.",
                        style = MaterialTheme.typography.bodySmall,
                        color = HudTextSecondary
                    )
                }
                Switch(
                    checked = qwenState.isThinkingModeEnabled,
                    onCheckedChange = { onToggleThinking() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = HudPurple,
                        uncheckedThumbColor = HudTextDim,
                        uncheckedTrackColor = HudSurfaceVariant
                    ),
                    modifier = Modifier.testTag("qwen_thinking_mode_switch")
                )
            }
        }
    }
}

@Composable
private fun StatusPill(label: String, value: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.35f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = color.copy(alpha = 0.9f)
            )
            Text(
                text = value,
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
        }
    }
}

@Composable
private fun WakeWordCard(
    uiState: VoiceUiState,
    onToggleWakeWord: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = HudCardBg),
        border = BorderStroke(1.dp, if (uiState.isWakeWordEnabled) HudEmerald.copy(alpha = 0.4f) else HudBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (uiState.isWakeWordEnabled) HudEmerald.copy(alpha = 0.2f) else HudSurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Hearing,
                            contentDescription = null,
                            tint = if (uiState.isWakeWordEnabled) HudEmerald else HudTextDim,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Wake-Word Detection",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = HudTextPrimary
                        )
                        Text(
                            text = "Trigger phrase: 'Muskan' or 'Hey Muskan'",
                            style = MaterialTheme.typography.bodySmall,
                            color = HudTextSecondary
                        )
                    }
                }

                Switch(
                    checked = uiState.isWakeWordEnabled,
                    onCheckedChange = { onToggleWakeWord() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = HudEmerald,
                        uncheckedThumbColor = HudTextDim,
                        uncheckedTrackColor = HudSurfaceVariant
                    ),
                    modifier = Modifier.testTag("wake_word_detection_switch")
                )
            }

            HorizontalDivider(color = HudBorder.copy(alpha = 0.5f))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (uiState.isWakeWordEnabled) HudEmerald else HudMagenta)
                )
                Text(
                    text = if (uiState.isWakeWordEnabled) {
                        "Status: Always listening in background • Hands-free active"
                    } else {
                        "Status: Wake word paused • Tap microphone icon on screen to speak"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (uiState.isWakeWordEnabled) HudEmerald else HudTextSecondary
                )
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = HudSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "HOW IT WORKS:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = HudCyan
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Muskan runs continuous acoustic recognition. Saying 'Muskan' activates a 5-minute continuous hands-free session with barge-in interruption.",
                        style = MaterialTheme.typography.bodySmall,
                        color = HudTextSecondary
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun VoiceSpeedCard(
    speedRate: Float,
    onSpeedChange: (Float) -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = HudCardBg),
        border = BorderStroke(1.dp, HudBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(HudCyan.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = HudCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Voice Speed (Rate)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = HudTextPrimary
                        )
                        Text(
                            text = getSpeedDescription(speedRate),
                            style = MaterialTheme.typography.bodySmall,
                            color = HudCyan
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = HudCyan.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, HudCyan.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = String.format(Locale.US, "%.2fx", speedRate),
                        color = HudCyan,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Interactive M3 Slider
            Slider(
                value = speedRate.coerceIn(0.5f, 2.0f),
                onValueChange = { onSpeedChange(it) },
                valueRange = 0.5f..2.0f,
                steps = 29, // 0.05 increments
                colors = SliderDefaults.colors(
                    thumbColor = HudCyan,
                    activeTrackColor = HudCyan,
                    inactiveTrackColor = HudSurfaceVariant
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("voice_speed_slider")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("0.5x Slow", fontSize = 11.sp, color = HudTextDim)
                Text("1.00x Normal", fontSize = 11.sp, color = HudTextSecondary)
                Text("2.0x Fast", fontSize = 11.sp, color = HudTextDim)
            }

            // Quick Speed Preset Chips
            Text(
                text = "Quick Presets:",
                style = MaterialTheme.typography.labelSmall,
                color = HudTextSecondary,
                fontWeight = FontWeight.SemiBold
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val speedPresets = listOf(
                    0.85f to "0.85x Slow",
                    1.00f to "1.00x Standard",
                    1.05f to "1.05x Natural",
                    1.25f to "1.25x Fast",
                    1.50f to "1.50x Rapid"
                )

                speedPresets.forEach { (rateVal, label) ->
                    val isSelected = kotlin.math.abs(speedRate - rateVal) < 0.03f
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSpeedChange(rateVal) },
                        label = { Text(label, fontSize = 12.sp) },
                        leadingIcon = if (isSelected) {
                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = HudCyan.copy(alpha = 0.25f),
                            selectedLabelColor = HudCyan,
                            containerColor = HudSurface,
                            labelColor = HudTextSecondary
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) HudCyan else HudBorder
                        )
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun VoicePitchCard(
    pitch: Float,
    onPitchChange: (Float) -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = HudCardBg),
        border = BorderStroke(1.dp, HudBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(HudPurple.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = HudPurple,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Voice Pitch (Tone)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = HudTextPrimary
                        )
                        Text(
                            text = getPitchDescription(pitch),
                            style = MaterialTheme.typography.bodySmall,
                            color = HudPurple
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = HudPurple.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, HudPurple.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = String.format(Locale.US, "%.2fx", pitch),
                        color = HudPurple,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Interactive M3 Slider
            Slider(
                value = pitch.coerceIn(0.5f, 2.0f),
                onValueChange = { onPitchChange(it) },
                valueRange = 0.5f..2.0f,
                steps = 29, // 0.05 increments
                colors = SliderDefaults.colors(
                    thumbColor = HudPurple,
                    activeTrackColor = HudPurple,
                    inactiveTrackColor = HudSurfaceVariant
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("voice_pitch_slider")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("0.5x Deep", fontSize = 11.sp, color = HudTextDim)
                Text("1.02x Calibrated", fontSize = 11.sp, color = HudTextSecondary)
                Text("2.0x High", fontSize = 11.sp, color = HudTextDim)
            }

            // Quick Pitch Preset Chips
            Text(
                text = "Quick Presets:",
                style = MaterialTheme.typography.labelSmall,
                color = HudTextSecondary,
                fontWeight = FontWeight.SemiBold
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val pitchPresets = listOf(
                    0.85f to "0.85x Deeper",
                    1.02f to "1.02x Calibrated",
                    1.15f to "1.15x Sweet Tone",
                    1.28f to "1.28x Youthful",
                    1.40f to "1.40x High Tone"
                )

                pitchPresets.forEach { (pitchVal, label) ->
                    val isSelected = kotlin.math.abs(pitch - pitchVal) < 0.03f
                    FilterChip(
                        selected = isSelected,
                        onClick = { onPitchChange(pitchVal) },
                        label = { Text(label, fontSize = 12.sp) },
                        leadingIcon = if (isSelected) {
                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = HudPurple.copy(alpha = 0.25f),
                            selectedLabelColor = HudPurple,
                            containerColor = HudSurface,
                            labelColor = HudTextSecondary
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) HudPurple else HudBorder
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun VoicePreviewCard(
    uiState: VoiceUiState,
    onTestVoice: () -> Unit,
    onResetDefaults: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = HudCardBg),
        border = BorderStroke(1.dp, HudBorderBright.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                    contentDescription = null,
                    tint = HudEmerald,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "Live Speech Output Preview",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = HudTextPrimary
                )
            }

            Text(
                text = "Hear how Muskan sounds with your custom speed (${String.format(Locale.US, "%.2fx", uiState.speechRate)}) and pitch (${String.format(Locale.US, "%.2fx", uiState.speechPitch)}) settings in real time.",
                style = MaterialTheme.typography.bodySmall,
                color = HudTextSecondary
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onTestVoice,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = HudCyan,
                        contentColor = Color.Black
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("settings_test_voice_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Test Voice", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onResetDefaults,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, HudBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = HudTextSecondary
                    ),
                    modifier = Modifier.testTag("settings_reset_defaults_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reset")
                }
            }
        }
    }
}

@Composable
private fun VoicePresetsCard(
    currentPreset: String,
    onPresetSelect: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = HudCardBg),
        border = BorderStroke(1.dp, HudBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = HudCyan,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "Calibrated Voice Profiles",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = HudTextPrimary
                )
            }

            val presets = listOf(
                Triple("Muskan Voice Calibration (Rate: 1.0x, Pitch: 1.0x)", "1.00x Speed • 1.00x Pitch", "Muskan vocal calibration: neutral, articulate cadence and authoritative tone."),
                Triple("Natural Hinglish (Recommended)", "1.00x Speed • 1.00x Pitch", "Fluent Hinglish, Hindi, and Indian English with standard cadence."),
                Triple("Warm & Gentle", "1.00x Speed • 1.00x Pitch", "Softer, calm cadence ideal for relaxed interactions.")
            )

            presets.forEach { (name, stats, desc) ->
                val isSelected = currentPreset == name
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) HudCyan.copy(alpha = 0.12f) else HudSurface,
                    border = BorderStroke(1.dp, if (isSelected) HudCyan else HudBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPresetSelect(name) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) HudCyan else HudTextPrimary
                                )
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = HudSurfaceVariant
                                ) {
                                    Text(
                                        text = stats,
                                        fontSize = 10.sp,
                                        color = HudTextSecondary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = desc,
                                style = MaterialTheme.typography.bodySmall,
                                color = HudTextSecondary
                            )
                        }
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Active preset",
                                tint = HudCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun getSpeedDescription(rate: Float): String {
    return when {
        rate < 0.85f -> "Slow & Relaxed Pacing"
        rate in 0.85f..1.15f -> "Natural Conversational Pacing"
        rate in 1.15f..1.45f -> "Brisk & Energetic Pacing"
        else -> "Fast / High-Tempo Pacing"
    }
}

private fun getPitchDescription(pitch: Float): String {
    return when {
        pitch < 0.90f -> "Deep, Resonant Tone"
        pitch in 0.90f..1.15f -> "Sweet, Natural Feminine Tone"
        pitch in 1.15f..1.35f -> "Youthful, Bright Tone"
        else -> "High-Frequency Tone"
    }
}

@Composable
private fun PermanentMemoryCard(
    onOpenPermanentMemory: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = HudCardBg),
        border = BorderStroke(1.dp, HudPurple.copy(alpha = 0.35f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("permanent_memory_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(HudPurple.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = HudPurple,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Permanent Memory & Workflows",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = HudTextPrimary
                    )
                    Text(
                        text = "Learned facts, user preferences & multi-step routines",
                        style = MaterialTheme.typography.bodySmall,
                        color = HudTextSecondary
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = HudSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Muskan automatically remembers your preferences ('Mera naam Sultan Mirza hai', 'Mujhe coffee pasand hai') and voice-taught routines ('Jab main bolun Good Morning, toh WhatsApp kholo').",
                    style = MaterialTheme.typography.bodySmall,
                    color = HudTextSecondary,
                    modifier = Modifier.padding(10.dp)
                )
            }

            Button(
                onClick = onOpenPermanentMemory,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = HudPurple,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("open_permanent_memory_button")
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Manage Memories & Workflows", fontWeight = FontWeight.Bold)
            }
        }
    }
}

