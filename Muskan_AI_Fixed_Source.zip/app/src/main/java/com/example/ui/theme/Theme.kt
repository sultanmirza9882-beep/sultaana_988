package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Futuristic Sci-Fi Dark HUD Color Scheme
private val SciFiHudColorScheme = darkColorScheme(
    primary = HudCyan,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF003840),
    onPrimaryContainer = HudCyan,

    secondary = HudPurple,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF3B0764),
    onSecondaryContainer = HudPurple,

    tertiary = HudMagenta,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFF4C0519),
    onTertiaryContainer = HudMagenta,

    background = HudVoid,
    onBackground = HudTextPrimary,

    surface = HudSurface,
    onSurface = HudTextPrimary,
    surfaceVariant = HudSurfaceVariant,
    onSurfaceVariant = HudTextSecondary,

    outline = HudBorder,
    outlineVariant = HudBorderBright,
    error = HudMagenta,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SciFiHudColorScheme,
        typography = Typography,
        content = content
    )
}
