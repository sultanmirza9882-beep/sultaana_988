package com.example.ui.components

import android.content.Context
import android.os.PowerManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BatterySaver
import androidx.compose.material.icons.filled.BubbleChart
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import java.util.Locale
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import com.example.ui.controller.MuskanUIController
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material.icons.filled.Speed
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import com.example.ui.theme.AccentLightingManager
import com.example.ui.theme.AccentLightingTheme
import com.example.engine.network.NetworkDiagnosticsEngine
import com.example.engine.network.NetworkHealthStatus
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.VoiceUiState
import com.example.service.FloatingBubbleService
import com.example.service.MuskanAccessibilityService

/**
 * Structured Settings Sheet categorized with 4 expandable sections:
 *  1. Voice & Wake Word
 *  2. Accessibility & Phone Automation
 *  3. Overlay & Floating Widgets
 *  4. Gaming & Do-Not-Disturb Mode
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsBottomSheet(
    uiState: VoiceUiState,
    context: Context,
    onDismiss: () -> Unit,
    onToggleWakeWord: () -> Unit,
    onToggleMute: () -> Unit,
    onSetVoicePreset: (String) -> Unit,
    onToggleFloatingBubble: () -> Unit,
    onOpenOverlaySettings: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onToggleGamingMode: () -> Unit,
    onOpenBatteryTutorial: () -> Unit,
    onToggleVoiceBiometrics: () -> Unit = {},
    onToggleNoiseSuppression: () -> Unit = {},
    onOpenVoiceEnrollment: () -> Unit = {},
    onOpenApiManager: () -> Unit = {},
    onOpenMasterDashboard: () -> Unit = {},
    onUpdateSpeechRate: (Float) -> Unit = {},
    onUpdateSpeechPitch: (Float) -> Unit = {},
    onTestVoice: () -> Unit = {},
    onResetVoiceDefaults: () -> Unit = {}
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Expandable section states - defaulted with Voice, Biometrics and Accessibility open
    var voiceSectionExpanded by remember { mutableStateOf(true) }
    var biometricsSectionExpanded by remember { mutableStateOf(true) }
    var apiSectionExpanded by remember { mutableStateOf(true) }
    var accentSectionExpanded by remember { mutableStateOf(false) }
    var networkSectionExpanded by remember { mutableStateOf(false) }
    var uiControllerSectionExpanded by remember { mutableStateOf(false) }
    var accessibilitySectionExpanded by remember { mutableStateOf(false) }
    var overlaySectionExpanded by remember { mutableStateOf(false) }
    var gamingSectionExpanded by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()
    val accentTheme by AccentLightingManager.currentTheme.collectAsState()
    val networkReport by NetworkDiagnosticsEngine.reportFlow.collectAsState()
    val uiContainers by MuskanUIController.containersFlow.collectAsState()
    val uiComponentCount by MuskanUIController.activeComponentCount.collectAsState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.testTag("structured_settings_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 24.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.primary,
                                        Color(0xFF818CF8)
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "Settings",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Customize Muskan assistant",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("settings_close_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close settings",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
            )

            // Scrollable Settings Sections
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Section 1: Voice & Wake Word
                ExpandableSettingsCard(
                    title = "Voice & Wake Word",
                    subtitle = "Wake word 'Muskan', speech synthesis & mute",
                    icon = Icons.Default.Hearing,
                    isExpanded = voiceSectionExpanded,
                    onToggle = { voiceSectionExpanded = !voiceSectionExpanded }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        // Wake Word Detection Toggle
                        SettingToggleRow(
                            title = "Hands-Free Wake Word",
                            subtitle = "Say 'Muskan' to activate anytime without touching phone",
                            isChecked = uiState.isWakeWordEnabled,
                            onCheckedChange = { onToggleWakeWord() },
                            tag = "setting_wake_word_switch"
                        )

                        // Voice Mute Toggle
                        SettingToggleRow(
                            title = "Mute Muskan Voice",
                            subtitle = "Say 'Chup' or mute to stop voice responses",
                            isChecked = uiState.isMuted,
                            onCheckedChange = { onToggleMute() },
                            tag = "setting_mute_switch"
                        )

                        // Voice Speed Slider
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Voice Speed (Speech Rate)",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = String.format(Locale.US, "%.2fx", uiState.speechRate),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Slider(
                                value = uiState.speechRate.coerceIn(0.5f, 2.0f),
                                onValueChange = onUpdateSpeechRate,
                                valueRange = 0.5f..2.0f,
                                steps = 29,
                                modifier = Modifier.testTag("sheet_voice_speed_slider")
                            )
                        }

                        // Voice Pitch Slider
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Voice Pitch (Tone)",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = String.format(Locale.US, "%.2fx", uiState.speechPitch),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Slider(
                                value = uiState.speechPitch.coerceIn(0.5f, 2.0f),
                                onValueChange = onUpdateSpeechPitch,
                                valueRange = 0.5f..2.0f,
                                steps = 29,
                                modifier = Modifier.testTag("sheet_voice_pitch_slider")
                            )
                        }

                        // Test Voice Button & Reset Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onTestVoice,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("sheet_test_voice_button")
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Test Voice")
                            }

                            OutlinedButton(
                                onClick = onResetVoiceDefaults,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("sheet_reset_voice_button")
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reset")
                            }
                        }

                        // Voice Presets
                        Text(
                            text = "Conversational Voice Preset:",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 4.dp)
                        )

                        val presets = listOf(
                            "Muskan Voice Calibration (Rate: 1.0x, Pitch: 1.0x)" to "Muskan vocal calibration: neutral cadence and authoritative tone",
                            "Natural Hinglish (Recommended)" to "Fluent Hinglish, Hindi & English neural cadence",
                            "Warm & Gentle" to "Softer, calm cadence ideal for relaxed interactions"
                        )

                        presets.forEach { (presetName, desc) ->
                            val isSelected = uiState.voicePresetName == presetName
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) {
                                        MaterialTheme.colorScheme.primaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.surface
                                    }
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSetVoicePreset(presetName) }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = presetName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = desc,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = "Active preset",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Battery optimization tutorial shortcut
                        OutlinedButton(
                            onClick = onOpenBatteryTutorial,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("setting_battery_tutorial_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.BatterySaver,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Background Battery Optimization Guide")
                        }
                    }
                }

                // Section: Voice Biometrics & Ambient Noise Cancellation
                ExpandableSettingsCard(
                    title = "Voice Biometrics & Noise Cancellation",
                    subtitle = "Sultan Mirza Voice Match (85% Lock) • RNNoise DSP Filter",
                    icon = Icons.Default.Shield,
                    isExpanded = biometricsSectionExpanded,
                    onToggle = { biometricsSectionExpanded = !biometricsSectionExpanded }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SettingToggleRow(
                            title = "Sultan Mirza Voice Match Lock",
                            subtitle = "Strict acoustic verification: only Sultan's voice triggers Muskan. Secondary talkers & crowd discarded with 0 latency.",
                            isChecked = uiState.isVoiceBiometricsActive,
                            onCheckedChange = { onToggleVoiceBiometrics() },
                            tag = "setting_biometrics_switch"
                        )

                        SettingToggleRow(
                            title = "Environmental Noise Cancellation (DSP)",
                            subtitle = "80Hz-3800Hz Bandpass & Spectral Subtraction: neutralizes traffic rumble, auto-rickshaws, and sudden transient clinks.",
                            isChecked = uiState.isNoiseSuppressionActive,
                            onCheckedChange = { onToggleNoiseSuppression() },
                            tag = "setting_noise_suppression_switch"
                        )

                        // Status info card
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Cryptographic Voiceprint: Sultan Mirza",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "128-D Acoustic Mel-Filterbank & Pitch Fingerprint • 85% Cosine Threshold",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFF059669).copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "LOCKED • ${(uiState.biometricConfidenceScore * 100).toInt()}%",
                                        color = Color(0xFF10B981),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        // Voice Enrollment Button
                        OutlinedButton(
                            onClick = onOpenVoiceEnrollment,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("re_enroll_voice_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Re-Enroll Voice Profile (4 Prompts)")
                        }
                    }
                }

                // Section: API Keys & AI Model
                ExpandableSettingsCard(
                    title = "API Management & Credentials",
                    subtitle = "Active: ${uiState.activeApiName} • Multi-API Failover",
                    icon = Icons.Default.AutoAwesome,
                    isExpanded = apiSectionExpanded,
                    onToggle = { apiSectionExpanded = !apiSectionExpanded }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Current Active API",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = uiState.activeApiName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (uiState.activeApiStatus == "VERIFIED") Color(0xFF059669).copy(alpha = 0.2f) else Color(0xFFE11D48).copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = uiState.activeApiStatus,
                                    color = if (uiState.activeApiStatus == "VERIFIED") Color(0xFF10B981) else Color(0xFFF43F5E),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Text(
                            text = "Manage multiple API keys (Gemini & OpenAI), test live connections, set active API, or return to default anytime.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedButton(
                            onClick = onOpenApiManager,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("open_api_manager_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Open API Key Manager (Add / Verify / Switch)")
                        }
                    }
                }

                // Section 2: Accessibility & Phone Automation
                ExpandableSettingsCard(
                    title = "Accessibility & Automation",
                    subtitle = "Explicit voice actions: Home, Back, Apps, Typing",
                    icon = Icons.Default.Accessibility,
                    isExpanded = accessibilitySectionExpanded,
                    onToggle = { accessibilitySectionExpanded = !accessibilitySectionExpanded }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Accessibility Service Status",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (uiState.isAccessibilityEnabled) {
                                        "Active: Muskan can navigate and open apps on explicit voice command."
                                    } else {
                                        "Inactive: Enable Muskan in Android Accessibility settings."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (uiState.isAccessibilityEnabled) Color(0xFF059669) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Button(
                                onClick = onOpenAccessibilitySettings,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (uiState.isAccessibilityEnabled) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primary,
                                    contentColor = if (uiState.isAccessibilityEnabled) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onPrimary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("settings_open_accessibility_btn")
                            ) {
                                Text(if (uiState.isAccessibilityEnabled) "Configured" else "Enable")
                            }
                        }

                        Text(
                            text = "Explicit Intent Rule: Muskan ONLY performs clicks, typing, or opens apps on explicit command ('Muskan, open YouTube'). General questions are answered purely via voice without screen changes.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        // Always-On Screen Perception Section
                        val isPerceptionActive by com.example.automation.AlwaysOnScreenPerceptionManager.isAlwaysOnPerceptionActive.collectAsState()
                        val screenNarrative by com.example.automation.AlwaysOnScreenPerceptionManager.screenActivityNarrative.collectAsState()

                        SettingToggleRow(
                            title = "Always-On Screen Perception",
                            subtitle = "Continuously scans active display & window hierarchy every 2s for real-time visual context",
                            isChecked = isPerceptionActive,
                            onCheckedChange = { enabled ->
                                com.example.automation.AlwaysOnScreenPerceptionManager.setAlwaysOnPerceptionEnabled(enabled)
                            },
                            tag = "setting_screen_perception_switch"
                        )

                        Card(
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isPerceptionActive) Color(0xFF06B6D4).copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = if (isPerceptionActive) Color(0xFF06B6D4) else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "LIVE SCREEN NARRATIVE",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isPerceptionActive) Color(0xFF06B6D4) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = screenNarrative,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                // Section 3: Overlay & Floating Widgets
                ExpandableSettingsCard(
                    title = "Overlay & Floating Widgets",
                    subtitle = "Always-on floating bubble over other apps",
                    icon = Icons.Default.BubbleChart,
                    isExpanded = overlaySectionExpanded,
                    onToggle = { overlaySectionExpanded = !overlaySectionExpanded }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        val hasOverlayPermission = FloatingBubbleService.hasOverlayPermission(context)

                        if (!hasOverlayPermission) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Display Over Other Apps",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Permission required to display floating assistant bubble",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Button(
                                    onClick = onOpenOverlaySettings,
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text("Grant")
                                }
                            }
                        }

                        SettingToggleRow(
                            title = "Floating Assistant Bubble",
                            subtitle = "Keep Muskan accessible anywhere with drag physics & non-blocking touches",
                            isChecked = uiState.isFloatingBubbleActive,
                            enabled = hasOverlayPermission,
                            onCheckedChange = {
                                if (hasOverlayPermission) {
                                    onToggleFloatingBubble()
                                } else {
                                    onOpenOverlaySettings()
                                }
                            },
                            tag = "setting_floating_bubble_switch"
                        )

                        Text(
                            text = "Non-blocking: Uses FLAG_NOT_FOCUSABLE & FLAG_NOT_TOUCH_MODAL so game controls and gestures pass through seamlessly.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Section 4: Gaming & Do-Not-Disturb Mode
                ExpandableSettingsCard(
                    title = "Gaming & Do-Not-Disturb Mode",
                    subtitle = "Zero touch latency, edge indicator & manual override",
                    icon = Icons.Default.SportsEsports,
                    isExpanded = gamingSectionExpanded,
                    onToggle = { gamingSectionExpanded = !gamingSectionExpanded }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SettingToggleRow(
                            title = "Gaming Mode",
                            subtitle = "Minimizes overlay into edge indicator. Yields instantly to manual gaming touches.",
                            isChecked = uiState.isGamingMode,
                            onCheckedChange = { onToggleGamingMode() },
                            tag = "setting_gaming_mode_switch"
                        )

                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (uiState.isGamingMode) {
                                    Color(0xFF10B981).copy(alpha = 0.12f)
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                }
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (uiState.isGamingMode) "Active Gaming Optimizations:" else "Gaming Feature Highlights:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (uiState.isGamingMode) Color(0xFF059669) else MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "• Manual Touch Priority: Any tap on screen immediately cancels automated gestures.\n• Voice-Only Responses: Casual chat never opens apps or pauses your gameplay.\n• Long-Press Bubble: Instantly mute or pause active listening.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Section 5: Dynamic Accent Lighting
                ExpandableSettingsCard(
                    title = "Dashboard & UI Accent Lighting",
                    subtitle = "Current: ${accentTheme.displayName} • Dynamic Themes",
                    icon = Icons.Default.Tune,
                    isExpanded = accentSectionExpanded,
                    onToggle = { accentSectionExpanded = !accentSectionExpanded }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Select Accent Lighting Theme:",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )

                        AccentLightingTheme.values().forEach { theme ->
                            val isSelected = accentTheme == theme
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) theme.primaryColor.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) theme.primaryColor else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { AccentLightingManager.setAccentTheme(theme) }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(14.dp)
                                                .clip(CircleShape)
                                                .background(theme.primaryColor)
                                        )
                                        Text(
                                            text = theme.displayName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) theme.primaryColor else MaterialTheme.colorScheme.onSurface
                                        )
                                    }

                                    if (isSelected) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = theme.primaryColor.copy(alpha = 0.2f)
                                        ) {
                                            Text(
                                                text = "ACTIVE",
                                                color = theme.primaryColor,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Section 6: Direct Network Diagnostics
                ExpandableSettingsCard(
                    title = "Network Diagnostics & Probing",
                    subtitle = "Status: ${networkReport.status.label} • ${if (networkReport.pingLatencyMs > 0) "${networkReport.pingLatencyMs}ms" else "Probing ready"}",
                    icon = Icons.Default.Speed,
                    isExpanded = networkSectionExpanded,
                    onToggle = { networkSectionExpanded = !networkSectionExpanded }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Direct Network Probing",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = networkReport.diagnosticSummary,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (networkReport.status == NetworkHealthStatus.VERIFIED) Color(0xFF059669).copy(alpha = 0.2f) else Color(0xFFD97706).copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = networkReport.status.label,
                                    color = if (networkReport.status == NetworkHealthStatus.VERIFIED) Color(0xFF10B981) else Color(0xFFD97706),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    NetworkDiagnosticsEngine.runDirectDiagnostics(context)
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Run Direct Network Diagnostics Now")
                        }
                    }
                }

                // Section 7: Modular UIController & Master HUD
                ExpandableSettingsCard(
                    title = "Modular UIController & Master HUD",
                    subtitle = "${uiContainers.size} Containers Active • $uiComponentCount Dynamic Widgets",
                    icon = Icons.Default.Widgets,
                    isExpanded = uiControllerSectionExpanded,
                    onToggle = { uiControllerSectionExpanded = !uiControllerSectionExpanded }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Dynamic UIController API allows the AI agent to autonomously add, remove, and modify modular dashboard containers and components at runtime with real-time state synchronization.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Button(
                            onClick = onOpenMasterDashboard,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Widgets, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Open Master HUD & Widget Controller")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun ExpandableSettingsCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    isExpanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onToggle),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = onToggle,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "Collapse" else "Expand",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                ) {
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    content()
                }
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true,
    tag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled) { onCheckedChange(!isChecked) },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = if (enabled) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.testTag(tag)
        )
    }
}
