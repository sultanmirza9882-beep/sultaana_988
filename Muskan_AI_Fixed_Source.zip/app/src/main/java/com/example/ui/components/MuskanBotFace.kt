package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.example.AssistantState
import com.example.ui.theme.MkAmber
import com.example.ui.theme.MkCoral
import com.example.ui.theme.MkCream
import com.example.ui.theme.MkCreamDim
import com.example.ui.theme.MkInk
import com.example.ui.theme.MkInkLine
import com.example.ui.theme.MkInkRaised
import com.example.ui.theme.MkMint
import com.example.ui.theme.MkViolet
import kotlin.math.abs
import kotlin.math.sin

/**
 * Muskan's face: a friendly little robot drawn with Canvas.
 * Eyes blink, look around while thinking, widen while listening, and the mouth
 * turns into a live equalizer while she speaks.
 */
@Composable
fun MuskanBotFace(
    state: AssistantState,
    isMuted: Boolean,
    level: Float,
    modifier: Modifier = Modifier
) {
    val accent = when {
        isMuted -> MkCreamDim
        state == AssistantState.LISTENING -> MkMint
        state == AssistantState.SPEAKING -> MkCoral
        state == AssistantState.PROCESSING -> MkViolet
        state == AssistantState.ERROR -> MkCoral
        else -> MkAmber
    }

    val t = rememberInfiniteTransition(label = "muskan_bot")
    val spin by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing)),
        label = "spin"
    )
    val wave by t.animateFloat(
        initialValue = 0f, targetValue = 6.2832f,
        animationSpec = infiniteRepeatable(tween(650, easing = LinearEasing)),
        label = "wave"
    )
    val glow by t.animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse
        ),
        label = "glow"
    )
    val blink by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            keyframes {
                durationMillis = 4200
                0f at 0
                0f at 3900
                1f at 4020
                0f at 4140
                0f at 4200
            }
        ),
        label = "blink"
    )
    val look by t.animateFloat(
        initialValue = -1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse
        ),
        label = "look"
    )

    Canvas(modifier = modifier) {
        val w = size.minDimension
        val c = Offset(size.width / 2f, size.height / 2f)
        val lv = level.coerceIn(0f, 1f)

        // soft glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(accent.copy(alpha = 0.30f * glow), Color.Transparent),
                center = c, radius = w * 0.5f
            ),
            radius = w * 0.5f, center = c
        )

        // dashed orbit ring
        rotate(degrees = spin, pivot = c) {
            drawCircle(
                color = accent.copy(alpha = 0.38f),
                radius = w * 0.46f, center = c,
                style = Stroke(
                    width = w * 0.007f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(w * 0.03f, w * 0.026f))
                )
            )
        }
        // bright orbit arcs (counter rotation)
        rotate(degrees = -spin * 1.6f, pivot = c) {
            val r = w * 0.42f
            drawArc(
                color = accent, startAngle = 0f, sweepAngle = 58f, useCenter = false,
                topLeft = Offset(c.x - r, c.y - r), size = Size(r * 2, r * 2),
                style = Stroke(width = w * 0.012f, cap = StrokeCap.Round)
            )
            drawArc(
                color = accent.copy(alpha = 0.55f), startAngle = 180f, sweepAngle = 34f, useCenter = false,
                topLeft = Offset(c.x - r, c.y - r), size = Size(r * 2, r * 2),
                style = Stroke(width = w * 0.012f, cap = StrokeCap.Round)
            )
        }

        // head
        val headW = w * 0.56f
        val headH = w * 0.44f
        val headTop = c.y - headH / 2f + w * 0.035f
        val headLeft = c.x - headW / 2f
        val headCenterY = headTop + headH / 2f

        // ears
        val earW = w * 0.045f
        val earH = headH * 0.34f
        for (side in listOf(-1f, 1f)) {
            val ex = if (side < 0) headLeft - earW * 0.6f else headLeft + headW - earW * 0.4f
            drawRoundRect(
                color = accent.copy(alpha = 0.85f),
                topLeft = Offset(ex, headCenterY - earH / 2f),
                size = Size(earW, earH),
                cornerRadius = CornerRadius(earW / 2f)
            )
        }

        // antenna
        val bulbCenter = Offset(c.x, headTop - w * 0.085f)
        drawLine(
            color = accent.copy(alpha = 0.8f),
            start = Offset(c.x, headTop), end = bulbCenter,
            strokeWidth = w * 0.012f, cap = StrokeCap.Round
        )
        drawCircle(accent.copy(alpha = 0.30f * glow), radius = w * 0.045f, center = bulbCenter)
        drawCircle(accent, radius = w * 0.022f, center = bulbCenter)

        // head shell
        drawRoundRect(
            brush = Brush.verticalGradient(
                listOf(MkInkRaised, MkInkLine),
                startY = headTop, endY = headTop + headH
            ),
            topLeft = Offset(headLeft, headTop),
            size = Size(headW, headH),
            cornerRadius = CornerRadius(w * 0.13f)
        )
        drawRoundRect(
            color = accent,
            topLeft = Offset(headLeft, headTop),
            size = Size(headW, headH),
            cornerRadius = CornerRadius(w * 0.13f),
            style = Stroke(width = w * 0.011f)
        )

        // face plate
        val inset = w * 0.035f
        drawRoundRect(
            color = MkInk,
            topLeft = Offset(headLeft + inset, headTop + inset),
            size = Size(headW - inset * 2, headH - inset * 2),
            cornerRadius = CornerRadius(w * 0.10f)
        )

        // eyes
        val eyeW = headW * 0.17f
        val openBase = when {
            isMuted -> 0.18f
            state == AssistantState.LISTENING -> 1f + lv * 0.35f
            else -> 1f
        }
        val eyeH = headH * 0.27f * openBase * (1f - blink * 0.92f)
        val lookShift = if (state == AssistantState.PROCESSING && !isMuted) look * headW * 0.045f else 0f
        val eyeY = headCenterY - headH * 0.07f
        for (side in listOf(-1f, 1f)) {
            val ex = c.x + side * headW * 0.205f + lookShift
            drawRoundRect(
                color = accent.copy(alpha = 0.25f * glow),
                topLeft = Offset(ex - eyeW * 0.8f, eyeY - eyeH * 0.8f),
                size = Size(eyeW * 1.6f, eyeH * 1.6f),
                cornerRadius = CornerRadius(eyeW * 0.8f)
            )
            drawRoundRect(
                color = accent,
                topLeft = Offset(ex - eyeW / 2f, eyeY - eyeH / 2f),
                size = Size(eyeW, eyeH),
                cornerRadius = CornerRadius(eyeW / 2f)
            )
        }

        // mouth
        val mouthY = headCenterY + headH * 0.25f
        when {
            isMuted -> drawLine(
                color = MkCreamDim,
                start = Offset(c.x - headW * 0.09f, mouthY),
                end = Offset(c.x + headW * 0.09f, mouthY),
                strokeWidth = w * 0.014f, cap = StrokeCap.Round
            )
            state == AssistantState.SPEAKING -> {
                val barW = w * 0.02f
                val gap = w * 0.016f
                val total = barW * 5 + gap * 4
                for (i in 0 until 5) {
                    val h = w * 0.018f + w * 0.055f * abs(sin(wave + i * 0.9f)) * (0.45f + lv)
                    val bx = c.x - total / 2f + i * (barW + gap)
                    drawRoundRect(
                        color = MkCream,
                        topLeft = Offset(bx, mouthY - h / 2f),
                        size = Size(barW, h),
                        cornerRadius = CornerRadius(barW / 2f)
                    )
                }
            }
            else -> {
                val mw = headW * 0.22f
                val mh = headH * 0.16f
                drawArc(
                    color = MkCream, startAngle = 25f, sweepAngle = 130f, useCenter = false,
                    topLeft = Offset(c.x - mw / 2f, mouthY - mh / 2f - mh * 0.2f),
                    size = Size(mw, mh),
                    style = Stroke(width = w * 0.014f, cap = StrokeCap.Round)
                )
            }
        }
    }
}
