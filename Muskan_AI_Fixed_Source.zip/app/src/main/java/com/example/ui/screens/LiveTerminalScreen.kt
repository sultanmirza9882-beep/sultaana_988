package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.terminal.WorkspaceTerminalEngine
import com.example.ui.theme.HudBorder
import com.example.ui.theme.HudCardBg
import com.example.ui.theme.HudCyan
import com.example.ui.theme.HudEmerald
import com.example.ui.theme.HudMagenta
import com.example.ui.theme.HudPurple
import com.example.ui.theme.HudTextPrimary
import com.example.ui.theme.HudTextSecondary
import com.example.ui.theme.HudVoid
import kotlinx.coroutines.launch

@Composable
fun LiveTerminalScreen(
    context: Context,
    modifier: Modifier = Modifier
) {
    val session by WorkspaceTerminalEngine.sessionState.collectAsStateWithLifecycle()
    val coroutineScope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    var inputCommand by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(session.lines.size) {
        if (session.lines.isNotEmpty()) {
            listState.animateScrollToItem(session.lines.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF03070E))
            .imePadding()
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF06101C),
            border = BorderStroke(0.8.dp, HudBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (session.isExecuting) HudMagenta else HudEmerald)
                    )
                    Text(
                        text = "MUSKAN TERMUX SHELL // 0x7E",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = HudCyan
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (session.isExecuting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            color = HudMagenta,
                            strokeWidth = 1.5.dp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    IconButton(
                        onClick = { WorkspaceTerminalEngine.clear() },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Clear Terminal",
                            tint = HudTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF050B14))
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val chips = listOf("status", "ls", "snapshots", "verify", "help", "clear")
            chips.forEach { cmd ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF0B192A),
                    border = BorderStroke(0.8.dp, HudCyan.copy(alpha = 0.4f)),
                    modifier = Modifier.clip(RoundedCornerShape(8.dp))
                ) {
                    Text(
                        text = cmd,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = HudCyan,
                        modifier = Modifier
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                            .clickable {
                                coroutineScope.launch {
                                    WorkspaceTerminalEngine.executeCommand(context, cmd)
                                }
                            }
                    )
                }
            }
        }

        if (session.activeAgent != null || session.activeTask != null) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = HudPurple.copy(alpha = 0.1f),
                border = BorderStroke(0.5.dp, HudPurple.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "OWNER: ${session.activeAgent ?: "NONE"}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = HudPurple
                    )
                    Text(
                        text = "TASK: ${session.activeTask ?: "Standby"}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = HudTextSecondary,
                        maxLines = 1
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(session.lines, key = { it.id }) { line ->
                    val color = when (line.type) {
                        WorkspaceTerminalEngine.TerminalLineType.COMMAND -> HudCyan
                        WorkspaceTerminalEngine.TerminalLineType.SUCCESS -> HudEmerald
                        WorkspaceTerminalEngine.TerminalLineType.ERROR -> HudMagenta
                        WorkspaceTerminalEngine.TerminalLineType.AGENT_EVENT -> Color(0xFFD8B4FE)
                        WorkspaceTerminalEngine.TerminalLineType.TOOL_EVENT -> Color(0xFF93C5FD)
                        WorkspaceTerminalEngine.TerminalLineType.INFO -> Color(0xFF94A3B8)
                        WorkspaceTerminalEngine.TerminalLineType.OUTPUT -> Color(0xFFE2E8F0)
                    }

                    Text(
                        text = line.text,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = color,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF06101C),
            border = BorderStroke(1.dp, HudBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "muskan@workspace:~$",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = HudCyan
                )

                OutlinedTextField(
                    value = inputCommand,
                    onValueChange = { inputCommand = it },
                    placeholder = {
                        Text(
                            text = "type command (e.g. status, ls, snapshots, verify)",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            color = HudTextSecondary
                        )
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF040A12),
                        unfocusedContainerColor = Color(0xFF040A12),
                        focusedBorderColor = HudCyan,
                        unfocusedBorderColor = HudBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (inputCommand.isNotBlank()) {
                                val cmd = inputCommand.trim()
                                inputCommand = ""
                                focusManager.clearFocus()
                                coroutineScope.launch {
                                    WorkspaceTerminalEngine.executeCommand(context, cmd)
                                }
                            }
                        }
                    )
                )

                IconButton(
                    onClick = {
                        if (inputCommand.isNotBlank()) {
                            val cmd = inputCommand.trim()
                            inputCommand = ""
                            focusManager.clearFocus()
                            coroutineScope.launch {
                                WorkspaceTerminalEngine.executeCommand(context, cmd)
                            }
                        }
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(HudCyan)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Run Command",
                        tint = HudVoid,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
