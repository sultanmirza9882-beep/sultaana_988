package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sci-Fi Dark HUD Palette
val HudVoid = Color(0xFF040711)
val HudSurface = Color(0xFF0A101D)
val HudSurfaceVariant = Color(0xFF131D31)
val HudCardBg = Color(0xE60D1527)
val HudBorder = Color(0x3300F0FF)
val HudBorderBright = Color(0x8000F0FF)

// Cyber Neon Accents
val HudCyan = Color(0xFF00F0FF)
val HudCyanGlow = Color(0x5500F0FF)
val HudPurple = Color(0xFFA855F7)
val HudMagenta = Color(0xFFF43F5E)
val HudEmerald = Color(0xFF10B981)
val HudAmber = Color(0xFFF59E0B)

// Typography & HUD Text
val HudTextPrimary = Color(0xFFF8FAFC)
val HudTextSecondary = Color(0xFF94A3B8)
val HudTextDim = Color(0xFF64748B)

// Legacy Material3 mappings
val Purple80 = HudPurple
val PurpleGrey80 = Color(0xFFCBD5E1)
val Pink80 = HudMagenta

val Purple40 = Color(0xFF7C3AED)
val PurpleGrey40 = Color(0xFF475569)
val Pink40 = Color(0xFFE11D48)

// ---------------------------------------------------------------------------
// Muskan "Ember" palette: warm plum-ink surfaces with coral / amber / mint accents.
// ---------------------------------------------------------------------------
val MkInk = Color(0xFF120D1A)
val MkInkDeep = Color(0xFF0B0711)
val MkInkRaised = Color(0xFF1D1529)
val MkInkLine = Color(0xFF2F2342)
val MkCream = Color(0xFFFFF1E0)
val MkCreamDim = Color(0xFFB7A9C4)
val MkCoral = Color(0xFFFF6B57)
val MkAmber = Color(0xFFFFB84D)
val MkMint = Color(0xFF5EEAD4)
val MkViolet = Color(0xFFB794F6)
