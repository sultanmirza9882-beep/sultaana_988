package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.AssistantState
import com.example.VoiceUiState
import com.example.ui.components.MuskanBotFace
import com.example.ui.theme.MkAmber
import com.example.ui.theme.MkCoral
import com.example.ui.theme.MkCream
import com.example.ui.theme.MkCreamDim
import com.example.ui.theme.MkInk
import com.example.ui.theme.MkInkDeep
import com.example.ui.theme.MkInkLine
import com.example.ui.theme.MkInkRaised
import com.example.ui.theme.MkMint
import com.example.ui.theme.MkViolet

/**
 * Muskan home — "Ember" layout.
 *
 * A big animated robot face sits at the centre of the screen. Around it the layout is a bento
 * grid of colourful tiles, and a rounded command pill sits at the bottom.
 */
@Composable
fun MuskanHomeScreen(
    uiState: VoiceUiState,
    onSendMessage: (String) -> Unit,
    onMicClick: () -> Unit,
    onOpenChat: () -> Unit,
    onOpenUpload: () -> Unit,
    onOpenAiMode: () -> Unit,
    onOpenDrive: () -> Unit,
    onOpenCamera: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    var inputText by remember { mutableStateOf("") }

    val (statusText, statusColor) = when {
        uiState.isMuted -> "Mic band hai" to MkCreamDim
        uiState.state == AssistantState.LISTENING -> "Sun rahi hoon…" to MkMint
        uiState.state == AssistantState.PROCESSING -> "Soch rahi hoon…" to MkViolet
        uiState.state == AssistantState.SPEAKING -> "Bol rahi hoon…" to MkCoral
        uiState.state == AssistantState.ERROR -> "Kuch gadbad hui" to MkCoral
        uiState.isWakeWordStandby -> "Bulaiye, main yahin hoon" to MkAmber
        else -> "Tayyar hoon" to MkAmber
    }
    val faceLevel = if (uiState.state == AssistantState.SPEAKING) uiState.audioOutputLevel else uiState.audioRmsLevel

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(MkInk, MkInkDeep)))
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ---- Hero: robot face (tap = talk) ----
            MuskanBotFace(
                state = uiState.state,
                isMuted = uiState.isMuted,
                level = faceLevel,
                modifier = Modifier
                    .size(260.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onMicClick
                    )
            )

            Text(
                text = "Muskan",
                fontSize = 38.sp,
                fontWeight = FontWeight.Black,
                color = MkCream,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center
            )

            // status pill
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(statusColor.copy(alpha = 0.14f))
                    .border(1.dp, statusColor.copy(alpha = 0.45f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(statusColor))
                Text(statusText, color = statusColor, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }

            // ---- Live task card ----
            if (uiState.isAgenticTaskRunning) {
                val total = uiState.totalAgenticSteps
                val cur = uiState.currentAgenticStepIndex
                val fraction = if (total > 0) (cur.toFloat() / total.toFloat()).coerceIn(0.05f, 1f) else 0.3f
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(MkInkRaised)
                        .border(1.dp, MkViolet.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.SmartToy, contentDescription = null, tint = MkViolet, modifier = Modifier.size(18.dp))
                        Text(
                            text = uiState.currentAgenticPlanTitle ?: "Kaam chal raha hai",
                            color = MkCream, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape)
                            .background(MkInkLine)
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(fraction)
                                .fillMaxHeight()
                                .clip(CircleShape)
                                .background(Brush.horizontalGradient(listOf(MkViolet, MkCoral)))
                        )
                    }
                    Text(
                        text = (if (total > 0) "Step $cur/$total  •  " else "") +
                            (uiState.agenticCurrentStatusText ?: "Screen par kaam ho raha hai…"),
                        color = MkCreamDim, fontSize = 12.sp,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // ---- Last reply bubble ----
            if (uiState.lastResponseText.isNotBlank()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(MkCoral.copy(alpha = 0.18f))
                            .border(1.dp, MkCoral.copy(alpha = 0.6f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.SmartToy, contentDescription = null, tint = MkCoral, modifier = Modifier.size(18.dp))
                    }
                    Text(
                        text = uiState.lastResponseText,
                        color = MkCream,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        maxLines = 6,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp, 22.dp, 22.dp, 22.dp))
                            .background(MkInkRaised)
                            .padding(horizontal = 14.dp, vertical = 12.dp)
                    )
                }
            }

            // ---- Bento grid ----
            Row(
                modifier = Modifier.fillMaxWidth().height(172.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BentoTile(
                    title = if (uiState.isMuted) "Mic chalu karo" else "Bolo",
                    hint = "Awaaz se baat",
                    icon = if (uiState.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                    brush = Brush.linearGradient(listOf(MkCoral, Color(0xFFFF9A5C))),
                    onDark = false,
                    onClick = onMicClick,
                    modifier = Modifier.weight(1.15f).fillMaxHeight()
                )
                Column(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    BentoTile(
                        title = "Chat",
                        hint = "Likh kar poochho",
                        icon = Icons.Default.ChatBubble,
                        brush = Brush.linearGradient(listOf(MkViolet, Color(0xFF8B6FE0))),
                        onDark = false,
                        onClick = onOpenChat,
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    )
                    BentoTile(
                        title = "Upload",
                        hint = "Zip / APK",
                        icon = Icons.Default.Upload,
                        brush = Brush.linearGradient(listOf(MkAmber, Color(0xFFFFD27A))),
                        onDark = false,
                        onClick = onOpenUpload,
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().height(64.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MiniTile("Drive", Icons.Default.Cloud, MkMint, onOpenDrive, Modifier.weight(1f).fillMaxHeight())
                MiniTile("Camera", Icons.Default.CameraAlt, MkAmber, onOpenCamera, Modifier.weight(1f).fillMaxHeight())
                MiniTile("Voice", Icons.Default.Tune, MkViolet, onOpenAiMode, Modifier.weight(1f).fillMaxHeight())
            }
            Spacer(Modifier.height(4.dp))
        }

        // ---- Command pill ----
        val pill = RoundedCornerShape(30.dp)
        val send = {
            val msg = inputText.trim()
            if (msg.isNotEmpty()) {
                onSendMessage(msg)
                inputText = ""
                focusManager.clearFocus()
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp)
                .clip(pill)
                .background(MkInkRaised)
                .border(1.dp, MkInkLine, pill)
                .padding(start = 18.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                textStyle = TextStyle(color = MkCream, fontSize = 15.sp),
                cursorBrush = SolidColor(MkCoral),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() }),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (inputText.isEmpty()) {
                            Text("Muskan se kuch bhi kaho…", color = MkCreamDim, fontSize = 15.sp)
                        }
                        inner()
                    }
                }
            )
            val hasText = inputText.isNotBlank()
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(MkCoral, MkAmber)))
                    .clickable { if (hasText) send() else onMicClick() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (hasText) Icons.AutoMirrored.Filled.Send else Icons.Default.Mic,
                    contentDescription = if (hasText) "Send" else "Mic",
                    tint = MkInkDeep,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

@Composable
private fun BentoTile(
    title: String,
    hint: String,
    icon: ImageVector,
    brush: Brush,
    onDark: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ink = if (onDark) MkCream else MkInkDeep
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(26.dp))
            .background(brush)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(ink.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = ink, modifier = Modifier.size(20.dp))
        }
        Column {
            Text(title, color = ink, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
            Text(hint, color = ink.copy(alpha = 0.75f), fontSize = 12.sp)
        }
    }
}

@Composable
private fun MiniTile(
    label: String,
    icon: ImageVector,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier = modifier
            .clip(shape)
            .background(MkInkRaised)
            .border(1.dp, tint.copy(alpha = 0.35f), shape)
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.size(6.dp))
        Text(label, color = MkCream, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}
