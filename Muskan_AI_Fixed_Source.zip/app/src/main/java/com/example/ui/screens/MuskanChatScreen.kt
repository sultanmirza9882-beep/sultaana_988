package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.AssistantState
import com.example.MessageSender
import com.example.VoiceMessage
import com.example.VoiceUiState
import com.example.ui.theme.HudBorder
import com.example.ui.theme.HudCardBg
import com.example.ui.theme.HudCyan
import com.example.ui.theme.HudEmerald
import com.example.ui.theme.HudMagenta
import com.example.ui.theme.HudPurple
import com.example.ui.theme.HudTextPrimary
import com.example.ui.theme.HudTextSecondary
import com.example.ui.theme.HudVoid

@Composable
fun MuskanChatScreen(
    uiState: VoiceUiState,
    onSendMessage: (String) -> Unit,
    onMicClick: () -> Unit,
    onAttachmentClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(uiState.conversationHistory.size) {
        if (uiState.conversationHistory.isNotEmpty()) {
            listState.animateScrollToItem(uiState.conversationHistory.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(HudVoid)
            .imePadding()
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF091322),
            border = BorderStroke(0.5.dp, HudBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(
                                when (uiState.state) {
                                    AssistantState.SPEAKING -> HudMagenta
                                    AssistantState.LISTENING -> HudCyan
                                    AssistantState.PROCESSING -> HudPurple
                                    else -> HudEmerald
                                }
                            )
                    )
                    Text(
                        text = when (uiState.state) {
                            AssistantState.SPEAKING -> "MUSKAN SPEAKING"
                            AssistantState.LISTENING -> "MUSKAN LISTENING…"
                            AssistantState.PROCESSING -> "MUSKAN THINKING…"
                            else -> "MUSKAN READY"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = when (uiState.state) {
                            AssistantState.SPEAKING -> HudMagenta
                            AssistantState.LISTENING -> HudCyan
                            AssistantState.PROCESSING -> HudPurple
                            else -> HudEmerald
                        }
                    )
                }

                Text(
                    text = "HINDI // URDU // EN",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = HudTextSecondary
                )
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (uiState.conversationHistory.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(HudCyan.copy(alpha = 0.1f))
                            .border(1.dp, HudCyan, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = HudCyan,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Muskan",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = HudTextPrimary
                    )
                    Text(
                        text = "Ask questions, discuss project files, or describe code changes.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = HudTextSecondary,
                        modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                    )

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val suggestions = listOf(
                            "Project mein review & approval flow check karo",
                            "Imported APK ka manifest aur permissions inspect karo",
                            "Workspace snapshot aur backup status batao",
                            "Network diagnostics aur ping check karo"
                        )
                        suggestions.forEach { prompt ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = HudCardBg,
                                border = BorderStroke(1.dp, HudBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onSendMessage(prompt)
                                    }
                            ) {
                                Text(
                                    text = prompt,
                                    fontSize = 12.sp,
                                    color = HudCyan,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                                )
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(uiState.conversationHistory) { message ->
                        MessageBubble(message = message)
                    }

                    if (uiState.state == AssistantState.PROCESSING) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = HudCyan,
                                    strokeWidth = 2.dp
                                )
                                Text(
                                    text = "Muskan is coordinating specialist agents…",
                                    fontSize = 12.sp,
                                    color = HudCyan,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        if (uiState.partialTranscript.isNotBlank()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                color = HudCyan.copy(alpha = 0.12f),
                border = BorderStroke(0.8.dp, HudCyan)
            ) {
                Text(
                    text = "🎤 ${uiState.partialTranscript}",
                    modifier = Modifier.padding(8.dp),
                    fontSize = 12.sp,
                    color = HudCyan,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF07101B),
            border = BorderStroke(1.dp, HudBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onAttachmentClick,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(HudCardBg)
                        .border(1.dp, HudBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Attach or import ZIP/APK",
                        tint = HudCyan
                    )
                }

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = {
                        Text(
                            text = "Ask Muskan or request code change…",
                            fontSize = 13.sp,
                            color = HudTextSecondary
                        )
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = HudCardBg,
                        unfocusedContainerColor = HudCardBg,
                        focusedBorderColor = HudCyan,
                        unfocusedBorderColor = HudBorder,
                        focusedTextColor = HudTextPrimary,
                        unfocusedTextColor = HudTextPrimary
                    ),
                    maxLines = 4,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (inputText.isNotBlank()) {
                                onSendMessage(inputText.trim())
                                inputText = ""
                                focusManager.clearFocus()
                            }
                        }
                    )
                )

                IconButton(
                    onClick = onMicClick,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                uiState.state == AssistantState.LISTENING -> HudCyan
                                uiState.state == AssistantState.SPEAKING -> HudMagenta
                                else -> HudCardBg
                            }
                        )
                        .border(
                            1.dp,
                            if (uiState.state == AssistantState.LISTENING) HudCyan else HudBorder,
                            CircleShape
                        )
                ) {
                    Icon(
                        imageVector = when {
                            uiState.state == AssistantState.SPEAKING -> Icons.Default.Stop
                            uiState.state == AssistantState.LISTENING -> Icons.Default.GraphicEq
                            uiState.isMuted -> Icons.Default.MicOff
                            else -> Icons.Default.Mic
                        },
                        contentDescription = "Voice Input",
                        tint = if (uiState.state == AssistantState.LISTENING || uiState.state == AssistantState.SPEAKING) HudVoid else HudCyan
                    )
                }

                if (inputText.isNotBlank()) {
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                onSendMessage(inputText.trim())
                                inputText = ""
                                focusManager.clearFocus()
                            }
                        },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(HudCyan)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = HudVoid,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: VoiceMessage) {
    val isUser = message.sender == MessageSender.USER
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(0.85f),
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 2.dp,
                bottomEnd = if (isUser) 2.dp else 16.dp
            ),
            colors = CardDefaults.cardColors(
                containerColor = if (isUser) Color(0xFF0D253A) else HudCardBg
            ),
            border = BorderStroke(
                1.dp,
                if (isUser) HudCyan.copy(alpha = 0.5f) else HudBorder
            )
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                if (!isUser) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(bottom = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = HudCyan,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "Muskan",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = HudCyan
                        )
                    }
                }
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = HudTextPrimary,
                    lineHeight = 20.sp
                )
            }
        }
    }
}
