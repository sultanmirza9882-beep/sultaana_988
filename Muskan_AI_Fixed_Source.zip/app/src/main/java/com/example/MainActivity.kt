package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.engine.approval.OwnerApprovalGate
import com.example.engine.backup.GoogleDriveBackupEngine
import com.example.engine.dev.ApkInspectionEngine
import com.example.engine.dev.MuskanTaskManager
import com.example.engine.dev.ProjectWorkspaceManager
import com.example.engine.dev.SelfDevelopmentEngine
import com.example.engine.llm.QwenOfflineModelManager
import com.example.engine.network.NetworkDiagnosticsEngine
import com.example.engine.persona.MuskanPersonalityEngine
import com.example.engine.terminal.WorkspaceTerminalEngine
import com.example.service.FloatingBubbleService
import com.example.service.MuskanAccessibilityService
import com.example.ui.components.ApiManagementDialog
import com.example.ui.components.BatteryOptimizationTutorialDialog
import com.example.ui.components.ConversationHistoryDrawerContent
import com.example.ui.components.FirebaseMemoryManagerDialog
import com.example.ui.components.IntegrationsAndPermissionsDialog
import com.example.ui.components.MuskaanMasterDashboard
import com.example.ui.components.PermanentMemoryScreen
import com.example.ui.components.SettingsBottomSheet
import com.example.ui.components.SettingsScreen
import com.example.ui.components.VoiceEnrollmentDialog
import com.example.ui.screens.ApprovalsScreen
import com.example.ui.screens.LiveTerminalScreen
import com.example.ui.screens.MasterSettingsHubScreen
import com.example.ui.screens.MuskanChatScreen
import com.example.ui.screens.MuskanDock
import com.example.ui.screens.MuskanHeader
import com.example.ui.screens.MuskanHomeScreen
import com.example.ui.screens.MuskanTab
import com.example.ui.theme.AccentLightingManager
import com.example.ui.theme.MkInk
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AccentLightingManager.initialize(this)
        GoogleDriveBackupEngine.initialize(this)
        MuskanPersonalityEngine.initialize(this)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MuskanVoiceApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MuskanVoiceApp(
    viewModel: VoiceViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val recentHistoryTurns by viewModel.recentHistoryTurns.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf(MuskanTab.HOME) }

    val sourceZipPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                val fileName = runCatching {
                    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (cursor.moveToFirst() && nameIndex >= 0) {
                            cursor.getString(nameIndex)
                        } else {
                            "import_${System.currentTimeMillis()}.zip"
                        }
                    }
                }.getOrNull() ?: "import_${System.currentTimeMillis()}.zip"
                val isApk = fileName.endsWith(".apk", ignoreCase = true)

                val resultMessage = runCatching {
                    val tempFile = File(context.cacheDir, "muskan_upload_${System.currentTimeMillis()}_$fileName")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        tempFile.outputStream().use { output -> input.copyTo(output) }
                    } ?: throw IllegalStateException("Could not open the selected file.")
                    try {
                        if (isApk) {
                            val report = ApkInspectionEngine.inspectApk(context, tempFile)
                            WorkspaceTerminalEngine.logToolEvent("ApkInspectionEngine", "inspectApk", report.message, 0L)
                            report.message
                        } else {
                            val res = ProjectWorkspaceManager.importSourceZip(context, tempFile)
                            WorkspaceTerminalEngine.logToolEvent("ProjectWorkspaceManager", "importSourceZip", res.message, 0L)
                            res.message
                        }
                    } finally {
                        tempFile.delete()
                    }
                }.getOrElse { error ->
                    "File import failed: ${error.message ?: "unknown error"}"
                }
                snackbarHostState.showSnackbar(resultMessage)
            }
        }
    }

    var pendingDrafts by remember { mutableStateOf(emptyList<SelfDevelopmentEngine.PendingDraft>()) }
    var reviewDraftId by remember { mutableStateOf<String?>(null) }
    var reviewDraftSummary by remember { mutableStateOf("") }
    var reviewDraftFiles by remember { mutableStateOf(emptyList<Pair<String, String>>()) }
    var reviewBusy by remember { mutableStateOf(false) }

    fun refreshPendingDrafts() {
        pendingDrafts = SelfDevelopmentEngine.listPendingDrafts(context)
    }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    var showStructuredSettingsSheet by remember { mutableStateOf(false) }
    var showSettingsScreen by remember { mutableStateOf(false) }
    var showPermanentMemoryScreen by remember { mutableStateOf(false) }
    var showBatteryTutorialDialog by remember { mutableStateOf(false) }
    var showIntegrationsDialog by remember { mutableStateOf(false) }

    val powerManager = remember { context.getSystemService(Context.POWER_SERVICE) as? PowerManager }
    var isIgnoringBatteryOptimizations by remember {
        mutableStateOf(powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: true)
    }

    // Sync Accessibility Service status on resume
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                val isConnected = MuskanAccessibilityService.isConnected()
                VoiceSessionManager.setAccessibilityServiceConnected(isConnected)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val permissionsToRequest = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.CAMERA,
                Manifest.permission.READ_CONTACTS
            )
        } else {
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA,
                Manifest.permission.READ_CONTACTS
            )
        }
    }

    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val recordAudioGranted = results[Manifest.permission.RECORD_AUDIO] ?: false
        viewModel.setPermissionGranted(recordAudioGranted)
        if (!recordAudioGranted) {
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Microphone permission is required for hands-free Muskan.")
            }
        }
    }

    // Initial startup checks & auto network diagnostics
    LaunchedEffect(Unit) {
        val audioGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        viewModel.setPermissionGranted(audioGranted)
        viewModel.checkAccessibilityStatus()
        viewModel.checkOverlayPermission()

        NetworkDiagnosticsEngine.runDirectDiagnostics(context)
        GoogleDriveBackupEngine.performDailyAutoSync(context)

        coroutineScope.launch {
            MuskanTaskManager.loadPersistedTask(context)
        }

        if (!audioGranted) {
            permissionsLauncher.launch(permissionsToRequest)
        }
    }

    // Refresh pending code drafts when new chat turns arrive
    LaunchedEffect(uiState.conversationHistory.size) {
        if (uiState.conversationHistory.isNotEmpty()) {
            refreshPendingDrafts()
        }
    }

    // Route voice command "history dikhao" to the single unified history drawer
    LaunchedEffect(uiState.showHistoryPanel) {
        if (uiState.showHistoryPanel) {
            drawerState.open()
            viewModel.showHistoryPanel(false)
        }
    }

    // Show error snackbar
    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let { error ->
            val cleanError = when {
                error.contains("429") || error.contains("RESOURCE_EXHAUSTED", ignoreCase = true) ->
                    "Gemini API Quota Exceeded (HTTP 429). Offline companion active."
                error.length > 120 -> error.take(120) + "…"
                else -> error
            }
            coroutineScope.launch {
                snackbarHostState.showSnackbar(cleanError)
            }
        }
    }

    val onMicClick = {
        focusManager.clearFocus()
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        when {
            !hasPermission -> permissionsLauncher.launch(permissionsToRequest)
            uiState.isMuted -> viewModel.setMuted(false)
            uiState.isGeminiLiveConnected -> viewModel.stopGeminiLiveSession()
            uiState.state == AssistantState.LISTENING -> viewModel.stopListening()
            uiState.state == AssistantState.SPEAKING -> viewModel.stopTtsAndListen()
            else -> viewModel.startListening()
        }
    }

    // Single unified Modal Navigation Drawer hosting Room Conversation History
    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ConversationHistoryDrawerContent(
                turns = recentHistoryTurns,
                onCloseDrawer = {
                    coroutineScope.launch { drawerState.close() }
                },
                onReplay = { responseText ->
                    viewModel.replayTurn(responseText)
                },
                onAskAgain = { prompt ->
                    coroutineScope.launch { drawerState.close() }
                    viewModel.processSpeechInput(prompt)
                },
                onDeleteTurn = { turnId ->
                    viewModel.deleteHistoryTurn(turnId)
                },
                onClearAll = {
                    viewModel.clearRoomHistory()
                },
                onShowSnackbar = { msg ->
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar(msg)
                    }
                },
                onOpenSettings = {
                    coroutineScope.launch { drawerState.close() }
                    showSettingsScreen = true
                }
            )
        }
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MkInk,
            topBar = {
                MuskanHeader(
                    state = uiState.state,
                    isMuted = uiState.isMuted,
                    onMenu = { coroutineScope.launch { drawerState.open() } },
                    onToggleMute = { viewModel.toggleMute() },
                    onKey = { viewModel.setShowApiManagerDialog(true) },
                    onSettings = { showStructuredSettingsSheet = true }
                )
            },
            bottomBar = {
                val livePendingApprovals by OwnerApprovalGate.pendingCount.collectAsStateWithLifecycle()
                MuskanDock(
                    selected = selectedTab,
                    pendingCount = pendingDrafts.size + livePendingApprovals,
                    onSelect = { tab ->
                        selectedTab = tab
                        if (tab == MuskanTab.PROJECTS) refreshPendingDrafts()
                    }
                )
            },
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .imePadding(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (uiState.isAgenticTaskRunning) {
                    AgenticTaskExecutionBanner(
                        planTitle = uiState.currentAgenticPlanTitle ?: "Autonomous Agentic Task",
                        currentStep = uiState.currentAgenticStepIndex,
                        totalSteps = uiState.totalAgenticSteps,
                        statusText = uiState.agenticCurrentStatusText ?: "Perceiving & interacting with screen…",
                        onCancel = { viewModel.cancelAgenticExecution() }
                    )
                }

                if (!uiState.isAccessibilityEnabled) {
                    AccessibilityAutomationBanner(
                        isEnabled = false,
                        onEnableClick = {
                            MuskanAccessibilityService.openAccessibilitySettings(context)
                        }
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (selectedTab) {
                        MuskanTab.HOME -> {
                            MuskanHomeScreen(
                                uiState = uiState,
                                onSendMessage = { prompt ->
                                    viewModel.processSpeechInput(prompt)
                                },
                                onMicClick = onMicClick,
                                onOpenChat = { selectedTab = MuskanTab.CHAT },
                                onOpenUpload = {
                                    sourceZipPicker.launch(
                                        arrayOf(
                                            "application/zip",
                                            "application/vnd.android.package-archive",
                                            "application/octet-stream"
                                        )
                                    )
                                },
                                onOpenAiMode = { showSettingsScreen = true },
                                onOpenDrive = {
                                    coroutineScope.launch {
                                        GoogleDriveBackupEngine.performDailyAutoSync(context)
                                        snackbarHostState.showSnackbar("Local backup snapshot saved to app storage.")
                                    }
                                },
                                onOpenCamera = {
                                    val cameraIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    runCatching {
                                        context.startActivity(cameraIntent)
                                    }.onFailure {
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar("No camera app available on this device.")
                                        }
                                    }
                                }
                            )
                        }

                        MuskanTab.PROJECTS -> {
                            Column(modifier = Modifier.fillMaxSize()) {
                                ApprovalsScreen(
                                    context = context,
                                    pendingDrafts = pendingDrafts,
                                    reviewDraftId = reviewDraftId,
                                    reviewDraftSummary = reviewDraftSummary,
                                    reviewDraftFiles = reviewDraftFiles,
                                    reviewBusy = reviewBusy,
                                    onRefreshDrafts = { refreshPendingDrafts() },
                                    onReviewDraft = { draft ->
                                        coroutineScope.launch {
                                            reviewBusy = true
                                            val loaded = runCatching {
                                                val files = SelfDevelopmentEngine.loadDraftFilesForReview(context, draft.draftId)
                                                (0 until files.length()).map { i ->
                                                    val item = files.getJSONObject(i)
                                                    item.optString("path") to item.optString("content")
                                                }
                                            }
                                            if (loaded.isSuccess) {
                                                reviewDraftId = draft.draftId
                                                reviewDraftSummary = draft.summary
                                                reviewDraftFiles = loaded.getOrThrow()
                                            } else {
                                                snackbarHostState.showSnackbar(
                                                    "Could not open draft: ${loaded.exceptionOrNull()?.message ?: "unknown error"}"
                                                )
                                            }
                                            reviewBusy = false
                                        }
                                    },
                                    onApproveAndApply = {
                                        val draftId = reviewDraftId ?: return@ApprovalsScreen
                                        coroutineScope.launch {
                                            reviewBusy = true
                                            val result = runCatching {
                                                val patch = SelfDevelopmentEngine.loadDraftFilesForReview(context, draftId)
                                                ProjectWorkspaceManager.applyReviewedPatch(context, patch)
                                            }.getOrElse { error ->
                                                ProjectWorkspaceManager.WorkspaceResult(
                                                    false,
                                                    error.message ?: "Could not apply reviewed patch."
                                                )
                                            }
                                            snackbarHostState.showSnackbar(result.message)
                                            if (result.success) {
                                                runCatching { SelfDevelopmentEngine.markDraftApplied(context, draftId) }
                                                reviewDraftId = null
                                                reviewDraftFiles = emptyList()
                                                reviewDraftSummary = ""
                                                refreshPendingDrafts()
                                            }
                                            reviewBusy = false
                                        }
                                    },
                                    onCancelReview = {
                                        reviewDraftId = null
                                        reviewDraftFiles = emptyList()
                                        reviewDraftSummary = ""
                                    },
                                    onRollbackSnapshot = { snapshotName ->
                                        coroutineScope.launch {
                                            val result = ProjectWorkspaceManager.rollbackToSnapshot(context, snapshotName)
                                            snackbarHostState.showSnackbar(result.message)
                                        }
                                    }
                                )
                            }
                        }

                        MuskanTab.CHAT -> {
                            MuskanChatScreen(
                                uiState = uiState,
                                onSendMessage = { prompt ->
                                    viewModel.processSpeechInput(prompt)
                                },
                                onMicClick = onMicClick,
                                onAttachmentClick = {
                                    sourceZipPicker.launch(
                                        arrayOf(
                                            "application/zip",
                                            "application/vnd.android.package-archive",
                                            "application/octet-stream"
                                        )
                                    )
                                }
                            )
                        }

                        MuskanTab.TOOLS -> {
                            LiveTerminalScreen(context = context)
                        }

                        MuskanTab.SETTINGS -> {
                            MasterSettingsHubScreen(
                                uiState = uiState,
                                context = context,
                                onOpenApiManager = { viewModel.setShowApiManagerDialog(true) },
                                onOpenVoiceSettings = { showSettingsScreen = true },
                                onOpenBiometrics = { viewModel.setShowVoiceEnrollmentDialog(true) },
                                onOpenApprovals = {
                                    selectedTab = MuskanTab.PROJECTS
                                    refreshPendingDrafts()
                                },
                                onOpenTerminal = { selectedTab = MuskanTab.TOOLS },
                                onOpenProjects = { selectedTab = MuskanTab.PROJECTS },
                                onOpenMasterDashboard = { viewModel.setShowMasterDashboard(true) },
                                onOpenMemoryManager = { viewModel.setShowMemoryManagerDialog(true) },
                                onOpenBatteryTutorial = { showBatteryTutorialDialog = true },
                                onOpenAccessibility = {
                                    MuskanAccessibilityService.openAccessibilitySettings(context)
                                },
                                onOpenPermissionsAndIntegrations = {
                                    showIntegrationsDialog = true
                                },
                                onToggleWakeWord = { viewModel.toggleWakeWord() },
                                onToggleFloatingBubble = { viewModel.toggleFloatingBubble() }
                            )
                        }
                    }
                }
            }
        }

        // Live Owner Approval Modal for Sensitive Outbound Actions (CALL_PHONE, SEND_SMS, WHATSAPP, CALENDAR, EMAIL, SOCIAL)
        val activeSensitiveApproval by OwnerApprovalGate.activeActionPrompt.collectAsStateWithLifecycle()
        activeSensitiveApproval?.let { pendingRequest ->
            AlertDialog(
                onDismissRequest = {
                    OwnerApprovalGate.rejectProposal(
                        pendingRequest.id,
                        "Dismissed by owner"
                    )
                },
                containerColor = Color(0xFF101828),
                titleContentColor = Color.White,
                textContentColor = Color(0xFFD0D5DD),
                title = {
                    Text(
                        text = pendingRequest.title,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Action: ${pendingRequest.sensitiveActionType?.label ?: pendingRequest.category.name}",
                            color = Color(0xFF38BDF8),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                        Text(text = pendingRequest.hinglishExplanation)
                        pendingRequest.payloadPreview?.takeIf { it.isNotBlank() }?.let { preview ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF070D17)
                            ) {
                                Text(
                                    text = preview,
                                    modifier = Modifier.padding(10.dp),
                                    color = Color(0xFF67E8F9),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            OwnerApprovalGate.approveProposal(pendingRequest.id)
                        },
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("modal_approve_sensitive_action_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                    ) {
                        Text("Approve", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        onClick = {
                            OwnerApprovalGate.rejectProposal(
                                pendingRequest.id,
                                "Denied by owner"
                            )
                        },
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("modal_deny_sensitive_action_button")
                    ) {
                        Text("Deny", color = Color(0xFFF43F5E), fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        // Quick Settings Bottom Sheet
        if (showStructuredSettingsSheet) {
            SettingsBottomSheet(
                uiState = uiState,
                context = context,
                onDismiss = { showStructuredSettingsSheet = false },
                onToggleWakeWord = { viewModel.toggleWakeWord() },
                onToggleMute = { viewModel.toggleMute() },
                onSetVoicePreset = { preset -> viewModel.setVoicePreset(preset) },
                onToggleFloatingBubble = { viewModel.toggleFloatingBubble() },
                onOpenOverlaySettings = {
                    FloatingBubbleService.openOverlaySettings(context)
                },
                onOpenAccessibilitySettings = {
                    MuskanAccessibilityService.openAccessibilitySettings(context)
                },
                onToggleGamingMode = { viewModel.toggleGamingMode() },
                onOpenBatteryTutorial = {
                    showStructuredSettingsSheet = false
                    showBatteryTutorialDialog = true
                },
                onToggleVoiceBiometrics = { viewModel.toggleVoiceBiometrics() },
                onToggleNoiseSuppression = { viewModel.toggleNoiseSuppression() },
                onOpenVoiceEnrollment = {
                    showStructuredSettingsSheet = false
                    viewModel.setShowVoiceEnrollmentDialog(true)
                },
                onOpenApiManager = {
                    showStructuredSettingsSheet = false
                    viewModel.setShowApiManagerDialog(true)
                },
                onOpenMasterDashboard = {
                    showStructuredSettingsSheet = false
                    viewModel.setShowMasterDashboard(true)
                },
                onUpdateSpeechRate = { rate -> viewModel.updateSpeechRate(rate) },
                onUpdateSpeechPitch = { pitch -> viewModel.updateSpeechPitch(pitch) },
                onTestVoice = {
                    viewModel.replayTurn("Namaste Sultan! Yeh meri aawaz ki speed aur pitch ka live preview hai. Kaisi lag rahi hai meri aawaz?")
                },
                onResetVoiceDefaults = {
                    viewModel.updateSpeechRate(1.05f)
                    viewModel.updateSpeechPitch(1.02f)
                }
            )
        }

        // Dedicated Full Settings Screen (Offline Qwen3 Brain, Voice Speed/Pitch, Permanent Memory)
        if (showSettingsScreen) {
            SettingsScreen(
                uiState = uiState,
                onBack = { showSettingsScreen = false },
                onToggleWakeWord = { viewModel.toggleWakeWord() },
                onUpdateSpeechRate = { rate -> viewModel.updateSpeechRate(rate) },
                onUpdateSpeechPitch = { pitch -> viewModel.updateSpeechPitch(pitch) },
                onSetVoicePreset = { preset -> viewModel.setVoicePreset(preset) },
                onTestVoice = {
                    viewModel.replayTurn("Namaste Sultan! Yeh meri aawaz ki speed aur pitch ka live preview hai. Kaisi lag rahi hai meri aawaz?")
                },
                onResetVoiceDefaults = {
                    viewModel.updateSpeechRate(1.05f)
                    viewModel.updateSpeechPitch(1.02f)
                },
                onToggleMute = { viewModel.toggleMute() },
                onToggleForceOfflineBrain = { viewModel.toggleForceOfflineBrain() },
                onStartQwenDownload = {
                    QwenOfflineModelManager.startOrResumeDownload(context)
                },
                onPauseQwenDownload = {
                    QwenOfflineModelManager.pauseDownload()
                },
                onScanQwenModel = {
                    QwenOfflineModelManager.initialize(context)
                },
                onToggleThinkingMode = {
                    val curr = QwenOfflineModelManager.state.value.isThinkingModeEnabled
                    QwenOfflineModelManager.setThinkingMode(context, !curr)
                },
                onOpenPermanentMemory = {
                    showPermanentMemoryScreen = true
                }
            )
        }

        // Dedicated Permanent Memory & Workflows Management Screen
        if (showPermanentMemoryScreen) {
            PermanentMemoryScreen(
                onBack = { showPermanentMemoryScreen = false }
            )
        }

        // Voice Profile Enrollment Dialog
        if (uiState.showVoiceEnrollmentDialog) {
            VoiceEnrollmentDialog(
                isEnrolled = uiState.isVoiceBiometricsEnrolled,
                onEnrollmentComplete = { samples ->
                    viewModel.enrollVoiceSamples(samples)
                },
                onRecordSample = {
                    viewModel.recordEnrollmentSample()
                },
                onDismiss = {
                    viewModel.setShowVoiceEnrollmentDialog(false)
                }
            )
        }

        // Master Autonomous Dashboard & 128-Engine Status Control Room
        if (uiState.showMasterDashboard) {
            MuskaanMasterDashboard(
                onDismiss = { viewModel.setShowMasterDashboard(false) }
            )
        }

        // API Management & Key Rotation Pool Dialog
        if (uiState.showApiManagerDialog) {
            ApiManagementDialog(
                onDismiss = { viewModel.setShowApiManagerDialog(false) }
            )
        }

        // Cloud & Firebase Persistent Memory Dialog
        if (uiState.showMemoryManagerDialog) {
            FirebaseMemoryManagerDialog(
                uiState = uiState,
                viewModel = viewModel,
                onDismiss = { viewModel.setShowMemoryManagerDialog(false) }
            )
        }

        // Battery Optimization In-App Tutorial Dialog
        if (showBatteryTutorialDialog) {
            BatteryOptimizationTutorialDialog(
                context = context,
                isIgnored = isIgnoringBatteryOptimizations,
                onDismiss = { showBatteryTutorialDialog = false },
                onStatusChanged = { updatedIgnored ->
                    isIgnoringBatteryOptimizations = updatedIgnored
                }
            )
        }

        // Blueprint Section 8 Permissions, Call Screening Role & Encrypted OAuth Integrations
        if (showIntegrationsDialog) {
            IntegrationsAndPermissionsDialog(
                context = context,
                onDismiss = { showIntegrationsDialog = false }
            )
        }
    }
}

@Composable
fun AccessibilityAutomationBanner(
    isEnabled: Boolean,
    onEnableClick: () -> Unit
) {
    Surface(
        color = if (isEnabled) {
            Color(0xFF10B981).copy(alpha = 0.12f)
        } else {
            Color(0xFFEF4444).copy(alpha = 0.15f)
        },
        border = BorderStroke(
            1.dp,
            if (isEnabled) Color(0xFF10B981).copy(alpha = 0.35f) else Color(0xFFEF4444).copy(alpha = 0.5f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.Accessibility,
                    contentDescription = null,
                    tint = if (isEnabled) Color(0xFF10B981) else Color(0xFFEF4444),
                    modifier = Modifier.size(22.dp)
                )
                Column {
                    Text(
                        text = if (isEnabled) "Phone Automation: Active" else "Accessibility Service Disconnected",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isEnabled) MaterialTheme.colorScheme.onSurface else Color(0xFFFCA5A5)
                    )
                    Text(
                        text = if (isEnabled) {
                            "Muskan can autonomously navigate, scroll & execute actions."
                        } else {
                            "WhatsApp control & screen actions blocked to prevent fake reports. Turn ON to enable."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (!isEnabled) {
                Button(
                    onClick = onEnableClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFEF4444),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.padding(start = 6.dp)
                ) {
                    Text("Turn On", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun AgenticTaskExecutionBanner(
    planTitle: String,
    currentStep: Int,
    totalSteps: Int,
    statusText: String,
    onCancel: () -> Unit
) {
    Surface(
        color = Color(0xFF064E3B).copy(alpha = 0.95f),
        contentColor = Color.White,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        shadowElevation = 6.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = Color(0xFF10B981),
                        strokeWidth = 2.dp
                    )
                    Text(
                        text = planTitle,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF6EE7B7)
                    )
                }
                TextButton(onClick = onCancel) {
                    Text("Cancel", color = Color(0xFFFCA5A5), style = MaterialTheme.typography.labelSmall)
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Step $currentStep of $totalSteps: $statusText",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFE5E7EB)
            )
        }
    }
}
