package com.example

import java.util.UUID

enum class AssistantState {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING,
    ERROR
}

enum class AuthoritativeVoiceSessionState {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING,
    ERROR
}

enum class MessageSender {
    USER,
    ASSISTANT
}

enum class BiometricVerdict {
    IDLE,
    VERIFYING,
    VERIFIED_SULTAN,
    REJECTED_UNKNOWN
}

data class VoiceMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class VoiceUiState(
    val state: AssistantState = AssistantState.IDLE,
    val authoritativeVoiceState: AuthoritativeVoiceSessionState = AuthoritativeVoiceSessionState.IDLE,
    val statusMessage: String = "Say 'Muskan' or tap mic to talk",
    val partialTranscript: String = "",
    val lastUserQuery: String = "",
    val lastResponseText: String = "",
    val isTtsSpeaking: Boolean = false,
    val audioRmsLevel: Float = 0f,
    val audioOutputLevel: Float = 0f,
    val errorMessage: String? = null,
    val conversationHistory: List<VoiceMessage> = emptyList(),
    val hasAudioPermission: Boolean = false,
    val isSpeechAvailable: Boolean = true,
    // Wake-word detection settings
    val isWakeWordEnabled: Boolean = true,
    val isWakeWordStandby: Boolean = false,
    val wakeWordDetectedNotice: Boolean = false,
    // Continuous 5-Minute Active Session
    val isContinuousSessionActive: Boolean = false,
    val sessionRemainingSeconds: Int = 0,
    // Voice-controlled Mute & Unmute
    val isMuted: Boolean = false,
    // Accessibility Service Phone Automation
    val isAccessibilityEnabled: Boolean = false,
    // Floating Overlay Bubble (SYSTEM_ALERT_WINDOW)
    val isOverlayPermissionGranted: Boolean = false,
    val isFloatingBubbleActive: Boolean = false,
    // Gaming & Non-Intrusive Mode
    val isGamingMode: Boolean = false,
    val isUserInteractingManually: Boolean = false,
    // Agentic Multi-Step Task Execution
    val isAgenticTaskRunning: Boolean = false,
    val currentAgenticPlanTitle: String? = null,
    val currentAgenticStepIndex: Int = 0,
    val totalAgenticSteps: Int = 0,
    val agenticCurrentStatusText: String? = null,
    // Muskan Voice Calibration (Rate: 1.0x, Pitch: 1.0x)
    val voicePresetName: String = "Muskan Voice Calibration (Rate: 1.0x, Pitch: 1.0x)",
    val selectedVoiceDescription: String = "Muskan Voice Calibration (Rate: 1.0x, Pitch: 1.0x)",
    val speechRate: Float = 1.00f,
    val speechPitch: Float = 1.00f,
    val showHistoryPanel: Boolean = false,
    // Voice Biometric Isolation & Noise Cancellation
    val isVoiceBiometricsEnrolled: Boolean = false,
    val isVoiceBiometricsActive: Boolean = false,
    val biometricConfidenceScore: Float = 0f,
    val lastBiometricVerdict: BiometricVerdict = BiometricVerdict.IDLE,
    val isNoiseSuppressionActive: Boolean = true,
    val showVoiceEnrollmentDialog: Boolean = false,
    val voiceEnrollmentStep: Int = 0,
    val totalEnrollmentSteps: Int = 4,
    val discardedSpeakerNotice: String? = null,
    // Master Autonomous Dashboard & Approvals
    val showMasterDashboard: Boolean = false,
    val pendingApprovalsCount: Int = 0,
    val lastOrchestrationRationale: String? = null,
    // Manual API Management
    val showApiManagerDialog: Boolean = false,
    val activeApiName: String = "Default API (System)",
    val activeApiStatus: String = "VERIFIED",
    // Continuous Microphone Listening Controls
    val isListeningEnabledByUser: Boolean = true,
    // Gemini Live API & Bidirectional WebSocket
    val isGeminiLiveConnected: Boolean = false,
    val liveSessionState: com.example.data.gemini.LiveSessionState = com.example.data.gemini.LiveSessionState.IDLE,
    val isProactiveQuestionsEnabled: Boolean = true,
    // Firebase Authentication & Firestore Persistent Memory
    val isFirebaseAuthSignedIn: Boolean = false,
    val firebaseUserDisplayName: String = "Sultan Mirza",
    val firebaseUserEmail: String? = "sultaan.m33@gmail.com",
    val firebaseMemoriesCount: Int = 0,
    val showMemoryManagerDialog: Boolean = false,
    // Dual-Brain Architecture (Gemini Cloud + Qwen3 1.7B GGUF Offline)
    val activeBrainMode: String = "Dual-Brain (Auto)",
    val isOfflineBrainForced: Boolean = false,
    val isOfflineModelReady: Boolean = false,
    val lastBrainUsed: String? = null,
    val offlineBrainStatusNotice: String? = null
)
