package com.example.data

import com.example.BuildConfig
import com.example.api.ApiKeySlot
import com.example.api.ApiConfigHelper
import com.example.api.KeyRotationPoolManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Raw Gemini call for the autonomous phone agent.
 *
 * Unlike GeminiClient.askGemini (which forces the short chat persona), this sends the agent's own
 * system prompt, can attach screenshots / video frames, and can ask for strict JSON output.
 * It reuses the same key pool and rotates keys on quota / auth errors.
 */
object AgentLlm {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(75, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generate(
        system: String,
        user: String,
        imagesJpegBase64: List<String> = emptyList(),
        expectJson: Boolean = true,
        maxOutputTokens: Int = 1200
    ): Result<String> = withContext(Dispatchers.IO) {
        var slot = KeyRotationPoolManager.selectActiveSlotForRequest()
        var lastError: Throwable? = null

        for (attempt in 0 until 3) {
            val key = (if (slot.keyString.isNotBlank()) slot.keyString else BuildConfig.GEMINI_API_KEY).trim()
            if (key.isBlank() || key == "MY_GEMINI_API_KEY" || ApiKeySlot.isPlaceholderKey(key)) {
                return@withContext Result.failure(IllegalStateException("Gemini API key set nahi hai (Settings mein key daalein)."))
            }
            if (key.startsWith("sk-")) {
                return@withContext Result.failure(IllegalStateException("Autonomous agent ke liye Gemini API key chahiye (OpenAI key support nahi)."))
            }
            try {
                val model = ApiConfigHelper.cleanModelId(slot.modelId)
                val parts = JSONArray()
                parts.put(JSONObject().put("text", user))
                for (img in imagesJpegBase64) {
                    parts.put(JSONObject().put("inlineData", JSONObject()
                        .put("mimeType", "image/jpeg").put("data", img)))
                }
                val gen = JSONObject()
                    .put("temperature", 0.3)
                    .put("maxOutputTokens", maxOutputTokens)
                if (expectJson) gen.put("responseMimeType", "application/json")
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                    .put("generationConfig", gen)

                val req = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    .header("x-goog-api-key", key)
                    .header("Content-Type", "application/json")
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                client.newCall(req).execute().use { resp ->
                    val text = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        val out = JSONObject(text).optJSONArray("candidates")
                            ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                            ?.let { arr -> (0 until arr.length()).joinToString("") { arr.optJSONObject(it)?.optString("text").orEmpty() } }
                            .orEmpty().trim()
                        if (out.isNotBlank()) {
                            KeyRotationPoolManager.recordSuccess(slot.slotIndex)
                            return@withContext Result.success(out)
                        }
                        lastError = Exception("AI ne khaali jawab diya.")
                    } else {
                        val code = resp.code
                        lastError = Exception("AI error HTTP $code: ${text.take(120)}")
                        val retryable = code == 429 || code == 401 || code == 403 || code >= 500
                        if (retryable) {
                            slot = KeyRotationPoolManager.recordErrorAndRotate(slot.slotIndex, code == 429, code)
                            return@use
                        }
                        return@withContext Result.failure(lastError!!)
                    }
                }
            } catch (e: Exception) {
                lastError = e
            }
        }
        Result.failure(lastError ?: Exception("AI se jawab nahi mila."))
    }
}
