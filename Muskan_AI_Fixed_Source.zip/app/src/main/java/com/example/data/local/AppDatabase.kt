package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Main Room Database for the Muskan Voice Assistant.
 * Uses explicit forward migrations to preserve user history, memories, and taught workflows
 * across app updates, allowing destructive fallback ONLY on schema downgrade.
 */
@Database(
    entities = [ConversationTurnEntity::class, UserMemoryEntity::class, TaughtWorkflowEntity::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun conversationTurnDao(): ConversationTurnDao
    abstract fun userMemoryDao(): UserMemoryDao
    abstract fun taughtWorkflowDao(): TaughtWorkflowDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Schema v1 -> v2: introduces the persistent `user_memories` table without disturbing
         * existing `conversation_turns` records.
         */
        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `user_memories` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `category` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `detail` TEXT NOT NULL,
                        `timestamp` INTEGER NOT NULL,
                        `is_pinned` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        /**
         * Schema v2 -> v3: introduces the `taught_workflows` table for voice-taught routines
         * while preserving all conversation turns and user memories.
         */
        val MIGRATION_2_3: Migration = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `taught_workflows` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `workflow_id` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `trigger_phrase` TEXT NOT NULL,
                        `description` TEXT NOT NULL,
                        `steps_json` TEXT NOT NULL,
                        `is_enabled` INTEGER NOT NULL,
                        `execution_count` INTEGER NOT NULL,
                        `last_executed_at` INTEGER NOT NULL,
                        `created_at` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        val ALL_MIGRATIONS: Array<Migration> = arrayOf(MIGRATION_1_2, MIGRATION_2_3)

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "muskan_voice_database"
                )
                    .addMigrations(*ALL_MIGRATIONS)
                    .fallbackToDestructiveMigrationOnDowngrade(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
