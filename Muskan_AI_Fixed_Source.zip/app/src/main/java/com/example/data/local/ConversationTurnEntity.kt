package com.example.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room entity representing a single conversation turn between the user and Muskan.
 * Captures both the user prompt and Muskan's response along with metadata.
 */
@Entity(tableName = "conversation_turns")
data class ConversationTurnEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "user_query")
    val userQuery: String,

    @ColumnInfo(name = "assistant_response")
    val assistantResponse: String,

    @ColumnInfo(name = "timestamp")
    val timestamp: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "is_automation_action")
    val isAutomationAction: Boolean = false,

    @ColumnInfo(name = "action_tag")
    val actionTag: String? = null
)
