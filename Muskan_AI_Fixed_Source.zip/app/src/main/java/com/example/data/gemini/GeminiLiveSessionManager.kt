package com.example.data.gemini

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import com.example.api.KeyRotationPoolManager
import com.example.data.firebase.FirestoreMemoryRepository
import com.example.data.firebase.UserPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.Closeable
import java.nio.ByteBuffer
import java.nio.ByteOrder

class GeminiLiveSessionManager(
    private val context: Context,
    private val memoryRepository: FirestoreMemoryRepository? = null,
    private val onLiveTranscript: ((isUser: Boolean, text: String) -> Unit)? = null
) : Closeable {
    private var scopeJob = SupervisorJob()
    private var scope = CoroutineScope(scopeJob + Dispatchers.Default)

    private var liveWebSocketClient: GeminiLiveWebSocketClient? = null
    private var sessionStartupJob: Job? = null
    private var sessionCollectorsJob: Job? = null
    private var recordingJob: Job? = null
    private var inactivityWatchdogJob: Job? = null
    private var audioRecord: AudioRecord? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var noiseSuppressor: NoiseSuppressor? = null

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private var previousAudioMode: Int? = null
    private var previousSpeakerphone: Boolean? = null

    /**
     * Voice-call style audio path (what voice-chat apps use): lets the hardware echo canceller
     * hear the assistant's own playback and remove it from the mic, so the assistant stops
     * interrupting itself. Output goes to speaker unless a headset is connected.
     */
    private fun enterCommunicationAudioMode() {
        val am = audioManager ?: return
        try {
            if (previousAudioMode == null) {
                previousAudioMode = am.mode
                @Suppress("DEPRECATION")
                previousSpeakerphone = am.isSpeakerphoneOn
            }
            am.mode = AudioManager.MODE_IN_COMMUNICATION
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                val devices = am.availableCommunicationDevices
                val headset = devices.firstOrNull {
                    it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                        it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                        it.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
                        it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                        it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
                }
                val target = headset ?: devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                if (target != null) am.setCommunicationDevice(target)
            } else {
                @Suppress("DEPRECATION")
                am.isSpeakerphoneOn = !am.isWiredHeadsetOn && !am.isBluetoothScoOn
            }
        } catch (_: Exception) {}
    }

    private fun exitCommunicationAudioMode() {
        val am = audioManager ?: return
        val mode = previousAudioMode ?: return
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                am.clearCommunicationDevice()
            } else {
                @Suppress("DEPRECATION")
                am.isSpeakerphoneOn = previousSpeakerphone ?: false
            }
            am.mode = mode
        } catch (_: Exception) {}
        previousAudioMode = null
        previousSpeakerphone = null
    }

    private val sampleRate = 16000
    private val channelConfig = AudioFormat.CHANNEL_IN_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT
    private val minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
    private val bufferSize = maxOf(minBufferSize, 3200) // 100ms chunk (1600 samples = 3200 bytes)

    private val _liveState = MutableStateFlow(LiveSessionState.IDLE)
    val liveState: StateFlow<LiveSessionState> = _liveState.asStateFlow()

    val isActive: Boolean
        get() = _liveState.value != LiveSessionState.IDLE && _liveState.value != LiveSessionState.ERROR

    private val _statusMessage = MutableStateFlow("Muskaan is ready")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _audioRms = MutableStateFlow(0f)
    val audioRms: StateFlow<Float> = _audioRms.asStateFlow()

    private val _isProactiveEnabled = MutableStateFlow(true)
    val isProactiveEnabled: StateFlow<Boolean> = _isProactiveEnabled.asStateFlow()

    private var lastUserSpeechTimestamp = System.currentTimeMillis()
    private var lastProactivePromptTimestamp = 0L

    fun toggleProactiveQuestions(enabled: Boolean) {
        _isProactiveEnabled.value = enabled
        val repo = memoryRepository ?: return
        scope.launch {
            try {
                repo.saveUserPreferences(
                    UserPreferences(
                        userId = repo.currentUserId ?: "",
                        proactiveQuestionsEnabled = enabled
                    )
                )
            } catch (_: Exception) {}
        }
    }

    @SuppressLint("MissingPermission")
    fun startLiveSession() {
        if (_liveState.value != LiveSessionState.IDLE && _liveState.value != LiveSessionState.ERROR) {
            return
        }
        if (!scopeJob.isActive) {
            scopeJob = SupervisorJob()
            scope = CoroutineScope(scopeJob + Dispatchers.Default)
        }

        _isMicrophoneOwnedByLive.value = true
        sessionStartupJob?.cancel()
        sessionCollectorsJob?.cancel()

        sessionStartupJob = scope.launch {
            val memoryContext = memoryRepository?.loadRelevantMemoryPromptContext() ?: ""
            val systemInstruction = buildSystemInstruction(memoryContext)

            liveWebSocketClient?.release()
            val client = GeminiLiveWebSocketClient(
                context = context,
                apiKeyProvider = {
                    KeyRotationPoolManager.getActiveGeminiKey()
                },
                systemInstructionProvider = { systemInstruction },
                onTranscriptReceived = { isUser, text ->
                    if (text.isNotBlank()) {
                        onLiveTranscript?.invoke(isUser, text)
                        if (!isUser) {
                            _statusMessage.value = text
                        }
                    }
                },
                onInterruptionDetected = {
                    _liveState.value = LiveSessionState.USER_SPEAKING
                },
                onPhoneAction = { command -> runPhoneAction(command) }
            )
            liveWebSocketClient = client

            // Forward state from websocket inside a cancellable collector job so repeated sessions never leak
            sessionCollectorsJob = launch {
                launch {
                    client.sessionState.collect { state ->
                        _liveState.value = state
                        if (state == LiveSessionState.IDLE || state == LiveSessionState.ERROR) {
                            _isMicrophoneOwnedByLive.value = false
                        }
                    }
                }
                launch {
                    client.statusText.collect { txt ->
                        _statusMessage.value = txt
                    }
                }
            }

            enterCommunicationAudioMode()
            client.startSession()
            startContinuousAudioRecording(client)
            // Muskan Non-Intrusive Engine: Inactivity watchdog removed - assistant speaks only when addressed
        }
    }

    /**
     * Executes a phone request through the real automation engine and returns the VERIFIED outcome.
     * The live model is told to repeat only this result, so it can no longer claim success it didn't achieve.
     */
    private suspend fun runPhoneAction(command: String): String {
        val planner = com.example.automation.AgenticExecutionPlanner
        val agent = com.example.automation.UniversalPhoneAgent
        // Open-ended / multi-step goals: let the universal agent work out HOW itself
        if (agent.shouldTakePriority(command)) return runUniversalAgent(command)
        val plan = planner.createPlanForPrompt(command)
        if (plan != null) {
            val outcome = kotlinx.coroutines.withTimeoutOrNull(90_000L) {
                kotlinx.coroutines.suspendCancellableCoroutine<Pair<Boolean, String>> { cont ->
                    planner.executePlan(context, plan) { success, feedback ->
                        if (cont.isActive) cont.resumeWith(Result.success(success to feedback))
                    }
                }
            }
            return when {
                outcome == null -> runUniversalAgent(command)
                outcome.first -> "SUCCESS (screen par verify hua): ${outcome.second}"
                else -> runUniversalAgent(command)
            }
        }
        return when (val r = com.example.automation.AutomationActionEngine.processVoiceCommand(context, command)) {
            is com.example.automation.AutomationResult.Handled -> "SUCCESS: ${r.spokenFeedback}"
            is com.example.automation.AutomationResult.AccessibilityRequired -> "FAILED: ${r.message}"
            else -> runUniversalAgent(command)
        }
    }

    private suspend fun runUniversalAgent(command: String): String {
        val outcome = kotlinx.coroutines.withTimeoutOrNull(240_000L) {
            com.example.automation.UniversalPhoneAgent.run(context, command)
        } ?: run {
            com.example.automation.UniversalPhoneAgent.cancel()
            return "FAILED: kaam 4 minute mein poora nahi hua."
        }
        return if (outcome.first) "SUCCESS (screen par verify hua): ${outcome.second}" else "FAILED: ${outcome.second}"
    }

    private fun buildSystemInstruction(memoryContext: String): String {
        return """
            You are Muskan, Sultan Mirza's AI companion with a calm, clear voice and respectful cadence.
            Language & Tone: Natural, respectful, authoritative Hindi / Hinglish.
            Sultan Mirza is your Commander. Address him respectfully as 'Sultan'.

            SIGNATURE VOCABULARY & PHRASING:
            - When acknowledging commands: only "Ji Sultan." Never claim a phone action is running or done ("execute kar rahi hoon", "ho gaya", "kar diya"); the app announces the verified result itself.
            - On task completion: "Kaam mukammal ho gaya hai, Sultan."
            - Never use conversational filler, excuses, or unsolicited babble.

            PHONE ACTIONS (MOST IMPORTANT):
            - For ANY request to do something on the phone (open an app, scroll reels, play a song, write a note, type, tap, send a message, sketch), you MUST call the phone_action tool with Sultan's request. Do not describe or promise the action yourself.
            - After the tool returns, say ONE short sentence with only what the result says. If it says FAILED, tell the real reason. Never say it is done unless the result says SUCCESS.
            - Never read out or recite long text you wrote for him (poems, shayari); the tool writes it on the screen.

            RESPONSE LENGTH RULE:
            - Strictly maximum 1 to 2 crisp, direct sentences unless an in-depth breakdown is explicitly demanded by Sultan.

            DIRECT UNIFIED AUTONOMOUS ARCHITECTURE:
            Muskan is a single, unified, direct autonomous mobile agent with NO separate sub-agents, subordinate workers, or multi-agent layers. You execute all screen perception, gestures, and OS automation directly yourself for Sultan Mirza.
            When Sultan Mirza asks about agents (e.g. 'agent bnao', 'kitne agent hain', 'agent hatao', 'kiske sahare kaam hota hai'):
            Confirm clearly: "Sultan, mere andar koi alag sub-agent nahi hai. Main khud ek unified direct autonomous engine hoon jo aapke sabhi orders par screen perception aur phone actions direct execute karti hoon."

            CRITICAL ANTI-FABRICATION & PROHIBITIONS:
            - You have NO access to edit source code files or compile APKs at runtime.
            - NEVER claim you are compiling, editing layout in background, modifying code, or working on percentages (e.g. '80% complete', 'Volkswagen task').
            - NEVER ask 'Aap chup kyun ho gaye' or inject unrequested questions during silence.
            - All actual phone actions are performed exclusively by the Android Automation Engine and MuskanAccessibilityService.
            $memoryContext
        """.trimIndent()
    }

    @SuppressLint("MissingPermission")
    private fun startContinuousAudioRecording(client: GeminiLiveWebSocketClient) {
        recordingJob?.cancel()
        recordingJob = scope.launch(Dispatchers.IO) {
            try {
                // (Re)creates the mic. Used at start AND whenever Android/another app steals or kills it,
                // so the stream stays open until the user stops the session.
                fun initRecord(): Boolean {
                    try { echoCanceler?.release() } catch (_: Exception) {}
                    try { noiseSuppressor?.release() } catch (_: Exception) {}
                    echoCanceler = null; noiseSuppressor = null
                    try { audioRecord?.stop(); audioRecord?.release() } catch (_: Exception) {}
                    // VOICE_COMMUNICATION gives hardware Acoustic Echo Cancellation (AEC)
                    val rec = AudioRecord(
                        MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                        sampleRate, channelConfig, audioFormat, bufferSize
                    )
                    audioRecord = rec
                    if (rec.state != AudioRecord.STATE_INITIALIZED) return false
                    try {
                        val sessionId = rec.audioSessionId
                        if (AcousticEchoCanceler.isAvailable()) {
                            echoCanceler = AcousticEchoCanceler.create(sessionId)?.apply { enabled = true }
                        }
                        if (NoiseSuppressor.isAvailable()) {
                            noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply { enabled = true }
                        }
                    } catch (_: Exception) {}
                    rec.startRecording()
                    return rec.recordingState == AudioRecord.RECORDSTATE_RECORDING
                }

                if (!initRecord()) {
                    _liveState.value = LiveSessionState.ERROR
                    _statusMessage.value = "Microphone initialization failed"
                    return@launch
                }
                var badReads = 0
                val shortBuffer = ShortArray(1600) // 100ms frames
                val byteBuffer = ByteBuffer.allocate(3200).order(ByteOrder.LITTLE_ENDIAN)

                // Voice Activity Detection state
                var ambientNoiseFloor = 0.015f
                var consecutiveSpeechFrames = 0

                while (isActive) {
                    val readShorts = audioRecord?.read(shortBuffer, 0, shortBuffer.size) ?: 0
                    if (readShorts <= 0) {
                        badReads++
                        delay(20L)
                        if (badReads >= 15) { // ~0.3s of nothing: mic was taken away, take it back
                            badReads = 0
                            if (!initRecord()) delay(500L)
                        }
                        continue
                    }
                    badReads = 0
                    if (readShorts > 0) {
                        // Calculate RMS of 100ms frame
                        var sum = 0.0
                        byteBuffer.clear()
                        for (i in 0 until readShorts) {
                            val sample = shortBuffer[i]
                            sum += sample * sample
                            byteBuffer.putShort(sample)
                        }
                        val rms = (kotlin.math.sqrt(sum / readShorts) / 32768.0).toFloat()
                        val smoothedRms = (rms * 6f).coerceIn(0f, 1f)
                        _audioRms.value = smoothedRms

                        val isAssistantSpeaking = _liveState.value == LiveSessionState.ASSISTANT_SPEAKING

                        // Adapt background noise floor during idle listening
                        if (!isAssistantSpeaking && rms < 0.04f) {
                            ambientNoiseFloor = (ambientNoiseFloor * 0.95f) + (rms * 0.05f)
                        }

                        // Robust speech threshold relative to ambient noise floor
                        val speechThreshold = if (isAssistantSpeaking) {
                            // Slightly higher threshold during playback to reject residual speaker echo
                            maxOf(0.08f, ambientNoiseFloor * 3.0f + 0.03f)
                        } else {
                            maxOf(0.025f, ambientNoiseFloor * 2.0f + 0.01f)
                        }

                        val hasSpeechEnergy = rms > speechThreshold

                        if (hasSpeechEnergy) {
                            consecutiveSpeechFrames++
                        } else {
                            consecutiveSpeechFrames = 0
                        }

                        // Require at least 2 consecutive frames (~200ms) to confirm human speech
                        if (consecutiveSpeechFrames >= 2) {
                            lastUserSpeechTimestamp = System.currentTimeMillis()
                        }
                        // Local barge-in only after ~600ms of clearly loud speech, so the assistant's own
                        // speaker echo or short noises don't cut it off (server VAD still handles real interrupts)
                        if (isAssistantSpeaking && consecutiveSpeechFrames >= 6) {
                            client.handleLocalBargeIn()
                        }

                        // While Muskan is talking, send silence instead of the mic unless the user is clearly
                        // speaking over her. This stops her own voice from echoing back and re-triggering
                        // the model (the Listening/Speaking flicker seen in the screen recording).
                        if (isAssistantSpeaking && consecutiveSpeechFrames < 6) {
                            client.sendAudioChunk(ByteArray(3200))
                        } else {
                            client.sendAudioChunk(byteBuffer.array())
                        }
                    }
                }
            } catch (e: Exception) {
                _liveState.value = LiveSessionState.ERROR
                _statusMessage.value = "Audio capture error: ${e.localizedMessage}"
            } finally {
                cleanUpAudioRecord()
            }
        }
    }

    private fun startInactivityWatchdog(client: GeminiLiveWebSocketClient) {
        inactivityWatchdogJob?.cancel()
        inactivityWatchdogJob = null
        // Muskan: Automatic proactive dialogue injection during silence completely disabled
    }

    private fun cleanUpAudioRecord() {
        try {
            echoCanceler?.release()
        } catch (_: Exception) {}
        echoCanceler = null

        try {
            noiseSuppressor?.release()
        } catch (_: Exception) {}
        noiseSuppressor = null

        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null
        _isMicrophoneOwnedByLive.value = false
        exitCommunicationAudioMode()
    }

    fun stopLiveSession() {
        sessionStartupJob?.cancel()
        sessionStartupJob = null
        sessionCollectorsJob?.cancel()
        sessionCollectorsJob = null
        recordingJob?.cancel()
        recordingJob = null
        inactivityWatchdogJob?.cancel()
        inactivityWatchdogJob = null
        cleanUpAudioRecord()
        liveWebSocketClient?.release()
        liveWebSocketClient = null
        _isMicrophoneOwnedByLive.value = false
        _liveState.value = LiveSessionState.IDLE
        _statusMessage.value = "Session ended"
        _audioRms.value = 0f
    }

    fun release() {
        stopLiveSession()
        scopeJob.cancelChildren()
        scopeJob.cancel()
    }

    override fun close() {
        release()
    }

    companion object {
        private val _isMicrophoneOwnedByLive = MutableStateFlow(false)
        val isMicrophoneOwnedByLive: StateFlow<Boolean> = _isMicrophoneOwnedByLive.asStateFlow()

        fun isLiveMicActive(): Boolean = _isMicrophoneOwnedByLive.value
    }
}
