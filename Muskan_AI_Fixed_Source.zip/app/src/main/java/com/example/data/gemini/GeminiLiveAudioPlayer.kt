package com.example.data.gemini

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.io.Closeable
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class GeminiLiveAudioPlayer(
    private val context: Context? = null,
    private val sampleRate: Int = 24000,
    private val onPlaybackStateChanged: (Boolean) -> Unit = {}
) : Closeable {
    private var scopeJob = SupervisorJob()
    private var scope = CoroutineScope(scopeJob + Dispatchers.Default)
    private var audioTrack: AudioTrack? = null

    private data class StampedAudioChunk(val pcm: ByteArray, val epoch: Long)
    private val audioChannel = Channel<StampedAudioChunk>(Channel.UNLIMITED)
    private var playbackJob: Job? = null
    private val isPlaying = AtomicBoolean(false)
    private val currentTurnEpoch = AtomicLong(0L)

    private val audioManager = context?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null

    val isCurrentlyPlaying: Boolean
        get() = isPlaying.get()

    fun start() {
        if (playbackJob?.isActive == true) return
        if (!scopeJob.isActive) {
            scopeJob = SupervisorJob()
            scope = CoroutineScope(scopeJob + Dispatchers.Default)
        }

        val minBufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = maxOf(minBufferSize, 8192)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()

        audioTrack = AudioTrack(
            audioAttributes,
            AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build(),
            bufferSize,
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )

        audioTrack?.play()

        playbackJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                val chunk = if (isPlaying.get()) {
                    // Wait up to 450ms for next packet before treating stream as paused/complete
                    val next = withTimeoutOrNull(450L) { audioChannel.receive() }
                    if (next == null) {
                        if (isPlaying.getAndSet(false)) {
                            onPlaybackStateChanged(false)
                        }
                        abandonAssistantAudioFocus()
                        continue
                    }
                    next
                } else {
                    audioChannel.receive()
                }
                // Drop stale chunks from older/interrupted turns
                if (chunk.epoch != currentTurnEpoch.get()) {
                    continue
                }

                if (chunk.pcm.isNotEmpty() && audioTrack?.playState == AudioTrack.PLAYSTATE_PLAYING) {
                    if (!isPlaying.getAndSet(true)) {
                        requestAssistantAudioFocus()
                        onPlaybackStateChanged(true)
                    }
                    audioTrack?.write(chunk.pcm, 0, chunk.pcm.size)
                }
            }
        }
    }

    /**
     * Queues an audio frame associated with the current response turn.
     */
    fun playChunk(pcmBytes: ByteArray) {
        if (pcmBytes.isNotEmpty()) {
            audioChannel.trySend(StampedAudioChunk(pcmBytes, currentTurnEpoch.get()))
        }
    }

    /**
     * Immediately stops playback, flushes queued buffers, increments turn epoch to
     * permanently discard any in-flight stale audio chunks, and resets track for immediate cancellation.
     */
    fun stopAndFlush() {
        val wasPlaying = isPlaying.getAndSet(false)
        // Advance turn epoch to invalidate all pending/in-flight chunks
        currentTurnEpoch.incrementAndGet()

        // Drain any pending chunks in channel
        while (!audioChannel.isEmpty) {
            audioChannel.tryReceive()
        }

        try {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.play()
        } catch (_: Exception) {}

        abandonAssistantAudioFocus()
        if (wasPlaying) {
            onPlaybackStateChanged(false)
        }
    }

    private fun requestAssistantAudioFocus() {
        val am = audioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (audioFocusRequest == null) {
                    val attrs = AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                    audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                        .setAudioAttributes(attrs)
                        .setAcceptsDelayedFocusGain(false)
                        .build()
                }
                audioFocusRequest?.let { am.requestAudioFocus(it) }
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(null, AudioManager.STREAM_VOICE_CALL, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            }
        } catch (_: Exception) {}
    }

    private fun abandonAssistantAudioFocus() {
        val am = audioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (_: Exception) {}
    }

    fun release() {
        val wasPlaying = isPlaying.getAndSet(false)
        playbackJob?.cancel()
        playbackJob = null
        scopeJob.cancel()
        currentTurnEpoch.incrementAndGet()
        while (!audioChannel.isEmpty) {
            audioChannel.tryReceive()
        }
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (_: Exception) {}
        audioTrack = null
        abandonAssistantAudioFocus()
        if (wasPlaying) {
            onPlaybackStateChanged(false)
        }
    }

    override fun close() {
        release()
    }
}
