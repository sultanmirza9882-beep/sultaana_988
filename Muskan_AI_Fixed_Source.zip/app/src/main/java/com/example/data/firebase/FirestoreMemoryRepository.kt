package com.example.data.firebase

import android.content.Context
import com.example.R
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class FirestoreMemoryRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {

    companion object {
        fun create(context: Context, auth: FirebaseAuth = FirebaseAuth.getInstance()): FirestoreMemoryRepository {
            val databaseId = runCatching {
                context.applicationContext.getString(R.string.firestore_database_id).trim()
            }.getOrDefault("")
            val db = if (databaseId.isNotBlank()) {
                FirebaseFirestore.getInstance(FirebaseApp.getInstance(), databaseId)
            } else {
                FirebaseFirestore.getInstance()
            }
            return FirestoreMemoryRepository(firestore = db, auth = auth)
        }
    }

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)

    private fun requireUserId(): String {
        return auth.currentUser?.uid ?: error("User must be signed in to perform Firestore memory operations")
    }

    val currentUserId: String?
        get() = auth.currentUser?.uid

    /**
     * Observes real-time approved memories for current user
     */
    fun observeUserMemories(): Flow<List<UserMemory>> = callbackFlow {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = firestore.collection("users")
            .document(uid)
            .collection("memories")
            .whereEqualTo("userId", uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val memories = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(UserMemory::class.java)
                } ?: emptyList()
                trySend(memories)
            }

        awaitClose { listener.remove() }
    }

    /**
     * Saves or updates a user memory
     */
    suspend fun saveMemory(
        content: String,
        category: String = "preference",
        tags: List<String> = emptyList(),
        memoryId: String = UUID.randomUUID().toString()
    ): UserMemory {
        val uid = requireUserId()
        val now = dateFormat.format(Date())
        val memory = UserMemory(
            memoryId = memoryId,
            userId = uid,
            content = content,
            category = category,
            tags = tags,
            isApproved = true,
            createdAt = now,
            updatedAt = now
        )

        firestore.collection("users")
            .document(uid)
            .collection("memories")
            .document(memoryId)
            .set(memory)
            .await()

        return memory
    }

    /**
     * Deletes a memory by ID
     */
    suspend fun deleteMemory(memoryId: String) {
        val uid = requireUserId()
        firestore.collection("users")
            .document(uid)
            .collection("memories")
            .document(memoryId)
            .delete()
            .await()
    }

    /**
     * Clears all memories for the current user
     */
    suspend fun clearAllMemories() {
        val uid = requireUserId()
        val docs = firestore.collection("users")
            .document(uid)
            .collection("memories")
            .get()
            .await()

        val batch = firestore.batch()
        for (doc in docs.documents) {
            batch.delete(doc.reference)
        }
        batch.commit().await()
    }

    /**
     * Fetches formatted memory context string to inject into Gemini Live system prompt
     */
    suspend fun loadRelevantMemoryPromptContext(): String {
        val uid = auth.currentUser?.uid ?: return ""
        return try {
            val snapshot = firestore.collection("users")
                .document(uid)
                .collection("memories")
                .whereEqualTo("userId", uid)
                .whereEqualTo("isApproved", true)
                .get()
                .await()

            val memories = snapshot.documents.mapNotNull { it.toObject(UserMemory::class.java) }
            if (memories.isEmpty()) return ""

            val builder = StringBuilder("User's Long-Term Verified Memories & Preferences:\n")
            memories.forEach { mem ->
                builder.append("- [${mem.category}]: ${mem.content}\n")
            }
            builder.toString()
        } catch (_: Exception) {
            ""
        }
    }

    /**
     * Observes user preferences
     */
    fun observeUserPreferences(): Flow<UserPreferences?> = callbackFlow {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val listener = firestore.collection("users")
            .document(uid)
            .collection("preferences")
            .document("default")
            .addSnapshotListener { snapshot, _ ->
                val prefs = snapshot?.toObject(UserPreferences::class.java)
                trySend(prefs)
            }

        awaitClose { listener.remove() }
    }

    /**
     * Saves user preferences
     */
    suspend fun saveUserPreferences(prefs: UserPreferences) {
        val uid = requireUserId()
        val updated = prefs.copy(
            userId = uid,
            updatedAt = dateFormat.format(Date())
        )
        firestore.collection("users")
            .document(uid)
            .collection("preferences")
            .document("default")
            .set(updated)
            .await()
    }

    /**
     * Records a conversation summary
     */
    suspend fun saveConversationSummary(
        title: String,
        summary: String,
        turnCount: Int,
        lastUserMessage: String,
        lastAssistantMessage: String
    ) {
        val uid = requireUserId()
        val now = dateFormat.format(Date())
        val recordId = UUID.randomUUID().toString()
        val record = ConversationSummaryRecord(
            conversationId = recordId,
            userId = uid,
            title = title,
            summary = summary,
            turnCount = turnCount,
            lastUserMessage = lastUserMessage,
            lastAssistantMessage = lastAssistantMessage,
            createdAt = now,
            updatedAt = now
        )

        firestore.collection("users")
            .document(uid)
            .collection("conversations")
            .document(recordId)
            .set(record)
            .await()
    }
}
