package com.example.data.gemini

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

enum class LiveSessionState {
    IDLE,
    CONNECTING,
    LISTENING,
    USER_SPEAKING,
    ASSISTANT_SPEAKING,
    RECONNECTING,
    ERROR
}

@JsonClass(generateAdapter = true)
data class LiveClientSetupMessage(
    @param:Json(name = "setup") val setup: LiveSetupConfig
)

@JsonClass(generateAdapter = true)
data class LiveSetupConfig(
    @param:Json(name = "model") val model: String = "models/gemini-2.0-flash-live-001",
    @param:Json(name = "generationConfig") val generationConfig: LiveGenerationConfig? = null,
    @param:Json(name = "systemInstruction") val systemInstruction: LiveSystemInstruction? = null,
    @param:Json(name = "contextWindowCompression") val contextWindowCompression: LiveContextWindowCompression? = null,
    @param:Json(name = "sessionResumption") val sessionResumption: LiveSessionResumptionConfig? = null,
    @param:Json(name = "realtimeInputConfig") val realtimeInputConfig: LiveRealtimeInputConfig? = null
)

@JsonClass(generateAdapter = true)
data class LiveRealtimeInputConfig(
    @param:Json(name = "automaticActivityDetection") val automaticActivityDetection: LiveAutomaticActivityDetection? = null
)

@JsonClass(generateAdapter = true)
data class LiveAutomaticActivityDetection(
    @param:Json(name = "startOfSpeechSensitivity") val startOfSpeechSensitivity: String? = null,
    @param:Json(name = "prefixPaddingMs") val prefixPaddingMs: Int? = null,
    @param:Json(name = "silenceDurationMs") val silenceDurationMs: Int? = null
)

@JsonClass(generateAdapter = true)
data class LiveContextWindowCompression(
    @param:Json(name = "slidingWindow") val slidingWindow: LiveSlidingWindow = LiveSlidingWindow()
)

@JsonClass(generateAdapter = true)
class LiveSlidingWindow

@JsonClass(generateAdapter = true)
data class LiveSessionResumptionConfig(
    @param:Json(name = "handle") val handle: String? = null
)

@JsonClass(generateAdapter = true)
data class LiveSessionResumptionUpdate(
    @param:Json(name = "newHandle") val newHandle: String? = null,
    @param:Json(name = "resumable") val resumable: Boolean? = null
)

@JsonClass(generateAdapter = true)
data class LiveGenerationConfig(
    @param:Json(name = "responseModalities") val responseModalities: List<String> = listOf("AUDIO"),
    @param:Json(name = "speechConfig") val speechConfig: LiveSpeechConfig? = null
)

@JsonClass(generateAdapter = true)
data class LiveSpeechConfig(
    @param:Json(name = "voiceConfig") val voiceConfig: LiveVoiceConfig? = null
)

@JsonClass(generateAdapter = true)
data class LiveVoiceConfig(
    @param:Json(name = "prebuiltVoiceConfig") val prebuiltVoiceConfig: LivePrebuiltVoiceConfig? = null
)

@JsonClass(generateAdapter = true)
data class LivePrebuiltVoiceConfig(
    @param:Json(name = "voiceName") val voiceName: String = "Aoede" // Warm natural female voice
)

@JsonClass(generateAdapter = true)
data class LiveSystemInstruction(
    @param:Json(name = "parts") val parts: List<LiveTextPart>
)

@JsonClass(generateAdapter = true)
data class LiveTextPart(
    @param:Json(name = "text") val text: String
)

@JsonClass(generateAdapter = true)
data class LiveRealtimeInputMessage(
    @param:Json(name = "realtimeInput") val realtimeInput: LiveRealtimeInput
)

@JsonClass(generateAdapter = true)
data class LiveRealtimeInput(
    @param:Json(name = "mediaChunks") val mediaChunks: List<LiveMediaChunk>
)

@JsonClass(generateAdapter = true)
data class LiveMediaChunk(
    @param:Json(name = "mimeType") val mimeType: String = "audio/pcm;rate=16000",
    @param:Json(name = "data") val data: String
)

@JsonClass(generateAdapter = true)
data class LiveClientContentMessage(
    @param:Json(name = "clientContent") val clientContent: LiveClientContent
)

@JsonClass(generateAdapter = true)
data class LiveClientContent(
    @param:Json(name = "turns") val turns: List<LiveTurn>,
    @param:Json(name = "turnComplete") val turnComplete: Boolean = true
)

@JsonClass(generateAdapter = true)
data class LiveTurn(
    @param:Json(name = "role") val role: String = "user",
    @param:Json(name = "parts") val parts: List<LiveTextPart>
)

// Server response payload models
@JsonClass(generateAdapter = true)
data class LiveServerMessage(
    @param:Json(name = "setupComplete") val setupComplete: Any? = null,
    @param:Json(name = "serverContent") val serverContent: LiveServerContent? = null,
    @param:Json(name = "toolCall") val toolCall: Any? = null,
    @param:Json(name = "error") val error: LiveServerError? = null,
    @param:Json(name = "sessionResumptionUpdate") val sessionResumptionUpdate: LiveSessionResumptionUpdate? = null,
    @param:Json(name = "goAway") val goAway: Any? = null
)

@JsonClass(generateAdapter = true)
data class LiveServerError(
    @param:Json(name = "code") val code: Int? = null,
    @param:Json(name = "message") val message: String? = null,
    @param:Json(name = "status") val status: String? = null
)

@JsonClass(generateAdapter = true)
data class LiveServerContent(
    @param:Json(name = "modelTurn") val modelTurn: LiveModelTurn? = null,
    @param:Json(name = "turnComplete") val turnComplete: Boolean? = null,
    @param:Json(name = "interrupted") val interrupted: Boolean? = null
)

@JsonClass(generateAdapter = true)
data class LiveModelTurn(
    @param:Json(name = "parts") val parts: List<LiveServerPart>? = null
)

@JsonClass(generateAdapter = true)
data class LiveServerPart(
    @param:Json(name = "text") val text: String? = null,
    @param:Json(name = "inlineData") val inlineData: LiveInlineData? = null
)

@JsonClass(generateAdapter = true)
data class LiveInlineData(
    @param:Json(name = "mimeType") val mimeType: String? = null,
    @param:Json(name = "data") val data: String? = null
)
