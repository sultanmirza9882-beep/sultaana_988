package com.example.data.local

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/**
 * Repository abstracting Room database operations for conversation turns.
 * Persists unlimited conversation interactions in the local Room SQLite database without auto-deletion.
 */
class ConversationRepository(
    private val dao: ConversationTurnDao,
    private val memoryDao: UserMemoryDao? = null
) {

    /**
     * Reactive stream of persistent user memories and custom instructions.
     */
    val allMemories: Flow<List<UserMemoryEntity>> =
        memoryDao?.getAllMemoriesFlow() ?: kotlinx.coroutines.flow.emptyFlow()

    suspend fun seedInitialMemoriesIfNeeded() = withContext(Dispatchers.IO) {
        if (memoryDao == null) return@withContext
        val existing = memoryDao.getAllMemories()
        if (existing.isEmpty()) {
            memoryDao.insertMemory(
                UserMemoryEntity(
                    category = "CREATOR",
                    title = "Developer & Creator",
                    detail = "Sultan Mirza is the lead developer, creator, and primary operator of Muskan.",
                    isPinned = true
                )
            )
            memoryDao.insertMemory(
                UserMemoryEntity(
                    category = "PREFERENCE",
                    title = "Ethereal Female Presence",
                    detail = "Warm, articulate female AI voice assistant with instantaneous spoken responses.",
                    isPinned = true
                )
            )
            memoryDao.insertMemory(
                UserMemoryEntity(
                    category = "INSTRUCTION",
                    title = "Language Flexibility",
                    detail = "Fluently replies in natural Hinglish (Roman English script) or English to match Sultan's prompt.",
                    isPinned = true
                )
            )
            memoryDao.insertMemory(
                UserMemoryEntity(
                    category = "CUSTOM",
                    title = "Storage & Biometrics",
                    detail = "Unlimited local Room SQLite logs with strict VAD and zero mechanical system beeps.",
                    isPinned = true
                )
            )
        }
    }

    suspend fun saveMemory(category: String, title: String, detail: String) = withContext(Dispatchers.IO) {
        memoryDao?.insertMemory(
            UserMemoryEntity(category = category, title = title, detail = detail)
        )
    }

    suspend fun deleteMemory(id: Long) = withContext(Dispatchers.IO) {
        memoryDao?.deleteMemoryById(id)
    }

    /**
     * Reactive stream of all conversation turns, ordered newest first.
     * Unconstrained local storage preserving complete history.
     */
    val allTurns: Flow<List<ConversationTurnEntity>> = dao.getAllTurnsFlow()

    /**
     * Reactive stream of the latest conversation turns.
     */
    val recentTurns: Flow<List<ConversationTurnEntity>> = dao.getAllTurnsFlow()

    /**
     * Reactive count of stored conversation turns.
     */
    val turnCount: Flow<Int> = dao.getTurnCountFlow()

    /**
     * Saves a completed conversation turn to the local Room database without auto-deletion.
     */
    suspend fun saveTurn(
        userQuery: String,
        assistantResponse: String,
        isAutomationAction: Boolean = false,
        actionTag: String? = null
    ): Long = withContext(Dispatchers.IO) {
        val entity = ConversationTurnEntity(
            userQuery = userQuery.trim(),
            assistantResponse = assistantResponse.trim(),
            timestamp = System.currentTimeMillis(),
            isAutomationAction = isAutomationAction,
            actionTag = actionTag
        )
        dao.insertTurn(entity)
    }

    /**
     * Fetches snapshot of all stored turns.
     */
    suspend fun getAllTurnsSnapshot(): List<ConversationTurnEntity> =
        withContext(Dispatchers.IO) {
            dao.getAllTurns()
        }

    /**
     * Fetches current snapshot of stored turns with optional limit.
     */
    suspend fun getRecentTurnsSnapshot(limit: Int = 100): List<ConversationTurnEntity> =
        withContext(Dispatchers.IO) {
            dao.getRecentTurns(limit)
        }

    /**
     * Deletes a single conversation turn by its database ID.
     */
    suspend fun deleteTurn(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteTurnById(id)
    }

    /**
     * Clears all saved turns from the local Room database.
     */
    suspend fun clearAllTurns() = withContext(Dispatchers.IO) {
        dao.clearAllTurns()
    }

    companion object {
        const val MAX_STORED_TURNS = 10
    }
}
