package com.example.data.gemini

import android.content.Context
import android.util.Base64
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.io.Closeable
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class GeminiLiveWebSocketClient(
    context: Context? = null,
    private val apiKeyProvider: () -> String,
    private val systemInstructionProvider: () -> String,
    private val onTranscriptReceived: (user: Boolean, text: String) -> Unit = { _, _ -> },
    private val onInterruptionDetected: () -> Unit = {},
    /** Runs a real phone action and returns a truthful result string ("SUCCESS: ..." / "FAILED: ..."). */
    private val onPhoneAction: suspend (command: String) -> String = { "FAILED: phone actions unavailable" }
) : Closeable {
    private var scopeJob = SupervisorJob()
    private var scope = CoroutineScope(scopeJob + Dispatchers.IO)
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    private val setupAdapter = moshi.adapter(LiveClientSetupMessage::class.java)
    private val realtimeInputAdapter = moshi.adapter(LiveRealtimeInputMessage::class.java)
    private val clientContentAdapter = moshi.adapter(LiveClientContentMessage::class.java)
    private val serverMessageAdapter = moshi.adapter(LiveServerMessage::class.java)

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS) // Continuous bidirectional streaming
        .writeTimeout(10, TimeUnit.SECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null
    @Volatile private var isTurnStreamingComplete = false
    private val audioPlayer = GeminiLiveAudioPlayer(context) { playing ->
        if (!playing && isTurnStreamingComplete && isSessionActive.get() &&
            _sessionState.value == LiveSessionState.ASSISTANT_SPEAKING) {
            isTurnStreamingComplete = false
            _sessionState.value = LiveSessionState.LISTENING
            _statusText.value = "Listening to you…"
        }
    }
    private val isSessionActive = AtomicBoolean(false)
    private val isSetupComplete = AtomicBoolean(false)

    private var reconnectJob: Job? = null
    private var reconnectAttempts = 0
    @Volatile private var resumptionHandle: String? = null
    private val maxReconnectAttempts = 200 // keep trying until the user stops the session

    // Real Gemini Multimodal Live BidiGenerateContent models in priority order
    private val candidateLiveModels = listOf(
        "models/gemini-2.0-flash-live-001",
        "models/gemini-2.5-flash-native-audio-preview-12-2025",
        "models/gemini-2.0-flash"
    )
    @Volatile private var activeModelIndex = 0

    private val _sessionState = MutableStateFlow(LiveSessionState.IDLE)
    val sessionState: StateFlow<LiveSessionState> = _sessionState.asStateFlow()

    private val _statusText = MutableStateFlow("Ready")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    fun startSession() {
        if (isSessionActive.get()) return
        if (!scopeJob.isActive) {
            scopeJob = SupervisorJob()
            scope = CoroutineScope(scopeJob + Dispatchers.IO)
        }
        isSessionActive.set(true)
        isSetupComplete.set(false)
        reconnectAttempts = 0
        resumptionHandle = null
        audioPlayer.start()
        connectWebSocket()
    }

    private fun connectWebSocket() {
        val apiKey = apiKeyProvider().trim()
        if (apiKey.isBlank()) {
            _sessionState.value = LiveSessionState.ERROR
            _statusText.value = "Gemini API key missing. Configure in Settings."
            return
        }

        _sessionState.value = if (reconnectAttempts > 0) LiveSessionState.RECONNECTING else LiveSessionState.CONNECTING
        _statusText.value = if (reconnectAttempts > 0) "Reconnecting to Muskaan Live…" else "Connecting to Muskaan Live…"

        // Official Gemini Multimodal Live API endpoint (API key passed via header so it never leaks in URLs/logs)
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"
        val request = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                _statusText.value = "Initializing Muskaan Live session…"
                sendSetupHandshake(ws)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                handleServerMessage(text)
            }

            override fun onClosing(ws: WebSocket, code: Int, reason: String) {
                ws.close(1000, null)
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                android.util.Log.w("GeminiLive", "WebSocket closed code=$code reason=$reason")
                isSetupComplete.set(false)
                if (isSessionActive.get()) {
                    scheduleReconnect()
                } else {
                    _sessionState.value = LiveSessionState.IDLE
                    _statusText.value = "Session ended"
                }
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                isSetupComplete.set(false)
                val code = response?.code

                // Non-retryable authentication / permission failures
                if (code == 400 || code == 401 || code == 403) {
                    _sessionState.value = LiveSessionState.ERROR
                    _statusText.value = "API authentication error (HTTP $code). Verify Gemini API key."
                    audioPlayer.stopAndFlush()
                    return
                }

                if (isSessionActive.get()) {
                    scheduleReconnect()
                } else {
                    _sessionState.value = LiveSessionState.ERROR
                    _statusText.value = "Connection failed: ${t.localizedMessage ?: "Network error"}"
                }
            }
        })
    }

    private fun sendSetupHandshake(ws: WebSocket) {
        val instructionText = systemInstructionProvider()
        val selectedModel = candidateLiveModels[activeModelIndex % candidateLiveModels.size]
        val setupPayload = LiveClientSetupMessage(
            setup = LiveSetupConfig(
                model = selectedModel,
                generationConfig = LiveGenerationConfig(
                    responseModalities = listOf("AUDIO"),
                    speechConfig = LiveSpeechConfig(
                        voiceConfig = LiveVoiceConfig(
                            prebuiltVoiceConfig = LivePrebuiltVoiceConfig(voiceName = "Aoede")
                        )
                    )
                ),
                systemInstruction = LiveSystemInstruction(
                    parts = listOf(LiveTextPart(text = instructionText))
                ),
                contextWindowCompression = LiveContextWindowCompression(),
                sessionResumption = LiveSessionResumptionConfig(handle = resumptionHandle),
                // Server-side voice detection: ignore short noises, wait ~0.8s of silence before the
                // user's turn ends (natural pauses don't cut the sentence), like the Gemini Live app
                realtimeInputConfig = LiveRealtimeInputConfig(
                    automaticActivityDetection = LiveAutomaticActivityDetection(
                        startOfSpeechSensitivity = "START_SENSITIVITY_LOW",
                        prefixPaddingMs = 100,
                        silenceDurationMs = 800
                    )
                )
            )
        )
        // Declare the phone_action tool so the live model can ACT instead of only talking.
        val root = org.json.JSONObject(setupAdapter.toJson(setupPayload))
        val tools = org.json.JSONArray().put(
            org.json.JSONObject().put("functionDeclarations", org.json.JSONArray().put(
                org.json.JSONObject()
                    .put("name", "phone_action")
                    .put("description",
                        "Performs a REAL action on Sultan's phone screen: open apps, scroll reels, search/play YouTube, " +
                        "send WhatsApp/SMS, create a note and write text in it, type text on screen, tap, sketch. " +
                        "ALWAYS call this for any request to do something on the phone. Pass Sultan's request in his own " +
                        "words (Hinglish/Hindi). It returns SUCCESS or FAILED after verifying the screen; tell Sultan only that result.")
                    .put("parameters", org.json.JSONObject()
                        .put("type", "OBJECT")
                        .put("properties", org.json.JSONObject().put("command", org.json.JSONObject()
                            .put("type", "STRING")
                            .put("description", "Sultan's full request, e.g. 'google notes mein 20 line ki shayari likh kar save karo'")))
                        .put("required", org.json.JSONArray().put("command")))
            ))
        )
        root.getJSONObject("setup").put("tools", tools)
        ws.send(root.toString())
    }

    private fun handleServerMessage(jsonText: String) {
        try {
            val message = serverMessageAdapter.fromJson(jsonText) ?: return

            // 1. Check for server error events (with automatic model fallback if model is unsupported)
            if (message.error != null) {
                val err = message.error
                val errMsg = err.message ?: "Server error (${err.code ?: "unknown"})"
                val isModelError = err.code == 404 ||
                        errMsg.contains("model", ignoreCase = true) ||
                        errMsg.contains("not found", ignoreCase = true) ||
                        errMsg.contains("not supported", ignoreCase = true)
                if (isModelError && activeModelIndex + 1 < candidateLiveModels.size && isSessionActive.get()) {
                    activeModelIndex++
                    _statusText.value = "Switching to compatible Gemini Live model…"
                    try { webSocket?.cancel() } catch (_: Exception) {}
                    scheduleReconnect()
                    return
                }
                _sessionState.value = LiveSessionState.ERROR
                _statusText.value = "Gemini Live: $errMsg"
                audioPlayer.stopAndFlush()
                return
            }

            // 2. Check for setupComplete signal from Gemini Live
            if (message.setupComplete != null) {
                isSetupComplete.set(true)
                reconnectAttempts = 0
                _sessionState.value = LiveSessionState.LISTENING
                _statusText.value = "Muskaan Live is listening • Speak naturally"
                return
            }

            // Keep the latest resumption token so a dropped connection continues the same session
            message.sessionResumptionUpdate?.let { update ->
                if (update.resumable == true && !update.newHandle.isNullOrBlank()) {
                    resumptionHandle = update.newHandle
                }
            }
            if (message.goAway != null) {
                android.util.Log.w("GeminiLive", "GoAway received: connection will close soon, will resume")
            }

            // Tool call: run the real phone action, then answer with the verified result
            (message.toolCall as? Map<*, *>)?.let { tc ->
                val calls = tc["functionCalls"] as? List<*> ?: emptyList<Any>()
                for (c in calls) {
                    val call = c as? Map<*, *> ?: continue
                    val id = call["id"]?.toString().orEmpty()
                    val name = call["name"]?.toString().orEmpty()
                    val command = ((call["args"] as? Map<*, *>)?.get("command"))?.toString().orEmpty()
                    scope.launch {
                        _statusText.value = "Muskan kaam kar rahi hai…"
                        val result = if (name == "phone_action" && command.isNotBlank()) {
                            try { onPhoneAction(command) } catch (e: Exception) { "FAILED: ${e.message}" }
                        } else "FAILED: unknown tool or empty command"
                        sendToolResponse(id, name, result)
                    }
                }
                return
            }

            val serverContent = message.serverContent ?: return

            // 3. Handle server-side interruption signal from Gemini Live
            if (serverContent.interrupted == true) {
                isTurnStreamingComplete = false
                audioPlayer.stopAndFlush()
                _sessionState.value = LiveSessionState.USER_SPEAKING
                _statusText.value = "Listening to you…"
                onInterruptionDetected()
                return
            }

            // 4. Handle incoming model response parts (audio + transcript)
            val parts = serverContent.modelTurn?.parts
            if (!parts.isNullOrEmpty()) {
                isTurnStreamingComplete = false
                _sessionState.value = LiveSessionState.ASSISTANT_SPEAKING
                _statusText.value = "Muskaan is speaking…"

                for (part in parts) {
                    part.text?.let { txt ->
                        if (txt.isNotBlank()) {
                            onTranscriptReceived(false, txt)
                        }
                    }
                    val inlineData = part.inlineData
                    if (inlineData != null && !inlineData.data.isNullOrBlank()) {
                        val pcmBytes = Base64.decode(inlineData.data, Base64.DEFAULT)
                        if (isSessionActive.get()) {
                            audioPlayer.playChunk(pcmBytes)
                        }
                    }
                }
            }

            // 5. Handle turn completion (wait for buffered tail audio to drain before un-gating mic)
            if (serverContent.turnComplete == true) {
                if (!audioPlayer.isCurrentlyPlaying) {
                    isTurnStreamingComplete = false
                    _sessionState.value = LiveSessionState.LISTENING
                    _statusText.value = "Listening to you…"
                } else {
                    isTurnStreamingComplete = true
                }
            }
        } catch (_: Exception) {}
    }

    /**
     * Streams 16kHz PCM audio chunk to the Gemini Live session.
     * Guaranteed never to send audio before setupComplete handshake.
     */
    fun sendAudioChunk(pcmBytes: ByteArray) {
        val ws = webSocket ?: return
        if (!isSessionActive.get() || !isSetupComplete.get()) return

        val base64 = Base64.encodeToString(pcmBytes, Base64.NO_WRAP)
        val payload = LiveRealtimeInputMessage(
            realtimeInput = LiveRealtimeInput(
                mediaChunks = listOf(
                    LiveMediaChunk(
                        mimeType = "audio/pcm;rate=16000",
                        data = base64
                    )
                )
            )
        )
        ws.send(realtimeInputAdapter.toJson(payload))
    }

    private fun sendToolResponse(id: String, name: String, result: String) {
        val ws = webSocket ?: return
        val payload = org.json.JSONObject().put("toolResponse", org.json.JSONObject().put(
            "functionResponses", org.json.JSONArray().put(
                org.json.JSONObject().put("id", id).put("name", name)
                    .put("response", org.json.JSONObject().put("result", result))
            )))
        ws.send(payload.toString())
    }

    /**
     * Triggers client-side instant interruption when user speech is detected during assistant playback.
     */
    fun handleLocalBargeIn() {
        if (_sessionState.value == LiveSessionState.ASSISTANT_SPEAKING) {
            isTurnStreamingComplete = false
            audioPlayer.stopAndFlush()
            _sessionState.value = LiveSessionState.USER_SPEAKING
            _statusText.value = "Listening to you…"
            onInterruptionDetected()
        }
    }

    /**
     * Sends proactive context-aware question or inactivity prompt into the live turn.
     */
    fun sendProactivePrompt(text: String) {
        val ws = webSocket ?: return
        if (!isSessionActive.get() || !isSetupComplete.get()) return
        val message = LiveClientContentMessage(
            clientContent = LiveClientContent(
                turns = listOf(
                    LiveTurn(
                        role = "user",
                        parts = listOf(LiveTextPart(text = "[PROACTIVE CONVERSATION PROMPT]: $text"))
                    )
                ),
                turnComplete = true
            )
        )
        ws.send(clientContentAdapter.toJson(message))
    }

    private fun scheduleReconnect() {
        if (!isSessionActive.get()) return
        if (reconnectAttempts >= maxReconnectAttempts) {
            _sessionState.value = LiveSessionState.ERROR
            _statusText.value = "Unable to reconnect after $maxReconnectAttempts attempts. Tap mic to retry."
            return
        }

        reconnectAttempts++
        _sessionState.value = LiveSessionState.RECONNECTING
        _statusText.value = "Reconnecting (attempt $reconnectAttempts of $maxReconnectAttempts)…"

        // Prevent duplicate concurrent reconnect jobs
        if (reconnectJob?.isActive == true) return

        reconnectJob = scope.launch {
            val backoffMs = minOf(1000L * (1 shl (reconnectAttempts - 1).coerceAtMost(3)), 8000L)
            delay(backoffMs)
            if (isActive && isSessionActive.get()) {
                connectWebSocket()
            }
        }
    }

    fun stopSession() {
        isSessionActive.set(false)
        isSetupComplete.set(false)
        isTurnStreamingComplete = false
        resumptionHandle = null
        reconnectJob?.cancel()
        reconnectJob = null
        scopeJob.cancelChildren()
        try {
            webSocket?.close(1000, "User ended session")
        } catch (_: Exception) {}
        webSocket = null
        audioPlayer.stopAndFlush()
        audioPlayer.release()
        _sessionState.value = LiveSessionState.IDLE
        _statusText.value = "Session ended"
    }

    fun release() {
        stopSession()
        scopeJob.cancel()
        try {
            client.dispatcher.executorService.shutdown()
            client.connectionPool.evictAll()
        } catch (_: Exception) {}
    }

    override fun close() {
        release()
    }
}
