package com.example.data.local

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import java.util.UUID

/**
 * Room entity representing a user-taught automated workflow, voice macro, or routine.
 * Enables Muskan to remember multi-step sequences triggered by voice phrases or manual taps.
 */
@Entity(tableName = "taught_workflows")
data class TaughtWorkflowEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "workflow_id")
    val workflowId: String = UUID.randomUUID().toString(),

    @ColumnInfo(name = "title")
    val title: String,

    @ColumnInfo(name = "trigger_phrase")
    val triggerPhrase: String,

    @ColumnInfo(name = "description")
    val description: String = "",

    @ColumnInfo(name = "steps_json")
    val stepsJson: String, // JSON array of ActionStep

    @ColumnInfo(name = "is_enabled")
    val isEnabled: Boolean = true,

    @ColumnInfo(name = "execution_count")
    val executionCount: Int = 0,

    @ColumnInfo(name = "last_executed_at")
    val lastExecutedAt: Long = 0L,

    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface TaughtWorkflowDao {

    @Query("SELECT * FROM taught_workflows ORDER BY created_at DESC")
    fun getAllWorkflowsFlow(): Flow<List<TaughtWorkflowEntity>>

    @Query("SELECT * FROM taught_workflows ORDER BY created_at DESC")
    suspend fun getAllWorkflows(): List<TaughtWorkflowEntity>

    @Query("SELECT * FROM taught_workflows WHERE is_enabled = 1")
    suspend fun getEnabledWorkflows(): List<TaughtWorkflowEntity>

    @Query("SELECT * FROM taught_workflows WHERE workflow_id = :workflowId LIMIT 1")
    suspend fun getWorkflowById(workflowId: String): TaughtWorkflowEntity?

    @Query("SELECT * FROM taught_workflows WHERE id = :id LIMIT 1")
    suspend fun getWorkflowByRowId(id: Long): TaughtWorkflowEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkflow(workflow: TaughtWorkflowEntity): Long

    @Update
    suspend fun updateWorkflow(workflow: TaughtWorkflowEntity)

    @Delete
    suspend fun deleteWorkflow(workflow: TaughtWorkflowEntity)

    @Query("DELETE FROM taught_workflows WHERE id = :id")
    suspend fun deleteWorkflowById(id: Long)

    @Query("DELETE FROM taught_workflows WHERE workflow_id = :workflowId")
    suspend fun deleteWorkflowByUuid(workflowId: String)

    @Query("UPDATE taught_workflows SET execution_count = execution_count + 1, last_executed_at = :timestamp WHERE id = :id")
    suspend fun recordExecution(id: Long, timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM taught_workflows")
    suspend fun clearAllWorkflows()
}
