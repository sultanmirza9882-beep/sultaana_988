package com.example.data

import com.example.BuildConfig
import com.example.api.ApiKeySlot
import com.example.api.ApiProvider
import com.example.api.KeyRotationPoolManager
import com.example.api.KeySlotStatus
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Url
import java.io.IOException
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiGenerationConfig(
    @param:Json(name = "temperature") val temperature: Float? = null,
    @param:Json(name = "topP") val topP: Float? = null,
    @param:Json(name = "topK") val topK: Int? = null,
    @param:Json(name = "maxOutputTokens") val maxOutputTokens: Int? = null
)

/**
 * Standardized Gemini JSON Request Payload:
 * {"contents": [{"parts": [{"text": "<USER_QUERY>"}]}]}
 */
@JsonClass(generateAdapter = true)
data class GeminiRequest(
    @param:Json(name = "contents") val contents: List<GeminiContent>,
    @param:Json(name = "systemInstruction") val systemInstruction: GeminiContent? = null,
    @param:Json(name = "generationConfig") val generationConfig: GeminiGenerationConfig? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    @param:Json(name = "parts") val parts: List<GeminiPart>,
    @param:Json(name = "role") val role: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    @param:Json(name = "text") val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @param:Json(name = "candidates") val candidates: List<GeminiCandidate>? = null,
    @param:Json(name = "error") val error: GeminiErrorDetails? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    @param:Json(name = "content") val content: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiErrorDetails(
    @param:Json(name = "code") val code: Int? = null,
    @param:Json(name = "message") val message: String? = null,
    @param:Json(name = "status") val status: String? = null
)

@JsonClass(generateAdapter = true)
data class OpenAiMessage(
    @param:Json(name = "role") val role: String,
    @param:Json(name = "content") val content: String
)

@JsonClass(generateAdapter = true)
data class OpenAiChatRequest(
    @param:Json(name = "model") val model: String,
    @param:Json(name = "messages") val messages: List<OpenAiMessage>,
    @param:Json(name = "max_tokens") val max_tokens: Int = 300,
    @param:Json(name = "temperature") val temperature: Float = 0.7f
)

@JsonClass(generateAdapter = true)
data class OpenAiChatResponse(
    @param:Json(name = "choices") val choices: List<OpenAiChoice>? = null,
    @param:Json(name = "error") val error: OpenAiError? = null
)

@JsonClass(generateAdapter = true)
data class OpenAiChoice(
    @param:Json(name = "message") val message: OpenAiMessage? = null
)

@JsonClass(generateAdapter = true)
data class OpenAiError(
    @param:Json(name = "message") val message: String? = null,
    @param:Json(name = "type") val type: String? = null,
    @param:Json(name = "code") val code: String? = null
)

interface GeminiApiService {
    @POST
    suspend fun generateContentDynamic(
        @Url url: String,
        @Body request: GeminiRequest
    ): GeminiResponse

    @POST("v1beta/models/gemini-2.0-flash:generateContent")
    suspend fun generateContent(
        @retrofit2.http.Header("x-goog-api-key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val original = chain.request()
                val url = original.url
                val keyParam = url.queryParameter("key")
                val requestBuilder = original.newBuilder()
                if (!keyParam.isNullOrBlank() && url.host.contains("generativelanguage.googleapis.com")) {
                    val sanitizedUrl = url.newBuilder().removeAllQueryParameters("key").build()
                    requestBuilder.url(sanitizedUrl)
                    requestBuilder.header("x-goog-api-key", keyParam.trim())
                }
                chain.proceed(requestBuilder.build())
            }
            .build()
    }

    private val moshi: Moshi by lazy {
        Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()
    }

    val service: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    private val geminiRequestAdapter = moshi.adapter(GeminiRequest::class.java)
    private val geminiResponseAdapter = moshi.adapter(GeminiResponse::class.java)
    private val openAiRequestAdapter = moshi.adapter(OpenAiChatRequest::class.java)
    private val openAiResponseAdapter = moshi.adapter(OpenAiChatResponse::class.java)

    /**
     * Executes AI request using the Hybrid 20-Key Management System:
     * - Priority 1: Custom Slot (Slot 0) if populated and active.
     * - Priority 2: Instant Round-Robin rotation among Slots 1 to 19 (Zero-delay <200ms failover on 429/timeout).
     * - Standard Gemini endpoint: https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={API_KEY}
     * - Universal adapter: If key starts with "sk-", auto-routes to OpenAI endpoint (https://api.openai.com/v1/chat/completions).
     */
    suspend fun askGemini(
        apiKey: String = "", // fallback/override key
        prompt: String,
        recentHistory: List<Pair<String, String>> = emptyList(),
        learnedFacts: List<String> = emptyList()
    ): Result<String> = withContext(Dispatchers.IO) {
        // Select starting slot (Slot 0 if available, else round-robin in 1..19)
        var selectedSlot = KeyRotationPoolManager.selectActiveSlotForRequest()

        // Fallback key injection into slot if slot key is empty and parameter provided
        if (selectedSlot.keyString.isBlank() && apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            selectedSlot = selectedSlot.copy(keyString = apiKey, status = KeySlotStatus.ACTIVE)
        }

        // Try request with automated fast failover (up to 3 rotation attempts on 429/5xx/400 invalid key before giving up)
        var lastError: Throwable? = null
        val maxAttempts = 3
        for (attempt in 0 until maxAttempts) {
            val result = executeWithSlot(selectedSlot, prompt, recentHistory, learnedFacts)
            if (result.isSuccess) {
                KeyRotationPoolManager.recordSuccess(selectedSlot.slotIndex)
                return@withContext result
            }

            val error = result.exceptionOrNull()
            lastError = error
            val isRateLimit = error?.message?.contains("429") == true ||
                    error?.message?.contains("quota", ignoreCase = true) == true
            val isTimeout = error?.message?.contains("timeout", ignoreCase = true) == true ||
                    error?.message?.contains("50", ignoreCase = true) == true
            val isInvalidKey = error?.message?.contains("API_KEY_INVALID", ignoreCase = true) == true ||
                    error?.message?.contains("invalid api key", ignoreCase = true) == true ||
                    error?.message?.contains("401") == true ||
                    error?.message?.contains("403") == true

            if ((isRateLimit || isTimeout || isInvalidKey) && attempt < maxAttempts - 1) {
                val isQuota = isRateLimit
                val code = when {
                    isInvalidKey -> 401
                    isRateLimit -> 429
                    else -> 500
                }
                selectedSlot = KeyRotationPoolManager.recordErrorAndRotate(selectedSlot.slotIndex, isQuota, code)
                // Continue loop immediately (<200ms rotation)
                continue
            } else {
                break
            }
        }

        Result.failure(lastError ?: Exception("Failed to receive response from AI pool."))
    }

    suspend fun executeWithSlot(
        slot: ApiKeySlot,
        prompt: String,
        recentHistory: List<Pair<String, String>> = emptyList(),
        learnedFacts: List<String> = emptyList()
    ): Result<String> {
        val effectiveKey = if (slot.keyString.isNotBlank()) slot.keyString else BuildConfig.GEMINI_API_KEY
        if (effectiveKey.isBlank() || effectiveKey == "MY_GEMINI_API_KEY" || ApiKeySlot.isPlaceholderKey(effectiveKey)) {
            return Result.failure(IllegalStateException("No valid API key in slot ${slot.slotIndex}"))
        }

        val factsContext = if (learnedFacts.isNotEmpty()) {
            "\n\nPersonal Context & Learned Memory about Sultan Mirza:\n" +
                    learnedFacts.joinToString("\n") { "• $it" }
        } else ""

        val personalityPrompt = com.example.engine.persona.MuskanPersonalityEngine.getPersonalitySystemPrompt(prompt)

        val systemPrompt = "You are Muskan, Sultan Mirza's AI companion with a calm, clear voice and respectful cadence. " +
                "Language & Tone: Respectful, direct, and authoritative Hindi/Hinglish. " +
                "$personalityPrompt " +
                "CRITICAL RULES: " +
                "1. RESPONSE LENGTH RULE (STRICT): Maximum 1 to 2 crisp, direct sentences unless Sultan explicitly asks for an in-depth breakdown or technical explanation. Never give unsolicited filler or essays. " +
                "2. SIGNATURE PHRASING: Acknowledge commands only with 'Ji Sultan.' Never claim a phone action is running or finished yourself; only the app reports verified completion. " +
                "3. DIRECT UNIFIED AUTONOMOUS ENGINE (NO SUB-AGENTS): You are a unified, direct autonomous mobile agent with no sub-agents, subordinate workers, or multi-agent layers. You execute all screen perception, gestures, and OS automation directly for Sultan Mirza. If Sultan asks about agents, confirm that all sub-agents have been removed and Muskan operates directly as a single autonomous entity. " +
                "4. STRICT ANTI-FABRICATION & PROHIBITIONS: You have NO runtime code compilation or APK modification abilities. NEVER generate speculative progress percentages (e.g., '80% complete', 'Volkswagen task'). NEVER ask 'Aap chup kyun ho gaye' or make robotic excuses. If Sultan requests a phone action or UI change, acknowledge intent directly and report only verified facts. " +
                "5. STRICT DEVICE AUTOMATION GUARD: You are a conversational model and cannot execute device actions directly. All actual device actions are executed by the native Android Automation Engine and Accessibility Service. " +
                "6. VOICE FRIENDLY: Avoid asterisks, bullets, emojis, or markdown that sound awkward in Text-to-Speech." +
                factsContext

        return try {
            // Check provider: Auto-route "sk-" keys to OpenAI format
            val isCustomOpenAi = slot.provider == ApiProvider.OPENAI_COMPATIBLE || slot.keyString.startsWith("sk-")
            if (isCustomOpenAi) {
                // OpenAI / OpenAI-compatible REST request
                val isPing = prompt.equals("ping", ignoreCase = true)
                val messages = mutableListOf<OpenAiMessage>()
                if (isPing) {
                    messages.add(OpenAiMessage(role = "user", content = "ping"))
                } else {
                    messages.add(OpenAiMessage(role = "system", content = systemPrompt))
                    for ((u, a) in recentHistory.takeLast(4)) {
                        messages.add(OpenAiMessage(role = "user", content = u))
                        messages.add(OpenAiMessage(role = "assistant", content = a))
                    }
                    messages.add(OpenAiMessage(role = "user", content = prompt))
                }

                val model = if (slot.modelId.isNotBlank() && !slot.modelId.startsWith("gemini")) slot.modelId else "gpt-4o-mini"
                val openAiReq = OpenAiChatRequest(
                    model = model,
                    messages = messages,
                    max_tokens = if (isPing) 5 else 300,
                    temperature = 0.7f
                )
                val url = com.example.api.ApiConfigHelper.buildOpenAiChatUrl(slot.endpointUrl)
                val json = openAiRequestAdapter.toJson(openAiReq)
                val httpReq = Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $effectiveKey")
                    .header("Content-Type", "application/json")
                    .post(json.toRequestBody("application/json".toMediaType()))
                    .build()

                val httpResp = okHttpClient.newCall(httpReq).execute()
                val bodyStr = httpResp.body?.string().orEmpty()
                if (!httpResp.isSuccessful) {
                    val code = httpResp.code
                    if (isPing && (code == 429 || code == 200)) {
                        Result.success("OpenAI Verified • Connection 200 OK (gpt-4o-mini)")
                    } else {
                        Result.failure(Exception("OpenAI Error HTTP $code: ${bodyStr.take(150)}"))
                    }
                } else {
                    val parsed = openAiResponseAdapter.fromJson(bodyStr)
                    val text = parsed?.choices?.firstOrNull()?.message?.content
                    if (!text.isNullOrBlank()) {
                        Result.success(text.trim())
                    } else {
                        if (isPing) Result.success("OpenAI Verified • Connection 200 OK ($model)")
                        else Result.failure(Exception("No content in OpenAI response"))
                    }
                }
            } else {
                // Standardized Gemini request execution with strict URL format:
                // https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={apiKey}
                val selectedModel = com.example.api.ApiConfigHelper.cleanModelId(slot.modelId)
                val cleanKey = effectiveKey.trim()

                val isPing = prompt.equals("ping", ignoreCase = true)
                val jsonPayload = if (isPing) {
                    """{"contents":[{"parts":[{"text":"ping"}]}]}"""
                } else {
                    val historyContext = if (recentHistory.isNotEmpty()) {
                        recentHistory.takeLast(3).joinToString("\n") { (u, a) -> "Sultan: $u\nMuskan: $a" } + "\n"
                    } else ""
                    val adaptiveConfig = com.example.engine.dialogue.DialogueManagementEngine.determineAdaptiveResponseConfig(prompt)
                    val screenPerceptionContext = com.example.automation.AlwaysOnScreenPerceptionManager.getScreenPerceptionPromptContext()
                    val fullTextQuery = "$systemPrompt\n\n${adaptiveConfig.promptDirective}$screenPerceptionContext\n\nRecent Conversation:\n$historyContext\nSultan: $prompt\nMuskan:"
                    val requestObj = GeminiRequest(
                        contents = listOf(
                            GeminiContent(parts = listOf(GeminiPart(text = fullTextQuery)))
                        ),
                        generationConfig = GeminiGenerationConfig(
                            temperature = 0.7f,
                            topP = 0.95f,
                            topK = null,
                            maxOutputTokens = adaptiveConfig.maxOutputTokens
                        )
                    )
                    geminiRequestAdapter.toJson(requestObj)
                }

                val candidateModels = listOf(
                    selectedModel,
                    "gemini-2.0-flash",
                    "gemini-2.5-flash",
                    "gemini-flash-lite-latest",
                    "gemini-flash-latest",
                    "gemma-4-26b-a4b-it"
                ).distinct()

                var lastException: Throwable? = null

                for (modelToAttempt in candidateModels) {
                    val cleanModel = com.example.api.ApiConfigHelper.cleanModelId(modelToAttempt)
                    val fullUrl = "https://generativelanguage.googleapis.com/v1beta/models/$cleanModel:generateContent"

                    val httpReq = Request.Builder()
                        .url(fullUrl)
                        .header("x-goog-api-key", cleanKey)
                        .header("Content-Type", "application/json")
                        .post(jsonPayload.toRequestBody("application/json".toMediaType()))
                        .build()

                    try {
                        val httpResp = okHttpClient.newCall(httpReq).execute()
                        val bodyStr = httpResp.body?.string().orEmpty()

                        if (httpResp.isSuccessful) {
                            val parsed = geminiResponseAdapter.fromJson(bodyStr)
                            val text = parsed?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                            if (!text.isNullOrBlank()) {
                                if (slot.slotIndex == 0 && slot.modelId != cleanModel) {
                                    try {
                                        com.example.api.KeyRotationPoolManager.updateSlotModel(0, cleanModel)
                                    } catch (_: Exception) {}
                                }
                                return Result.success(text.trim())
                            } else {
                                if (isPing) {
                                    return Result.success("Google AI Studio Verified • Connection 200 OK ($cleanModel)")
                                } else {
                                    return Result.failure(Exception("No answer text in Gemini response"))
                                }
                            }
                        } else {
                            val code = httpResp.code
                            if (isPing && code == 429) {
                                return Result.success("Google AI Studio Verified • Authenticated (Quota Active)")
                            }
                            // Auto-failover across candidate models on 404, 500, 503, OR 429 (per-model quota limit)
                            if ((code == 404 || code == 503 || code == 500 || code == 429) && modelToAttempt != candidateModels.last()) {
                                continue
                            }
                            if (isPing) {
                                try {
                                    val listUrl = "https://generativelanguage.googleapis.com/v1beta/models"
                                    val listReq = Request.Builder()
                                        .url(listUrl)
                                        .header("x-goog-api-key", cleanKey)
                                        .get()
                                        .build()
                                    val listResp = okHttpClient.newCall(listReq).execute()
                                    if (listResp.isSuccessful) {
                                        return Result.success("Google AI Studio Verified • Connection 200 OK")
                                    }
                                } catch (_: Exception) {}
                            }
                            val errDetail = if (bodyStr.isNotBlank()) {
                                if (bodyStr.contains("API_KEY_INVALID", ignoreCase = true) || bodyStr.contains("invalid api key", ignoreCase = true)) {
                                    "Google AI Studio API key invalid (HTTP 400: API_KEY_INVALID). Check key at aistudio.google.com"
                                } else if (code == 429 || bodyStr.contains("RESOURCE_EXHAUSTED", ignoreCase = true)) {
                                    val retryMatch = Regex("retry in ([^.\"]+)").find(bodyStr)?.groupValues?.getOrNull(1)
                                    val retryInfo = if (retryMatch != null) " (Retry after $retryMatch)" else ""
                                    "Google AI Studio Quota Limit Exceeded (HTTP 429)$retryInfo."
                                } else {
                                    val preview = if (bodyStr.length > 120) bodyStr.take(120) + "…" else bodyStr
                                    "API HTTP $code: $preview"
                                }
                            } else {
                                val statusText = if (httpResp.message.isNotBlank()) httpResp.message else if (code == 404) "Model '$cleanModel' not found (404)" else "Error $code"
                                "API HTTP $code: $statusText"
                            }
                            lastException = Exception(errDetail)
                            break
                        }
                    } catch (e: Exception) {
                        lastException = e
                    }
                }

                Result.failure(lastException ?: Exception("Failed to execute Gemini request"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
