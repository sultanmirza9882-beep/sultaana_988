package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for persisting and querying conversation turns in Room SQLite.
 * Strictly manages the latest conversation turns.
 */
@Dao
interface ConversationTurnDao {

    @Query("SELECT * FROM conversation_turns ORDER BY timestamp DESC")
    fun getAllTurnsFlow(): Flow<List<ConversationTurnEntity>>

    @Query("SELECT * FROM conversation_turns ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentTurnsFlow(limit: Int): Flow<List<ConversationTurnEntity>>

    @Query("SELECT * FROM conversation_turns ORDER BY timestamp DESC")
    suspend fun getAllTurns(): List<ConversationTurnEntity>

    @Query("SELECT * FROM conversation_turns ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentTurns(limit: Int): List<ConversationTurnEntity>

    @Query("SELECT COUNT(*) FROM conversation_turns")
    fun getTurnCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTurn(turn: ConversationTurnEntity): Long

    @Query("DELETE FROM conversation_turns WHERE id NOT IN (SELECT id FROM conversation_turns ORDER BY timestamp DESC LIMIT :maxTurns)")
    suspend fun pruneOldTurns(maxTurns: Int)

    @Query("DELETE FROM conversation_turns WHERE id = :id")
    suspend fun deleteTurnById(id: Long)

    @Query("DELETE FROM conversation_turns")
    suspend fun clearAllTurns()
}
