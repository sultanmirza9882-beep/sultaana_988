package com.example.data.firebase

import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName

@IgnoreExtraProperties
data class UserMemory(
    @get:PropertyName("memoryId") @set:PropertyName("memoryId") var memoryId: String = "",
    @get:PropertyName("userId") @set:PropertyName("userId") var userId: String = "",
    @get:PropertyName("content") @set:PropertyName("content") var content: String = "",
    @get:PropertyName("category") @set:PropertyName("category") var category: String = "preference",
    @get:PropertyName("tags") @set:PropertyName("tags") var tags: List<String> = emptyList(),
    @get:PropertyName("isApproved") @set:PropertyName("isApproved") var isApproved: Boolean = true,
    @get:PropertyName("createdAt") @set:PropertyName("createdAt") var createdAt: String = "",
    @get:PropertyName("updatedAt") @set:PropertyName("updatedAt") var updatedAt: String = ""
)

@IgnoreExtraProperties
data class UserPreferences(
    @get:PropertyName("userId") @set:PropertyName("userId") var userId: String = "",
    @get:PropertyName("assistantPersona") @set:PropertyName("assistantPersona") var assistantPersona: String = "Muskaan (Supportive & Caring Friend)",
    @get:PropertyName("proactiveQuestionsEnabled") @set:PropertyName("proactiveQuestionsEnabled") var proactiveQuestionsEnabled: Boolean = true,
    @get:PropertyName("inactivitySeconds") @set:PropertyName("inactivitySeconds") var inactivitySeconds: Int = 25,
    @get:PropertyName("cooldownSeconds") @set:PropertyName("cooldownSeconds") var cooldownSeconds: Int = 60,
    @get:PropertyName("femaleVoiceOnly") @set:PropertyName("femaleVoiceOnly") var femaleVoiceOnly: Boolean = true,
    @get:PropertyName("updatedAt") @set:PropertyName("updatedAt") var updatedAt: String = ""
)

@IgnoreExtraProperties
data class ConversationSummaryRecord(
    @get:PropertyName("conversationId") @set:PropertyName("conversationId") var conversationId: String = "",
    @get:PropertyName("userId") @set:PropertyName("userId") var userId: String = "",
    @get:PropertyName("title") @set:PropertyName("title") var title: String = "",
    @get:PropertyName("summary") @set:PropertyName("summary") var summary: String = "",
    @get:PropertyName("turnCount") @set:PropertyName("turnCount") var turnCount: Int = 0,
    @get:PropertyName("lastUserMessage") @set:PropertyName("lastUserMessage") var lastUserMessage: String = "",
    @get:PropertyName("lastAssistantMessage") @set:PropertyName("lastAssistantMessage") var lastAssistantMessage: String = "",
    @get:PropertyName("createdAt") @set:PropertyName("createdAt") var createdAt: String = "",
    @get:PropertyName("updatedAt") @set:PropertyName("updatedAt") var updatedAt: String = ""
)

@IgnoreExtraProperties
data class FirestoreWorkflow(
    @get:PropertyName("workflowId") @set:PropertyName("workflowId") var workflowId: String = "",
    @get:PropertyName("userId") @set:PropertyName("userId") var userId: String = "",
    @get:PropertyName("title") @set:PropertyName("title") var title: String = "",
    @get:PropertyName("triggerPhrase") @set:PropertyName("triggerPhrase") var triggerPhrase: String = "",
    @get:PropertyName("description") @set:PropertyName("description") var description: String = "",
    @get:PropertyName("stepsJson") @set:PropertyName("stepsJson") var stepsJson: String = "",
    @get:PropertyName("isEnabled") @set:PropertyName("isEnabled") var isEnabled: Boolean = true,
    @get:PropertyName("createdAt") @set:PropertyName("createdAt") var createdAt: String = "",
    @get:PropertyName("updatedAt") @set:PropertyName("updatedAt") var updatedAt: String = ""
)

