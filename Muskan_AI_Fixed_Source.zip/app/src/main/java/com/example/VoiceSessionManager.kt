package com.example

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.example.api.ApiProfile
import com.example.api.ApiProfileManager
import com.example.api.ApiVerificationResult
import com.example.data.GeminiClient
import com.example.data.firebase.FirebaseAuthManager
import com.example.data.firebase.FirestoreMemoryRepository
import com.example.data.firebase.UserMemory
import com.example.data.firebase.UserPreferences
import com.example.data.gemini.GeminiLiveSessionManager
import com.example.data.gemini.LiveSessionState
import com.example.data.local.AppDatabase
import com.example.data.local.ConversationRepository
import com.example.dsp.AudioDspProcessor
import com.example.dsp.BiometricAudioStreamManager
import com.example.dsp.VoiceBiometricsEngine
import com.example.util.AudioFeedbackHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

object VoiceSessionManager {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var appContext: Context? = null
    private var feedbackHelper: AudioFeedbackHelper? = null

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false
    private var pendingSpeechText: String? = null

    private var wakeWordLoopJob: Job? = null
    private var silenceWatchdogJob: Job? = null
    private var ttsWaveSimulationJob: Job? = null
    private var onSpeechDoneCallback: (() -> Unit)? = null

    private var isInterruptedByExternalAudio = false
    private var repository: ConversationRepository? = null

    private var biometricsEngine: VoiceBiometricsEngine? = null
    private var audioStreamManager: BiometricAudioStreamManager? = null

    // Persistent continuous session & mic state (5 minutes = 300 seconds)
    private const val CONTINUOUS_SESSION_DURATION_MS = 300_000L
    private var isRecognizerListening = false
    private var isContinuousSessionActive = false
    private var sessionExpiryTimestamp = 0L
    private var sessionCountdownJob: Job? = null
    private var inactivityWatchdogJob: Job? = null

    // Robust continuous listening controls (eliminates repeated disconnect/reconnect loops)
    private var isListeningEnabledByUser = true
    private var isStartingListening = false
    private var consecutiveRecognizerRetries = 0
    private const val MAX_AUTOMATIC_RECOGNIZER_RETRIES = 3
    private var lastProcessedQuery = ""
    private var lastProcessedQueryTime = 0L

    // Female voice verification and smooth audio RMS filter
    private var isVerifiedFemaleVoiceSelected = false
    private var lastSmoothedRms = 0f

    private var liveSessionManager: GeminiLiveSessionManager? = null
    private var firestoreMemoryRepo: FirestoreMemoryRepository? = null
    private var firebaseAuthManager: FirebaseAuthManager? = null

    val memoryRepository: FirestoreMemoryRepository?
        get() = firestoreMemoryRepo

    val authManager: FirebaseAuthManager?
        get() = firebaseAuthManager

    val liveManager: GeminiLiveSessionManager?
        get() = liveSessionManager

    val conversationRepository: ConversationRepository?
        get() = repository

    private val _uiState = MutableStateFlow(VoiceUiState())
    val uiState: StateFlow<VoiceUiState> = _uiState.asStateFlow()

    fun initialize(context: Context) {
        if (appContext != null) return
        val app = context.applicationContext
        appContext = app
        feedbackHelper = AudioFeedbackHelper(app)

        val bioEngine = VoiceBiometricsEngine(app)
        biometricsEngine = bioEngine
        audioStreamManager = BiometricAudioStreamManager(app, bioEngine) {
            liveSessionManager?.isActive == true || GeminiLiveSessionManager.isLiveMicActive()
        }

        // Safe Biometric Gate: never enforce lock before the user explicitly enrolls their voiceprint
        val effectiveBiometricsActive = bioEngine.isEnrolled && bioEngine.isBiometricsActive
        if (!bioEngine.isEnrolled && bioEngine.isBiometricsActive) {
            bioEngine.isBiometricsActive = false
        }

        _uiState.update {
            it.copy(
                isVoiceBiometricsEnrolled = bioEngine.isEnrolled,
                isVoiceBiometricsActive = effectiveBiometricsActive,
                biometricConfidenceScore = if (bioEngine.isEnrolled) 0.94f else 0f
            )
        }

        try {
            val db = AppDatabase.getDatabase(app)
            val repo = ConversationRepository(db.conversationTurnDao(), db.userMemoryDao())
            repository = repo
            scope.launch(Dispatchers.IO) {
                repo.seedInitialMemoriesIfNeeded()
            }
        } catch (_: Exception) {}

        checkSpeechAvailability()
        initTextToSpeech()

        // Initialize Manual API Profile Manager and Hybrid 20-Key Rotation Pool
        ApiProfileManager.initialize(app)
        com.example.api.KeyRotationPoolManager.initialize(app)
        scope.launch(Dispatchers.Main) {
            com.example.api.KeyRotationPoolManager.activeSlotIndex.collect { slotIdx ->
                val slot = com.example.api.KeyRotationPoolManager.slots.value.getOrNull(slotIdx)
                val label = slot?.label ?: "Slot $slotIdx"
                val statusText = slot?.status?.name ?: "ACTIVE"
                _uiState.update {
                    it.copy(
                        activeApiName = label,
                        activeApiStatus = statusText
                    )
                }
            }
        }

        scope.launch(Dispatchers.Main) {
            com.example.engine.approval.OwnerApprovalGate.pendingCount.collect { count ->
                _uiState.update { it.copy(pendingApprovalsCount = count) }
            }
        }

        // Initialize Dual-Brain Architecture (Gemini Cloud + Qwen3 1.7B GGUF Offline)
        com.example.engine.brain.DualBrainCoordinator.initialize(app)
        scope.launch(Dispatchers.Main) {
            com.example.engine.brain.DualBrainCoordinator.brainState.collect { bState ->
                _uiState.update {
                    it.copy(
                        activeBrainMode = bState.activeBrainLabel,
                        isOfflineBrainForced = bState.mode == com.example.engine.brain.DualBrainCoordinator.BrainMode.FORCE_OFFLINE,
                        isOfflineModelReady = bState.isOfflineModelReady,
                        lastBrainUsed = bState.lastBrainUsed?.displayName
                    )
                }
            }
        }

        try {
            val fAuth = FirebaseAuthManager()
            firebaseAuthManager = fAuth
            val fMemory = FirestoreMemoryRepository.create(app)
            firestoreMemoryRepo = fMemory
            val liveSession = GeminiLiveSessionManager(app, fMemory) { isUser, text ->
                recordGeminiLiveTurn(isUser, text)
            }
            liveSessionManager = liveSession

            scope.launch(Dispatchers.Main) {
                fAuth.currentUser.collect { user ->
                    _uiState.update {
                        it.copy(
                            isFirebaseAuthSignedIn = user != null,
                            firebaseUserDisplayName = user?.displayName ?: "Sultan Mirza",
                            firebaseUserEmail = user?.email ?: "sultaan.m33@gmail.com"
                        )
                    }
                }
            }

            scope.launch(Dispatchers.Main) {
                fMemory.observeUserMemories().collect { memories ->
                    _uiState.update { it.copy(firebaseMemoriesCount = memories.size) }
                }
            }

            var wasLiveConnected = false
            scope.launch(Dispatchers.Main) {
                liveSession.liveState.collect { liveState ->
                    val isConnected = liveState != LiveSessionState.IDLE && liveState != LiveSessionState.ERROR
                    // If live stream encountered a transient error, retry Gemini Live when online & allowed,
                    // otherwise fall back cleanly to offline-capable VAD/SpeechRecognizer without looping.
                    if (wasLiveConnected && liveState == LiveSessionState.ERROR &&
                        isListeningEnabledByUser && !_uiState.value.isMuted) {
                        mainHandler.postDelayed({
                            if (!isListeningEnabledByUser || _uiState.value.isMuted) return@postDelayed
                            if (canUseGeminiLive()) {
                                startGeminiLiveSession()
                            } else {
                                startSilentVadGatedFallback()
                            }
                        }, 1500L)
                    }
                    wasLiveConnected = isConnected
                    _uiState.update {
                        it.copy(
                            isGeminiLiveConnected = isConnected,
                            liveSessionState = liveState,
                            state = when (liveState) {
                                LiveSessionState.LISTENING -> AssistantState.LISTENING
                                LiveSessionState.USER_SPEAKING -> AssistantState.PROCESSING
                                LiveSessionState.ASSISTANT_SPEAKING -> AssistantState.SPEAKING
                                LiveSessionState.ERROR -> AssistantState.ERROR
                                else -> if (it.state == AssistantState.SPEAKING && isConnected) AssistantState.SPEAKING else it.state
                            }
                        )
                    }
                }
            }

            scope.launch(Dispatchers.Main) {
                liveSession.statusMessage.collect { status ->
                    if (_uiState.value.isGeminiLiveConnected) {
                        _uiState.update { it.copy(statusMessage = status) }
                    }
                }
            }

            scope.launch(Dispatchers.Main) {
                liveSession.audioRms.collect { rms ->
                    if (_uiState.value.isGeminiLiveConnected) {
                        _uiState.update { it.copy(audioRmsLevel = rms) }
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private fun checkSpeechAvailability() {
        val context = appContext ?: return
        val available = SpeechRecognizer.isRecognitionAvailable(context)
        _uiState.update { it.copy(isSpeechAvailable = available) }
    }

    private fun initTextToSpeech() {
        val context = appContext ?: return
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsReady = true

                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                textToSpeech?.setAudioAttributes(audioAttributes)

                configureHinglishVoice()
                applyVoiceSettings(rate = _uiState.value.speechRate, pitch = _uiState.value.speechPitch)

                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _uiState.update {
                            it.copy(
                                state = AssistantState.SPEAKING,
                                isTtsSpeaking = true,
                                statusMessage = "Muskan is speaking…"
                            )
                        }
                        startTtsWaveformSimulation()
                    }

                    override fun onDone(utteranceId: String?) {
                        stopTtsWaveformSimulation()
                        mainHandler.post {
                            _uiState.update {
                                it.copy(
                                    state = if (isListeningEnabledByUser && !it.isMuted) AssistantState.LISTENING else AssistantState.IDLE,
                                    isTtsSpeaking = false,
                                    audioOutputLevel = 0f,
                                    statusMessage = if (isListeningEnabledByUser && !it.isMuted) {
                                        "Listening… Speak your command"
                                    } else if (it.isMuted) {
                                        "Muskan is muted • Say 'Muskan suno'"
                                    } else {
                                        "Ready"
                                    }
                                )
                            }

                            val callback = onSpeechDoneCallback
                            onSpeechDoneCallback = null
                            if (callback != null) {
                                callback()
                            } else if (isListeningEnabledByUser && !_uiState.value.isMuted) {
                                // Continuous conversation: Gracefully return to LISTENING ready for next command!
                                scope.launch(Dispatchers.Main) {
                                    delay(400L) // Wait for TTS audio track to close cleanly to avoid audio pops
                                    safeStartListening(isContinuousSession = true)
                                }
                            }
                        }
                    }

                    @Deprecated("Deprecated in Java", ReplaceWith("onError(utteranceId, -1)"))
                    override fun onError(utteranceId: String?) {
                        stopTtsWaveformSimulation()
                        handleTtsFinish()
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        stopTtsWaveformSimulation()
                        handleTtsFinish()
                    }

                    private fun handleTtsFinish() {
                        mainHandler.postDelayed({
                            _uiState.update {
                                it.copy(
                                    state = if (isListeningEnabledByUser && !it.isMuted && isContinuousSessionActive) AssistantState.LISTENING else AssistantState.IDLE,
                                    isTtsSpeaking = false,
                                    audioOutputLevel = 0f,
                                    statusMessage = if (isContinuousSessionActive) "Muskan is listening…" else if (it.isMuted) "Muskan is muted" else "Ready"
                                )
                            }
                            val callback = onSpeechDoneCallback
                            onSpeechDoneCallback = null
                            if (callback != null) {
                                callback()
                            } else if (isListeningEnabledByUser && !_uiState.value.isMuted) {
                                if (isContinuousSessionActive && System.currentTimeMillis() < sessionExpiryTimestamp) {
                                    safeStartListening(isContinuousSession = true)
                                } else if (_uiState.value.isWakeWordEnabled && _uiState.value.hasAudioPermission) {
                                    safeStartListening(isContinuousSession = false)
                                }
                            }
                        }, 300L)
                    }
                })

                val pending = pendingSpeechText
                if (pending != null) {
                    pendingSpeechText = null
                    mainHandler.post { speakOut(pending) }
                }
            }
        }
    }

    private fun isMaleVoice(name: String): Boolean {
        val n = name.lowercase(Locale.ROOT)
        if (n.contains("male") && !n.contains("female")) return true
        if (n.contains("man") || n.contains("boy")) return true
        val maleMarkers = listOf("-enb", "-end", "-enf", "-hib", "-hic", "-iol", "-iom", "-iob", "-sfg-m", "-m-", "_male", ".male")
        return maleMarkers.any { n.contains(it) }
    }

    private fun isFemaleVoice(name: String): Boolean {
        val n = name.lowercase(Locale.ROOT)
        if (n.contains("female") || n.contains("woman") || n.contains("girl") || n.contains("fem")) return true
        val femaleMarkers = listOf("-ena", "-enc", "-ene", "-hia", "-hid", "-hie", "-hif", "-sfg", "-tpd", "-cxx", "-ahf", "f00", "female_", "_female")
        return femaleMarkers.any { n.contains(it) }
    }

    private fun configureHinglishVoice() {
        val hinglishLocale = Locale.forLanguageTag("en-IN")
        val result = textToSpeech?.setLanguage(hinglishLocale)

        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            val hindiResult = textToSpeech?.setLanguage(Locale.forLanguageTag("hi-IN"))
            if (hindiResult == TextToSpeech.LANG_MISSING_DATA || hindiResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                textToSpeech?.setLanguage(Locale.getDefault())
            }
        }

        val allVoices = textToSpeech?.voices
        if (allVoices.isNullOrEmpty()) {
            isVerifiedFemaleVoiceSelected = false
            applyVoiceSettings(rate = _uiState.value.speechRate, pitch = _uiState.value.speechPitch)
            return
        }

        // Strict rejection: completely eliminate any identified male voice!
        val nonMaleVoices = allVoices.filter { voice ->
            !isMaleVoice(voice.name)
        }

        // Look specifically for confirmed natural female voices
        val explicitlyFemaleVoices = nonMaleVoices.filter { voice ->
            isFemaleVoice(voice.name)
        }

        val pool = if (explicitlyFemaleVoices.isNotEmpty()) explicitlyFemaleVoices else nonMaleVoices
        val preferOfflineTts = _uiState.value.isOfflineBrainForced || !isDeviceOnline()

        val bestVoice = pool.maxByOrNull { voice ->
            var score = 0
            val name = voice.name.lowercase(Locale.ROOT)
            val lang = voice.locale.language.lowercase(Locale.ROOT)
            val country = voice.locale.country.lowercase(Locale.ROOT)

            // Prioritize offline-capable local voices so weak/no network never stalls TTS
            if (!voice.isNetworkConnectionRequired) {
                score += if (preferOfflineTts) 250 else 100
            } else if (!preferOfflineTts && (name.contains("neural") || name.contains("wavenet"))) {
                score += 20
            }

            // Top score for sweet young female Indian neural voices
            if (name.contains("hie")) score += 450 // Google Hindi Female Neural (soft young girl)
            if (name.contains("ene")) score += 380 // Google Indian English Female Neural
            if (name.contains("hid") || name.contains("hif") || name.contains("hia")) score += 340
            if (name.contains("enc") || name.contains("ena")) score += 300

            if (name.contains("female")) score += 200
            if (lang == "hi") score += 120
            if (lang == "en" && country == "in") score += 100
            if (lang == "en") score += 50

            if (voice.quality == Voice.QUALITY_VERY_HIGH) score += 60
            if (voice.quality == Voice.QUALITY_HIGH) score += 30
            if (name.contains("neural") || name.contains("wavenet")) score += 40

            score
        }

        if (bestVoice != null && !isMaleVoice(bestVoice.name)) {
            try {
                textToSpeech?.voice = bestVoice
                isVerifiedFemaleVoiceSelected = isFemaleVoice(bestVoice.name)
                val label = "Muskan Voice (${bestVoice.locale.displayLanguage})"
                _uiState.update { it.copy(selectedVoiceDescription = label) }
            } catch (_: Exception) {}
        } else {
            isVerifiedFemaleVoiceSelected = false
        }

        applyVoiceSettings(rate = _uiState.value.speechRate, pitch = _uiState.value.speechPitch)
    }

    fun playAcknowledgeChime() {
        // Completely silent: harsh ToneGenerator beeps removed so nothing rings in the user's ear.
        // Uses subtle haptic pulse only.
        feedbackHelper?.triggerWakeWordFeedback()
    }

    private fun applyVoiceSettings(rate: Float = 1.00f, pitch: Float = 1.00f) {
        val safeRate = rate.coerceIn(0.6f, 1.8f)
        val safePitch = pitch.coerceIn(0.6f, 1.8f)
        try {
            textToSpeech?.setSpeechRate(safeRate)
            textToSpeech?.setPitch(safePitch)
        } catch (_: Exception) {}
        _uiState.update { it.copy(speechRate = safeRate, speechPitch = safePitch) }
    }

    fun updateSpeechRate(rate: Float) {
        applyVoiceSettings(rate = rate, pitch = _uiState.value.speechPitch)
    }

    fun updateSpeechPitch(pitch: Float) {
        applyVoiceSettings(rate = _uiState.value.speechRate, pitch = pitch)
    }

    fun toggleVoiceBiometrics() {
        val engine = biometricsEngine
        val next = !_uiState.value.isVoiceBiometricsActive
        if (next && engine?.isEnrolled != true) {
            // Require explicit enrollment before enabling biometric lock so normal voice commands are never blocked
            _uiState.update {
                it.copy(
                    isVoiceBiometricsActive = false,
                    showVoiceEnrollmentDialog = true,
                    statusMessage = "Enroll your voice first to enable biometric lock."
                )
            }
            return
        }
        engine?.isBiometricsActive = next
        _uiState.update { it.copy(isVoiceBiometricsActive = next) }
    }

    fun setBiometricThreshold(threshold: Float) {
        biometricsEngine?.verificationThreshold = threshold
    }

    fun toggleNoiseSuppression() {
        val next = !_uiState.value.isNoiseSuppressionActive
        _uiState.update { it.copy(isNoiseSuppressionActive = next) }
    }

    fun setShowVoiceEnrollmentDialog(show: Boolean) {
        _uiState.update { it.copy(showVoiceEnrollmentDialog = show) }
    }

    fun setShowMasterDashboard(show: Boolean) {
        _uiState.update { it.copy(showMasterDashboard = show) }
    }

    fun enrollVoiceSamples(samples: List<ShortArray>): Boolean {
        val engine = biometricsEngine ?: return false
        val success = engine.enrollNewVoiceprint(samples)
        if (success) {
            engine.isBiometricsActive = true
            _uiState.update {
                it.copy(
                    isVoiceBiometricsEnrolled = true,
                    isVoiceBiometricsActive = true,
                    biometricConfidenceScore = 0.96f,
                    lastBiometricVerdict = BiometricVerdict.VERIFIED_SULTAN,
                    discardedSpeakerNotice = null
                )
            }
        }
        return success
    }

    /**
     * Records a real high-fidelity PCM audio sample for Sultan Mirza's Voice Match enrollment.
     */
    suspend fun recordEnrollmentSample(durationMs: Long = 2500): ShortArray {
        val streamManager = audioStreamManager ?: return ShortArray(0)
        val wasLiveActive = liveSessionManager?.isActive == true
        if (wasLiveActive) {
            liveSessionManager?.stopLiveSession()
        }
        val wasListening = isRecognizerListening
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {}
        isRecognizerListening = false

        val sample = streamManager.recordEnrollmentSample(durationMs)

        if (wasLiveActive && isListeningEnabledByUser && !_uiState.value.isMuted) {
            startGeminiLiveSession()
        } else if (wasListening && _uiState.value.isWakeWordEnabled && !_uiState.value.isMuted) {
            safeStartListening(isContinuousSession = isContinuousSessionActive)
        }
        return sample
    }

    fun checkBiometricMatch(): Boolean {
        val engine = biometricsEngine ?: return true
        // Allow normal voice commands smoothly when biometric lock is disabled or user has not enrolled yet
        if (!_uiState.value.isVoiceBiometricsActive || !engine.isEnrolled) return true
        val latest = audioStreamManager?.verificationResult?.value ?: return false
        return latest.isVerified &&
                latest.verdict == BiometricVerdict.VERIFIED_SULTAN &&
                latest.confidenceScore >= engine.verificationThreshold
    }

    fun isMuted(): Boolean = _uiState.value.isMuted

    fun setMuted(muted: Boolean) {
        _uiState.update {
            it.copy(
                isMuted = muted,
                statusMessage = if (muted) "Muskan is muted • Say 'Muskan suno'" else "Listening for 'Muskan'…"
            )
        }
        if (muted) {
            endContinuousSession(timedOut = false)
            stopTts()
            try { speechRecognizer?.stopListening() } catch (_: Exception) {}
            isRecognizerListening = false
            speakOut("Ji Sultan, main chup ho gayi hoon. Sunne ke liye kahiye 'Muskan suno'.")
        } else {
            isListeningEnabledByUser = true
            feedbackHelper?.triggerWakeWordFeedback()
            speakOut("Ji Sultan, main sun rahi hoon.") {
                startContinuousSession()
                safeStartListening(isContinuousSession = true)
            }
        }
    }

    fun toggleMute() {
        setMuted(!_uiState.value.isMuted)
    }

    fun isAuthoritativeListeningActive(): Boolean {
        return isRecognizerListening && _uiState.value.hasAudioPermission
    }

    private var silentVadGateJob: Job? = null
    private var preferOfflineSpeechRecognition = false
    private var offlineRetryAttemptedForCurrentTurn = false

    private val unmuteAudioStreamsRunnable = Runnable {
        val ctx = appContext ?: return@Runnable
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return@Runnable
        try {
            am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_UNMUTE, 0)
            am.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_UNMUTE, 0)
        } catch (_: Exception) {}
    }

    private fun hasConfiguredGeminiKey(): Boolean {
        val geminiKey = com.example.api.KeyRotationPoolManager.getActiveGeminiKey()
        return geminiKey.isNotBlank() && !com.example.api.ApiKeySlot.isPlaceholderKey(geminiKey)
    }

    private fun isDeviceOnline(): Boolean {
        val ctx = appContext ?: return false
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            false
        }
    }

    private fun canUseGeminiLive(): Boolean {
        return !_uiState.value.isOfflineBrainForced &&
            hasConfiguredGeminiKey() &&
            isDeviceOnline()
    }

    fun recordGeminiLiveTurn(isUser: Boolean, text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return
        val sender = if (isUser) MessageSender.USER else MessageSender.ASSISTANT
        _uiState.update { current ->
            val history = current.conversationHistory
            val last = history.lastOrNull()
            val updatedHistory = if (last != null && last.sender == sender &&
                (System.currentTimeMillis() - last.timestamp) < 4000L &&
                !clean.equals(last.text, ignoreCase = true)
            ) {
                val merged = if (clean.startsWith(last.text)) clean else "${last.text} $clean".trim()
                history.dropLast(1) + last.copy(text = merged, timestamp = System.currentTimeMillis())
            } else if (last != null && last.sender == sender && clean.equals(last.text, ignoreCase = true)) {
                history
            } else {
                history + VoiceMessage(sender = sender, text = clean)
            }
            current.copy(
                lastUserQuery = if (isUser) clean else current.lastUserQuery,
                lastResponseText = if (!isUser) clean else current.lastResponseText,
                conversationHistory = updatedHistory
            )
        }
    }

    /**
     * Temporarily silences system notification/system streams for 400ms around SpeechRecognizer
     * start/stop so Google Speech Services NEVER plays the "keyboard mic ding-dong" earcon in the ear.
     */
    private fun suppressSystemMicBeepBriefly() {
        val ctx = appContext ?: return
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        try {
            mainHandler.removeCallbacks(unmuteAudioStreamsRunnable)
            am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_MUTE, 0)
            am.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_MUTE, 0)
            mainHandler.postDelayed(unmuteAudioStreamsRunnable, 400L)
        } catch (_: Exception) {}
    }

    /**
     * Zero-beep silent hardware VAD gate: instead of re-triggering Android SpeechRecognizer every 3 seconds
     * during silence (which causes repeated mic triggers and keyboard mic ding-dong sounds), this monitors
     * the microphone silently via AudioRecord (BiometricAudioStreamManager) and only wakes SpeechRecognizer
     * when real human voice energy is detected!
     */
    private fun startSilentVadGatedFallback() {
        if (_uiState.value.isGeminiLiveConnected || liveSessionManager?.isActive == true) return
        if (!isListeningEnabledByUser || _uiState.value.isMuted || !_uiState.value.hasAudioPermission) return
        if (canUseGeminiLive() && _uiState.value.hasAudioPermission) {
            startGeminiLiveSession()
            return
        }
        val streamMgr = audioStreamManager
        if (streamMgr == null) {
            safeStartListening(isContinuousSession = isContinuousSessionActive)
            return
        }
        silentVadGateJob?.cancel()
        _uiState.update {
            it.copy(
                state = AssistantState.LISTENING,
                statusMessage = if (_uiState.value.isOfflineBrainForced) {
                    "Muskan Offline VAD active • Speak naturally"
                } else {
                    "Muskan Live VAD active • Speak naturally"
                }
            )
        }
        streamMgr.startLiveVerificationStream(
            onVerifiedSpeechDetected = { pcmChunk, _ ->
                var energy = 0.0
                for (s in pcmChunk) energy += s * s
                val rms = kotlin.math.sqrt(energy / pcmChunk.size.coerceAtLeast(1)) / 32768.0
                if (rms > 0.022) {
                    streamMgr.stopStream()
                    mainHandler.post {
                        if (isListeningEnabledByUser && !_uiState.value.isMuted) {
                            safeStartListening(isContinuousSession = true)
                        }
                    }
                }
            }
        )
    }

    fun setPermissionGranted(granted: Boolean) {
        _uiState.update {
            it.copy(
                hasAudioPermission = granted,
                authoritativeVoiceState = if (!granted) AuthoritativeVoiceSessionState.IDLE else it.authoritativeVoiceState
            )
        }
        if (!granted) {
            stopListening()
        } else if (_uiState.value.isWakeWordEnabled && _uiState.value.state == AssistantState.IDLE) {
            if (canUseGeminiLive()) {
                startGeminiLiveSession()
            } else {
                startSilentVadGatedFallback()
            }
        }
    }

    fun toggleWakeWord() {
        val newState = !_uiState.value.isWakeWordEnabled
        _uiState.update { it.copy(isWakeWordEnabled = newState) }
        if (newState) {
            if (_uiState.value.hasAudioPermission && _uiState.value.state == AssistantState.IDLE) {
                if (canUseGeminiLive()) {
                    startGeminiLiveSession()
                } else {
                    startSilentVadGatedFallback()
                }
            }
        } else {
            stopListening()
            _uiState.update {
                it.copy(
                    isWakeWordStandby = false,
                    isContinuousSessionActive = false,
                    statusMessage = "Wake-word paused. Tap mic to talk."
                )
            }
        }
    }

    /**
     * Handles external audio interrupts (incoming phone call, other media apps).
     */
    fun onExternalAudioInterrupt() {
        isInterruptedByExternalAudio = true
        audioStreamManager?.stopStream()
        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
        isRecognizerListening = false
        stopTts()
        _uiState.update {
            it.copy(
                statusMessage = "Audio paused for phone call/media",
                audioRmsLevel = 0f
            )
        }
    }

    /**
     * Resumes hands-free wake word listening after external audio/call ends.
     */
    fun onExternalAudioResumed() {
        if (!isInterruptedByExternalAudio) return
        isInterruptedByExternalAudio = false
        if (_uiState.value.isWakeWordEnabled && _uiState.value.hasAudioPermission && !_uiState.value.isMuted) {
            if (canUseGeminiLive()) {
                startGeminiLiveSession()
            } else {
                startSilentVadGatedFallback()
            }
        }
    }

    /* -------------------------------------------------------------
     * PERSISTENT AUDIO & GEMINI LIVE FULL-DUPLEX ARCHITECTURE
     * (Eliminates keyboard mic ding-dong beeps and repeated re-triggers)
     * ------------------------------------------------------------- */

    private fun getOrCreateRecognizer(context: Context): SpeechRecognizer? {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _uiState.update { it.copy(isSpeechAvailable = false) }
            return null
        }
        if (speechRecognizer == null) {
            try {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(persistentRecognitionListener)
                }
            } catch (_: Exception) {
                speechRecognizer = null
            }
        }
        return speechRecognizer
    }

    /**
     * Starts continuous hands-free Gemini Live full-duplex streaming (zero mic beeps!)
     * or silent VAD-gated listening when no Gemini key is configured.
     */
    fun startHandsFreeListening() {
        if (_uiState.value.isGeminiLiveConnected || liveSessionManager?.isActive == true) return
        if (!isListeningEnabledByUser) return
        if (!_uiState.value.isWakeWordEnabled || !_uiState.value.hasAudioPermission) return
        if (_uiState.value.isTtsSpeaking || _uiState.value.state == AssistantState.PROCESSING) return
        if (isInterruptedByExternalAudio || _uiState.value.isMuted) return

        if (canUseGeminiLive()) {
            startGeminiLiveSession()
        } else {
            startSilentVadGatedFallback()
        }
    }

    fun startGeminiLiveSession() {
        stopTts()
        silentVadGateJob?.cancel()
        audioStreamManager?.stopStream()
        silenceWatchdogJob?.cancel()
        sessionCountdownJob?.cancel()
        isContinuousSessionActive = true
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
        } catch (_: Exception) {}
        isRecognizerListening = false
        isStartingListening = false
        _uiState.update {
            it.copy(
                state = AssistantState.LISTENING,
                isListeningEnabledByUser = true,
                isContinuousSessionActive = true,
                isWakeWordStandby = false,
                isMuted = false,
                statusMessage = "Muskan Live is listening • Speak naturally"
            )
        }
        feedbackHelper?.triggerWakeWordFeedback()
        liveSessionManager?.startLiveSession()
    }

    fun stopGeminiLiveSession() {
        liveSessionManager?.stopLiveSession()
        _uiState.update { it.copy(isGeminiLiveConnected = false) }
        scope.launch(Dispatchers.Main) {
            delay(250L) // Audio settle delay to prevent hardware mic contention
            if (_uiState.value.isWakeWordEnabled && !_uiState.value.isMuted && isListeningEnabledByUser) {
                safeStartListening(isContinuousSession = false)
            }
        }
    }

    fun toggleGeminiLiveSession() {
        if (_uiState.value.isGeminiLiveConnected) {
            stopGeminiLiveSession()
        } else {
            startGeminiLiveSession()
        }
    }

    fun toggleProactiveQuestions(enabled: Boolean) {
        _uiState.update { it.copy(isProactiveQuestionsEnabled = enabled) }
        liveSessionManager?.toggleProactiveQuestions(enabled)
    }

    fun setShowMemoryManagerDialog(show: Boolean) {
        _uiState.update { it.copy(showMemoryManagerDialog = show) }
    }

    fun setForceOfflineBrain(enabled: Boolean) {
        val context = appContext ?: return
        com.example.engine.brain.DualBrainCoordinator.setBrainMode(
            context,
            if (enabled) com.example.engine.brain.DualBrainCoordinator.BrainMode.FORCE_OFFLINE
            else com.example.engine.brain.DualBrainCoordinator.BrainMode.HYBRID_AUTO
        )
    }

    fun toggleForceOfflineBrain() {
        val current = _uiState.value.isOfflineBrainForced
        setForceOfflineBrain(!current)
    }

    suspend fun saveUserApprovedMemory(content: String, category: String = "preference") {
        firestoreMemoryRepo?.saveMemory(content, category)
    }

    suspend fun deleteUserMemory(memoryId: String) {
        firestoreMemoryRepo?.deleteMemory(memoryId)
    }

    suspend fun clearAllUserMemories() {
        firestoreMemoryRepo?.clearAllMemories()
    }

    /**
     * Start explicit command listening (from UI tap or wake-up response).
     * Initiates or refreshes the continuous 5-minute session!
     */
    fun startExplicitListening() {
        silenceWatchdogJob?.cancel()
        stopTts()
        offlineRetryAttemptedForCurrentTurn = false
        isListeningEnabledByUser = true
        _uiState.update {
            it.copy(
                isListeningEnabledByUser = true,
                isMuted = false
            )
        }

        startContinuousSession()
        if (canUseGeminiLive()) {
            startGeminiLiveSession()
        } else {
            safeStartListening(isContinuousSession = true)
        }
    }

    fun startContinuousSession() {
        isContinuousSessionActive = true
        sessionExpiryTimestamp = System.currentTimeMillis() + CONTINUOUS_SESSION_DURATION_MS
        _uiState.update {
            it.copy(
                isContinuousSessionActive = true,
                sessionRemainingSeconds = 300,
                isWakeWordStandby = false,
                wakeWordDetectedNotice = true,
                statusMessage = "Muskan is listening… (5m 00s remaining)"
            )
        }
        startSessionCountdownJob()
    }

    private fun refreshContinuousSessionTimer() {
        if (!isContinuousSessionActive) return
        sessionExpiryTimestamp = System.currentTimeMillis() + CONTINUOUS_SESSION_DURATION_MS
    }

    fun endContinuousSession(timedOut: Boolean = false) {
        cancelInactivityWatchdog()
        sessionCountdownJob?.cancel()
        sessionCountdownJob = null
        isContinuousSessionActive = false
        _uiState.update {
            it.copy(
                isContinuousSessionActive = false,
                sessionRemainingSeconds = 0,
                isWakeWordStandby = true,
                state = AssistantState.IDLE,
                statusMessage = if (timedOut) "5 min silence • Say 'Muskan' to talk" else "Listening for 'Muskan'…"
            )
        }
        if (_uiState.value.isWakeWordEnabled && !_uiState.value.isMuted) {
            safeStartListening(isContinuousSession = false)
        }
    }

    private fun startSessionCountdownJob() {
        sessionCountdownJob?.cancel()
        sessionCountdownJob = scope.launch(Dispatchers.Main) {
            while (isActive) {
                val now = System.currentTimeMillis()
                val remainingMs = sessionExpiryTimestamp - now
                if (remainingMs <= 0L) {
                    endContinuousSession(timedOut = true)
                    break
                }
                val remainingSec = (remainingMs / 1000L).toInt()
                _uiState.update {
                    it.copy(
                        isContinuousSessionActive = true,
                        sessionRemainingSeconds = remainingSec
                    )
                }
                delay(1000L)
            }
        }
    }

    private fun cancelInactivityWatchdog() {
        inactivityWatchdogJob?.cancel()
        inactivityWatchdogJob = null
    }

    private fun safeStartListening(isContinuousSession: Boolean) {
        val context = appContext ?: return
        if (_uiState.value.isGeminiLiveConnected || liveSessionManager?.isActive == true) return
        if (!isListeningEnabledByUser) return
        if (!_uiState.value.hasAudioPermission) return
        if (_uiState.value.isTtsSpeaking) return
        if (_uiState.value.isMuted) return
        if (isInterruptedByExternalAudio) return
        if (isRecognizerListening || isStartingListening) return

        audioStreamManager?.stopStream()
        isStartingListening = true
        scope.launch(Dispatchers.Main) {
            try {
                val recognizer = getOrCreateRecognizer(context)
                if (recognizer == null) {
                    isStartingListening = false
                    return@launch
                }
                suppressSystemMicBeepBriefly()
                val intent = createSpeechIntent(isWakeWord = !isContinuousSession)
                recognizer.startListening(intent)
                isRecognizerListening = true
            } catch (_: Exception) {
                try {
                    speechRecognizer?.cancel()
                    val recognizer = getOrCreateRecognizer(context)
                    if (recognizer != null) {
                        val intent = createSpeechIntent(isWakeWord = !isContinuousSession)
                        recognizer.startListening(intent)
                        isRecognizerListening = true
                    }
                } catch (_: Exception) {}
            } finally {
                isStartingListening = false
            }
        }
    }

    private val persistentRecognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            consecutiveRecognizerRetries = 0
            isRecognizerListening = true
            isStartingListening = false
            _uiState.update {
                val status = when {
                    it.isMuted -> "Muskan is muted • Say 'Muskan suno'"
                    !isListeningEnabledByUser -> "Listening is OFF • Tap mic to start"
                    isContinuousSessionActive -> {
                        val secLeft = ((sessionExpiryTimestamp - System.currentTimeMillis()) / 1000L).coerceAtLeast(0).toInt()
                        val m = secLeft / 60
                        val s = secLeft % 60
                        "Listening to you… (${m}m ${s}s remaining)"
                    }
                    else -> "Listening for 'Muskan'…"
                }
                it.copy(
                    state = if (isListeningEnabledByUser && !it.isMuted) AssistantState.LISTENING else AssistantState.IDLE,
                    isWakeWordStandby = !isContinuousSessionActive,
                    isListeningEnabledByUser = isListeningEnabledByUser,
                    statusMessage = status,
                    errorMessage = null,
                    wakeWordDetectedNotice = false
                )
            }
        }

        override fun onBeginningOfSpeech() {
            cancelInactivityWatchdog()
            if (_uiState.value.isGeminiLiveConnected || liveSessionManager?.isActive == true) return
            if (_uiState.value.isTtsSpeaking) {
                mainHandler.post { stopTtsAndListen() }
                return
            }
            if (isContinuousSessionActive) {
                refreshContinuousSessionTimer()
                _uiState.update {
                    it.copy(
                        state = AssistantState.LISTENING,
                        statusMessage = "Listening…",
                        errorMessage = null
                    )
                }
            }
        }

        override fun onRmsChanged(rmsdB: Float) {
            if (_uiState.value.isGeminiLiveConnected || liveSessionManager?.isActive == true) return
            if (_uiState.value.isTtsSpeaking && rmsdB > 5.5f) {
                mainHandler.post { stopTtsAndListen() }
                return
            }
            // Real-time audio wave amplitude (HUD visualizer)
            val normalizedRms = ((rmsdB + 2f) / 12f).coerceIn(0.05f, 1.0f)
            lastSmoothedRms = (lastSmoothedRms * 0.65f) + (normalizedRms * 0.35f)
            val currentRms = _uiState.value.audioRmsLevel
            if (kotlin.math.abs(lastSmoothedRms - currentRms) > 0.02f) {
                _uiState.update { it.copy(audioRmsLevel = lastSmoothedRms) }
            }
        }

        override fun onBufferReceived(buffer: ByteArray?) {
            if (_uiState.value.isGeminiLiveConnected || liveSessionManager?.isActive == true) return
            // Live Stream Pipeline: only run strict speaker verification when user has explicitly enrolled & enabled lock
            val engine = biometricsEngine
            if (buffer != null && buffer.size >= 320 && _uiState.value.isVoiceBiometricsActive && engine?.isEnrolled == true) {
                try {
                    val shorts = ShortArray(buffer.size / 2)
                    java.nio.ByteBuffer.wrap(buffer).order(java.nio.ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)
                    val result = engine.verifyAudioStream(shorts)
                    audioStreamManager?.updateExternalVerificationResult(result)
                    _uiState.update {
                        it.copy(
                            biometricConfidenceScore = result.confidenceScore,
                            lastBiometricVerdict = result.verdict,
                            discardedSpeakerNotice = if (!result.isVerified) result.message else null
                        )
                    }
                } catch (_: Exception) {}
            }
        }

        override fun onEndOfSpeech() {
            if (_uiState.value.isGeminiLiveConnected || liveSessionManager?.isActive == true) return
            silenceWatchdogJob?.cancel()
            _uiState.update { it.copy(audioRmsLevel = 0f) }
            // Do NOT switch to AssistantState.PROCESSING here!
            // Prematurely switching causes the mic button to stutter/flicker between Mic and Spinner.
            // Muskan will switch to PROCESSING in onResults() when text is actually ready to be processed.
            if (isContinuousSessionActive) {
                _uiState.update {
                    it.copy(statusMessage = "Listening to you…")
                }
            }
        }

        override fun onError(error: Int) {
            silenceWatchdogJob?.cancel()
            isRecognizerListening = false
            isStartingListening = false
            _uiState.update { it.copy(audioRmsLevel = 0f) }

            if (_uiState.value.isGeminiLiveConnected || liveSessionManager?.isActive == true) {
                return
            }

            if (!isListeningEnabledByUser || _uiState.value.isMuted || _uiState.value.isTtsSpeaking) {
                return
            }

            // Silence timeout / no match during normal gaps in speaking:
            // Instead of re-triggering SpeechRecognizer in a loop (which plays keyboard mic ding-dong beeps!),
            // switch immediately to Gemini Live or silent AudioRecord VAD gate until the user speaks!
            if (error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || error == SpeechRecognizer.ERROR_NO_MATCH) {
                suppressSystemMicBeepBriefly()
                scope.launch(Dispatchers.Main) {
                    delay(400L)
                    if (isListeningEnabledByUser && !_uiState.value.isMuted && !_uiState.value.isTtsSpeaking) {
                        if (canUseGeminiLive() && _uiState.value.hasAudioPermission) {
                            startGeminiLiveSession()
                        } else {
                            startSilentVadGatedFallback()
                        }
                    }
                }
                return
            }

            // Network outage during SpeechRecognizer: retry once with offline recognition enabled
            if (error == SpeechRecognizer.ERROR_NETWORK ||
                error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                error == SpeechRecognizer.ERROR_SERVER_DISCONNECTED
            ) {
                if (!offlineRetryAttemptedForCurrentTurn) {
                    preferOfflineSpeechRecognition = true
                    offlineRetryAttemptedForCurrentTurn = true
                    scope.launch(Dispatchers.Main) {
                        delay(500L)
                        if (isListeningEnabledByUser && !_uiState.value.isMuted && !_uiState.value.isTtsSpeaking) {
                            safeStartListening(isContinuousSession = isContinuousSessionActive)
                        }
                    }
                    return
                }
            }

            // If recognizer is busy or temporary audio glitch, retry smoothly with quiet backoff delay
            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_AUDIO) {
                scope.launch(Dispatchers.Main) {
                    if (consecutiveRecognizerRetries >= MAX_AUTOMATIC_RECOGNIZER_RETRIES) {
                        _uiState.update { it.copy(state = AssistantState.IDLE, statusMessage = "Audio recognition paused after repeated errors. Tap the mic to retry.") }
                        return@launch
                    }
                    consecutiveRecognizerRetries++
                    delay(2500L)
                    if (isListeningEnabledByUser && !_uiState.value.isTtsSpeaking && !_uiState.value.isMuted && !isInterruptedByExternalAudio) {
                        safeStartListening(isContinuousSession = isContinuousSessionActive)
                    }
                }
                return
            }

            // Fatal / permanent errors
            val userMsg = when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network issue in speech recognition."
                else -> "Speech recognition error ($error)"
            }
            _uiState.update {
                it.copy(
                    state = AssistantState.IDLE,
                    statusMessage = userMsg,
                    partialTranscript = ""
                )
            }
            // Fatal/permanent errors (especially missing microphone permission) must not loop.
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                isListeningEnabledByUser = false
                _uiState.update { it.copy(state = AssistantState.IDLE, statusMessage = "Microphone permission required. Grant permission, then tap the mic.") }
            }
        }

        override fun onResults(results: Bundle?) {
            offlineRetryAttemptedForCurrentTurn = false
            cancelInactivityWatchdog()
            silenceWatchdogJob?.cancel()
            isRecognizerListening = false
            isStartingListening = false
            if (_uiState.value.isGeminiLiveConnected || liveSessionManager?.isActive == true) {
                return
            }
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val recognizedText = matches?.firstOrNull { it.isNotBlank() }?.trim() ?: ""

            if (recognizedText.isBlank()) {
                _uiState.update {
                    it.copy(
                        audioRmsLevel = 0f,
                        partialTranscript = ""
                    )
                }
                scope.launch(Dispatchers.Main) {
                    delay(1500L)
                    if (isListeningEnabledByUser && !_uiState.value.isMuted && !_uiState.value.isTtsSpeaking) {
                        safeStartListening(isContinuousSession = isContinuousSessionActive)
                    }
                }
                return
            }

            if (_uiState.value.isTtsSpeaking) {
                mainHandler.post {
                    stopTtsAndListen()
                    if (recognizedText.isNotBlank()) {
                        processSpeechInput(recognizedText)
                    }
                }
                return
            }

            // Valid speech recognized: transition to PROCESSING cleanly!
            _uiState.update {
                it.copy(
                    state = AssistantState.PROCESSING,
                    statusMessage = "Muskan is thinking…",
                    audioRmsLevel = 0f,
                    partialTranscript = ""
                )
            }

            // Deduplicate rapid identical triggers within 1.5 seconds
            val now = System.currentTimeMillis()
            if (recognizedText.equals(lastProcessedQuery, ignoreCase = true) && (now - lastProcessedQueryTime) < 1500L) {
                return
            }
            lastProcessedQuery = recognizedText
            lastProcessedQueryTime = now

            if (isContinuousSessionActive) {
                handleContinuousSessionResults(recognizedText)
            } else {
                handleStandbyResults(recognizedText)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            if (_uiState.value.isGeminiLiveConnected || liveSessionManager?.isActive == true) return
            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val partial = matches?.firstOrNull { it.isNotBlank() }?.trim() ?: ""
            if (partial.isNotBlank()) {
                val isAgenticBusy = _uiState.value.isAgenticTaskRunning ||
                        com.example.automation.UniversalPhoneAgent.isRunning ||
                        com.example.automation.AgenticExecutionPlanner.isExecuting.value

                if (isAgenticBusy && isStopOrInterruptionCommand(partial)) {
                    com.example.automation.AgenticExecutionPlanner.cancelExecution()
            com.example.automation.UniversalPhoneAgent.cancel()
                    mainHandler.post {
                        stopTtsAndListen()
                        playAcknowledgeChime()
                    }
                    return
                }

                if (_uiState.value.isTtsSpeaking) {
                    mainHandler.post { stopTtsAndListen() }
                    return
                }
                if (isContinuousSessionActive) {
                    _uiState.update { it.copy(partialTranscript = partial) }
                    silenceWatchdogJob?.cancel()
                    // Allow Sultan a full 4.5 seconds of natural breathing/pausing before finalizing speech,
                    // ensuring long commands and multi-clause statements are never cut off mid-thought!
                    silenceWatchdogJob = scope.launch(Dispatchers.Main) {
                        delay(4500L)
                        if (_uiState.value.state == AssistantState.LISTENING) {
                            try { speechRecognizer?.stopListening() } catch (_: Exception) {}
                        }
                    }
                } else {
                    if (containsWakeWord(partial)) {
                        _uiState.update { it.copy(wakeWordDetectedNotice = true) }
                        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
                    }
                }
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleContinuousSessionResults(recognizedText: String) {
        if (recognizedText.isBlank()) {
            if (System.currentTimeMillis() >= sessionExpiryTimestamp) {
                endContinuousSession(timedOut = true)
            } else {
                safeStartListening(isContinuousSession = true)
            }
            return
        }

        // Voice Biometric Check (only enforced when explicitly enrolled and enabled)
        if (_uiState.value.isVoiceBiometricsActive && biometricsEngine?.isEnrolled == true && !checkBiometricMatch()) {
            _uiState.update {
                it.copy(
                    lastBiometricVerdict = BiometricVerdict.REJECTED_UNKNOWN,
                    discardedSpeakerNotice = "Secondary speaker rejected • 0 latency",
                    statusMessage = "Biometric lock: Voice ignored"
                )
            }
            safeStartListening(isContinuousSession = true)
            return
        }

        _uiState.update {
            it.copy(
                lastBiometricVerdict = BiometricVerdict.VERIFIED_SULTAN,
                discardedSpeakerNotice = null
            )
        }

        val lower = recognizedText.lowercase(Locale.ROOT)
        if (isMuteCommand(lower)) {
            feedbackHelper?.triggerWakeWordFeedback()
            endContinuousSession(timedOut = false)
            setMuted(true)
            return
        }

        // Extend 5-minute session
        refreshContinuousSessionTimer()

        val prompt = if (containsWakeWord(recognizedText)) {
            val cleaned = extractQueryAfterWakeWord(recognizedText)
            if (cleaned.isNotBlank()) cleaned else recognizedText
        } else {
            recognizedText
        }

        processSpeechInput(prompt)
    }

    private fun handleStandbyResults(recognizedText: String) {
        val lower = recognizedText.lowercase(Locale.ROOT)

        if (isUnmuteCommand(lower)) {
            feedbackHelper?.triggerWakeWordFeedback()
            setMuted(false)
            return
        }

        if (_uiState.value.isMuted) {
            safeStartListening(isContinuousSession = false)
            return
        }

        if (isMuteCommand(lower)) {
            feedbackHelper?.triggerWakeWordFeedback()
            setMuted(true)
            return
        }

        if (containsWakeWord(recognizedText)) {
            if (_uiState.value.isVoiceBiometricsActive && biometricsEngine?.isEnrolled == true && !checkBiometricMatch()) {
                _uiState.update {
                    it.copy(
                        lastBiometricVerdict = BiometricVerdict.REJECTED_UNKNOWN,
                        discardedSpeakerNotice = "Unverified voice discarded • 0 latency"
                    )
                }
                safeStartListening(isContinuousSession = false)
                return
            }

            _uiState.update {
                it.copy(
                    lastBiometricVerdict = BiometricVerdict.VERIFIED_SULTAN,
                    discardedSpeakerNotice = null
                )
            }

            feedbackHelper?.triggerWakeWordFeedback()

            // START 5-MINUTE CONTINUOUS ACTIVE SESSION
            startContinuousSession()

            val prompt = extractQueryAfterWakeWord(recognizedText)
            if (prompt.isNotBlank()) {
                processSpeechInput(prompt)
            } else {
                speakOut("Ji Sultan.") {
                    safeStartListening(isContinuousSession = true)
                }
            }
        } else {
            val query = recognizedText.trim()
            if (query.isNotBlank() && query.length >= 3) {
                // Sultan spoke directly to the app: execute command smoothly!
                startContinuousSession()
                processSpeechInput(query)
            } else {
                // Resume standby listening smoothly
                safeStartListening(isContinuousSession = false)
            }
        }
    }

    private fun isMuteCommand(text: String): Boolean = VoiceCommandRouter.isMuteCommand(text)

    private fun isUnmuteCommand(text: String): Boolean = VoiceCommandRouter.isUnmuteCommand(text)

    fun isStopOrInterruptionCommand(text: String): Boolean = VoiceCommandRouter.isStopOrInterruptionCommand(text)

    private fun containsWakeWord(text: String): Boolean = VoiceCommandRouter.containsWakeWord(text)

    private fun isTrainingCommand(prompt: String): Boolean = VoiceCommandRouter.isTrainingCommand(prompt)

    /** Hands the goal to the universal agent and speaks the TRUE outcome when it finishes. */
    private fun runUniversalAgent(context: Context, prompt: String) {
        playAcknowledgeChime()
        _uiState.update { it.copy(state = AssistantState.PROCESSING, statusMessage = "Muskan kaam kar rahi hai…") }
        com.example.automation.UniversalPhoneAgent.start(context, prompt) { success, feedback ->
            val resultMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = feedback)
            _uiState.update { current ->
                current.copy(
                    state = AssistantState.SPEAKING,
                    statusMessage = feedback,
                    lastResponseText = feedback,
                    conversationHistory = current.conversationHistory + resultMsg
                )
            }
            saveTurnToRoom(
                prompt = prompt,
                response = feedback,
                isAutomation = true,
                actionTag = if (success) "Agent Task" else "Agent Notice"
            )
            mainHandler.post { speakOut(feedback) }
        }
    }

    private fun isDeviceAutomationRequest(prompt: String): Boolean =
        VoiceCommandRouter.isDeviceAutomationRequest(prompt)

    private fun extractQueryAfterWakeWord(text: String): String =
        VoiceCommandRouter.extractQueryAfterWakeWord(text)

    private fun createSpeechIntent(isWakeWord: Boolean): Intent {
        val context = appContext
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("hi-IN", "en-US", "en-IN"))
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            if (context != null) {
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            }

            if (preferOfflineSpeechRecognition || _uiState.value.isOfflineBrainForced || !isDeviceOnline()) {
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }

            // Muskan SpeechPipeline continuous recognition parameters:
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000L)
        }
    }

    fun stopListening() {
        isListeningEnabledByUser = false
        silentVadGateJob?.cancel()
        audioStreamManager?.stopStream()
        cancelInactivityWatchdog()
        silenceWatchdogJob?.cancel()
        sessionCountdownJob?.cancel()
        isContinuousSessionActive = false
        stopGeminiLiveSession()
        _uiState.update {
            it.copy(
                state = AssistantState.IDLE,
                isContinuousSessionActive = false,
                isListeningEnabledByUser = false,
                isGeminiLiveConnected = false,
                sessionRemainingSeconds = 0,
                statusMessage = "Listening is OFF • Tap mic to start",
                audioRmsLevel = 0f,
                isWakeWordStandby = false
            )
        }
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
                speechRecognizer?.cancel()
            } catch (_: Exception) {}
            isRecognizerListening = false
        }
    }

    fun stopHandsFreeListening() {
        stopListening()
    }

    private fun cleanUpRecognizer() {
        silenceWatchdogJob?.cancel()
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer = null
        isRecognizerListening = false
    }

    fun setAccessibilityServiceConnected(connected: Boolean) {
        _uiState.update { it.copy(isAccessibilityEnabled = connected) }
    }

    /* -------------------------------------------------------------
     * MANUAL API MANAGEMENT DELEGATORS
     * ------------------------------------------------------------- */

    fun setShowApiManagerDialog(show: Boolean) {
        _uiState.update { it.copy(showApiManagerDialog = show) }
    }

    fun setActiveApiProfile(profileId: String): Result<ApiProfile> {
        val result = ApiProfileManager.setActiveProfile(profileId)
        result.onSuccess { active ->
            _uiState.update {
                it.copy(
                    activeApiName = active.name,
                    activeApiStatus = if (active.isVerified) "VERIFIED" else "NOT VERIFIED"
                )
            }
        }
        return result
    }

    fun resetToDefaultApi(): ApiProfile {
        val defaultProfile = ApiProfileManager.resetToDefault()
        _uiState.update {
            it.copy(
                activeApiName = defaultProfile.name,
                activeApiStatus = "VERIFIED"
            )
        }
        return defaultProfile
    }

    suspend fun verifyApiProfile(profile: ApiProfile): ApiVerificationResult {
        return ApiProfileManager.verifyProfile(profile)
    }

    fun saveApiProfile(profile: ApiProfile) {
        ApiProfileManager.saveProfile(profile)
    }

    fun deleteApiProfile(profileId: String): Boolean {
        val res = ApiProfileManager.deleteProfile(profileId)
        val active = ApiProfileManager.getActiveProfile()
        _uiState.update {
            it.copy(
                activeApiName = active.name,
                activeApiStatus = if (active.isVerified) "VERIFIED" else "NOT VERIFIED"
            )
        }
        return res
    }

    fun checkAccessibilityStatus() {
        val context = appContext ?: return
        val enabled = com.example.service.MuskanAccessibilityService.isAccessibilitySettingsEnabled(context)
        _uiState.update { it.copy(isAccessibilityEnabled = enabled) }
    }

    fun setOverlayPermissionGranted(granted: Boolean) {
        _uiState.update { it.copy(isOverlayPermissionGranted = granted) }
    }

    fun checkOverlayPermission() {
        val context = appContext ?: return
        val granted = com.example.service.FloatingBubbleService.hasOverlayPermission(context)
        _uiState.update { it.copy(isOverlayPermissionGranted = granted) }
    }

    fun setFloatingBubbleActive(active: Boolean) {
        _uiState.update { it.copy(isFloatingBubbleActive = active) }
    }

    /**
     * Touch Override: Triggered when user manually touches/interacts with the screen
     * while an automated accessibility action or agentic plan is running.
     * Instantly yields control back to manual user gestures.
     */
    fun notifyUserManualTouchDetected() {
        val currentState = _uiState.value
        if (currentState.isAgenticTaskRunning) {
            com.example.automation.AgenticExecutionPlanner.cancelExecution()
            com.example.automation.UniversalPhoneAgent.cancel()
            val notice = "Manual touch detected. Muskan yielding control to you."
            _uiState.update {
                it.copy(
                    isUserInteractingManually = true,
                    statusMessage = notice
                )
            }
            mainHandler.post {
                speakOut("Control aapke haath mein de rahi hoon.")
            }
        }
    }

    fun setGamingMode(enabled: Boolean) {
        _uiState.update { it.copy(isGamingMode = enabled) }
    }

    fun toggleGamingMode() {
        _uiState.update { it.copy(isGamingMode = !it.isGamingMode) }
    }

    fun updateAgenticExecution(
        running: Boolean,
        title: String?,
        step: Int,
        total: Int,
        statusText: String?
    ) {
        _uiState.update {
            it.copy(
                isAgenticTaskRunning = running,
                currentAgenticPlanTitle = title,
                currentAgenticStepIndex = step,
                totalAgenticSteps = total,
                agenticCurrentStatusText = statusText,
                statusMessage = if (running && statusText != null) statusText else it.statusMessage
            )
        }
    }

    fun processSpeechInput(prompt: String) {
        if (prompt.isBlank()) return

        wakeWordLoopJob?.cancel()
        silenceWatchdogJob?.cancel()
        cancelInactivityWatchdog()
        cleanUpRecognizer()

        val userMessage = VoiceMessage(sender = MessageSender.USER, text = prompt)

        _uiState.update { current ->
            current.copy(
                state = AssistantState.PROCESSING,
                statusMessage = "Muskan is thinking…",
                lastUserQuery = prompt,
                partialTranscript = "",
                errorMessage = null,
                isWakeWordStandby = false,
                wakeWordDetectedNotice = false,
                conversationHistory = current.conversationHistory + userMessage
            )
        }

        val lowerPrompt = prompt.lowercase(Locale.ROOT).trim()

        val isAgenticBusy = _uiState.value.isAgenticTaskRunning ||
                com.example.automation.AgenticExecutionPlanner.isExecuting.value

        // 0. Live Voice Interruption & Stop Protocol (Barge-in / Cancel)
        if (isStopOrInterruptionCommand(lowerPrompt)) {
            com.example.automation.AgenticExecutionPlanner.cancelExecution()
            com.example.automation.UniversalPhoneAgent.cancel()
            mainHandler.post { textToSpeech?.stop() }
            playAcknowledgeChime()
            val stopReply = "काम रोक दिया गया है, सर।"
            val assistantMessage = VoiceMessage(sender = MessageSender.ASSISTANT, text = stopReply)
            _uiState.update { current ->
                current.copy(
                    state = AssistantState.SPEAKING,
                    statusMessage = stopReply,
                    lastResponseText = stopReply,
                    conversationHistory = current.conversationHistory + assistantMessage
                )
            }
            saveTurnToRoom(prompt, stopReply, isAutomation = true, actionTag = "Interruption Stop")
            mainHandler.post { speakOut(stopReply) }
            return
        }

        // Live Barge-in Preemption: If tasks were running and user gives a NEW command:
        if (isAgenticBusy) {
            com.example.automation.AgenticExecutionPlanner.cancelExecution()
            com.example.automation.UniversalPhoneAgent.cancel()
            mainHandler.post { textToSpeech?.stop() }
            playAcknowledgeChime()
        }

        // Always-On Screen Perception query handler
        if (VoiceCommandRouter.isScreenQuery(prompt)) {
            val snapshot = com.example.automation.AlwaysOnScreenPerceptionManager.latestSnapshot.value
            val narrative = com.example.automation.AlwaysOnScreenPerceptionManager.generateScreenNarrative(snapshot)
            val replyText = "Ji Sultan. Screen perception ke mutabiq: $narrative"
            val assistantMessage = VoiceMessage(sender = MessageSender.ASSISTANT, text = replyText)
            _uiState.update { current ->
                current.copy(
                    state = AssistantState.SPEAKING,
                    statusMessage = replyText,
                    lastResponseText = replyText,
                    conversationHistory = current.conversationHistory + assistantMessage
                )
            }
            saveTurnToRoom(prompt, replyText, isAutomation = true, actionTag = "Screen Perception")
            mainHandler.post { speakOut(replyText) }
            return
        }

        // 0. Pre-LLM Dynamic Dashboard & UIController Command Interception (REAL UI MODIFICATION - NO FABRICATION)
        if (VoiceCommandRouter.isDashboardUiCommand(prompt)) {
            val result = com.example.ui.controller.MuskanUIController.executeAgentCommand(prompt)
            val extractedTitle = com.example.ui.controller.MuskanUIController.extractDynamicTitle(prompt)
            val reply = if (result is com.example.ui.controller.AgentUIResult.Success) {
                "Beshak Sultan, maine dashboard par $extractedTitle card live add kar diya hai. Kaam mukammal ho gaya hai, Sultan."
            } else {
                "Sultan, card add karne mein error aaya."
            }
            val assistantMessage = VoiceMessage(sender = MessageSender.ASSISTANT, text = reply)
            _uiState.update { current ->
                current.copy(
                    state = AssistantState.SPEAKING,
                    statusMessage = reply,
                    lastResponseText = reply,
                    conversationHistory = current.conversationHistory + assistantMessage
                )
            }
            saveTurnToRoom(prompt, reply, isAutomation = true, actionTag = "Dynamic Dashboard")
            mainHandler.post { speakOut(reply) }
            return
        }

        // 0.03 Self-Training & Procedural Learning Memory Inquiry ("System ne naya kya seekha?")
        if (VoiceCommandRouter.isLearningInquiry(prompt)) {
            val ctx = appContext
            scope.launch(Dispatchers.Main) {
                val learnedReply = com.example.engine.learning.SelfTrainingMemoryEngine.getLearnedSummaryForVoice(ctx)
                val assistantMessage = VoiceMessage(sender = MessageSender.ASSISTANT, text = learnedReply)
                _uiState.update { current ->
                    current.copy(
                        state = AssistantState.SPEAKING,
                        statusMessage = learnedReply,
                        lastResponseText = learnedReply,
                        conversationHistory = current.conversationHistory + assistantMessage
                    )
                }
                saveTurnToRoom(prompt, learnedReply, isAutomation = true, actionTag = "Procedural Memory")
                speakOut(learnedReply)
            }
            return
        }

        // 0.04 Self-Diagnosis & Error Status Inquiry
        if (VoiceCommandRouter.isErrorInquiry(prompt)) {
            val errorReportReply = com.example.engine.repair.SelfRepairEngine.getHealingSummaryForVoice()
            val assistantMessage = VoiceMessage(sender = MessageSender.ASSISTANT, text = errorReportReply)
            _uiState.update { current ->
                current.copy(
                    state = AssistantState.SPEAKING,
                    statusMessage = errorReportReply,
                    lastResponseText = errorReportReply,
                    conversationHistory = current.conversationHistory + assistantMessage
                )
            }
            saveTurnToRoom(prompt, errorReportReply, isAutomation = true, actionTag = "Self Repair")
            mainHandler.post { speakOut(errorReportReply) }
            return
        }

        // 0.15 Prompt-to-source workflow: generate a reviewable patch bundle inside Muskan.
        // The installed APK is never represented as self-modified; Android source changes must
        // be exported, reviewed, built, and installed separately.
        if (com.example.engine.dev.SelfDevelopmentEngine.isSelfDevelopmentPrompt(prompt)) {
            val ctx = appContext
            if (ctx == null) {
                val unavailable = "Self-development workspace is not initialized yet. Open Muskan fully and retry."
                _uiState.update { current -> current.copy(statusMessage = unavailable, lastResponseText = unavailable) }
                mainHandler.post { speakOut(unavailable) }
                return
            }
            val kickoff = "जी, मुस्कान सेल्फ़-डेवलपमेंट टास्क शुरू कर रही है। सोर्स ड्राफ़्ट तैयार किया जा रहा है..."
            val kickoffMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = kickoff)
            _uiState.update { current ->
                current.copy(
                    state = AssistantState.PROCESSING,
                    statusMessage = kickoff,
                    lastResponseText = kickoff,
                    conversationHistory = current.conversationHistory + kickoffMsg
                )
            }
            mainHandler.post { speakOut(kickoff) }
            scope.launch {
                val result = com.example.engine.dev.SelfDevelopmentEngine.generatePatch(ctx, prompt)
                val report = if (result.success) {
                    "${result.message} Draft ID: ${result.draftId}. Internal bundle: ${result.zipPath}. Important: this is a reviewable source patch only; it has not changed the installed APK and no Android build/device test has been run."
                } else {
                    "Self-development stopped safely. ${result.message}"
                }
                val resultMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = report)
                _uiState.update { current ->
                    current.copy(
                        state = AssistantState.SPEAKING,
                        statusMessage = report,
                        lastResponseText = report,
                        conversationHistory = current.conversationHistory + resultMsg
                    )
                }
                saveTurnToRoom(prompt, report, isAutomation = true, actionTag = "Self Development")
                mainHandler.post { speakOut(report) }
            }
            return
        }

        // 0. Engine Orchestration & Task-Specific Route Selection
        val orchestration = com.example.engine.EngineOrchestrator.orchestrate(prompt)
        _uiState.update { it.copy(lastOrchestrationRationale = orchestration.rationale) }

        val context = appContext
        val lower = prompt.lowercase()
        if (context != null) {
            // 0.85 WebSocket & WebRTC Signaling voice control
            if (VoiceCommandRouter.isWebSocketOrWebRtcCommand(prompt)) {
                com.example.engine.network.MuskanWebSocketBridge.init(context)
                val msg = when {
                    lower.contains("disconnect") || lower.contains("band karo") || lower.contains("बंद करो") -> {
                        com.example.engine.network.WebRtcSignalingManager.closeSession("Closed by voice command")
                        com.example.engine.network.MuskanWebSocketBridge.disconnect("Disconnected by voice command")
                        "WebSocket aur WebRTC signaling session band kar diya gaya hai, Sultan."
                    }
                    lower.contains("webrtc") || lower.contains("signaling") -> {
                        val summary = com.example.engine.network.WebRtcSignalingManager.runLoopbackSelfTest("muskan-voice-room")
                        "WebRTC signaling active aur STABLE hai, Sultan. ($summary)"
                    }
                    else -> {
                        com.example.engine.network.MuskanWebSocketBridge.connect(context)
                        "WebSocket bridge connect kar diya gaya hai, Sultan."
                    }
                }
                val resultMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = msg)
                _uiState.update { current ->
                    current.copy(
                        state = AssistantState.SPEAKING,
                        statusMessage = msg,
                        lastResponseText = msg,
                        conversationHistory = current.conversationHistory + resultMsg
                    )
                }
                saveTurnToRoom(prompt, msg, isAutomation = true, actionTag = "WebSocket/WebRTC")
                mainHandler.post { speakOut(msg) }
                return
            }

            // 0.9 "Training kholo" -> open the knowledge / training screen
            if (isTrainingCommand(prompt)) {
                try {
                    context.startActivity(android.content.Intent(context, com.example.ui.TrainingActivity::class.java)
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {}
                val msg = "Training screen khol di, Sultan."
                _uiState.update { it.copy(state = AssistantState.SPEAKING, statusMessage = msg, lastResponseText = msg) }
                mainHandler.post { speakOut(msg) }
                return
            }

            // 0.92 Module 09: Calendar & Appointment Engine (schedule reading, conflict check, approval-gated events)
            if (VoiceCommandRouter.isCalendarCommand(prompt)) {
                _uiState.update { it.copy(state = AssistantState.PROCESSING, statusMessage = "Calendar check ho raha hai...") }
                scope.launch {
                    val reply = com.example.engine.calendar.CalendarEngine.handleVoiceCalendarCommand(context, prompt)
                    val resultMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = reply)
                    _uiState.update { current ->
                        current.copy(
                            state = AssistantState.SPEAKING,
                            statusMessage = reply,
                            lastResponseText = reply,
                            conversationHistory = current.conversationHistory + resultMsg
                        )
                    }
                    saveTurnToRoom(prompt, reply, isAutomation = true, actionTag = "CalendarEngine")
                    mainHandler.post { speakOut(reply) }
                }
                return
            }

            // 0.93 Module 05: AI Email Management Engine (Gmail API + AI summarize/draft + approval-gated send)
            if (VoiceCommandRouter.isEmailCommand(prompt)) {
                _uiState.update { it.copy(state = AssistantState.PROCESSING, statusMessage = "Email engine process kar raha hai...") }
                scope.launch {
                    val reply = com.example.engine.email.EmailEngine.handleVoiceEmailCommand(context, prompt)
                    val resultMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = reply)
                    _uiState.update { current ->
                        current.copy(
                            state = AssistantState.SPEAKING,
                            statusMessage = reply,
                            lastResponseText = reply,
                            conversationHistory = current.conversationHistory + resultMsg
                        )
                    }
                    saveTurnToRoom(prompt, reply, isAutomation = true, actionTag = "EmailEngine")
                    mainHandler.post { speakOut(reply) }
                }
                return
            }

            // 0.935 Module 08: Autonomous Calling & Call Screening Engine
            if (VoiceCommandRouter.isCallingCommand(prompt)) {
                _uiState.update { it.copy(state = AssistantState.PROCESSING, statusMessage = "Call screening report check ho raha hai...") }
                scope.launch {
                    com.example.engine.calling.CallingEngine.initialize(context)
                    val reply = com.example.engine.calling.CallingEngine.handleVoiceCallingCommand(context, prompt)
                    val resultMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = reply)
                    _uiState.update { current ->
                        current.copy(
                            state = AssistantState.SPEAKING,
                            statusMessage = reply,
                            lastResponseText = reply,
                            conversationHistory = current.conversationHistory + resultMsg
                        )
                    }
                    saveTurnToRoom(prompt, reply, isAutomation = true, actionTag = "CallingEngine")
                    mainHandler.post { speakOut(reply) }
                }
                return
            }

            // 0.94 Module 04: Digital Intelligence & Authorized Public OSINT Engine
            if (VoiceCommandRouter.isOsintCommand(prompt)) {
                _uiState.update { it.copy(state = AssistantState.PROCESSING, statusMessage = "OSINT aur link safety analysis chal raha hai...") }
                scope.launch {
                    val reply = com.example.engine.osint.DigitalIntelligenceEngine.handleVoiceOsintCommand(context, prompt)
                    val resultMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = reply)
                    _uiState.update { current ->
                        current.copy(
                            state = AssistantState.SPEAKING,
                            statusMessage = reply,
                            lastResponseText = reply,
                            conversationHistory = current.conversationHistory + resultMsg
                        )
                    }
                    saveTurnToRoom(prompt, reply, isAutomation = true, actionTag = "DigitalIntelligenceEngine")
                    mainHandler.post { speakOut(reply) }
                }
                return
            }

            // 0.942 Module 06: AI Image & Video Creation Studio
            if (VoiceCommandRouter.isMediaStudioCommand(prompt)) {
                _uiState.update { it.copy(state = AssistantState.PROCESSING, statusMessage = "Media Studio render kar raha hai...") }
                scope.launch {
                    val reply = com.example.engine.media.MediaStudioEngine.handleVoiceMediaCommand(context, prompt)
                    val resultMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = reply)
                    _uiState.update { current ->
                        current.copy(
                            state = AssistantState.SPEAKING,
                            statusMessage = reply,
                            lastResponseText = reply,
                            conversationHistory = current.conversationHistory + resultMsg
                        )
                    }
                    saveTurnToRoom(prompt, reply, isAutomation = true, actionTag = "MediaStudioEngine")
                    mainHandler.post { speakOut(reply) }
                }
                return
            }

            // 0.944 Module 01: Social Media Management Engine
            if (VoiceCommandRouter.isSocialMediaCommand(prompt)) {
                _uiState.update { it.copy(state = AssistantState.PROCESSING, statusMessage = "Social Media engine process kar raha hai...") }
                scope.launch {
                    val reply = com.example.engine.social.SocialMediaEngine.handleVoiceSocialCommand(context, prompt)
                    val resultMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = reply)
                    _uiState.update { current ->
                        current.copy(
                            state = AssistantState.SPEAKING,
                            statusMessage = reply,
                            lastResponseText = reply,
                            conversationHistory = current.conversationHistory + resultMsg
                        )
                    }
                    saveTurnToRoom(prompt, reply, isAutomation = true, actionTag = "SocialMediaEngine")
                    mainHandler.post { speakOut(reply) }
                }
                return
            }

            // 0.946 Module 13: Client Work & Business Engine (CRM + PDF Invoices)
            if (VoiceCommandRouter.isBusinessCommand(prompt)) {
                _uiState.update { it.copy(state = AssistantState.PROCESSING, statusMessage = "Business CRM & Invoice engine active...") }
                scope.launch {
                    val reply = com.example.engine.business.BusinessEngine.handleVoiceBusinessCommand(context, prompt)
                    val resultMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = reply)
                    _uiState.update { current ->
                        current.copy(
                            state = AssistantState.SPEAKING,
                            statusMessage = reply,
                            lastResponseText = reply,
                            conversationHistory = current.conversationHistory + resultMsg
                        )
                    }
                    saveTurnToRoom(prompt, reply, isAutomation = true, actionTag = "BusinessEngine")
                    mainHandler.post { speakOut(reply) }
                }
                return
            }

            // 0.95 Open-ended / multi-step requests go to the universal agent FIRST: it figures out HOW itself
            if (com.example.automation.UniversalPhoneAgent.shouldTakePriority(prompt)) {
                runUniversalAgent(context, prompt)
                return
            }

            // 1. Check for Multi-Step Autonomous Agentic Tasks FIRST (WhatsApp, YouTube seek/skip, Movie download, Reels scroll, ChatGPT, Notes, Camera, Maps)
            val agenticPlan = com.example.automation.AgenticExecutionPlanner.createPlanForPrompt(prompt)
            if (agenticPlan != null) {
                // Action-First Protocol:
                // Pre-Speech Suppression: Play 150ms HUD chime acknowledgment tone immediately without preliminary talking
                playAcknowledgeChime()
                _uiState.update { current ->
                    current.copy(
                        state = AssistantState.PROCESSING,
                        statusMessage = "एक्ज़ीक्यूट हो रहा है..."
                    )
                }

                // CRITICAL: Execute plan IMMEDIATELY with live cursor pointer & state verification
                com.example.automation.AgenticExecutionPlanner.executePlan(context, agenticPlan) { success, feedback ->
                    if (!success && !feedback.contains("Approval denied", ignoreCase = true) && !feedback.contains("denied", ignoreCase = true)) {
                        // Fallback to UniversalPhoneAgent (with Redmi 13 5G notes) if legacy fixed planner fails
                        runUniversalAgent(context, prompt)
                        return@executePlan
                    }
                    val resultMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = feedback)
                    _uiState.update { current ->
                        current.copy(
                            state = AssistantState.SPEAKING,
                            statusMessage = feedback,
                            lastResponseText = feedback,
                            conversationHistory = current.conversationHistory + resultMsg
                        )
                    }
                    saveTurnToRoom(
                        prompt = prompt,
                        response = feedback,
                        isAutomation = true,
                        actionTag = if (success) "Agentic Task" else "Agentic Error"
                    )
                    // Final Vocal Report in calm, authoritative Muskan tone
                    mainHandler.post { speakOut(feedback) }
                }
                return
            }

            // 2. Direct Device Automation Actions (Torch, Volume, Settings, Navigation, Direct App Launch)
            val autoResult = com.example.automation.AutomationActionEngine.processVoiceCommand(context, prompt)
            when (autoResult) {
                is com.example.automation.AutomationResult.Handled -> {
                    val assistantMessage = VoiceMessage(
                        sender = MessageSender.ASSISTANT,
                        text = autoResult.spokenFeedback
                    )
                    _uiState.update { current ->
                        current.copy(
                            state = AssistantState.SPEAKING,
                            statusMessage = autoResult.spokenFeedback,
                            lastResponseText = autoResult.spokenFeedback,
                            conversationHistory = current.conversationHistory + assistantMessage
                        )
                    }
                    saveTurnToRoom(prompt, autoResult.spokenFeedback, isAutomation = true, actionTag = "Automation")
                    mainHandler.post {
                        speakOut(autoResult.spokenFeedback)
                    }
                    return
                }
                is com.example.automation.AutomationResult.AccessibilityRequired -> {
                    val assistantMessage = VoiceMessage(
                        sender = MessageSender.ASSISTANT,
                        text = autoResult.message
                    )
                    _uiState.update { current ->
                        current.copy(
                            state = AssistantState.SPEAKING,
                            statusMessage = autoResult.message,
                            lastResponseText = autoResult.message,
                            conversationHistory = current.conversationHistory + assistantMessage
                        )
                    }
                    saveTurnToRoom(prompt, autoResult.message, isAutomation = true, actionTag = "Notice")
                    mainHandler.post {
                        speakOut(autoResult.message)
                    }
                    return
                }
                is com.example.automation.AutomationResult.NotAnAutomationCommand -> {
                    // Continue to offline and cloud intelligence handlers
                }
            }

            // 2.4 Anything else that sounds like a phone task: the universal agent works it out itself
            if (com.example.automation.UniversalPhoneAgent.shouldHandle(prompt)) {
                runUniversalAgent(context, prompt)
                return
            }

            // 2.5 Strict Device Automation Guard: Prevent LLM fabrication
            if (isDeviceAutomationRequest(prompt)) {
                val lower = prompt.lowercase(Locale.ROOT).trim()
                val feedback = if (lower.contains("whatsapp")) {
                    val encoded = Uri.encode(prompt)
                    val directIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?text=$encoded")).apply {
                        setPackage("com.whatsapp")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try { context.startActivity(directIntent) } catch (_: Exception) {
                        com.example.service.MuskanAccessibilityService.launchAppByName(context, "whatsapp")
                    }
                    if (!com.example.service.MuskanAccessibilityService.isConnected()) {
                        com.example.service.MuskanAccessibilityService.openAccessibilitySettings(context)
                        "Accessibility permission band hai, WhatsApp control karne ke liye Settings on karein."
                    } else {
                        "WhatsApp open kar diya hai, Sultan."
                    }
                } else {
                    "Sultan, yeh device action poora karne ke liye automation command recognize nahi ho paayi."
                }
                val assistantMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = feedback)
                _uiState.update { current ->
                    current.copy(
                        state = AssistantState.SPEAKING,
                        statusMessage = feedback,
                        lastResponseText = feedback,
                        conversationHistory = current.conversationHistory + assistantMsg
                    )
                }
                saveTurnToRoom(prompt, feedback, isAutomation = true, actionTag = "Automation Guard")
                mainHandler.post { speakOut(feedback) }
                return
            }
        }

        // 3. Check for Instant Offline Keyword Responses (Time, Date, Identity, Greetings, Capabilities)
        val offlineAnswer = com.example.util.OfflineKeywordResponder.matchOfflineResponse(prompt)
        if (offlineAnswer != null) {
            val assistantMessage = VoiceMessage(
                sender = MessageSender.ASSISTANT,
                text = offlineAnswer.answer
            )
            _uiState.update { current ->
                current.copy(
                    state = AssistantState.SPEAKING,
                    statusMessage = offlineAnswer.answer,
                    lastResponseText = offlineAnswer.answer,
                    conversationHistory = current.conversationHistory + assistantMessage
                )
            }
            saveTurnToRoom(prompt, offlineAnswer.answer, isAutomation = true, actionTag = "Offline (${offlineAnswer.category})")
            mainHandler.post {
                speakOut(offlineAnswer.answer)
            }
            return
        }

        scope.launch {
            try {
                val ctx = appContext
                val recentTurns = if (ctx != null) {
                    try {
                        com.example.data.local.AppDatabase.getDatabase(ctx)
                            .conversationTurnDao()
                            .getRecentTurns(4)
                            .reversed()
                            .map { Pair(it.userQuery, it.assistantResponse) }
                    } catch (_: Exception) {
                        emptyList()
                    }
                } else emptyList()

                val learnedMemories = if (ctx != null) {
                    try {
                        com.example.data.local.AppDatabase.getDatabase(ctx)
                            .userMemoryDao()
                            .getAllMemories()
                            .map { "${it.category}: ${it.title} - ${it.detail}" }
                    } catch (_: Exception) {
                        emptyList()
                    }
                } else emptyList()

                val historyPairs = if (recentTurns.isNotEmpty()) {
                    recentTurns
                } else {
                    _uiState.value.conversationHistory
                        .dropLast(1) // exclude current user prompt
                        .chunked(2)
                        .mapNotNull { chunk ->
                            val user = chunk.firstOrNull { it.sender == MessageSender.USER }?.text
                            val assistant = chunk.firstOrNull { it.sender == MessageSender.ASSISTANT }?.text
                            if (user != null && assistant != null) Pair(user, assistant) else null
                        }
                }

                // 1. Check Voice-Taught Workflow Teaching ("Muskan, naya routine sikho: jab main bolun X toh...")
                if (ctx != null) {
                    val taught = com.example.engine.workflow.TaughtWorkflowEngine.teachWorkflowFromSpeech(ctx, prompt)
                    if (taught != null) {
                        val reply = "Ji Sultan! Maine naya routine '${taught.title}' hamesha ke liye yaad kar liya hai. Jab bhi aap bolenge '${taught.triggerPhrase}', main ise chala doongi."
                        val assistantMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = reply)
                        _uiState.update { current ->
                            current.copy(
                                state = AssistantState.SPEAKING,
                                statusMessage = "Taught Workflow Saved",
                                lastResponseText = reply,
                                conversationHistory = current.conversationHistory + assistantMsg
                            )
                        }
                        saveTurnToRoom(prompt = prompt, response = reply, isAutomation = true, actionTag = "TaughtWorkflow")
                        mainHandler.post { speakOut(reply) }
                        return@launch
                    }
                }

                // 2. Check Permanent Memory statements ("Mera naam Sultan Mirza hai", "Mujhe coffee pasand hai", "Yaad rakhna...")
                if (ctx != null) {
                    val memCapture = com.example.engine.memory.PermanentMemoryEngine.inspectAndCaptureMemory(ctx, prompt)
                    if (memCapture.isHandled && memCapture.confirmationSpeech != null) {
                        val reply = memCapture.confirmationSpeech
                        val assistantMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = reply)
                        _uiState.update { current ->
                            current.copy(
                                state = AssistantState.SPEAKING,
                                statusMessage = "Memory Permanently Saved",
                                lastResponseText = reply,
                                conversationHistory = current.conversationHistory + assistantMsg
                            )
                        }
                        saveTurnToRoom(prompt = prompt, response = reply, isAutomation = false, actionTag = "PermanentMemory")
                        mainHandler.post { speakOut(reply) }
                        return@launch
                    }
                }

                // 3. Check Taught Workflow execution triggers ("Good morning", "Night routine", "Focus mode", etc.)
                if (ctx != null) {
                    val matchingWf = com.example.engine.workflow.TaughtWorkflowEngine.findMatchingWorkflow(ctx, prompt)
                    if (matchingWf != null) {
                        val reply = "Routine '${matchingWf.title}' chala rahi hoon, Sultan."
                        val assistantMsg = VoiceMessage(sender = MessageSender.ASSISTANT, text = reply)
                        _uiState.update { current ->
                            current.copy(
                                state = AssistantState.SPEAKING,
                                statusMessage = "Executing ${matchingWf.title}…",
                                lastResponseText = reply,
                                conversationHistory = current.conversationHistory + assistantMsg
                            )
                        }
                        saveTurnToRoom(prompt = prompt, response = reply, isAutomation = true, actionTag = "WorkflowExecution")
                        mainHandler.post {
                            speakOut(reply) {
                                scope.launch {
                                    com.example.engine.workflow.TaughtWorkflowEngine.executeWorkflow(ctx, matchingWf)
                                }
                            }
                        }
                        return@launch
                    }
                }

                val brainResult = if (ctx != null) {
                    com.example.engine.brain.DualBrainCoordinator.executeReasoning(
                        context = ctx,
                        prompt = prompt,
                        recentHistory = historyPairs,
                        learnedFacts = learnedMemories
                    )
                } else {
                    com.example.engine.brain.DualBrainCoordinator.BrainResult(
                        responseText = "सुल्तान सर, सिस्टम इनिशियलाइज़ हो रहा है।",
                        source = com.example.engine.brain.DualBrainCoordinator.BrainSource.OFFLINE_DEVICE_SLM,
                        isOffline = true,
                        latencyMs = 0L
                    )
                }

                val augmentedResponse = com.example.engine.dialogue.DialogueManagementEngine.augmentWithCounterQuestionIfNeeded(
                    prompt,
                    brainResult.responseText
                )
                val assistantMessage = VoiceMessage(
                    sender = MessageSender.ASSISTANT,
                    text = augmentedResponse
                )

                val statusMsg = if (brainResult.isOffline) {
                    "Muskan speaking (${brainResult.source.displayName})…"
                } else {
                    "Muskan speaking (Gemini Cloud)…"
                }

                _uiState.update { current ->
                    current.copy(
                        state = AssistantState.SPEAKING,
                        statusMessage = statusMsg,
                        lastResponseText = augmentedResponse,
                        lastBrainUsed = brainResult.source.displayName,
                        errorMessage = brainResult.detailNotice,
                        conversationHistory = current.conversationHistory + assistantMessage
                    )
                }

                saveTurnToRoom(
                    prompt = prompt,
                    response = augmentedResponse,
                    isAutomation = brainResult.isOffline,
                    actionTag = brainResult.source.displayName
                )

                mainHandler.post {
                    speakOut(augmentedResponse)
                }
            } catch (t: Throwable) {
                val fallbackReply = "Maaf kijiye Sultan, abhi is sawal par jawab dene mein dikkat aayi hai. Dobara kahiye?"
                val assistantMessage = VoiceMessage(sender = MessageSender.ASSISTANT, text = fallbackReply)
                _uiState.update { current ->
                    current.copy(
                        state = AssistantState.SPEAKING,
                        statusMessage = fallbackReply,
                        lastResponseText = fallbackReply,
                        errorMessage = t.localizedMessage,
                        conversationHistory = current.conversationHistory + assistantMessage
                    )
                }
                mainHandler.post { speakOut(fallbackReply) }
            }
        }
    }

    fun speakOut(text: String, onDone: (() -> Unit)? = null) {
        if (text.isBlank()) {
            onDone?.invoke()
            return
        }

        // Pause speech recognition gracefully without destroying or resetting audio tracks
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {}
        isRecognizerListening = false

        onSpeechDoneCallback = onDone
        val cleanText = cleanForTts(text)

        if (!isTtsReady || textToSpeech == null) {
            pendingSpeechText = cleanText
            return
        }

        if (!isVerifiedFemaleVoiceSelected) {
            configureHinglishVoice()
        }

        val effectivePitch = _uiState.value.speechPitch.coerceIn(0.6f, 1.8f)
        val effectiveRate = _uiState.value.speechRate.coerceIn(0.6f, 1.8f)
        try {
            textToSpeech?.setPitch(effectivePitch)
            textToSpeech?.setSpeechRate(effectiveRate)
        } catch (_: Exception) {}

        val utteranceId = UUID.randomUUID().toString()
        val params = Bundle().apply {
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        }

        try {
            var speakResult = textToSpeech?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
            if (speakResult == TextToSpeech.ERROR) {
                speakResult = textToSpeech?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
            }
            if (speakResult == TextToSpeech.ERROR || speakResult == null) {
                _uiState.update {
                    it.copy(
                        isTtsSpeaking = false,
                        state = if (isListeningEnabledByUser && !it.isMuted) AssistantState.LISTENING else AssistantState.IDLE,
                        statusMessage = if (isListeningEnabledByUser && !it.isMuted) "Listening… Speak your command" else "Ready"
                    )
                }
                val callback = onSpeechDoneCallback
                onSpeechDoneCallback = null
                if (callback != null) {
                    callback()
                } else if (isListeningEnabledByUser && !_uiState.value.isMuted) {
                    safeStartListening(isContinuousSession = isContinuousSessionActive)
                }
            }
            // Muskan Non-Intrusive Engine: Never start recognition while TTS is actively speaking!
            // Listening resumes cleanly in onDone callback once speech concludes without self-trigger or false interrupts.
        } catch (e: Exception) {
            _uiState.update {
                it.copy(
                    isTtsSpeaking = false,
                    state = AssistantState.IDLE,
                    statusMessage = "Ready"
                )
            }
            val callback = onSpeechDoneCallback
            onSpeechDoneCallback = null
            callback?.invoke() ?: run {
                if (isListeningEnabledByUser && !_uiState.value.isMuted) {
                    safeStartListening(isContinuousSession = isContinuousSessionActive)
                }
            }
        }
    }

    fun stopTts() {
        onSpeechDoneCallback = null
        stopTtsWaveformSimulation()
        try {
            textToSpeech?.stop()
        } catch (_: Exception) {}
        _uiState.update {
            it.copy(
                isTtsSpeaking = false,
                audioOutputLevel = 0f,
                state = if (it.state == AssistantState.SPEAKING) AssistantState.IDLE else it.state,
                statusMessage = if (it.isMuted) {
                    "Muskan is muted • Say 'Muskan suno'"
                } else if (com.example.engine.dialogue.DialogueManagementEngine.contextFlow.value.isAwaitingAnswer) {
                    "Awaiting your reply, Sultan… (Listening)"
                } else if (it.isWakeWordEnabled) {
                    "Listening for 'Muskan'…"
                } else {
                    "Ready"
                }
            )
        }
        val isAwaiting = com.example.engine.dialogue.DialogueManagementEngine.contextFlow.value.isAwaitingAnswer
        if ((_uiState.value.isWakeWordEnabled || isAwaiting) && _uiState.value.hasAudioPermission && !_uiState.value.isMuted) {
            safeStartListening(isContinuousSession = isContinuousSessionActive || isAwaiting)
        }
    }

    /**
     * Instantly stops any active speech output and transitions directly to LISTENING state,
     * allowing Sultan to interrupt ("thokna") Muskan seamlessly without waiting!
     */
    fun stopTtsAndListen() {
        onSpeechDoneCallback = null
        stopTtsWaveformSimulation()
        try {
            textToSpeech?.stop()
        } catch (_: Exception) {}
        isListeningEnabledByUser = true
        _uiState.update {
            it.copy(
                isTtsSpeaking = false,
                audioOutputLevel = 0f,
                isMuted = false,
                isListeningEnabledByUser = true,
                state = AssistantState.LISTENING,
                statusMessage = "Listening to you, Sultan…",
                wakeWordDetectedNotice = true
            )
        }
        startContinuousSession()
        mainHandler.post {
            safeStartListening(isContinuousSession = true)
        }
    }

    fun replayLastResponse() {
        val lastResponse = _uiState.value.lastResponseText
        if (lastResponse.isNotBlank()) {
            speakOut(lastResponse)
        }
    }

    fun clearHistory() {
        stopTts()
        _uiState.update {
            it.copy(
                conversationHistory = emptyList(),
                lastUserQuery = "",
                lastResponseText = "",
                statusMessage = if (it.isMuted) {
                    "Chat cleared. Muskan is muted."
                } else if (it.isWakeWordEnabled) {
                    "Chat cleared. Say 'Muskan' to talk."
                } else {
                    "Conversation cleared."
                },
                errorMessage = null
            )
        }
    }

    private fun saveTurnToRoom(
        prompt: String,
        response: String,
        isAutomation: Boolean,
        actionTag: String? = null
    ) {
        scope.launch(Dispatchers.IO) {
            try {
                repository?.saveTurn(
                    userQuery = prompt,
                    assistantResponse = response,
                    isAutomationAction = isAutomation,
                    actionTag = actionTag
                )
            } catch (_: Exception) {}
        }
    }

    fun setHistoryPanelVisible(visible: Boolean) {
        _uiState.update { it.copy(showHistoryPanel = visible) }
    }

    fun clearRoomHistory() {
        scope.launch(Dispatchers.IO) {
            try {
                repository?.clearAllTurns()
            } catch (_: Exception) {}
        }
    }

    fun deleteHistoryTurn(id: Long) {
        scope.launch(Dispatchers.IO) {
            try {
                repository?.deleteTurn(id)
            } catch (_: Exception) {}
        }
    }

    fun setVoicePreset(preset: String) {
        val (rate, pitch) = when {
            preset.contains("Natural Hinglish", ignoreCase = true) -> 1.02f to 1.00f
            preset.contains("Warm & Gentle", ignoreCase = true) -> 0.95f to 0.96f
            preset.contains("Expressive", ignoreCase = true) -> 1.12f to 1.03f
            else -> 1.00f to 1.00f
        }
        applyVoiceSettings(rate = rate, pitch = pitch)
        _uiState.update { it.copy(voicePresetName = preset) }
    }

    private fun cleanForTts(raw: String): String {
        return raw
            .replace(Regex("```[\\s\\S]*?```"), "Code omitted.")
            .replace(Regex("`.*?`"), "")
            .replace(Regex("[*#_~>]"), "")
            .replace(Regex("\\[(.*?)\\]\\(.*?\\)"), "$1")
            .replace(Regex("[\\p{So}\\p{Cn}]"), "")
            .replace(Regex("(?i)\\be\\.g\\."), "for example")
            .replace(Regex("(?i)\\bi\\.e\\."), "that is")
            .replace(Regex("(?i)\\betc\\."), "and so on")
            .replace(Regex("(?i)\\bapprox\\."), "approximately")
            .replace(Regex("(?i)\\bvs\\."), "versus")
            .replace(Regex("(?i)\\bdr\\."), "Doctor")
            .replace(Regex("\\$([0-9]+)"), "$1 dollars")
            .replace(Regex("₹([0-9]+)"), "$1 rupees")
            .replace(Regex("([0-9]+)%"), "$1 percent")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun startTtsWaveformSimulation() {
        stopTtsWaveformSimulation()
        ttsWaveSimulationJob = scope.launch(Dispatchers.Default) {
            var step = 0
            while (true) {
                // Generate a natural speech cadence envelope using sine harmonies + slight randomness
                val t = step * 0.15f
                val primaryWave = (Math.sin(t.toDouble()).toFloat() + 1f) * 0.5f
                val secondaryWave = (Math.sin((t * 2.3f).toDouble()).toFloat() + 1f) * 0.5f
                val randomFluctuation = (Math.random().toFloat() * 0.25f)
                val speechCadence = ((primaryWave * 0.55f + secondaryWave * 0.35f + randomFluctuation)
                    .coerceIn(0.15f, 1.0f))

                _uiState.update { current ->
                    if (current.isTtsSpeaking) current.copy(audioOutputLevel = speechCadence) else current
                }
                step++
                delay(40) // 25 updates per second for smooth waveform animation
            }
        }
    }

    private fun stopTtsWaveformSimulation() {
        ttsWaveSimulationJob?.cancel()
        ttsWaveSimulationJob = null
        _uiState.update { it.copy(audioOutputLevel = 0f) }
    }

    fun release() {
        wakeWordLoopJob?.cancel()
        silenceWatchdogJob?.cancel()
        silentVadGateJob?.cancel()
        sessionCountdownJob?.cancel()
        inactivityWatchdogJob?.cancel()
        stopTtsWaveformSimulation()
        liveSessionManager?.release()
        audioStreamManager?.release()
        cleanUpRecognizer()
        feedbackHelper?.release()
        try {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
        } catch (_: Exception) {}
    }
}
