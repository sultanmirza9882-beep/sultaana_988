package com.example.engine.social

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import com.example.engine.EngineRegistry
import com.example.engine.approval.OwnerApprovalGate
import com.example.engine.approval.SensitiveActionType
import com.example.engine.brain.DualBrainCoordinator
import com.example.engine.media.ImageFilterPreset
import com.example.engine.media.MediaStudioEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit

enum class ConversationVibe(
    val label: String,
    val toneDirective: String
) {
    FRIENDLY(
        "Friendly",
        "Warm, approachable, upbeat, and appreciative tone."
    ),
    FLIRTY(
        "Flirty",
        "Playful, charming, witty, lighthearted, and respectful banter."
    ),
    PROFESSIONAL(
        "Professional",
        "Polished, executive, concise, courteous, and business-ready."
    ),
    ARROGANT(
        "Arrogant",
        "Bold, ultra-confident, sharp, unbothered alpha swagger (never abusive)."
    ),
    HINGLISH(
        "Hinglish",
        "Natural modern Indian Hinglish with casual energy and relatability."
    )
}

data class SocialComment(
    val id: String,
    val author: String,
    val text: String,
    val timestamp: String = ""
)

data class SocialContentStrategy(
    val niche: String,
    val platform: String,
    val hooks: List<String>,
    val hashtags: List<String>,
    val cadence: String,
    val strategyMarkdown: String
)

data class SocialOperationResult(
    val success: Boolean,
    val postOrReplyId: String? = null,
    val usedShareIntentFallback: Boolean = false,
    val approvalDenied: Boolean = false,
    val message: String
)

/**
 * Module 01: Social Media Management Engine.
 *
 * **Meta OAuth Token vs. Android Share Intent Handoff:**
 * Direct publishing and reading Instagram/Facebook comments via Meta Graph API v21.0 requires a
 * user-configured Instagram Business/Creator or Facebook Page OAuth2 access token with
 * `instagram_basic`, `instagram_content_publish`, and `pages_manage_engagement` permissions.
 * When no Meta OAuth token is configured, Muskan cleanly generates AI captions, vibe-styled replies,
 * content strategies, and 9:16 Story/Reel visuals via [MediaStudioEngine], then hands off to
 * Instagram/Facebook via Android's standard `ACTION_SEND` Share Intent.
 *
 * Every outbound publish, reply, or share dispatch is gated behind
 * [OwnerApprovalGate.requestSensitiveActionApproval].
 */
object SocialMediaEngine {

    private const val TAG = "SocialMediaEngine"
    private const val GRAPH_API_BASE = "https://graph.facebook.com/v21.0"
    private const val PREFS_NAME = "muskan_social_oauth_prefs"
    private const val KEY_META_TOKEN = "meta_graph_oauth_token"

    const val META_OAUTH_REQUIREMENT_NOTE =
        "Direct Meta Graph API publishing requires an Instagram Business/Creator or Facebook Page OAuth2 token. Without a token, Muskan uses Android ACTION_SEND Share Intent handoff."

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    private fun securePrefs(context: Context) =
        com.example.api.SecurePreferences.openMigrating(context, PREFS_NAME)

    fun setMetaOAuthToken(context: Context, token: String?) {
        val prefs = securePrefs(context)
        if (token.isNullOrBlank()) {
            prefs.edit().remove(KEY_META_TOKEN).apply()
        } else {
            prefs.edit().putString(KEY_META_TOKEN, token.trim()).apply()
        }
    }

    fun getMetaOAuthToken(context: Context): String? {
        val prefs = securePrefs(context)
        return prefs.getString(KEY_META_TOKEN, null)?.takeIf { it.isNotBlank() }
    }

    /**
     * Parses a Meta Graph API comments/messages JSON response (`{ "data": [ ... ] }`).
     */
    fun parseGraphCommentsJson(json: String): List<SocialComment> {
        if (json.isBlank()) return emptyList()
        return runCatching {
            val root = JSONObject(json)
            val data = root.optJSONArray("data") ?: return emptyList()
            buildList {
                for (i in 0 until data.length()) {
                    val item = data.optJSONObject(i) ?: continue
                    val id = item.optString("id").trim()
                    val text = item.optString("text").ifBlank { item.optString("message") }.trim()
                    val author = item.optString("username").ifBlank {
                        item.optJSONObject("from")?.optString("name").orEmpty()
                    }.ifBlank { "Unknown" }
                    val ts = item.optString("timestamp").ifBlank { item.optString("created_time") }
                    if (id.isNotBlank() && text.isNotBlank()) {
                        add(SocialComment(id = id, author = author, text = text, timestamp = ts))
                    }
                }
            }
        }.getOrDefault(emptyList())
    }

    /**
     * Parses a Meta Graph API publish/reply JSON response (`{ "id": "..." }`).
     */
    fun parseGraphPublishResponse(json: String): String? {
        if (json.isBlank()) return null
        return runCatching {
            JSONObject(json).optString("id").takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    /**
     * Reads recent Instagram/Facebook comments via Meta Graph API v21.0 using an OAuth2 Bearer token.
     */
    suspend fun fetchRecentComments(
        context: Context,
        mediaOrPostId: String,
        accessToken: String? = null
    ): Result<List<SocialComment>> = withContext(Dispatchers.IO) {
        EngineRegistry.recordInvocation(102, success = true)
        val token = accessToken?.takeIf { it.isNotBlank() } ?: getMetaOAuthToken(context)
            ?: return@withContext Result.failure(
                IllegalStateException("Meta Graph OAuth2 token not configured. $META_OAUTH_REQUIREMENT_NOTE")
            )

        runCatching {
            val url = "$GRAPH_API_BASE/${Uri.encode(mediaOrPostId)}/comments?fields=id,text,message,username,from,timestamp,created_time"
            val req = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $token")
                .header("Accept", "application/json")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException("Meta Graph comments HTTP ${resp.code}")
                }
                parseGraphCommentsJson(resp.body?.string().orEmpty())
            }
        }
    }

    /**
     * Formats the vibe-aware prompt sent to [DualBrainCoordinator] for comment/DM replies.
     */
    fun buildVibeReplyPrompt(
        vibe: ConversationVibe,
        incomingMessage: String,
        authorHint: String = ""
    ): String {
        val fromPart = if (authorHint.isNotBlank()) " from $authorHint" else ""
        return """
            You are Muskan, Sultan Mirza's Social Media AI Strategist.
            Write a short, engaging social media reply (1-2 sentences max) to this message$fromPart:
            "$incomingMessage"
            Selected Vibe: ${vibe.label} (${vibe.toneDirective})
            Output ONLY the reply text without quotes or commentary.
        """.trimIndent()
    }

    /**
     * Deterministic vibe-specific fallback formatter when offline or LLM response is unavailable.
     */
    fun formatFallbackVibeReply(vibe: ConversationVibe, incomingMessage: String): String {
        val topicHint = incomingMessage.trim().take(48)
        return when (vibe) {
            ConversationVibe.FRIENDLY ->
                "Thanks so much for dropping by! Really appreciate your message about \"$topicHint\" — hope you're having an awesome day!"
            ConversationVibe.FLIRTY ->
                "Careful now, messages like that might just steal all my attention — tell me more!"
            ConversationVibe.PROFESSIONAL ->
                "Thank you for reaching out regarding \"$topicHint\". I appreciate your interest and will follow up with complete details shortly."
            ConversationVibe.ARROGANT ->
                "Of course you noticed — excellence is hard to miss. Watch this space."
            ConversationVibe.HINGLISH ->
                "Shukriya yaar! Tumhara message padh kar maza aa gaya — aise hi jude raho, aur zabardast updates aa rahe hain!"
        }
    }

    /**
     * Generates a vibe-tuned reply via [DualBrainCoordinator] with a distinct deterministic fallback.
     */
    suspend fun generateVibeReply(
        context: Context,
        incomingMessage: String,
        vibe: ConversationVibe = ConversationVibe.FRIENDLY,
        authorHint: String = ""
    ): String {
        EngineRegistry.recordInvocation(102, success = true)
        val prompt = buildVibeReplyPrompt(vibe, incomingMessage, authorHint)
        val aiText = runCatching {
            DualBrainCoordinator.executeReasoning(context, prompt).responseText.trim()
        }.getOrNull()

        return if (!aiText.isNullOrBlank() && aiText.length >= 8 && !aiText.contains("Online-Only mode", ignoreCase = true)) {
            aiText
        } else {
            formatFallbackVibeReply(vibe, incomingMessage)
        }
    }

    /**
     * Generates a content strategy, viral hooks, posting cadence, and niche hashtags via [DualBrainCoordinator].
     */
    suspend fun generateContentStrategy(
        context: Context,
        niche: String,
        platform: String = "Instagram"
    ): SocialContentStrategy {
        EngineRegistry.recordInvocation(102, success = true)
        val cleanNiche = niche.trim().ifBlank { "AI & Tech Creator" }
        val tagBase = cleanNiche.replace(Regex("[^A-Za-z0-9]"), "").take(16).ifBlank { "Creator" }
        val defaultHooks = listOf(
            "Stop scrolling: 3 $cleanNiche mistakes costing you growth today",
            "How I automated my $cleanNiche workflow in under 10 minutes",
            "Behind the scenes of my latest $cleanNiche build"
        )
        val defaultHashtags = listOf(
            "#$tagBase", "#${platform}Growth", "#ReelsIndia", "#AIWorkflow", "#SultanMirza"
        )

        val prompt = """
            Create a concise $platform content strategy for niche "$cleanNiche" in Hinglish/English:
            Include 3 Reel hooks, ideal posting cadence, and 5 targeted hashtags.
        """.trimIndent()

        val aiMarkdown = runCatching {
            DualBrainCoordinator.executeReasoning(context, prompt).responseText.trim()
        }.getOrNull()?.takeIf { it.length > 20 }
            ?: buildString {
                appendLine("## $platform Content Strategy: $cleanNiche")
                appendLine("- **Cadence:** 4 Reels + 5 Stories per week (7:30 PM IST peak slot)")
                appendLine("- **Hooks:**")
                defaultHooks.forEach { appendLine("  - $it") }
                appendLine("- **Hashtags:** ${defaultHashtags.joinToString(" ")}")
            }.trim()

        return SocialContentStrategy(
            niche = cleanNiche,
            platform = platform,
            hooks = defaultHooks,
            hashtags = defaultHashtags,
            cadence = "4 Reels + 5 Stories / week",
            strategyMarkdown = aiMarkdown
        )
    }

    /**
     * Generates a ready-to-share 9:16 vertical Story/Reel visual via [MediaStudioEngine].
     */
    fun createStoryOrReelAsset(
        context: Context,
        headline: String,
        subtitle: String = "",
        vibe: ConversationVibe = ConversationVibe.FRIENDLY
    ): File {
        val preset = when (vibe) {
            ConversationVibe.FRIENDLY -> ImageFilterPreset.WARM
            ConversationVibe.FLIRTY -> ImageFilterPreset.VIVID
            ConversationVibe.PROFESSIONAL -> ImageFilterPreset.COOL
            ConversationVibe.ARROGANT -> ImageFilterPreset.NOIR
            ConversationVibe.HINGLISH -> ImageFilterPreset.CINEMATIC
        }
        return MediaStudioEngine.composeVerticalStoryCard(
            context = context,
            sourceBitmap = null,
            headline = headline,
            subtitle = subtitle.ifBlank { "${vibe.label} Edition • 9:16 Story" },
            filter = preset
        )
    }

    /**
     * Publishes a post via Meta Graph API v21.0 (when OAuth token + accountId are configured)
     * or dispatches an Android `ACTION_SEND` Share Intent handoff — ALWAYS gated behind
     * [OwnerApprovalGate.requestSensitiveActionApproval].
     */
    suspend fun publishOrSharePost(
        context: Context,
        platformLabel: String = "Instagram/Facebook",
        caption: String,
        accountId: String? = null,
        imageFile: File? = null,
        accessToken: String? = null
    ): SocialOperationResult = withContext(Dispatchers.IO) {
        val approved = OwnerApprovalGate.requestSensitiveActionApproval(
            actionType = SensitiveActionType.SOCIAL_PUBLISH,
            recipient = platformLabel,
            summary = "Sultan, $platformLabel par ye post/story publish/share karne ki explicit approval chahiye.",
            payloadPreview = buildString {
                append(caption.take(260))
                if (imageFile != null) append("\n[Media: ${imageFile.name}]")
            },
            technicalDetails = "SocialMediaEngine.publishOrSharePost ($platformLabel; Graph API or Share Intent fallback)."
        )
        if (!approved) {
            return@withContext SocialOperationResult(
                success = false,
                approvalDenied = true,
                message = "Approval denied: Social post/share for $platformLabel was cancelled."
            )
        }

        val token = accessToken?.takeIf { it.isNotBlank() } ?: getMetaOAuthToken(context)
        if (token != null && !accountId.isNullOrBlank()) {
            val apiResult = runCatching {
                val formBody = FormBody.Builder()
                    .add("message", caption)
                    .build()
                val req = Request.Builder()
                    .url("$GRAPH_API_BASE/${Uri.encode(accountId)}/feed")
                    .header("Authorization", "Bearer $token")
                    .post(formBody)
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        throw IllegalStateException("Meta Graph publish HTTP ${resp.code}")
                    }
                    parseGraphPublishResponse(resp.body?.string().orEmpty())
                }
            }
            if (apiResult.isSuccess) {
                EngineRegistry.recordInvocation(102, success = true)
                return@withContext SocialOperationResult(
                    success = true,
                    postOrReplyId = apiResult.getOrNull(),
                    usedShareIntentFallback = false,
                    message = "Sultan, aapki post Meta Graph API ke zariye publish ho gayi hai (ID: ${apiResult.getOrNull() ?: "ok"})."
                )
            }
            Log.w(TAG, "Meta Graph API publish failed; falling back to Share Intent", apiResult.exceptionOrNull())
        }

        // Android ACTION_SEND Share Intent handoff
        val shareIntent = if (imageFile != null && imageFile.exists()) {
            MediaStudioEngine.createShareIntent(context, imageFile, "image/png", caption)
        } else {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, caption)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }

        return@withContext try {
            context.startActivity(shareIntent)
            EngineRegistry.recordInvocation(102, success = true)
            SocialOperationResult(
                success = true,
                usedShareIntentFallback = true,
                message = "Sultan, Android Share Sheet open kar diya gaya hai — aap $platformLabel par 1 tap mein share kar sakte hain."
            )
        } catch (e: Exception) {
            SocialOperationResult(
                success = false,
                usedShareIntentFallback = true,
                message = "Share intent open nahi ho saka: ${e.localizedMessage ?: "No target app available"}"
            )
        }
    }

    /**
     * Replies to an Instagram/Facebook comment via Meta Graph API (when token configured)
     * or Android Share Intent fallback — ALWAYS gated behind [OwnerApprovalGate].
     */
    suspend fun replyToComment(
        context: Context,
        commentId: String,
        replyText: String,
        accessToken: String? = null
    ): SocialOperationResult = withContext(Dispatchers.IO) {
        val approved = OwnerApprovalGate.requestSensitiveActionApproval(
            actionType = SensitiveActionType.SOCIAL_REPLY,
            recipient = "Comment #$commentId",
            summary = "Sultan, comment #$commentId par ye reply post karne ki explicit approval chahiye.",
            payloadPreview = replyText.take(260),
            technicalDetails = "SocialMediaEngine.replyToComment (Meta Graph API or Share Intent fallback)."
        )
        if (!approved) {
            return@withContext SocialOperationResult(
                success = false,
                approvalDenied = true,
                message = "Approval denied: Social comment reply was cancelled."
            )
        }

        val token = accessToken?.takeIf { it.isNotBlank() } ?: getMetaOAuthToken(context)
        if (token != null) {
            val apiResult = runCatching {
                val formBody = FormBody.Builder()
                    .add("message", replyText)
                    .build()
                val req = Request.Builder()
                    .url("$GRAPH_API_BASE/${Uri.encode(commentId)}/replies")
                    .header("Authorization", "Bearer $token")
                    .post(formBody)
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        throw IllegalStateException("Meta Graph reply HTTP ${resp.code}")
                    }
                    parseGraphPublishResponse(resp.body?.string().orEmpty())
                }
            }
            if (apiResult.isSuccess) {
                EngineRegistry.recordInvocation(102, success = true)
                return@withContext SocialOperationResult(
                    success = true,
                    postOrReplyId = apiResult.getOrNull(),
                    usedShareIntentFallback = false,
                    message = "Sultan, comment reply Meta Graph API par post ho gaya hai."
                )
            }
            Log.w(TAG, "Meta Graph reply failed; falling back to Share Intent", apiResult.exceptionOrNull())
        }

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, replyText)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return@withContext try {
            context.startActivity(shareIntent)
            EngineRegistry.recordInvocation(102, success = true)
            SocialOperationResult(
                success = true,
                usedShareIntentFallback = true,
                message = "Meta OAuth token linked nahi hai — reply text Share Sheet mein ready kar diya gaya hai."
            )
        } catch (e: Exception) {
            SocialOperationResult(
                success = false,
                usedShareIntentFallback = true,
                message = "Share Sheet open nahi ho saki: ${e.localizedMessage ?: "Unavailable"}"
            )
        }
    }

    /**
     * Natural-language Hindi/Hinglish/English handler for Social Media commands.
     */
    suspend fun handleVoiceSocialCommand(context: Context, prompt: String): String {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        val vibe = when {
            lower.contains("flirty") -> ConversationVibe.FLIRTY
            lower.contains("arrogant") || lower.contains("attitude") -> ConversationVibe.ARROGANT
            lower.contains("professional") || lower.contains("formal") -> ConversationVibe.PROFESSIONAL
            lower.contains("hinglish") -> ConversationVibe.HINGLISH
            else -> ConversationVibe.FRIENDLY
        }

        return when {
            lower.contains("strategy") || lower.contains("hashtag") || lower.contains("content plan") -> {
                val niche = prompt.replace(Regex("(?i)(instagram|facebook|social media|content strategy|strategy|hashtag|banao|do)"), "").trim()
                generateContentStrategy(context, niche.ifBlank { "Tech & AI" }).strategyMarkdown
            }
            lower.contains("story") || lower.contains("reel") -> {
                val headline = prompt.replace(Regex("(?i)(instagram|story|reel|share karo|post karo|banao)"), "").trim()
                val asset = createStoryOrReelAsset(context, headline.ifBlank { "New Update" }, vibe = vibe)
                if (lower.contains("post") || lower.contains("share") || lower.contains("publish")) {
                    publishOrSharePost(
                        context = context,
                        platformLabel = "Instagram Story/Reel",
                        caption = headline.ifBlank { "Fresh update from Sultan Mirza!" },
                        imageFile = asset
                    ).message
                } else {
                    "Sultan, 9:16 ${vibe.label} Story/Reel asset '${asset.name}' ready ho gaya hai."
                }
            }
            lower.contains("reply") || lower.contains("comment") -> {
                val reply = generateVibeReply(context, prompt, vibe)
                "Sultan (${vibe.label} vibe reply draft):\n$reply"
            }
            else -> {
                val strategy = generateContentStrategy(context, prompt)
                strategy.strategyMarkdown
            }
        }
    }
}
