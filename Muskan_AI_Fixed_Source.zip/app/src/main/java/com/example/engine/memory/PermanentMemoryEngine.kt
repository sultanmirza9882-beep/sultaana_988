package com.example.engine.memory

import android.content.Context
import com.example.VoiceSessionManager
import com.example.data.firebase.UserMemory
import com.example.data.local.AppDatabase
import com.example.data.local.UserMemoryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.UUID

/**
 * Permanent Memory & Preference Engine for Muskan.
 * Captures user preferences, facts, and instructions from natural conversation,
 * persists them permanently to Room SQLite and Cloud Firestore, and feeds them
 * into both Gemini and Qwen3 Dual-Brain reasoning.
 */
object PermanentMemoryEngine {

    data class MemoryCaptureResult(
        val isHandled: Boolean,
        val confirmationSpeech: String? = null,
        val category: String = "PREFERENCE",
        val title: String = "",
        val detail: String = ""
    )

    /**
     * Inspects spoken query for explicit preference/memory statements.
     * If detected, persists immediately and returns confirmation speech.
     */
    suspend fun inspectAndCaptureMemory(context: Context, rawPrompt: String): MemoryCaptureResult =
        withContext(Dispatchers.IO) {
            val prompt = rawPrompt.trim()
            val lower = prompt.lowercase(Locale.ROOT)

            // 1. Creator / Name declarations: "Mera naam Sultan Mirza hai" / "My name is Sultan"
            val nameRegex = Regex("""(?:mera naam|my name is)\s+([a-zA-Z\u0900-\u097F\s]+?)(?:\s+hai|\s+h|\.|\$)""", RegexOption.IGNORE_CASE)
            val nameMatch = nameRegex.find(prompt)
            if (nameMatch != null) {
                val name = nameMatch.groupValues[1].trim()
                if (name.isNotBlank() && name.length <= 40) {
                    val title = "User Identity"
                    val detail = "User's name is $name (Owner/Creator)"
                    persistMemory(context, "CREATOR", title, detail)
                    return@withContext MemoryCaptureResult(
                        isHandled = true,
                        confirmationSpeech = "Bilkul! Maine yaad rakh liya hai ki aapka naam $name hai.",
                        category = "CREATOR",
                        title = title,
                        detail = detail
                    )
                }
            }

            // 2. Preferences: "Mujhe coffee pasand hai" / "Mujhe biryani pasand hai"
            val likeRegex = Regex("""(?:mujhe|i like|i love)\s+(.+?)\s+(?:pasand hai|bahut pasand hai|achhi lagti hai|pasand h)""", RegexOption.IGNORE_CASE)
            val likeMatch = likeRegex.find(prompt)
            if (likeMatch != null) {
                val item = likeMatch.groupValues[1].trim()
                if (item.isNotBlank() && item.length <= 60) {
                    val title = "Preference: $item"
                    val detail = "User loves/prefers $item"
                    persistMemory(context, "PREFERENCE", title, detail)
                    return@withContext MemoryCaptureResult(
                        isHandled = true,
                        confirmationSpeech = "Zaroor! Maine hamesha ke liye yaad rakh liya hai ki aapko $item pasand hai.",
                        category = "PREFERENCE",
                        title = title,
                        detail = detail
                    )
                }
            }

            // 3. Instructions: "Mujhe hamesha Hinglish mein jawab do" / "Chhote jawab do"
            if (lower.contains("hamesha hinglish") || lower.contains("hinglish mein baat karo")) {
                val title = "Language Preference"
                val detail = "Always respond in fluent, natural conversational Hinglish"
                persistMemory(context, "INSTRUCTION", title, detail)
                return@withContext MemoryCaptureResult(
                    isHandled = true,
                    confirmationSpeech = "Bilkul Sultan! Ab se main aapko hamesha Hinglish mein hi jawab doongi.",
                    category = "INSTRUCTION",
                    title = title,
                    detail = detail
                )
            }

            // 4. Explicit Memory request: "Yaad rakhna ki..." / "Remember that..."
            val rememberRegex = Regex("""(?:yaad rakhna ki|yaad rakho ki|remember that|save this note)\s+(.+)""", RegexOption.IGNORE_CASE)
            val rememberMatch = rememberRegex.find(prompt)
            if (rememberMatch != null) {
                val fact = rememberMatch.groupValues[1].trim()
                if (fact.isNotBlank()) {
                    val title = "Note: ${fact.take(30)}"
                    val detail = fact
                    persistMemory(context, "NOTE", title, detail)
                    return@withContext MemoryCaptureResult(
                        isHandled = true,
                        confirmationSpeech = "Maine yeh baat hamesha ke liye memory mein save kar li hai.",
                        category = "NOTE",
                        title = title,
                        detail = detail
                    )
                }
            }

            MemoryCaptureResult(isHandled = false)
        }

    /**
     * Persists memory in both local Room database and Cloud Firestore (if user signed in).
     */
    suspend fun persistMemory(
        context: Context,
        category: String,
        title: String,
        detail: String,
        isPinned: Boolean = true
    ) = withContext(Dispatchers.IO) {
        try {
            // 1. Local Room DB
            val db = AppDatabase.getDatabase(context)
            val entity = UserMemoryEntity(
                category = category,
                title = title,
                detail = detail,
                timestamp = System.currentTimeMillis(),
                isPinned = isPinned
            )
            db.userMemoryDao().insertMemory(entity)

            // 2. Cloud Firestore (via VoiceSessionManager repository if available)
            VoiceSessionManager.memoryRepository?.saveMemory(
                content = "[$category] $title: $detail",
                category = category.lowercase(Locale.ROOT),
                tags = listOf(category.lowercase(Locale.ROOT), "permanent_memory")
            )
        } catch (_: Exception) {}
    }

    /**
     * Deletes memory by ID from local Room database.
     */
    suspend fun deleteMemory(context: Context, memoryId: Long) = withContext(Dispatchers.IO) {
        try {
            AppDatabase.getDatabase(context).userMemoryDao().deleteMemoryById(memoryId)
        } catch (_: Exception) {}
    }

    /**
     * Builds authoritative context block injected into Dual-Brain prompts.
     */
    suspend fun buildAuthoritativeMemoryContext(context: Context): String = withContext(Dispatchers.IO) {
        try {
            val db = AppDatabase.getDatabase(context)
            val memories = db.userMemoryDao().getAllMemories()
            if (memories.isEmpty()) {
                return@withContext "- Owner: Sultan Mirza\n- Tone: Articulate, respectful, fluent Hinglish"
            }
            buildString {
                appendLine("[PERMANENT USER MEMORIES & PREFERENCES]")
                for (m in memories) {
                    appendLine("• [${m.category}] ${m.title}: ${m.detail}")
                }
            }
        } catch (_: Exception) {
            "- Owner: Sultan Mirza"
        }
    }

    /**
     * Reactive stream of memories for UI.
     */
    fun getMemoriesFlow(context: Context): Flow<List<UserMemoryEntity>> {
        return AppDatabase.getDatabase(context).userMemoryDao().getAllMemoriesFlow()
    }
}
