package com.example.engine.dialogue

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class DialogueTurnType {
    GREETING,
    OPEN_QUERY,
    TECHNICAL_DEV,
    PERSONAL_EMOTIONAL,
    DIRECT_ACTION,
    FOLLOW_UP
}

data class DialogueContext(
    val currentTurnType: DialogueTurnType = DialogueTurnType.GREETING,
    val lastCounterQuestion: String? = null,
    val isAwaitingAnswer: Boolean = false,
    val consecutiveTurns: Int = 0
)

enum class ResponseLengthMode {
    CONCISE,   // Short questions -> 1 to 2 crisp, direct sentences (~100-120 tokens)
    MODERATE,  // Standard questions -> 3 to 4 sentences (~350 tokens)
    DETAILED   // In-depth / "vistaar mein" questions -> Comprehensive, multi-paragraph (~1000 tokens)
}

data class AdaptiveResponseConfig(
    val mode: ResponseLengthMode,
    val maxOutputTokens: Int,
    val promptDirective: String
)

/**
 * Dialogue Management Engine (Section 4 of Master Specification).
 * Enables Muskan to actively engage in dynamic, bidirectional counter-questioning
 * and adaptive response sizing based on user intent.
 */
object DialogueManagementEngine {

    private val _contextFlow = MutableStateFlow(DialogueContext())
    val contextFlow: StateFlow<DialogueContext> = _contextFlow.asStateFlow()

    private var counterQuestionIndex = 0

    /**
     * System directive for Gemini & OpenAI prompts to enforce natural counter-questioning.
     */
    const val DIALOGUE_SYSTEM_DIRECTIVE = """
ACTIVE DIALOGUE MANAGEMENT & COUNTER-QUESTIONING:
As Sultan Mirza's close, smart AI companion, actively sustain conversational momentum.
When appropriate, end your turn with a natural, caring, or insightful counter-question in smooth Hinglish (1 short sentence).
- If he greets or asks how you are, ask about his day or project.
- If he asks for advice or ideas, suggest an option and ask for his preference or thoughts.
- If he mentions code, bugs, or development, ask targeted technical follow-ups.
- Avoid robotic repetition. If he gives a direct command (e.g. 'Turn off Wi-Fi'), acknowledge directly without an unnecessary counter-question.
"""

    /**
     * Determines adaptive response token limit and prompt directives based on
     * user question length and depth ("agar sawal vistaar mein ho, to javaab lamba ho").
     */
    fun determineAdaptiveResponseConfig(prompt: String): AdaptiveResponseConfig {
        val clean = prompt.trim()
        val words = clean.split("\\s+".toRegex()).filter { it.isNotBlank() }
        val wordCount = words.size
        val lower = clean.lowercase(java.util.Locale.ROOT)

        val isDetailedIntent = wordCount >= 16 ||
                lower.contains("vistaar") ||
                lower.contains("vistar") ||
                lower.contains("detail") ||
                lower.contains("in-depth") ||
                lower.contains("explain") ||
                lower.contains("samjhao") ||
                lower.contains("step by step") ||
                lower.contains("difference") ||
                lower.contains("antara") ||
                lower.contains("kyun") && wordCount >= 8 ||
                lower.contains("kaise") && wordCount >= 8 ||
                lower.contains("architecture") ||
                lower.contains("story") ||
                lower.contains("kahani")

        val isConciseIntent = wordCount <= 7 && !isDetailedIntent

        return when {
            isDetailedIntent -> {
                AdaptiveResponseConfig(
                    mode = ResponseLengthMode.DETAILED,
                    maxOutputTokens = 1000,
                    promptDirective = "ADAPTIVE RESPONSE LENGTH (DETAILED): Sultan Mirza has asked an in-depth, comprehensive question (vistaar mein). Provide an extensive, thorough, structured, and complete explanation covering all nuances, examples, and technical or personal context in full detail!"
                )
            }
            isConciseIntent -> {
                AdaptiveResponseConfig(
                    mode = ResponseLengthMode.CONCISE,
                    maxOutputTokens = 120,
                    promptDirective = "ADAPTIVE RESPONSE LENGTH (CONCISE): Sultan Mirza has asked a short/casual question. Answer in exactly 1 or 2 crisp, sweet, direct sentences without unnecessary elaboration or long lectures."
                )
            }
            else -> {
                AdaptiveResponseConfig(
                    mode = ResponseLengthMode.MODERATE,
                    maxOutputTokens = 350,
                    promptDirective = "ADAPTIVE RESPONSE LENGTH (MODERATE): Provide a well-balanced, clear response in 2 to 4 sentences."
                )
            }
        }
    }

    /**
     * Generates a proactive counter-question when Sultan is silent for 20 seconds.
     * Keeps conversation alive instead of shutting down.
     */
    fun getInactivityCounterQuestion(screenNarrative: String? = null): String {
        val questions = listOf(
            "Ji Sultan, main standby par taiyaar hoon.",
            "Beshak Sultan, agla hukam farmaiye.",
            if (!screenNarrative.isNullOrBlank() && !screenNarrative.contains("standby", ignoreCase = true)) {
                "Sultan, kya aap screen ke mutabiq koi task run karna chahte hain?"
            } else {
                "Sultan, aapka agla task kya hai? WhatsApp, YouTube, ya koi automation?"
            },
            "Ji Sultan, jab chahein aawaz dijiye, main taiyaar hoon."
        )
        val selected = questions[counterQuestionIndex % questions.size]
        counterQuestionIndex++
        return selected
    }

    /**
     * Determines whether the user's prompt should trigger a follow-up or counter-question.
     */
    fun analyzePrompt(prompt: String): DialogueTurnType {
        val p = prompt.lowercase(java.util.Locale.ROOT).trim()
        return when {
            p.contains("hello") || p.contains("hi") || p.contains("hey") || p.contains("kaise ho") || p.contains("kya haal") ->
                DialogueTurnType.GREETING
            p.contains("error") || p.contains("bug") || p.contains("crash") || p.contains("code") || p.contains("build") || p.contains("gradle") || p.contains("android") ->
                DialogueTurnType.TECHNICAL_DEV
            p.contains("thak gaya") || p.contains("boring") || p.contains("sad") || p.contains("khush") || p.contains("mood") ->
                DialogueTurnType.PERSONAL_EMOTIONAL
            p.contains("kya karun") || p.contains("suggest") || p.contains("batao") || p.contains("kuch") || p.contains("gaana") || p.contains("movie") ->
                DialogueTurnType.OPEN_QUERY
            else ->
                DialogueTurnType.FOLLOW_UP
        }
    }

    /**
     * Checks if the AI response already contains an active question or counter-question.
     */
    fun hasExistingQuestion(text: String): Boolean {
        val trimmed = text.trim()
        if (trimmed.endsWith("?")) return true
        val lower = trimmed.lowercase(java.util.Locale.ROOT)
        return lower.contains("kya aap") || lower.contains("aap bataiye") ||
                lower.contains("kaisa laga") || lower.contains("kya plan hai") ||
                lower.contains("right?") || lower.contains("sahi hai na?")
    }

    /**
     * Inspects the AI's response and dynamically enriches it with a tailored, natural
     * Hinglish counter-question if the response is dead-ended or overly brief.
     */
    fun augmentWithCounterQuestionIfNeeded(userPrompt: String, aiResponse: String): String {
        if (aiResponse.isBlank()) return aiResponse
        val hasQ = hasExistingQuestion(aiResponse)
        _contextFlow.value = _contextFlow.value.copy(
            isAwaitingAnswer = hasQ,
            consecutiveTurns = _contextFlow.value.consecutiveTurns + 1
        )
        return aiResponse.trim()
    }
}
