package com.example.engine.dev

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Private, bounded workspace for source ZIPs. Import never modifies the installed APK.
 * Patch writes are explicit calls, path-confined, and preceded by a recoverable snapshot.
 */
object ProjectWorkspaceManager {
    private const val MAX_ENTRIES = 8_000
    private const val MAX_ENTRY_BYTES = 2L * 1024 * 1024
    private const val MAX_TOTAL_BYTES = 80L * 1024 * 1024
    private const val MAX_CONTEXT_CHARS = 32_000
    private val blockedNames = setOf(
        "google-services.json", "local.properties", ".env", "gradle.properties",
        "debug.keystore", "release.keystore", "keystore.properties"
    )
    private val sourceExtensions = setOf("kt", "java", "xml", "gradle", "kts", "properties", "json", "md")

    data class WorkspaceResult(val success: Boolean, val message: String, val path: String? = null)

    data class SnapshotInfo(
        val name: String,
        val createdAt: Long,
        val fileCount: Int,
        val totalBytes: Long,
        val digestSummary: String
    )

    data class WorkspaceSummary(
        val isImported: Boolean,
        val projectPath: String,
        val fileCount: Int,
        val totalSizeBytes: Long,
        val lastModified: Long,
        val snapshotCount: Int
    )

    private fun root(context: Context) = File(context.filesDir, "project_workspace")
    fun project(context: Context): File = File(root(context), "source")
    fun snapshots(context: Context): File = File(root(context), "snapshots")

    suspend fun importSourceZip(context: Context, zipFile: File): WorkspaceResult = withContext(Dispatchers.IO) {
        if (!zipFile.isFile || zipFile.length() <= 0L) return@withContext WorkspaceResult(false, "Source ZIP is missing or empty.")
        val base = root(context)
        val staging = File(base, "import_${UUID.randomUUID()}")
        if (!staging.mkdirs()) return@withContext WorkspaceResult(false, "Could not create private import staging directory.")
        var count = 0
        var total = 0L
        val importedPaths = mutableSetOf<String>()
        try {
            ZipInputStream(FileInputStream(zipFile)).use { zis ->
                while (true) {
                    val entry = zis.nextEntry ?: break
                    if (entry.isDirectory) { zis.closeEntry(); continue }
                    count++
                    require(count <= MAX_ENTRIES) { "ZIP contains too many files." }
                    val relative = validatePath(entry.name)
                    require(importedPaths.add(relative)) { "Duplicate ZIP entry rejected: $relative" }
                    require(relative.substringAfterLast('/') !in blockedNames) { "Protected config/secret file rejected: $relative" }
                    require(!relative.startsWith(".git/") && !relative.startsWith("build/") && "/build/" !in relative) { "Generated or repository metadata path rejected: $relative" }
                    val target = File(staging, relative)
                    require(target.canonicalPath.startsWith(staging.canonicalPath + File.separator)) { "Unsafe ZIP path rejected." }
                    target.parentFile?.mkdirs()
                    var entryBytes = 0L
                    FileOutputStream(target).use { out ->
                        val buffer = ByteArray(8192)
                        while (true) {
                            val read = zis.read(buffer)
                            if (read < 0) break
                            entryBytes += read
                            total += read
                            require(entryBytes <= MAX_ENTRY_BYTES) { "A file exceeds the 2 MiB import limit: $relative" }
                            require(total <= MAX_TOTAL_BYTES) { "Expanded ZIP exceeds the 80 MiB import limit." }
                            out.write(buffer, 0, read)
                        }
                    }
                    zis.closeEntry()
                }
            }
            require(count > 0) { "ZIP did not contain any files." }
            val current = project(context)
            if (current.exists()) {
                val snapshot = File(snapshots(context), "before_import_${System.currentTimeMillis()}")
                snapshot.parentFile?.mkdirs()
                copyTree(current, snapshot)
            }
            val old = File(base, "source_old_${System.currentTimeMillis()}")
            if (current.exists() && !current.renameTo(old)) throw IllegalStateException("Could not preserve existing workspace before import.")
            if (!staging.renameTo(current)) {
                if (old.exists()) old.renameTo(current)
                throw IllegalStateException("Could not activate imported workspace.")
            }
            old.deleteRecursively()
            WorkspaceResult(true, "Imported $count source files into Muskan's private workspace. This does not modify the installed APK.", current.absolutePath)
        } catch (e: Exception) {
            staging.deleteRecursively()
            WorkspaceResult(false, "Source ZIP rejected; existing workspace was preserved. ${e.message ?: "Import failed."}")
        }
    }

    suspend fun buildPromptContext(context: Context, userPrompt: String): String = withContext(Dispatchers.IO) {
        val dir = project(context)
        if (!dir.isDirectory) return@withContext "No source workspace imported. Generate only a reviewable draft patch; do not guess existing file contents."
        val files = dir.walkTopDown().filter { it.isFile && it.extension.lowercase() in sourceExtensions && it.length() <= 256 * 1024 }
            .filter { it.name !in blockedNames && ".git" !in it.path.split(File.separator) && "build" !in it.path.split(File.separator) }
            .toList()
        val terms = userPrompt.lowercase().split(Regex("[^a-z0-9_]+"))
        val ranked = files.map { file ->
            val text = runCatching { file.readText(Charsets.UTF_8) }.getOrDefault("")
            val score = terms.count { it.length >= 4 && (file.name.lowercase().contains(it) || text.lowercase().contains(it)) }
            Triple(file, text, score)
        }.sortedWith(compareByDescending<Triple<File, String, Int>> { it.third }.thenBy { it.first.relativeTo(dir).path })
        val out = StringBuilder("Imported source files (authoritative context; modify existing paths where appropriate):\n")
        var remaining = MAX_CONTEXT_CHARS
        for ((file, content, _) in ranked) {
            if (remaining <= 0) break
            val rel = file.relativeTo(dir).path.replace('\\', '/')
            val snippet = content.take(minOf(content.length, remaining - rel.length - 40))
            if (snippet.isBlank()) continue
            out.append("\n--- FILE: ").append(rel).append(" ---\n").append(snippet).append('\n')
            remaining = MAX_CONTEXT_CHARS - out.length
        }
        out.toString()
    }

    /** Applies a reviewed patch explicitly; every changed file is backed up first. */
    suspend fun applyReviewedPatch(context: Context, patch: JSONArray): WorkspaceResult = withContext(Dispatchers.IO) {
        val dir = project(context)
        if (!dir.isDirectory) return@withContext WorkspaceResult(false, "Import a source project before applying changes.")
        if (patch.length() !in 1..12) return@withContext WorkspaceResult(false, "Patch must contain 1–12 files.")
        val writes = mutableListOf<Pair<String, String>>()
        val seenPaths = mutableSetOf<String>()
        var backup: File? = null
        try {
            for (i in 0 until patch.length()) {
                val item = patch.optJSONObject(i) ?: throw IllegalArgumentException("Invalid patch file entry.")
                val path = validatePath(item.optString("path"))
                require(seenPaths.add(path)) { "Duplicate patch path rejected: $path" }
                require(path.substringAfterLast('/') !in blockedNames && !path.startsWith(".git/")) { "Protected path rejected: $path" }
                val content = item.optString("content")
                require(content.isNotBlank() && content.length <= 120_000) { "Empty or oversized content rejected: $path" }
                val target = File(dir, path)
                require(target.canonicalPath.startsWith(dir.canonicalPath + File.separator)) { "Unsafe target path." }
                writes += path to content
            }
            backup = File(snapshots(context), "before_patch_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}")
            backup.parentFile?.mkdirs()
            copyTree(dir, backup)
            require(backup.isDirectory && backup.listFiles() != null && treesMatch(dir, backup)) {
                "Could not verify the source snapshot before writing."
            }
            for ((path, content) in writes) {
                val target = File(dir, path)
                target.parentFile?.mkdirs()
                target.writeText(content, Charsets.UTF_8)
            }
            WorkspaceResult(true, "Applied ${writes.size} reviewed source files. Snapshot saved at ${backup.name}; Android build/tests have not run.", dir.absolutePath)
        } catch (e: Exception) {
            // Best-effort automatic restore if a write failed after the snapshot was made.
            var restoreMessage = "No writes were restored because a verified snapshot was unavailable."
            if (backup?.isDirectory == true) {
                val base = root(context)
                val restore = File(base, "restore_${UUID.randomUUID()}")
                val failed = File(base, "failed_apply_${UUID.randomUUID()}")
                runCatching {
                    copyTree(backup!!, restore)
                    require(restore.isDirectory && restore.listFiles() != null && treesMatch(backup!!, restore)) {
                        "Restored copy could not be verified."
                    }
                    // Keep the current tree intact until the restore copy is ready. If the
                    // second rename fails, put the just-written tree back instead of losing it.
                    if (dir.exists()) check(dir.renameTo(failed)) { "Could not preserve failed workspace." }
                    if (!restore.renameTo(dir)) {
                        if (failed.exists()) failed.renameTo(dir)
                        throw IllegalStateException("Could not activate restored snapshot.")
                    }
                    failed.deleteRecursively()
                    restoreMessage = "Original source snapshot restored."
                }.onFailure {
                    restore.deleteRecursively()
                    if (!dir.exists() && failed.exists()) failed.renameTo(dir)
                    restoreMessage = "Automatic restore failed safely: ${it.message ?: "unknown error"}. Existing workspace preservation was attempted."
                }
            }
            WorkspaceResult(false, "Patch failed: ${e.message ?: "validation failed"}. $restoreMessage")
        }
    }

    suspend fun rollbackLatest(context: Context): WorkspaceResult = withContext(Dispatchers.IO) {
        val latest = snapshots(context).listFiles()
            ?.filter { it.isDirectory && it.name.startsWith("before_patch_") }
            ?.sortedByDescending { it.lastModified() }
            ?.firstOrNull()
            ?: return@withContext WorkspaceResult(false, "No patch snapshot is available for rollback.")
        val base = root(context)
        val current = project(context)
        val rollback = File(base, "rollback_restore_${UUID.randomUUID()}")
        val displaced = File(base, "pre_rollback_current_${UUID.randomUUID()}")
        return@withContext try {
            copyTree(latest, rollback)
            require(rollback.isDirectory && rollback.listFiles() != null && treesMatch(latest, rollback)) {
                "Rollback copy could not be verified."
            }
            if (current.exists()) check(current.renameTo(displaced)) { "Could not preserve current workspace before rollback." }
            if (!rollback.renameTo(current)) {
                if (displaced.exists()) displaced.renameTo(current)
                throw IllegalStateException("Could not activate rollback snapshot; current workspace preservation was attempted.")
            }
            // Keep the displaced workspace as a safety copy rather than deleting user work.
            WorkspaceResult(true, "Restored patch snapshot ${latest.name}. Previous workspace retained as ${displaced.name}. Installed APK was not changed.", current.absolutePath)
        } catch (e: Exception) {
            rollback.deleteRecursively()
            if (!current.exists() && displaced.exists()) displaced.renameTo(current)
            WorkspaceResult(false, "Rollback failed safely: ${e.message}")
        }
    }

    suspend fun exportSourceZip(context: Context, destination: File): WorkspaceResult = withContext(Dispatchers.IO) {
        val dir = project(context)
        if (!dir.isDirectory) return@withContext WorkspaceResult(false, "No imported source workspace to export.")
        try {
            destination.parentFile?.mkdirs()
            ZipOutputStream(FileOutputStream(destination)).use { zos ->
                dir.walkTopDown().filter { it.isFile }.forEach { file ->
                    val rel = file.relativeTo(dir).path.replace('\\', '/')
                    zos.putNextEntry(ZipEntry(rel)); file.inputStream().use { it.copyTo(zos) }; zos.closeEntry()
                }
            }
            WorkspaceResult(true, "Exported source workspace ZIP. This is source code, not an APK.", destination.absolutePath)
        } catch (e: Exception) { destination.delete(); WorkspaceResult(false, "Export failed: ${e.message}") }
    }

    fun isImported(context: Context): Boolean = project(context).isDirectory

    suspend fun rollbackToSnapshot(context: Context, snapshotName: String): WorkspaceResult = withContext(Dispatchers.IO) {
        val targetSnapshot = File(snapshots(context), snapshotName)
        if (!targetSnapshot.isDirectory) {
            return@withContext WorkspaceResult(false, "Snapshot '$snapshotName' not found.")
        }
        val base = root(context)
        val current = project(context)
        val rollback = File(base, "rollback_restore_${UUID.randomUUID()}")
        val displaced = File(base, "pre_rollback_current_${UUID.randomUUID()}")
        return@withContext try {
            copyTree(targetSnapshot, rollback)
            require(rollback.isDirectory && rollback.listFiles() != null && treesMatch(targetSnapshot, rollback)) {
                "Rollback copy could not be verified."
            }
            if (current.exists()) check(current.renameTo(displaced)) { "Could not preserve current workspace before rollback." }
            if (!rollback.renameTo(current)) {
                if (displaced.exists()) displaced.renameTo(current)
                throw IllegalStateException("Could not activate rollback snapshot; current workspace preservation was attempted.")
            }
            WorkspaceResult(true, "Restored snapshot ${targetSnapshot.name}. Previous workspace retained as ${displaced.name}. Installed APK was not changed.", current.absolutePath)
        } catch (e: Exception) {
            rollback.deleteRecursively()
            if (!current.exists() && displaced.exists()) displaced.renameTo(current)
            WorkspaceResult(false, "Rollback failed safely: ${e.message}")
        }
    }

    fun listSnapshots(context: Context): List<SnapshotInfo> {
        val snapshotDir = snapshots(context)
        if (!snapshotDir.isDirectory) return emptyList()
        return snapshotDir.listFiles()?.filter { it.isDirectory && (it.name.startsWith("before_patch_") || it.name.startsWith("before_import_")) }
            ?.map { dir ->
                var files = 0
                var bytes = 0L
                dir.walkTopDown().filter { it.isFile }.forEach { file ->
                    files++
                    bytes += file.length()
                }
                val shortDigest = if (files > 0) {
                    val firstFile = dir.walkTopDown().firstOrNull { it.isFile }
                    if (firstFile != null) sha256(firstFile).take(12) else "none"
                } else "empty"
                SnapshotInfo(
                    name = dir.name,
                    createdAt = dir.lastModified(),
                    fileCount = files,
                    totalBytes = bytes,
                    digestSummary = shortDigest
                )
            }?.sortedByDescending { it.createdAt }.orEmpty()
    }

    fun getWorkspaceSummary(context: Context): WorkspaceSummary {
        val dir = project(context)
        val isImp = dir.isDirectory
        var files = 0
        var bytes = 0L
        var latestMod = 0L
        if (isImp) {
            dir.walkTopDown().filter { it.isFile }.forEach { file ->
                files++
                bytes += file.length()
                if (file.lastModified() > latestMod) latestMod = file.lastModified()
            }
        }
        val snapshotList = snapshots(context).listFiles()?.filter { it.isDirectory }?.size ?: 0
        return WorkspaceSummary(
            isImported = isImp,
            projectPath = dir.absolutePath,
            fileCount = files,
            totalSizeBytes = bytes,
            lastModified = latestMod,
            snapshotCount = snapshotList
        )
    }

    fun validatePath(raw: String): String {
        val path = raw.trim().replace('\\', '/')
        require(path.isNotBlank() && !path.startsWith('/') && !path.matches(Regex("^[A-Za-z]:.*"))) { "Absolute or blank path rejected." }
        val parts = path.split('/')
        require(parts.none { it.isBlank() || it == "." || it == ".." }) { "Path traversal rejected." }
        require(parts.all { it.matches(Regex("[A-Za-z0-9_.-]+")) }) { "Unsupported path characters." }
        return parts.joinToString("/")
    }

    /** Compares relative file paths and SHA-256 digests before a snapshot can be trusted. */
    private fun treesMatch(source: File, copy: File): Boolean {
        if (!source.isDirectory || !copy.isDirectory) return false
        fun inventory(root: File): Map<String, String> = root.walkTopDown()
            .filter { it.isFile }
            .associate { file ->
                val relative = file.relativeTo(root).path.replace('\\', '/')
                relative to sha256(file)
            }
        return inventory(source) == inventory(copy)
    }

    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun copyTree(from: File, to: File) {
        require(from.isDirectory) { "Snapshot source is not a directory." }
        from.walkTopDown().forEach { file ->
            val target = File(to, file.relativeTo(from).path)
            if (file.isDirectory) {
                if (!target.exists()) check(target.mkdirs()) { "Could not create snapshot directory: ${target.name}" }
            } else {
                target.parentFile?.let { parent ->
                    if (!parent.exists()) check(parent.mkdirs()) { "Could not create snapshot parent directory." }
                }
                file.copyTo(target, overwrite = true)
            }
        }
    }
}
