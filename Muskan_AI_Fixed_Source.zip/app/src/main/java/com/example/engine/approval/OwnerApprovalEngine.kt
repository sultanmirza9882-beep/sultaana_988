package com.example.engine.approval

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

enum class ProposalStatus {
    PENDING,
    APPROVED,
    REJECTED,
    POSTPONED,
    EXECUTED,
    ROLLED_BACK
}

enum class ProposalCategory {
    VOICE_DSP_IMPROVEMENT,
    MEMORY_OPTIMIZATION,
    PHONE_AUTOMATION_TOOL,
    SECURITY_PERMISSION,
    CODEBASE_REFACTOR,
    MODEL_SETTINGS
}

enum class SensitiveActionType(val label: String) {
    CALL_PHONE("CALL_PHONE"),
    SEND_SMS("SEND_SMS"),
    WHATSAPP_SEND("WHATSAPP_SEND"),
    CALENDAR_CREATE("CALENDAR_CREATE"),
    CALENDAR_RESCHEDULE("CALENDAR_RESCHEDULE"),
    CALENDAR_DELETE("CALENDAR_DELETE"),
    EMAIL_SEND("EMAIL_SEND"),
    SOCIAL_PUBLISH("SOCIAL_PUBLISH"),
    SOCIAL_REPLY("SOCIAL_REPLY")
}

data class ApprovalProposal(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val category: ProposalCategory,
    val hinglishExplanation: String,
    val technicalRationale: String,
    val affectedEngines: List<String>,
    val affectedFiles: List<String>,
    val expectedBenefits: String,
    val potentialRisks: String,
    val validationTests: String,
    val rollbackPlan: String,
    val requiresInternetOrCost: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    var status: ProposalStatus = ProposalStatus.PENDING,
    var ownerDecisionNote: String? = null,
    val sensitiveActionType: SensitiveActionType? = null,
    val targetRecipient: String? = null,
    val payloadPreview: String? = null
)

/**
 * Central Owner Approval Gate ensuring Sultan Mirza retains final authority over
 * sensitive external actions (CALL_PHONE, SEND_SMS, final WhatsApp message send)
 * and autonomous change proposals via a real suspendable CompletableDeferred queue.
 */
object OwnerApprovalGate {

    private val _proposals = MutableStateFlow<List<ApprovalProposal>>(emptyList())
    val proposals: StateFlow<List<ApprovalProposal>> = _proposals.asStateFlow()

    private val _pendingCount = MutableStateFlow(0)
    val pendingCount: StateFlow<Int> = _pendingCount.asStateFlow()

    private val _activeActionPrompt = MutableStateFlow<ApprovalProposal?>(null)
    val activeActionPrompt: StateFlow<ApprovalProposal?> = _activeActionPrompt.asStateFlow()

    private val pendingDecisions = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    private fun updateDerivedState() {
        val current = _proposals.value
        _pendingCount.value = current.count { it.status == ProposalStatus.PENDING }
        _activeActionPrompt.value = current.firstOrNull {
            it.status == ProposalStatus.PENDING && it.sensitiveActionType != null
        }
    }

    /**
     * Enqueues a sensitive action approval request and suspends on a real
     * [CompletableDeferred] until the owner explicitly approves, denies, cancels,
     * or the timeout expires (fail-closed: returns `false`).
     */
    suspend fun requestSensitiveActionApproval(
        actionType: SensitiveActionType,
        recipient: String,
        summary: String,
        payloadPreview: String? = null,
        technicalDetails: String = "",
        timeoutMs: Long = 120_000L
    ): Boolean {
        val proposalId = "action-${actionType.name.lowercase()}-${UUID.randomUUID().toString().take(8)}"
        val title = when (actionType) {
            SensitiveActionType.CALL_PHONE -> "Approve Phone Call: $recipient"
            SensitiveActionType.SEND_SMS -> "Approve SMS Send: $recipient"
            SensitiveActionType.WHATSAPP_SEND -> "Approve WhatsApp Send: $recipient"
            SensitiveActionType.CALENDAR_CREATE -> "Approve Calendar Event: $recipient"
            SensitiveActionType.CALENDAR_RESCHEDULE -> "Approve Event Reschedule: $recipient"
            SensitiveActionType.CALENDAR_DELETE -> "Approve Event Delete: $recipient"
            SensitiveActionType.EMAIL_SEND -> "Approve Email Send: $recipient"
            SensitiveActionType.SOCIAL_PUBLISH -> "Approve Social Publish: $recipient"
            SensitiveActionType.SOCIAL_REPLY -> "Approve Social Reply: $recipient"
        }
        val proposal = ApprovalProposal(
            id = proposalId,
            title = title,
            category = ProposalCategory.SECURITY_PERMISSION,
            hinglishExplanation = summary,
            technicalRationale = technicalDetails.ifBlank {
                "Explicit owner confirmation required before executing ${actionType.label} to '$recipient'."
            },
            affectedEngines = listOf("Engine 104 (Task Confirmation Engine)", "OwnerApprovalGate"),
            affectedFiles = listOf("OwnerApprovalEngine.kt"),
            expectedBenefits = "Prevents accidental outbound calls or messages without explicit approval.",
            potentialRisks = "Outbound communication (${actionType.label}) cannot be undone after dispatch.",
            validationTests = "Phase6ApprovalAndRoutingTest",
            rollbackPlan = "Denying cancels execution immediately before dispatch.",
            requiresInternetOrCost = actionType != SensitiveActionType.WHATSAPP_SEND,
            status = ProposalStatus.PENDING,
            sensitiveActionType = actionType,
            targetRecipient = recipient,
            payloadPreview = payloadPreview
        )

        val deferred = CompletableDeferred<Boolean>()
        pendingDecisions[proposalId] = deferred
        submitProposal(proposal)

        return try {
            val decision = withTimeoutOrNull(timeoutMs) {
                deferred.await()
            }
            if (decision == null) {
                rejectProposal(proposalId, reason = "Approval request timed out")
                false
            } else {
                decision
            }
        } catch (ce: CancellationException) {
            pendingDecisions.remove(proposalId)?.complete(false)
            markStatus(proposalId, ProposalStatus.REJECTED, "Cancelled before approval")
            throw ce
        } finally {
            pendingDecisions.remove(proposalId)
            updateDerivedState()
        }
    }

    fun submitProposal(proposal: ApprovalProposal) {
        _proposals.update { current ->
            listOf(proposal) + current.filter { it.id != proposal.id }
        }
        updateDerivedState()
    }

    fun approveProposal(proposalId: String, decisionNote: String = "Approved by Sultan Mirza"): Boolean {
        val found = markStatus(proposalId, ProposalStatus.APPROVED, decisionNote)
        pendingDecisions.remove(proposalId)?.complete(true)
        updateDerivedState()
        return found
    }

    fun rejectProposal(proposalId: String, reason: String = "Denied by owner"): Boolean {
        val found = markStatus(proposalId, ProposalStatus.REJECTED, reason)
        pendingDecisions.remove(proposalId)?.complete(false)
        updateDerivedState()
        return found
    }

    fun postponeProposal(proposalId: String): Boolean {
        val found = markStatus(proposalId, ProposalStatus.POSTPONED, "Postponed by owner")
        // Postponing a blocking sensitive action must never allow unapproved execution
        pendingDecisions.remove(proposalId)?.complete(false)
        updateDerivedState()
        return found
    }

    fun pendingSensitiveActions(): List<ApprovalProposal> {
        return _proposals.value.filter { it.status == ProposalStatus.PENDING && it.sensitiveActionType != null }
    }

    /**
     * Completes any awaiting requests with `false` and clears the in-memory queue (primarily for tests).
     */
    fun resetForTest() {
        val keys = pendingDecisions.keys.toList()
        keys.forEach { id ->
            pendingDecisions.remove(id)?.complete(false)
        }
        _proposals.value = emptyList()
        updateDerivedState()
    }

    private fun markStatus(proposalId: String, status: ProposalStatus, note: String?): Boolean {
        var found = false
        _proposals.update { list ->
            list.map {
                if (it.id == proposalId) {
                    found = true
                    it.copy(status = status, ownerDecisionNote = note)
                } else it
            }
        }
        return found
    }
}
