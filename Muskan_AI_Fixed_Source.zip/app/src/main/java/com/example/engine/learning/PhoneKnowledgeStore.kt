package com.example.engine.learning

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

/**
 * Muskan's trainable long-term memory for phone operation (v8 — Bilingual & Package-Aware Retrieval).
 *
 * Kinds of knowledge, all injected into the autonomous agent's prompt:
 *  - "builtin" : the Redmi 13 5G training notes bundled in assets/knowledge (loaded automatically)
 *  - "note"    : text the user taught (typed, imported from a file, or pasted)
 *  - "video"   : steps Muskan learned from a screen-recording the user uploaded
 *  - "routine" : action sequences Muskan recorded herself after succeeding, so the next time is faster
 * plus an automatic device profile (model, ROM, installed apps).
 */
object PhoneKnowledgeStore {

    data class Entry(
        val id: String,
        val kind: String,      // builtin | note | video | routine
        val title: String,
        val content: String,
        val createdAt: Long
    )

    private const val PREFS = "muskan_phone_knowledge"
    private const val KEY = "entries"
    private const val KEY_BUILTIN_VERSION = "builtin_version"
    private const val BUILTIN_VERSION = 2          // bumped in v8 so updated 06_Voice_Command_Examples.md reloads automatically
    private const val MAX_USER_ENTRIES = 300       // notes + videos + routines (built-in notes are never dropped)
    private const val MAX_CONTENT = 8000
    private const val CHUNK = 1500

    @Volatile private var appContext: Context? = null
    @Volatile private var cache: List<Entry>? = null

    /** Call before use. Also loads the bundled Redmi notes the first time (and when they are updated). */
    fun init(context: Context) {
        appContext = context.applicationContext
        seedBuiltinIfNeeded()
    }

    private fun prefs() = appContext?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun all(): List<Entry> {
        cache?.let { return it }
        val raw = prefs()?.getString(KEY, null) ?: return emptyList()
        val parsed = try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Entry(o.getString("id"), o.getString("kind"), o.getString("title"), o.getString("content"), o.getLong("ts"))
            }
        } catch (_: Exception) { emptyList() }
        cache = parsed
        return parsed
    }

    @Synchronized
    private fun save(list: List<Entry>) {
        val builtin = list.filter { it.kind == "builtin" }
        val user = list.filter { it.kind != "builtin" }.takeLast(MAX_USER_ENTRIES)
        val final = builtin + user
        val arr = JSONArray()
        final.forEach {
            arr.put(JSONObject().put("id", it.id).put("kind", it.kind).put("title", it.title)
                .put("content", it.content).put("ts", it.createdAt))
        }
        prefs()?.edit()?.putString(KEY, arr.toString())?.apply()
        cache = final
    }

    fun add(kind: String, title: String, content: String): Entry {
        val e = Entry(UUID.randomUUID().toString(), kind, title.trim().ifBlank { "Untitled" }, content.trim().take(MAX_CONTENT), System.currentTimeMillis())
        save(all() + e)
        return e
    }

    /** Updates an existing user note/video/routine in-place without losing its ID. */
    fun update(id: String, newTitle: String, newContent: String): Boolean {
        val current = all()
        val idx = current.indexOfFirst { it.id == id }
        if (idx < 0) return false
        val old = current[idx]
        val updated = old.copy(
            title = newTitle.trim().ifBlank { old.title },
            content = newContent.trim().take(MAX_CONTENT),
            createdAt = System.currentTimeMillis()
        )
        val mutable = current.toMutableList()
        mutable[idx] = updated
        save(mutable)
        return true
    }

    fun delete(id: String) = save(all().filterNot { it.id == id })

    fun builtinCount(): Int = all().count { it.kind == "builtin" }

    /** Re-load the bundled notes (e.g. if the user deleted them or updated assets). */
    fun reloadBuiltin() {
        prefs()?.edit()?.remove(KEY_BUILTIN_VERSION)?.apply()
        seedBuiltinIfNeeded()
    }

    /** Saves a routine Muskan just completed so similar goals are done faster next time. */
    fun recordRoutine(goal: String, steps: List<String>) {
        if (steps.size < 2) return
        val existing = all().firstOrNull { it.kind == "routine" && tokens(it.title) == tokens(goal) }
        if (existing != null) delete(existing.id)
        add("routine", goal.take(120), steps.joinToString("\n") { "- $it" })
    }

    // ------------------------------------------------------------------ built-in notes

    @Synchronized
    private fun seedBuiltinIfNeeded() {
        val ctx = appContext ?: return
        val p = prefs() ?: return
        if (p.getInt(KEY_BUILTIN_VERSION, 0) == BUILTIN_VERSION && all().any { it.kind == "builtin" }) return
        try {
            val files = ctx.assets.list("knowledge")?.sorted().orEmpty()
            if (files.isEmpty()) return
            val fresh = ArrayList<Entry>()
            val now = System.currentTimeMillis()
            for (f in files) {
                val text = ctx.assets.open("knowledge/$f").bufferedReader(Charsets.UTF_8).use { it.readText() }
                val short = f.removeSuffix(".md").replace('_', ' ')
                for ((heading, body) in chunkByHeading(text)) {
                    val always = f.startsWith("07_")
                    fresh.add(Entry(UUID.randomUUID().toString(), "builtin", (if (always) "!" else "") + "$short › $heading", body, now))
                }
            }
            val keep = all().filter { it.kind != "builtin" }
            val list = fresh + keep
            val arr = JSONArray()
            list.forEach {
                arr.put(JSONObject().put("id", it.id).put("kind", it.kind).put("title", it.title)
                    .put("content", it.content).put("ts", it.createdAt))
            }
            p.edit().putString(KEY, arr.toString()).putInt(KEY_BUILTIN_VERSION, BUILTIN_VERSION).apply()
            cache = list
        } catch (_: Exception) { /* notes are optional; never break the assistant */ }
    }

    /** Splits a markdown file at headings, then into pieces of at most CHUNK characters. */
    private fun chunkByHeading(text: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        var heading = "Overview"
        val buf = StringBuilder()
        fun flush() {
            val body = buf.toString().trim()
            buf.setLength(0)
            if (body.isBlank()) return
            var i = 0; var part = 1
            while (i < body.length) {
                var end = (i + CHUNK).coerceAtMost(body.length)
                if (end < body.length) {
                    val nl = body.lastIndexOf('\n', end)
                    if (nl > i + CHUNK / 2) end = nl
                }
                out.add((if (part == 1) heading else "$heading (part $part)") to body.substring(i, end).trim())
                i = end; part++
            }
        }
        for (line in text.lines()) {
            if (line.startsWith("#")) { flush(); heading = line.trimStart('#').trim().take(90).ifBlank { heading } }
            buf.append(line).append('\n')
        }
        flush()
        return out
    }

    // ------------------------------------------------------------------ retrieval (Bilingual + Package Expansion)

    private val bilingualSynonyms = mapOf(
        "व्हाट्सएप" to "whatsapp chat message call status",
        "whatsapp" to "व्हाट्सएप chat message call status",
        "मैसेज" to "message whatsapp chat send type",
        "message" to "मैसेज whatsapp chat send type",
        "यूट्यूब" to "youtube video shorts play search subscribe",
        "युटुब" to "youtube video shorts play search subscribe",
        "youtube" to "यूट्यूब video shorts play search subscribe",
        "शॉर्ट्स" to "shorts youtube vertical swipe",
        "इंस्टाग्राम" to "instagram reels story dm like",
        "insta" to "instagram इंस्टाग्राम reels story dm",
        "रील" to "reels instagram like swipe",
        "रील्स" to "reels instagram like swipe",
        "फेसबुक" to "facebook friend request post watch messenger",
        "fb" to "facebook फेसबुक friend request post",
        "क्रोम" to "chrome browser website omnibox translate tab",
        "ब्राउज़र" to "chrome browser website search url",
        "वेबसाइट" to "website chrome browser url translate",
        "कीबोर्ड" to "keyboard gboard type voice typing hindi spacebar",
        "टाइप" to "type keyboard gboard input",
        "सेटिंग" to "settings hyperos wifi bluetooth display hotspot battery",
        "सेटिंग्स" to "settings hyperos wifi bluetooth display hotspot battery",
        "वाई-फाई" to "wifi control center settings network",
        "नेट" to "mobile data internet wifi control center",
        "ब्लूटूथ" to "bluetooth control center settings pair",
        "टॉर्च" to "torch flashlight control center",
        "बत्ती" to "torch flashlight control center",
        "हॉटस्पॉट" to "hotspot portable password tethering",
        "ब्राइटनेस" to "brightness display control center dark mode",
        "डार्क" to "dark mode display settings",
        "स्पीकर" to "clear speaker additional settings sound",
        "कॉल" to "call video audio whatsapp dialer",
        "com.whatsapp" to "whatsapp व्हाट्सएप chat message",
        "com.google.android.youtube" to "youtube यूट्यूब video shorts",
        "com.instagram.android" to "instagram इंस्टाग्राम reels story",
        "com.facebook.katana" to "facebook फेसबुक friends post",
        "com.android.chrome" to "chrome क्रोम browser website",
        "com.android.settings" to "settings सेटिंग hyperos",
        "com.miui.home" to "home screen hyperos control center navigation"
    )

    private fun expandQueryText(raw: String): String {
        val lower = raw.lowercase(Locale.ROOT)
        val extra = StringBuilder(lower)
        for ((k, v) in bilingualSynonyms) {
            if (lower.contains(k)) {
                extra.append(' ').append(v)
            }
        }
        return extra.toString()
    }

    private fun tokens(s: String): Set<String> =
        s.lowercase(Locale.ROOT).split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.length > 2 }.toSet()

    private fun score(goalTokens: Set<String>, e: Entry): Int {
        val t = tokens(e.title + " " + e.content.take(2500))
        return goalTokens.count { it in t }
    }

    /**
     * Text block injected into the agent prompt: phone profile + core rules + the most relevant
     * taught knowledge. [extra] is extra context to match against (e.g. the app currently on screen).
     */
    fun promptContext(goal: String, extra: String = ""): String {
        val expanded = expandQueryText("$goal $extra")
        val gt = tokens(expanded)
        val entries = all()

        val always = entries.filter { it.title.startsWith("!") }.take(4)
        val userTaught = entries.filter { it.kind != "builtin" && it.kind != "routine" }
            .map { it to score(gt, it) }
            .sortedWith(compareByDescending<Pair<Entry, Int>> { it.second }.thenByDescending { it.first.createdAt })
            .take(3).map { it.first }

        val builtinRanked = entries.filter { it.kind == "builtin" && !it.title.startsWith("!") }
            .map { it to score(gt, it) }
            .sortedByDescending { it.second }
        val topBuiltin = builtinRanked.filter { it.second > 0 }.take(4).map { it.first }
            .ifEmpty { builtinRanked.take(2).map { it.first } }

        val taught = (userTaught + topBuiltin).distinctBy { it.id }.take(6)

        val routines = entries.filter { it.kind == "routine" }
            .map { it to score(gt, it) }.filter { it.second >= 2 }
            .sortedByDescending { it.second }.take(2).map { it.first }

        val sb = StringBuilder()
        sb.append("PHONE PROFILE:\n").append(deviceProfile()).append("\n")
        if (always.isNotEmpty()) {
            sb.append("\nCORE RULES FOR THIS PHONE:\n")
            always.forEach { sb.append(it.content.take(CHUNK)).append("\n") }
        }
        if (taught.isNotEmpty()) {
            sb.append("\nTAUGHT BY SULTAN / PHONE NOTES (trust these, but verify against the real screen; coordinates are approximate):\n")
            taught.forEach { sb.append("# ${it.title.removePrefix("!")}\n${it.content.take(CHUNK)}\n") }
        }
        if (routines.isNotEmpty()) {
            sb.append("\nPREVIOUSLY SUCCESSFUL ROUTINES (reuse, but verify against the real screen):\n")
            routines.forEach { sb.append("# ${it.title}\n${it.content.take(900)}\n") }
        }
        return sb.toString()
    }

    @Volatile private var cachedProfile: String? = null

    fun deviceProfile(refresh: Boolean = false): String {
        if (!refresh) cachedProfile?.let { return it }
        val ctx = appContext
        val rom = try {
            val c = Class.forName("android.os.SystemProperties")
            val m = c.getMethod("get", String::class.java, String::class.java)
            val miui = m.invoke(null, "ro.miui.ui.version.name", "") as String
            if (miui.isNotBlank()) "MIUI/HyperOS $miui" else Build.DISPLAY
        } catch (_: Exception) { Build.DISPLAY }

        val apps = try {
            val pm = ctx?.packageManager
            val i = android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER)
            pm?.queryIntentActivities(i, 0)?.map { it.loadLabel(pm).toString() }?.distinct()?.sorted()?.take(90)?.joinToString(", ").orEmpty()
        } catch (_: Exception) { "" }

        val dm = ctx?.resources?.displayMetrics
        val p = "Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ROM: $rom, " +
                "screen ${dm?.widthPixels}x${dm?.heightPixels}. Installed apps: $apps"
        cachedProfile = p
        return p
    }
}
