package com.example.engine.osint

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.engine.EngineRegistry
import com.example.engine.brain.DualBrainCoordinator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

enum class RiskLevel {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

data class RdapSummary(
    val domain: String,
    val handle: String,
    val registrar: String,
    val statuses: List<String>,
    val registrationDate: String,
    val expirationDate: String,
    val nameservers: List<String>
)

data class DnsRecordSet(
    val domain: String,
    val aRecords: List<String>,
    val mxRecords: List<String>,
    val txtRecords: List<String>,
    val hasSpf: Boolean,
    val hasDmarc: Boolean
)

data class HttpTlsInspection(
    val requestedUrl: String,
    val finalUrl: String,
    val statusCode: Int,
    val redirectCount: Int,
    val redirectChain: List<String>,
    val usesHttps: Boolean,
    val tlsVersion: String,
    val cipherSuite: String,
    val serverHeader: String,
    val hstsEnabled: Boolean
)

data class PhishingAssessment(
    val input: String,
    val normalizedHost: String,
    val riskScore: Int,
    val riskLevel: RiskLevel,
    val indicators: List<String>,
    val recommendation: String
)

data class DomainIntelligenceReport(
    val domain: String,
    val rdap: RdapSummary?,
    val dns: DnsRecordSet?,
    val httpTls: HttpTlsInspection?,
    val phishingAssessment: PhishingAssessment,
    val markdownReport: String
)

/**
 * Module 04: Digital Intelligence & Authorized Public OSINT Engine.
 *
 * Strictly limited to authorized public-source intelligence and defensive safety analysis:
 * - Public RDAP domain registration lookup (`https://rdap.org/domain/...`)
 * - Public Google DNS-over-HTTPS A/MX/TXT/DMARC resolution (`https://dns.google/resolve`)
 * - HTTP redirect chain & TLS handshake inspection via OkHttp
 * - Phishing, punycode/IDN lookalike, suspicious URL, and scam/fraud text heuristics
 * - Structured Markdown risk reports enriched via [DualBrainCoordinator]
 *
 * No unauthorized intrusion, port scanning, credential stuffing, or password cracking.
 */
object DigitalIntelligenceEngine {

    private const val TAG = "DigitalIntelEngine"
    private const val RDAP_BASE_URL = "https://rdap.org/domain/"
    private const val DOH_BASE_URL = "https://dns.google/resolve"
    private const val MAX_REDIRECTS = 5

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    private val manualRedirectClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(12, TimeUnit.SECONDS)
            .followRedirects(false)
            .followSslRedirects(false)
            .build()
    }

    private val riskyTlds = setOf(
        "tk", "ml", "ga", "cf", "gq", "xyz", "top", "zip", "click", "work", "buzz", "rest", "cam"
    )

    private val urlShorteners = setOf(
        "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "rb.gy", "cutt.ly", "rebrand.ly"
    )

    // Official apex domains for commonly impersonated brands
    private val brandOfficialDomains = mapOf(
        "paypal" to setOf("paypal.com"),
        "google" to setOf("google.com", "google.co.in", "accounts.google.com"),
        "amazon" to setOf("amazon.com", "amazon.in", "amazon.co.uk"),
        "sbi" to setOf("onlinesbi.sbi", "sbi.co.in"),
        "hdfc" to setOf("hdfcbank.com"),
        "icici" to setOf("icicibank.com"),
        "paytm" to setOf("paytm.com"),
        "phonepe" to setOf("phonepe.com"),
        "whatsapp" to setOf("whatsapp.com", "wa.me"),
        "instagram" to setOf("instagram.com"),
        "microsoft" to setOf("microsoft.com", "live.com", "outlook.com"),
        "apple" to setOf("apple.com", "icloud.com")
    )

    // Common leet/homoglyph lookalike spellings
    private val lookalikePatterns = listOf(
        Regex("""paypa[1l]""", RegexOption.IGNORE_CASE) to "PayPal lookalike spelling",
        Regex("""g00g[1l]e|go0gle""", RegexOption.IGNORE_CASE) to "Google lookalike spelling",
        Regex("""amaz0n|arnazon""", RegexOption.IGNORE_CASE) to "Amazon lookalike spelling",
        Regex("""micros0ft|rnicrosoft""", RegexOption.IGNORE_CASE) to "Microsoft lookalike spelling",
        Regex("""app[1l]eid|ic[1l]oud""", RegexOption.IGNORE_CASE) to "Apple/iCloud lookalike spelling",
        Regex("""whatsa[p]{1,2}-?(verify|login|update)""", RegexOption.IGNORE_CASE) to "WhatsApp verification impersonation",
        Regex("""(sbi|hdfc|icici|paytm|upi)-?(kyc|verify|update|login|secure)""", RegexOption.IGNORE_CASE) to "Banking/UPI KYC impersonation"
    )

    private val credentialKeywords = listOf(
        "login", "signin", "verify", "kyc", "update-account", "secure-bank",
        "password", "otp", "upi", "wallet", "claim-prize", "reward", "refund"
    )

    private val scamTextIndicators = listOf(
        "share otp" to 35,
        "send otp" to 35,
        "upi pin" to 40,
        "account will be blocked" to 35,
        "account suspended" to 30,
        "kyc expired" to 35,
        "kyc update" to 25,
        "lottery won" to 40,
        "won a prize" to 35,
        "click immediately" to 25,
        "urgent action required" to 25,
        "verify within 24 hours" to 30,
        "bank account blocked" to 35,
        "free recharge" to 25
    )

    private val ipv4Regex = Regex("""^\d{1,3}(\.\d{1,3}){3}$""")

    /**
     * Extracts a clean lowercase hostname from a URL, email address, or raw domain string.
     */
    fun extractDomain(input: String): String {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return ""

        // Email address (not containing URL scheme)
        if (!trimmed.contains("://") && trimmed.contains("@") && !trimmed.contains("/")) {
            return trimmed.substringAfterLast("@").lowercase(Locale.ROOT).trim().trimEnd('.')
        }

        val withScheme = if (trimmed.contains("://")) trimmed else "https://$trimmed"
        val hostFromUri = runCatching { Uri.parse(withScheme).host }.getOrNull()
        val candidate = hostFromUri?.takeIf { it.isNotBlank() }
            ?: trimmed
                .substringAfter("://")
                .substringAfter("@")
                .substringBefore("/")
                .substringBefore("?")
                .substringBefore("#")
                .substringBefore(":")

        return candidate.lowercase(Locale.ROOT).trim().trimEnd('.')
    }

    /**
     * Parses a public RDAP JSON response (`https://rdap.org/domain/...`) into a clean [RdapSummary].
     */
    fun parseRdapJson(domain: String, json: String): RdapSummary {
        val root = JSONObject(json)
        val ldhName = root.optString("ldhName").ifBlank { domain }
        val handle = root.optString("handle", "Unknown")

        val statuses = mutableListOf<String>()
        val statusArray = root.optJSONArray("status")
        if (statusArray != null) {
            for (i in 0 until statusArray.length()) {
                val s = statusArray.optString(i).trim()
                if (s.isNotBlank()) statuses.add(s)
            }
        }

        var registrationDate = "Unknown"
        var expirationDate = "Unknown"
        val events = root.optJSONArray("events")
        if (events != null) {
            for (i in 0 until events.length()) {
                val ev = events.optJSONObject(i) ?: continue
                val action = ev.optString("eventAction").lowercase(Locale.ROOT)
                val date = ev.optString("eventDate").trim()
                when (action) {
                    "registration" -> if (date.isNotBlank()) registrationDate = date
                    "expiration" -> if (date.isNotBlank()) expirationDate = date
                }
            }
        }

        val nameservers = mutableListOf<String>()
        val nsArray = root.optJSONArray("nameservers")
        if (nsArray != null) {
            for (i in 0 until nsArray.length()) {
                val ns = nsArray.optJSONObject(i)?.optString("ldhName")?.trim().orEmpty()
                if (ns.isNotBlank()) nameservers.add(ns.lowercase(Locale.ROOT))
            }
        }

        var registrar = "Unknown"
        val entities = root.optJSONArray("entities")
        if (entities != null) {
            for (i in 0 until entities.length()) {
                val entity = entities.optJSONObject(i) ?: continue
                val roles = entity.optJSONArray("roles")
                var isRegistrar = false
                if (roles != null) {
                    for (r in 0 until roles.length()) {
                        if (roles.optString(r).equals("registrar", ignoreCase = true)) {
                            isRegistrar = true
                            break
                        }
                    }
                }
                if (isRegistrar) {
                    val fn = extractVcardFullName(entity)
                    if (fn.isNotBlank()) {
                        registrar = fn
                        break
                    }
                }
            }
        }

        return RdapSummary(
            domain = ldhName.lowercase(Locale.ROOT),
            handle = handle,
            registrar = registrar,
            statuses = statuses,
            registrationDate = registrationDate,
            expirationDate = expirationDate,
            nameservers = nameservers
        )
    }

    /**
     * Parses a Google DNS-over-HTTPS JSON response (`https://dns.google/resolve`) and returns
     * all `Answer[].data` records.
     */
    fun parseDnsOverHttpsJson(json: String): List<String> {
        if (json.isBlank()) return emptyList()
        return runCatching {
            val root = JSONObject(json)
            if (root.optInt("Status", -1) != 0) return emptyList()
            val answers = root.optJSONArray("Answer") ?: return emptyList()
            buildList {
                for (i in 0 until answers.length()) {
                    val data = answers.optJSONObject(i)?.optString("data")?.trim().orEmpty()
                    if (data.isNotBlank()) add(data.trim('"'))
                }
            }
        }.getOrDefault(emptyList())
    }

    /**
     * Queries public RDAP (`https://rdap.org/domain/{domain}`).
     */
    suspend fun lookupRdap(domain: String): Result<RdapSummary> = withContext(Dispatchers.IO) {
        EngineRegistry.recordInvocation(18, success = true)
        val cleanDomain = extractDomain(domain)
        if (cleanDomain.isBlank() || !cleanDomain.contains(".")) {
            return@withContext Result.failure(IllegalArgumentException("Invalid domain: $domain"))
        }
        runCatching {
            val req = Request.Builder()
                .url("$RDAP_BASE_URL${Uri.encode(cleanDomain)}")
                .header("Accept", "application/rdap+json, application/json")
                .header("User-Agent", "MuskanOSINT/1.0")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException("RDAP HTTP ${resp.code}")
                }
                parseRdapJson(cleanDomain, resp.body?.string().orEmpty())
            }
        }
    }

    /**
     * Queries public Google DNS-over-HTTPS for A, MX, TXT, and `_dmarc` TXT records.
     */
    suspend fun lookupDnsOverHttps(domain: String): Result<DnsRecordSet> = withContext(Dispatchers.IO) {
        EngineRegistry.recordInvocation(18, success = true)
        val cleanDomain = extractDomain(domain)
        if (cleanDomain.isBlank() || !cleanDomain.contains(".")) {
            return@withContext Result.failure(IllegalArgumentException("Invalid domain: $domain"))
        }
        runCatching {
            val aRecords = queryDohRecord(cleanDomain, "A")
            val mxRecords = queryDohRecord(cleanDomain, "MX")
            val txtRecords = queryDohRecord(cleanDomain, "TXT")
            val dmarcRecords = queryDohRecord("_dmarc.$cleanDomain", "TXT")
            val allTxt = txtRecords + dmarcRecords

            DnsRecordSet(
                domain = cleanDomain,
                aRecords = aRecords,
                mxRecords = mxRecords,
                txtRecords = txtRecords,
                hasSpf = allTxt.any { it.contains("v=spf1", ignoreCase = true) },
                hasDmarc = allTxt.any { it.contains("v=DMARC1", ignoreCase = true) }
            )
        }
    }

    /**
     * Performs a bounded HTTP redirect and TLS handshake inspection using OkHttp.
     */
    suspend fun inspectHttpAndTls(rawUrl: String): Result<HttpTlsInspection> = withContext(Dispatchers.IO) {
        EngineRegistry.recordInvocation(18, success = true)
        val normalizedUrl = if (rawUrl.trim().contains("://")) rawUrl.trim() else "https://${rawUrl.trim()}"
        runCatching {
            val chain = mutableListOf(normalizedUrl)
            var currentUrl = normalizedUrl
            var lastStatusCode = 0
            var tlsVersion = "None"
            var cipherSuite = "None"
            var serverHeader = "Unknown"
            var hstsEnabled = false

            for (hop in 0..MAX_REDIRECTS) {
                val req = Request.Builder()
                    .url(currentUrl)
                    .header("User-Agent", "MuskanOSINT/1.0")
                    .get()
                    .build()

                manualRedirectClient.newCall(req).execute().use { resp ->
                    lastStatusCode = resp.code
                    resp.handshake?.let { hs ->
                        tlsVersion = hs.tlsVersion.javaName
                        cipherSuite = hs.cipherSuite.javaName
                    }
                    serverHeader = resp.header("Server") ?: serverHeader
                    if (!resp.header("Strict-Transport-Security").isNullOrBlank()) {
                        hstsEnabled = true
                    }

                    val location = resp.header("Location")
                    if (resp.isRedirect && !location.isNullOrBlank() && hop < MAX_REDIRECTS) {
                        val nextUrl = resp.request.url.resolve(location)?.toString() ?: location
                        chain.add(nextUrl)
                        currentUrl = nextUrl
                    } else {
                        return@runCatching HttpTlsInspection(
                            requestedUrl = normalizedUrl,
                            finalUrl = currentUrl,
                            statusCode = lastStatusCode,
                            redirectCount = (chain.size - 1).coerceAtLeast(0),
                            redirectChain = chain,
                            usesHttps = currentUrl.startsWith("https://", ignoreCase = true),
                            tlsVersion = tlsVersion,
                            cipherSuite = cipherSuite,
                            serverHeader = serverHeader,
                            hstsEnabled = hstsEnabled
                        )
                    }
                }
            }

            HttpTlsInspection(
                requestedUrl = normalizedUrl,
                finalUrl = currentUrl,
                statusCode = lastStatusCode,
                redirectCount = (chain.size - 1).coerceAtLeast(0),
                redirectChain = chain,
                usesHttps = currentUrl.startsWith("https://", ignoreCase = true),
                tlsVersion = tlsVersion,
                cipherSuite = cipherSuite,
                serverHeader = serverHeader,
                hstsEnabled = hstsEnabled
            )
        }
    }

    /**
     * Analyzes URLs, domains, emails, phone numbers, or messages for phishing,
     * punycode/IDN homographs, lookalike brand impersonation, and scam indicators.
     */
    fun analyzePhishingAndScam(input: String): PhishingAssessment {
        val trimmed = input.trim()
        val lower = trimmed.lowercase(Locale.ROOT)
        val indicators = mutableListOf<String>()
        var score = 0

        // Extract first URL/domain candidate if input is a full sentence
        val urlToken = Regex("""https?://[^\s]+""", RegexOption.IGNORE_CASE).find(trimmed)?.value
            ?: Regex("""\b(?:[a-z0-9-]+\.)+[a-z]{2,}\b""", RegexOption.IGNORE_CASE).find(trimmed)?.value
            ?: trimmed
        val host = extractDomain(urlToken)

        // 1. Punycode / IDN homograph check
        if (host.contains("xn--")) {
            score += 45
            indicators.add("Punycode (xn--) internationalized domain detected — high IDN homograph phishing risk")
        }
        if (host.any { it.code > 127 }) {
            score += 40
            indicators.add("Non-ASCII Unicode characters in domain host (possible lookalike homoglyph)")
        }

        // 2. Credential injection '@' inside URL authority
        val authority = urlToken.substringAfter("://", "").substringBefore("/")
        if (urlToken.contains("://") && authority.contains("@")) {
            score += 45
            indicators.add("URL contains '@' in authority section (classic destination obfuscation)")
        }

        // 3. Raw IP address host
        if (ipv4Regex.matches(host)) {
            score += 40
            indicators.add("URL points directly to a raw IPv4 address ($host) instead of a registered domain")
        }

        // 4. Explicit lookalike brand patterns (paypa1, g00gle, hdfc-kyc, etc.)
        for ((regex, label) in lookalikePatterns) {
            if (regex.containsMatchIn(host) || regex.containsMatchIn(urlToken)) {
                score += 45
                indicators.add("$label detected in '$host'")
            }
        }

        // 5. Brand impersonation outside official apex domain
        if (host.contains(".")) {
            for ((brand, officialSet) in brandOfficialDomains) {
                val isOfficial = officialSet.any { official ->
                    host == official || host.endsWith(".$official")
                }
                if (!isOfficial && host.contains(brand)) {
                    score += 40
                    indicators.add("Domain '$host' references brand '$brand' outside official domain(s) ${officialSet.joinToString()}")
                }
            }
        }

        // 6. Unencrypted HTTP + credential/sensitive keywords
        val hasCredentialKeyword = credentialKeywords.any { lower.contains(it) }
        if (urlToken.startsWith("http://", ignoreCase = true)) {
            score += if (hasCredentialKeyword) 35 else 15
            indicators.add("Uses unencrypted HTTP (no TLS protection)")
        }

        // 7. High-risk TLD & excessive subdomains / URL shortener
        val tld = host.substringAfterLast(".", "")
        if (tld in riskyTlds) {
            score += if (hasCredentialKeyword) 30 else 20
            indicators.add("Uses high-abuse TLD '.$tld'")
        }
        val labels = host.split(".").filter { it.isNotBlank() }
        if (labels.size >= 4 && !ipv4Regex.matches(host)) {
            score += 20
            indicators.add("Excessive subdomain depth (${labels.size} labels) often used to hide true apex domain")
        }
        if (host in urlShorteners) {
            score += 20
            indicators.add("URL shortener ($host) masks final destination")
        }
        if (urlToken.length > 130 && urlToken.contains("://")) {
            score += 15
            indicators.add("Unusually long URL (${urlToken.length} chars)")
        }

        // 8. Scam/fraud text & phone format patterns
        for ((phrase, weight) in scamTextIndicators) {
            if (lower.contains(phrase)) {
                score += weight
                indicators.add("Scam/social-engineering phrase detected: '$phrase'")
            }
        }
        if (Regex("""(?:\+881|\+882|\+224|\+252|\+375|\+371|\b140\d{7}\b)""").containsMatchIn(trimmed)) {
            score += 35
            indicators.add("Suspicious telemarketing or international callback/Wangiri phone number format")
        }

        val clampedScore = score.coerceIn(0, 100)
        val riskLevel = when {
            clampedScore >= 75 -> RiskLevel.CRITICAL
            clampedScore >= 50 -> RiskLevel.HIGH
            clampedScore >= 25 -> RiskLevel.MEDIUM
            else -> RiskLevel.LOW
        }

        if (indicators.isEmpty()) {
            indicators.add("No obvious phishing, punycode, or scam patterns detected")
        }

        val recommendation = when (riskLevel) {
            RiskLevel.CRITICAL -> "DO NOT OPEN OR SHARE OTP/CREDENTIALS. High-confidence phishing/scam threat."
            RiskLevel.HIGH -> "Avoid clicking or entering personal data; verify independently via official app/site."
            RiskLevel.MEDIUM -> "Proceed with caution and double-check the sender and final URL."
            RiskLevel.LOW -> "No major automated red flags found, though standard caution still applies."
        }

        return PhishingAssessment(
            input = trimmed,
            normalizedHost = host,
            riskScore = clampedScore,
            riskLevel = riskLevel,
            indicators = indicators,
            recommendation = recommendation
        )
    }

    /**
     * Runs a complete authorized public OSINT domain & URL audit (RDAP + DoH + HTTP/TLS +
     * phishing analysis) and formats a structured Markdown risk report via [DualBrainCoordinator].
     */
    suspend fun analyzeDomainAndGenerateReport(
        context: Context,
        rawInput: String
    ): DomainIntelligenceReport {
        val assessment = analyzePhishingAndScam(rawInput)
        val domain = assessment.normalizedHost

        val rdap = if (domain.contains(".") && !ipv4Regex.matches(domain)) lookupRdap(domain).getOrNull() else null
        val dns = if (domain.contains(".") && !ipv4Regex.matches(domain)) lookupDnsOverHttps(domain).getOrNull() else null
        val httpTls = if (domain.contains(".")) inspectHttpAndTls(rawInput).getOrNull() else null

        val markdown = generateMarkdownRiskReport(context, domain.ifBlank { rawInput }, rdap, dns, httpTls, assessment)
        return DomainIntelligenceReport(
            domain = domain,
            rdap = rdap,
            dns = dns,
            httpTls = httpTls,
            phishingAssessment = assessment,
            markdownReport = markdown
        )
    }

    suspend fun generateMarkdownRiskReport(
        context: Context,
        target: String,
        rdap: RdapSummary?,
        dns: DnsRecordSet?,
        httpTls: HttpTlsInspection?,
        assessment: PhishingAssessment
    ): String {
        val structuredFacts = buildString {
            appendLine("## OSINT & Safety Report: `$target`")
            appendLine("- **Risk Level:** `${assessment.riskLevel.name}` (${assessment.riskScore}/100)")
            appendLine("- **Recommendation:** ${assessment.recommendation}")
            appendLine()
            appendLine("### Phishing & Scam Indicators")
            assessment.indicators.forEach { appendLine("- $it") }
            if (rdap != null) {
                appendLine()
                appendLine("### Public RDAP Registration")
                appendLine("- **Registrar:** ${rdap.registrar}")
                appendLine("- **Registered:** ${rdap.registrationDate}")
                appendLine("- **Expires:** ${rdap.expirationDate}")
                if (rdap.nameservers.isNotEmpty()) {
                    appendLine("- **Nameservers:** ${rdap.nameservers.take(4).joinToString(", ")}")
                }
            }
            if (dns != null) {
                appendLine()
                appendLine("### DNS-over-HTTPS Summary")
                appendLine("- **A Records:** ${dns.aRecords.ifEmpty { listOf("None") }.joinToString(", ")}")
                appendLine("- **MX Records:** ${dns.mxRecords.ifEmpty { listOf("None") }.joinToString(", ")}")
                appendLine("- **Email Auth:** SPF=${if (dns.hasSpf) "Present" else "Missing"}, DMARC=${if (dns.hasDmarc) "Present" else "Missing"}")
            }
            if (httpTls != null) {
                appendLine()
                appendLine("### HTTP Redirects & TLS")
                appendLine("- **Status:** HTTP ${httpTls.statusCode} | **Redirects:** ${httpTls.redirectCount}")
                appendLine("- **Final URL:** `${httpTls.finalUrl}`")
                appendLine("- **TLS:** ${httpTls.tlsVersion} (${httpTls.cipherSuite}) | **HSTS:** ${httpTls.hstsEnabled}")
            }
        }.trim()

        val aiBrief = runCatching {
            val prompt = """
                Summarize this authorized public OSINT & phishing risk report in 2 concise Hinglish sentences for Sultan Mirza:
                $structuredFacts
            """.trimIndent()
            DualBrainCoordinator.executeReasoning(context, prompt).responseText.trim()
        }.getOrNull()?.takeIf { it.length > 15 }

        return if (aiBrief != null) {
            "$structuredFacts\n\n### Executive Summary\n$aiBrief"
        } else {
            structuredFacts
        }
    }

    /**
     * Natural-language Hindi/Hinglish/English handler for link safety checks and domain OSINT.
     */
    suspend fun handleVoiceOsintCommand(context: Context, prompt: String): String {
        val urlOrDomain = Regex("""https?://[^\s]+""", RegexOption.IGNORE_CASE).find(prompt)?.value
            ?: Regex("""\b(?:[a-z0-9-]+\.)+[a-z]{2,}\b""", RegexOption.IGNORE_CASE).find(prompt)?.value

        if (urlOrDomain == null) {
            val assessment = analyzePhishingAndScam(prompt)
            return "Sultan, scam/phishing check complete — Risk Level: ${assessment.riskLevel.name} (${assessment.riskScore}/100). " +
                "${assessment.indicators.firstOrNull().orEmpty()}. ${assessment.recommendation}"
        }

        val report = analyzeDomainAndGenerateReport(context, urlOrDomain)
        return report.markdownReport
    }

    private fun queryDohRecord(name: String, type: String): List<String> {
        val url = "$DOH_BASE_URL?name=${Uri.encode(name)}&type=${Uri.encode(type)}"
        val req = Request.Builder()
            .url(url)
            .header("Accept", "application/dns-json")
            .get()
            .build()
        return runCatching {
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                parseDnsOverHttpsJson(resp.body?.string().orEmpty())
            }
        }.getOrDefault(emptyList())
    }

    private fun extractVcardFullName(entity: JSONObject): String {
        val vcardArray = entity.optJSONArray("vcardArray") ?: return ""
        if (vcardArray.length() < 2) return ""
        val properties = vcardArray.optJSONArray(1) ?: return ""
        for (i in 0 until properties.length()) {
            val prop = properties.optJSONArray(i) ?: continue
            if (prop.length() >= 4 && prop.optString(0).equals("fn", ignoreCase = true)) {
                return prop.optString(3).trim()
            }
        }
        return ""
    }
}
