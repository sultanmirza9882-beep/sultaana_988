package com.example.engine.workflow

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import com.example.VoiceSessionManager
import com.example.automation.AutomationActionEngine
import com.example.data.local.AppDatabase
import com.example.data.local.TaughtWorkflowEntity
import com.example.service.MuskanAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

/**
 * Procedural Action Step within an automated workflow or routine.
 */
enum class WorkflowStepType {
    LAUNCH_APP,
    SPEAK,
    OPEN_URL,
    SET_VOLUME,
    TORCH,
    WAIT
}

data class WorkflowStep(
    val type: WorkflowStepType,
    val target: String,
    val delayMs: Long = 600L
)

/**
 * Autonomous Taught Workflow and Routine Engine for Muskan.
 * Permanently stores, teaches, recalls, and executes multi-step automation workflows.
 */
object TaughtWorkflowEngine {

    data class WorkflowExecutionState(
        val isRunning: Boolean = false,
        val activeWorkflowTitle: String? = null,
        val currentStepIndex: Int = 0,
        val totalSteps: Int = 0,
        val lastExecutedStatus: String = "Idle"
    )

    private val _executionState = MutableStateFlow(WorkflowExecutionState())
    val executionState: StateFlow<WorkflowExecutionState> = _executionState.asStateFlow()

    /**
     * Seeds initial high-utility workflows if database is completely empty.
     */
    suspend fun ensureDefaultWorkflowsSeeded(context: Context) = withContext(Dispatchers.IO) {
        try {
            val dao = AppDatabase.getDatabase(context).taughtWorkflowDao()
            val existing = dao.getAllWorkflows()
            if (existing.isNotEmpty()) return@withContext

            val defaultWorkflows = listOf(
                TaughtWorkflowEntity(
                    workflowId = UUID.randomUUID().toString(),
                    title = "Good Morning Routine",
                    triggerPhrase = "good morning",
                    description = "Subah ki shuruat: Greeting, WhatsApp open aur YouTube news",
                    stepsJson = serializeSteps(
                        listOf(
                            WorkflowStep(WorkflowStepType.SPEAK, "Subah bakhair Sultan! Din ki shuruat karte hain.", 1200L),
                            WorkflowStep(WorkflowStepType.LAUNCH_APP, "WhatsApp", 1000L),
                            WorkflowStep(WorkflowStepType.OPEN_URL, "https://www.youtube.com/results?search_query=aaj+tak+live+news", 1500L)
                        )
                    ),
                    isEnabled = true
                ),
                TaughtWorkflowEntity(
                    workflowId = UUID.randomUUID().toString(),
                    title = "Night Routine",
                    triggerPhrase = "good night",
                    description = "Raat ka routine: Sweet dreams greeting, torch band aur volume dheemi",
                    stepsJson = serializeSteps(
                        listOf(
                            WorkflowStep(WorkflowStepType.SPEAK, "Shubh raatri Sultan. Main phone ko quiet mode par set kar rahi hoon.", 1000L),
                            WorkflowStep(WorkflowStepType.TORCH, "OFF", 400L),
                            WorkflowStep(WorkflowStepType.SET_VOLUME, "15", 500L)
                        )
                    ),
                    isEnabled = true
                ),
                TaughtWorkflowEntity(
                    workflowId = UUID.randomUUID().toString(),
                    title = "Focus Mode",
                    triggerPhrase = "focus mode",
                    description = "Padhai aur kaam: Distractions band aur sound mute",
                    stepsJson = serializeSteps(
                        listOf(
                            WorkflowStep(WorkflowStepType.SPEAK, "Focus mode on kar diya hai, Sultan. Padhai shuru kijiye.", 1000L),
                            WorkflowStep(WorkflowStepType.SET_VOLUME, "0", 500L)
                        )
                    ),
                    isEnabled = true
                )
            )

            for (wf in defaultWorkflows) {
                dao.insertWorkflow(wf)
            }
        } catch (_: Exception) {}
    }

    /**
     * Checks if a voice query matches any taught workflow trigger.
     */
    suspend fun findMatchingWorkflow(context: Context, rawSpokenText: String): TaughtWorkflowEntity? =
        withContext(Dispatchers.IO) {
            val query = rawSpokenText.lowercase(Locale.ROOT).trim()
            if (query.isBlank()) return@withContext null

            try {
                ensureDefaultWorkflowsSeeded(context)
                val dao = AppDatabase.getDatabase(context).taughtWorkflowDao()
                val enabledWorkflows = dao.getEnabledWorkflows()

                // Check exact trigger or trigger containment
                for (wf in enabledWorkflows) {
                    val trigger = wf.triggerPhrase.lowercase(Locale.ROOT).trim()
                    if (trigger.isBlank()) continue
                    if (query == trigger || query.contains(trigger) || trigger.contains(query)) {
                        return@withContext wf
                    }
                }
            } catch (_: Exception) {}
            null
        }

    /**
     * Executes a taught workflow sequentially step-by-step with real device feedback.
     */
    suspend fun executeWorkflow(
        context: Context,
        workflow: TaughtWorkflowEntity,
        onStepFeedback: ((String) -> Unit)? = null
    ): Boolean = withContext(Dispatchers.Main) {
        val steps = deserializeSteps(workflow.stepsJson)
        if (steps.isEmpty()) return@withContext false

        _executionState.update {
            it.copy(
                isRunning = true,
                activeWorkflowTitle = workflow.title,
                currentStepIndex = 0,
                totalSteps = steps.size,
                lastExecutedStatus = "Starting ${workflow.title}…"
            )
        }

        try {
            for ((index, step) in steps.withIndex()) {
                _executionState.update {
                    it.copy(
                        currentStepIndex = index + 1,
                        lastExecutedStatus = "Step ${index + 1}/${steps.size}: ${step.type.name} -> ${step.target}"
                    )
                }
                onStepFeedback?.invoke("Executing ${step.type.name}: ${step.target}")

                when (step.type) {
                    WorkflowStepType.LAUNCH_APP -> {
                        MuskanAccessibilityService.launchAppByName(context, step.target)
                    }
                    WorkflowStepType.SPEAK -> {
                        VoiceSessionManager.speakOut(step.target)
                    }
                    WorkflowStepType.OPEN_URL -> {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(step.target)).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    }
                    WorkflowStepType.SET_VOLUME -> {
                        try {
                            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                            val maxVol = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15
                            val pct = step.target.toIntOrNull() ?: 50
                            val targetVol = ((pct / 100f) * maxVol).toInt().coerceIn(0, maxVol)
                            audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, AudioManager.FLAG_SHOW_UI)
                        } catch (_: Exception) {}
                    }
                    WorkflowStepType.TORCH -> {
                        val turnOn = step.target.equals("ON", ignoreCase = true)
                        AutomationActionEngine.setFlashlight(context, turnOn)
                    }
                    WorkflowStepType.WAIT -> {
                        val ms = step.target.toLongOrNull() ?: step.delayMs
                        delay(ms)
                    }
                }

                if (step.delayMs > 0) {
                    delay(step.delayMs)
                }
            }

            // Update execution stats in database
            withContext(Dispatchers.IO) {
                try {
                    AppDatabase.getDatabase(context).taughtWorkflowDao().recordExecution(workflow.id)
                } catch (_: Exception) {}
            }

            _executionState.update {
                it.copy(
                    isRunning = false,
                    lastExecutedStatus = "Completed ${workflow.title} successfully!"
                )
            }
            true
        } catch (e: Exception) {
            _executionState.update {
                it.copy(
                    isRunning = false,
                    lastExecutedStatus = "Workflow interrupted: ${e.message}"
                )
            }
            false
        }
    }

    /**
     * Parses natural language teaching instructions like:
     * "Muskan, naya routine sikho: jab main bolun [trigger], toh [action 1] aur [action 2]"
     */
    suspend fun teachWorkflowFromSpeech(context: Context, rawPrompt: String): TaughtWorkflowEntity? =
        withContext(Dispatchers.IO) {
            val prompt = rawPrompt.lowercase(Locale.ROOT)
            val isTeachingIntent = prompt.contains("naya routine") ||
                prompt.contains("naya workflow") ||
                prompt.contains("teach workflow") ||
                prompt.contains("sikho jab main bolun") ||
                prompt.contains("sikhao")

            if (!isTeachingIntent) return@withContext null

            // Extract trigger: "jab main bolun X" or "trigger X"
            val triggerRegex = Regex("""(?:jab main bolun|trigger|jab bolu)\s+['"]?([^,'"]+)['"]?""")
            val triggerMatch = triggerRegex.find(prompt)
            val trigger = triggerMatch?.groupValues?.get(1)?.trim() ?: return@withContext null

            val steps = mutableListOf<WorkflowStep>()
            steps.add(WorkflowStep(WorkflowStepType.SPEAK, "Workflows active, $trigger routine chalaya ja raha hai.", 800L))

            if (prompt.contains("whatsapp")) {
                steps.add(WorkflowStep(WorkflowStepType.LAUNCH_APP, "WhatsApp", 1000L))
            }
            if (prompt.contains("youtube")) {
                steps.add(WorkflowStep(WorkflowStepType.LAUNCH_APP, "YouTube", 1000L))
            }
            if (prompt.contains("torch band") || prompt.contains("torch off")) {
                steps.add(WorkflowStep(WorkflowStepType.TORCH, "OFF", 400L))
            } else if (prompt.contains("torch on") || prompt.contains("torch jalao")) {
                steps.add(WorkflowStep(WorkflowStepType.TORCH, "ON", 400L))
            }
            if (prompt.contains("silent") || prompt.contains("mute")) {
                steps.add(WorkflowStep(WorkflowStepType.SET_VOLUME, "0", 400L))
            }

            if (steps.size <= 1) {
                // Fallback action
                steps.add(WorkflowStep(WorkflowStepType.SPEAK, "Routine muqammal ho gaya hai, Sultan.", 500L))
            }

            val entity = TaughtWorkflowEntity(
                workflowId = UUID.randomUUID().toString(),
                title = trigger.replaceFirstChar { it.uppercase() } + " Routine",
                triggerPhrase = trigger,
                description = "User taught routine for '$trigger'",
                stepsJson = serializeSteps(steps),
                isEnabled = true
            )

            try {
                AppDatabase.getDatabase(context).taughtWorkflowDao().insertWorkflow(entity)
                entity
            } catch (_: Exception) {
                null
            }
        }

    fun serializeSteps(steps: List<WorkflowStep>): String {
        val array = JSONArray()
        for (step in steps) {
            val obj = JSONObject()
            obj.put("type", step.type.name)
            obj.put("target", step.target)
            obj.put("delayMs", step.delayMs)
            array.put(obj)
        }
        return array.toString()
    }

    fun deserializeSteps(json: String): List<WorkflowStep> {
        val list = mutableListOf<WorkflowStep>()
        if (json.isBlank()) return list
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val typeName = obj.optString("type", "SPEAK")
                val type = try {
                    WorkflowStepType.valueOf(typeName)
                } catch (_: Exception) {
                    WorkflowStepType.SPEAK
                }
                val target = obj.optString("target", "")
                val delayMs = obj.optLong("delayMs", 600L)
                list.add(WorkflowStep(type, target, delayMs))
            }
        } catch (_: Exception) {}
        return list
    }
}
