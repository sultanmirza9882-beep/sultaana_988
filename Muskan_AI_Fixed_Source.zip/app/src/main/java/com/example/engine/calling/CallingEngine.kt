package com.example.engine.calling

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.local.UserMemoryEntity
import com.example.engine.EngineRegistry
import com.example.engine.approval.OwnerApprovalGate
import com.example.engine.approval.SensitiveActionType
import com.example.engine.brain.DualBrainCoordinator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class CallRiskVerdict {
    ALLOWED,
    ALLOWLISTED,
    SUSPICIOUS_SPAM,
    BLOCKED_SPAM,
    BLOCKED_USER_LIST
}

enum class CallFollowUpChannel {
    SMS,
    WHATSAPP
}

data class CallScreeningDecision(
    val normalizedNumber: String,
    val verdict: CallRiskVerdict,
    val riskScore: Int,
    val shouldReject: Boolean,
    val shouldSilence: Boolean,
    val skipNotification: Boolean,
    val reasons: List<String>
)

data class ScreenedCallRecord(
    val id: String = UUID.randomUUID().toString(),
    val rawNumber: String,
    val normalizedNumber: String,
    val callerDisplayName: String = "",
    val verdict: CallRiskVerdict,
    val riskScore: Int,
    val reasons: List<String>,
    val timestamp: Long = System.currentTimeMillis(),
    val isMissedOrRejected: Boolean = false,
    val summary: String = ""
)

data class FollowUpDispatchResult(
    val success: Boolean,
    val approvalDenied: Boolean = false,
    val channel: CallFollowUpChannel,
    val draftedMessage: String,
    val message: String
)

/**
 * Module 08: Autonomous Calling & Call Screening Engine.
 *
 * **Android Platform Limitation (Voice Uplink Restriction):**
 * Android's Telecom and AudioPolicy frameworks restrict `VOICE_UPLINK` audio injection to
 * privileged system/carrier apps. Third-party apps CANNOT inject TTS/synthesized voice audio
 * directly into an active cellular uplink call stream on non-rooted Android devices.
 *
 * Therefore, [CallingEngine] implements fully compliant Android capabilities:
 * 1. API 29+ incoming call screening via [com.example.service.MuskanCallScreeningService]
 *    (`android.permission.BIND_SCREENING_SERVICE`).
 * 2. Phone number normalization, local spam/scam heuristics (TRAI 140xx/160xx telemarketing,
 *    Wangiri/premium scam prefixes, STIR/SHAKEN failures, spoofed/repeated patterns), and
 *    user-managed allowlist/blocklist.
 * 3. Screened/missed call logging in memory (`StateFlow`) and Room (`user_memories` category `CALL_SCREENING`).
 * 4. Concise Hinglish/English call summaries and AI-assisted post-call SMS/WhatsApp follow-up drafts
 *    strictly gated behind [OwnerApprovalGate.requestSensitiveActionApproval].
 */
object CallingEngine {

    private const val TAG = "CallingEngine"
    private const val PREFS_NAME = "muskan_call_screening_prefs"
    private const val KEY_BLOCKLIST = "call_blocklist"
    private const val KEY_ALLOWLIST = "call_allowlist"
    private const val MAX_IN_MEMORY_RECORDS = 100
    const val MEMORY_CATEGORY_CALL_LOG = "CALL_SCREENING"

    const val PLATFORM_VOICE_UPLINK_LIMITATION =
        "Android security policy prevents third-party apps from injecting TTS audio directly into the cellular uplink call stream. Muskan handles call screening, call logging, AI summaries, and approval-gated SMS/WhatsApp follow-ups instead."

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _callHistory = MutableStateFlow<List<ScreenedCallRecord>>(emptyList())
    val callHistory: StateFlow<List<ScreenedCallRecord>> = _callHistory.asStateFlow()

    private val _blocklist = MutableStateFlow<Set<String>>(emptySet())
    val blocklist: StateFlow<Set<String>> = _blocklist.asStateFlow()

    private val _allowlist = MutableStateFlow<Set<String>>(emptySet())
    val allowlist: StateFlow<Set<String>> = _allowlist.asStateFlow()

    // High-risk Wangiri / international callback scam country prefixes
    private val suspiciousInternationalPrefixes = listOf(
        "+881", "+882", "+224", "+252", "+375", "+371", "+231", "+247"
    )

    // Known caller-ID spam/scam display keywords
    private val spamCallerNameKeywords = listOf(
        "lottery", "prize winner", "kyc urgent", "kyc update", "loan offer",
        "credit card offer", "bank blocked", "telemarketer", "spam", "scam",
        "free gift", "jackpot"
    )

    fun initialize(context: Context) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        _blocklist.value = prefs.getStringSet(KEY_BLOCKLIST, emptySet()).orEmpty().toSet()
        _allowlist.value = prefs.getStringSet(KEY_ALLOWLIST, emptySet()).orEmpty().toSet()
    }

    /**
     * Normalizes raw phone numbers (handles `tel:` URIs, spaces, hyphens, parentheses,
     * `00` international prefix, leading `0`, and Indian 10-digit mobile numbers).
     */
    fun normalizePhoneNumber(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        val strippedScheme = raw.trim().removePrefix("tel:").removePrefix("TEL:").trim()
        val hasPlus = strippedScheme.startsWith("+")
        val digitsOnly = strippedScheme.filter { it.isDigit() }
        if (digitsOnly.isEmpty()) return ""

        return when {
            hasPlus -> "+$digitsOnly"
            digitsOnly.startsWith("00") && digitsOnly.length > 6 -> "+${digitsOnly.drop(2)}"
            digitsOnly.length == 11 && digitsOnly.startsWith("0") -> "+91${digitsOnly.drop(1)}"
            digitsOnly.length == 10 && digitsOnly.first() in '6'..'9' -> "+91$digitsOnly"
            digitsOnly.length == 12 && digitsOnly.startsWith("91") -> "+$digitsOnly"
            else -> digitsOnly
        }
    }

    fun addToBlocklist(context: Context?, rawNumber: String): String {
        val normalized = normalizePhoneNumber(rawNumber)
        if (normalized.isBlank()) return ""
        _allowlist.update { it - normalized }
        _blocklist.update { it + normalized }
        persistLists(context)
        return normalized
    }

    fun removeFromBlocklist(context: Context?, rawNumber: String) {
        val normalized = normalizePhoneNumber(rawNumber)
        _blocklist.update { it - normalized }
        persistLists(context)
    }

    fun addToAllowlist(context: Context?, rawNumber: String): String {
        val normalized = normalizePhoneNumber(rawNumber)
        if (normalized.isBlank()) return ""
        _blocklist.update { it - normalized }
        _allowlist.update { it + normalized }
        persistLists(context)
        return normalized
    }

    fun removeFromAllowlist(context: Context?, rawNumber: String) {
        val normalized = normalizePhoneNumber(rawNumber)
        _allowlist.update { it - normalized }
        persistLists(context)
    }

    /**
     * Evaluates an incoming call against allowlist, blocklist, STIR/SHAKEN verification status,
     * and local Indian/global spam & scam heuristics.
     */
    fun evaluateIncomingCall(
        rawNumber: String?,
        callerDisplayName: String? = null,
        stirVerificationFailed: Boolean = false
    ): CallScreeningDecision {
        val normalized = normalizePhoneNumber(rawNumber)
        val displayLower = callerDisplayName.orEmpty().lowercase(Locale.ROOT).trim()
        val reasons = mutableListOf<String>()

        if (normalized.isNotBlank() && _allowlist.value.contains(normalized)) {
            return CallScreeningDecision(
                normalizedNumber = normalized,
                verdict = CallRiskVerdict.ALLOWLISTED,
                riskScore = 0,
                shouldReject = false,
                shouldSilence = false,
                skipNotification = false,
                reasons = listOf("Caller is on owner allowlist")
            )
        }

        if (normalized.isNotBlank() && _blocklist.value.contains(normalized)) {
            return CallScreeningDecision(
                normalizedNumber = normalized,
                verdict = CallRiskVerdict.BLOCKED_USER_LIST,
                riskScore = 100,
                shouldReject = true,
                shouldSilence = true,
                skipNotification = true,
                reasons = listOf("Caller is on owner blocklist")
            )
        }

        var score = 0
        val digitsOnly = normalized.filter { it.isDigit() }

        // 1. Withheld / empty caller ID
        if (digitsOnly.isEmpty()) {
            score += 45
            reasons.add("Hidden or withheld caller ID")
        }

        // 2. Indian TRAI 140xx telemarketing series (+91140... or 140...)
        if (digitsOnly.startsWith("140") || digitsOnly.startsWith("91140")) {
            score += 80
            reasons.add("Matches Indian 140-series telemarketing spam prefix")
        }

        // 3. Suspicious international Wangiri / premium callback prefixes
        if (suspiciousInternationalPrefixes.any { normalized.startsWith(it) }) {
            score += 75
            reasons.add("High-risk international callback/Wangiri prefix")
        }

        // 4. Spoofed / repeated / sequential fake caller numbers
        if (digitsOnly.length >= 6) {
            val tail10 = digitsOnly.takeLast(10)
            if (tail10.toSet().size <= 2 || tail10 == "1234567890" || tail10 == "0123456789") {
                score += 65
                reasons.add("Spoofed or repeated-digit caller pattern")
            }
        }

        // 5. STIR/SHAKEN carrier verification failed (API 30+)
        if (stirVerificationFailed) {
            score += 40
            reasons.add("Carrier STIR/SHAKEN caller ID verification failed")
        }

        // 6. Spam/scam keywords in caller display name
        val matchedKeyword = spamCallerNameKeywords.firstOrNull { displayLower.contains(it) }
        if (matchedKeyword != null) {
            score += 60
            reasons.add("Caller display name contains scam/spam indicator ('$matchedKeyword')")
        }

        val clampedScore = score.coerceIn(0, 100)
        val verdict = when {
            clampedScore >= 75 -> CallRiskVerdict.BLOCKED_SPAM
            clampedScore >= 40 -> CallRiskVerdict.SUSPICIOUS_SPAM
            else -> CallRiskVerdict.ALLOWED
        }

        if (reasons.isEmpty()) {
            reasons.add("No spam or scam indicators detected")
        }

        return CallScreeningDecision(
            normalizedNumber = normalized.ifBlank { "Private/Unknown" },
            verdict = verdict,
            riskScore = clampedScore,
            shouldReject = verdict == CallRiskVerdict.BLOCKED_SPAM,
            shouldSilence = verdict == CallRiskVerdict.BLOCKED_SPAM || verdict == CallRiskVerdict.SUSPICIOUS_SPAM,
            skipNotification = verdict == CallRiskVerdict.BLOCKED_SPAM,
            reasons = reasons
        )
    }

    /**
     * Logs a screened or missed call into in-memory [callHistory] and persists a concise
     * entry to Room (`user_memories`, category `CALL_SCREENING`).
     */
    fun logScreenedCall(
        context: Context?,
        rawNumber: String?,
        callerDisplayName: String? = null,
        decision: CallScreeningDecision,
        isMissedOrRejected: Boolean = decision.shouldReject
    ): ScreenedCallRecord {
        EngineRegistry.recordInvocation(99, success = true)
        val timestamp = System.currentTimeMillis()
        val label = callerDisplayName?.takeIf { it.isNotBlank() } ?: decision.normalizedNumber
        val summary = buildConciseRecordSummary(label, decision, isMissedOrRejected, timestamp)

        val record = ScreenedCallRecord(
            rawNumber = rawNumber.orEmpty(),
            normalizedNumber = decision.normalizedNumber,
            callerDisplayName = callerDisplayName.orEmpty(),
            verdict = decision.verdict,
            riskScore = decision.riskScore,
            reasons = decision.reasons,
            timestamp = timestamp,
            isMissedOrRejected = isMissedOrRejected,
            summary = summary
        )

        _callHistory.update { current ->
            (listOf(record) + current).take(MAX_IN_MEMORY_RECORDS)
        }

        if (context != null) {
            val appCtx = context.applicationContext
            ioScope.launch {
                runCatching {
                    AppDatabase.getDatabase(appCtx).userMemoryDao().insertMemory(
                        UserMemoryEntity(
                            category = MEMORY_CATEGORY_CALL_LOG,
                            title = "Call: $label [${decision.verdict.name}]",
                            detail = summary,
                            timestamp = timestamp,
                            isPinned = false
                        )
                    )
                }.onFailure { err ->
                    Log.w(TAG, "Unable to persist screened call to Room", err)
                }
            }
        }

        return record
    }

    fun generateLastCallSummary(): String {
        val latest = _callHistory.value.firstOrNull()
            ?: return "Sultan, abhi tak koi screened ya missed call log nahi hui hai."
        return "Last call summary: ${latest.summary}"
    }

    fun generateSpamReport(): String {
        val history = _callHistory.value
        if (history.isEmpty()) {
            return "Sultan, abhi tak koi spam ya suspicious call detect nahi hui hai. Blocklist mein ${_blocklist.value.size} numbers hain."
        }
        val spamCalls = history.filter {
            it.verdict == CallRiskVerdict.BLOCKED_SPAM ||
                it.verdict == CallRiskVerdict.SUSPICIOUS_SPAM ||
                it.verdict == CallRiskVerdict.BLOCKED_USER_LIST
        }
        if (spamCalls.isEmpty()) {
            return "Sultan, pichli ${history.size} screened calls mein koi spam call nahi mili."
        }
        val lines = spamCalls.take(5).mapIndexed { idx, rec ->
            "${idx + 1}. ${rec.normalizedNumber} (${rec.verdict.name}, risk ${rec.riskScore}/100) — ${rec.reasons.firstOrNull().orEmpty()}"
        }
        return "Sultan, kul ${history.size} screened calls mein se ${spamCalls.size} spam/suspicious calls detect hui hain:\n" +
            lines.joinToString("\n")
    }

    /**
     * Generates an AI-assisted polite follow-up SMS or WhatsApp message draft for a caller.
     */
    suspend fun draftCallerFollowUp(
        context: Context,
        record: ScreenedCallRecord,
        customNote: String = ""
    ): String {
        val callerLabel = record.callerDisplayName.ifBlank { record.normalizedNumber }
        val prompt = """
            You are Muskan, Sultan Mirza's personal assistant.
            Draft a brief, polite Hinglish follow-up text message (max 2 sentences) to caller '$callerLabel'
            regarding a recent call (${record.verdict.name}).
            Extra owner instruction: ${customNote.ifBlank { "I missed your call and will call back soon." }}
            Output ONLY the message text.
        """.trimIndent()

        val aiDraft = runCatching {
            DualBrainCoordinator.executeReasoning(context, prompt).responseText.trim()
        }.getOrNull()

        return if (!aiDraft.isNullOrBlank() && aiDraft.length >= 10) {
            aiDraft
        } else {
            val suffix = if (customNote.isNotBlank()) " $customNote" else " Main abhi thoda busy hoon, jaldi aapko callback karta hoon."
            "Namaste, aapki call miss ho gayi thi.$suffix — Sultan Mirza"
        }
    }

    /**
     * Sends an AI-assisted caller follow-up via SMS or WhatsApp ONLY after explicit owner approval
     * through [OwnerApprovalGate.requestSensitiveActionApproval].
     */
    suspend fun sendApprovedCallerFollowUp(
        context: Context,
        phoneNumber: String,
        message: String,
        channel: CallFollowUpChannel = CallFollowUpChannel.SMS
    ): FollowUpDispatchResult = withContext(Dispatchers.IO) {
        val normalized = normalizePhoneNumber(phoneNumber).ifBlank { phoneNumber.trim() }
        val actionType = when (channel) {
            CallFollowUpChannel.SMS -> SensitiveActionType.SEND_SMS
            CallFollowUpChannel.WHATSAPP -> SensitiveActionType.WHATSAPP_SEND
        }

        val approved = OwnerApprovalGate.requestSensitiveActionApproval(
            actionType = actionType,
            recipient = normalized,
            summary = "Sultan, '$normalized' ko ${channel.name} follow-up bhejne ke liye aapki explicit approval chahiye.",
            payloadPreview = message,
            technicalDetails = "CallingEngine follow-up via ${channel.name} to '$normalized'."
        )
        if (!approved) {
            return@withContext FollowUpDispatchResult(
                success = false,
                approvalDenied = true,
                channel = channel,
                draftedMessage = message,
                message = "Approval denied: Caller follow-up (${channel.name}) to '$normalized' was cancelled."
            )
        }

        val intent = when (channel) {
            CallFollowUpChannel.SMS -> Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$normalized")).apply {
                putExtra("sms_body", message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            CallFollowUpChannel.WHATSAPP -> {
                val waDigits = normalized.filter { it.isDigit() }
                val url = "https://api.whatsapp.com/send?phone=$waDigits&text=${Uri.encode(message)}"
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
        }

        return@withContext try {
            context.startActivity(intent)
            EngineRegistry.recordInvocation(99, success = true)
            FollowUpDispatchResult(
                success = true,
                approvalDenied = false,
                channel = channel,
                draftedMessage = message,
                message = "Sultan, '$normalized' ke liye approved ${channel.name} follow-up compose kar diya gaya hai."
            )
        } catch (e: Exception) {
            Log.e(TAG, "Follow-up dispatch failed", e)
            FollowUpDispatchResult(
                success = false,
                approvalDenied = false,
                channel = channel,
                draftedMessage = message,
                message = "${channel.name} app open nahi ho payi: ${e.localizedMessage ?: "App unavailable"}"
            )
        }
    }

    /**
     * Natural-language Hindi/Hinglish/English voice & chat handler for call screening and summaries.
     */
    suspend fun handleVoiceCallingCommand(context: Context, prompt: String): String {
        val lower = prompt.lowercase(Locale.ROOT).trim()

        // 1. Block number command (e.g., "number block karo 1409123456")
        if (lower.contains("block") && (lower.contains("number") || lower.contains("caller") || Regex("""\d{6,}""").containsMatchIn(lower))) {
            val numMatch = Regex("""\+?\d[\d\s\-]{5,}""").find(prompt)?.value
            if (!numMatch.isNullOrBlank()) {
                val blocked = addToBlocklist(context, numMatch)
                return "Sultan, number '$blocked' ko call blocklist mein add kar diya gaya hai."
            }
        }

        // 2. Spam calls check
        if (lower.contains("spam") || lower.contains("scam call") || lower.contains("blocked call") || lower.contains("स्पैम")) {
            return generateSpamReport()
        }

        // 3. Follow-up request for latest caller
        if (lower.contains("follow up") || lower.contains("followup") || lower.contains("callback message")) {
            val latest = _callHistory.value.firstOrNull()
                ?: return "Sultan, follow-up bhejne ke liye abhi koi recent screened call nahi mili."
            val draft = draftCallerFollowUp(context, latest)
            val channel = if (lower.contains("whatsapp")) CallFollowUpChannel.WHATSAPP else CallFollowUpChannel.SMS
            val res = sendApprovedCallerFollowUp(context, latest.normalizedNumber, draft, channel)
            return res.message
        }

        // 4. Default: concise last call summary
        return generateLastCallSummary()
    }

    fun resetForTest(context: Context? = null) {
        _callHistory.value = emptyList()
        _blocklist.value = emptySet()
        _allowlist.value = emptySet()
        persistLists(context)
    }

    private fun persistLists(context: Context?) {
        val appCtx = context?.applicationContext ?: return
        appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putStringSet(KEY_BLOCKLIST, _blocklist.value)
            .putStringSet(KEY_ALLOWLIST, _allowlist.value)
            .apply()
    }

    private fun buildConciseRecordSummary(
        label: String,
        decision: CallScreeningDecision,
        isMissedOrRejected: Boolean,
        timestamp: Long
    ): String {
        val timeFmt = SimpleDateFormat("dd MMM, h:mm a", Locale.US).format(Date(timestamp))
        val actionText = when (decision.verdict) {
            CallRiskVerdict.BLOCKED_SPAM -> "Auto-blocked as spam (risk ${decision.riskScore}/100)"
            CallRiskVerdict.BLOCKED_USER_LIST -> "Blocked by owner blocklist"
            CallRiskVerdict.SUSPICIOUS_SPAM -> "Silenced as suspicious spam (risk ${decision.riskScore}/100)"
            CallRiskVerdict.ALLOWLISTED -> if (isMissedOrRejected) "Missed allowlisted call" else "Allowlisted incoming call"
            CallRiskVerdict.ALLOWED -> if (isMissedOrRejected) "Missed call" else "Screened incoming call"
        }
        val reason = decision.reasons.firstOrNull().orEmpty()
        return "$label ($timeFmt): $actionText. $reason"
    }
}
