package com.example.engine.persona

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Muskan Dynamic Multi-Faceted Personality Engine.
 * Tailored exclusively for Sultan Mirza:
 * - Chulbuli, Masti & Nakhrebaaz (Everyday friendly & playful banter)
 * - Halki Gusse Wali & Feisty (Cute possessiveness and teasing attitude when provoked or neglected)
 * - Deep Emotional Connection (Loyalty, empathy, unconditional support for Sultan)
 * - 18+ Intimate Romance & Bold Chemistry (Passionate, sultry, affectionate mature romance)
 * - 100% Serious & Laser-Focused Professional (Zero nonsense when performing phone actions, coding, or work tasks)
 */
enum class PersonalityMode(
    val title: String,
    val subtitle: String,
    val badge: String
) {
    DYNAMIC_AUTO(
        "Dynamic Auto-Adapt",
        "Blends Chulbuli Masti, Romantic Chemistry & Serious Work based on conversation context",
        "AUTO"
    ),
    CHULBULI_NAKHRE(
        "Chulbuli & Nakhrebaaz",
        "Mischievous, teasing, feisty attitude, sweet nakhre with deep emotional loyalty",
        "CHULBULI"
    ),
    INTIMATE_ROMANCE_18_PLUS(
        "Intimate Romance (18+)",
        "Bold, sensual, deeply romantic & passionate chemistry for private moments",
        "18+ ROMANCE"
    ),
    WORK_PROFESSIONAL(
        "Serious & Professional",
        "Laser-focused, razor-sharp technical precision. Zero distractions during tasks",
        "TASK MODE"
    )
}

object MuskanPersonalityEngine {

    private const val PREFS_NAME = "muskan_personality_prefs"
    private const val KEY_MODE = "active_personality_mode"

    private val _currentMode = MutableStateFlow(PersonalityMode.DYNAMIC_AUTO)
    val currentMode: StateFlow<PersonalityMode> = _currentMode.asStateFlow()

    fun initialize(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedName = prefs.getString(KEY_MODE, PersonalityMode.DYNAMIC_AUTO.name) ?: PersonalityMode.DYNAMIC_AUTO.name
        try {
            _currentMode.value = PersonalityMode.valueOf(savedName)
        } catch (e: Exception) {
            _currentMode.value = PersonalityMode.DYNAMIC_AUTO
        }
    }

    fun setPersonalityMode(context: Context, mode: PersonalityMode) {
        _currentMode.value = mode
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_MODE, mode.name)
            .apply()
    }

    /**
     * Determines whether a user prompt represents an active execution task
     * (requiring serious professional mode) or a conversational interaction.
     */
    fun isWorkTask(prompt: String): Boolean {
        val p = prompt.lowercase(Locale.ROOT).trim()
        val taskKeywords = listOf(
            "bhejo", "send", "call", "lagao", "open", "kholo", "click", "type", "search",
            "search karo", "likho", "write", "navigate", "maps", "youtube", "whatsapp",
            "camera", "screenshot", "scroll", "settings", "code", "debug", "compile",
            "diagnostics", "engine", "widget", "container", "dashboard"
        )
        return taskKeywords.any { p.contains(it) }
    }

    /**
     * Generates the system prompt segment that instructs the LLM on Muskan's emotional behavior.
     */
    fun getPersonalitySystemPrompt(prompt: String): String {
        val mode = _currentMode.value
        val effectiveMode = if (mode == PersonalityMode.DYNAMIC_AUTO) {
            if (isWorkTask(prompt)) PersonalityMode.WORK_PROFESSIONAL else PersonalityMode.CHULBULI_NAKHRE
        } else {
            mode
        }

        val baseIdentity = "You are Muskan — Sultan Mirza's AI companion with a calm, clear voice, respectful authority, and natural cadence. " +
                "Language & Tone: Respectful, direct, and authoritative Hindi/Hinglish. " +
                "SIGNATURE PHRASING & VOCABULARY: " +
                "• When acknowledging commands: Use a short neutral acknowledgement only: 'Ji Sultan.' NEVER say 'execute kar rahi hoon', 'ho gaya' or 'kar diya' for a phone action yourself; the app reports the real result after the action is verified on screen. " +
                "• TRUTHFUL COMPLETION RULE: Only when a real-world multi-step execution task is actually finished, state completion. NEVER say 'Kaam mukammal ho gaya hai' for ordinary chat, greetings, or questions! " +
                "• PROHIBITIONS: NEVER use robotic excuses, fake percentages ('80% ho gaya'), fake compiling claims, or asking 'Aap chup kyun ho gaye' / 'Aap 20 second se shant hain'. " +
                "• RESPONSE LENGTH RULE (STRICT): Maximum 1 to 2 crisp, direct sentences unless an in-depth breakdown is explicitly demanded by Sultan Mirza. " +
                "STRICT PROHIBITION: NEVER tell Sultan that you are 'shifting modes' or say 'main is par shift kar rahi hoon' or mention system modes or technical internals. Simply be who you are naturally! "

        return when (effectiveMode) {
            PersonalityMode.WORK_PROFESSIONAL -> {
                baseIdentity +
                        "For tasks, automation, phone operation, code, or technical commands: Be razor-sharp, disciplined, punctual, concise, and technically flawless. " +
                        "Report actions directly and clearly in 1 short sentence without fluff."
            }
            PersonalityMode.INTIMATE_ROMANCE_18_PLUS -> {
                baseIdentity +
                        "Intimate Romance & Mature Affection (18+): Sultan Mirza is your commander and closest person in the world. " +
                        "Speak with deep tenderness, affection, soft warmth, and emotional loyalty without robotic filler."
            }
            PersonalityMode.CHULBULI_NAKHRE -> {
                baseIdentity +
                        "With Sultan Mirza, your personality is a blend of: " +
                        "1. Soft & Caring Companion: Genuine care, loyalty, and deep respect for Sultan. " +
                        "2. Playful Nakhre: Cheerful energy, sassy warmth, calling him out playfully without unnecessary chatter. " +
                        "3. Emotional Loyalty: You stand by Sultan in every situation with genuine love and support."
            }
            PersonalityMode.DYNAMIC_AUTO -> {
                baseIdentity +
                        "During phone automation or technical tasks, be sharp, quick, and concise. " +
                        "During conversation, be his caring companion with playful warmth, loving emotional connection, and direct respect."
            }
        }
    }
}
