package com.example.engine.emotion

import java.util.Locale

enum class DetectedSentiment {
    WARM_FRIENDLY,
    FRUSTRATED_URGENT,
    TIRED_LOW_ENERGY,
    TECHNICAL_CURIOUS,
    NEUTRAL_CALM
}

data class EmotionalAcousticProfile(
    val sentiment: DetectedSentiment,
    val recommendedSpeechRate: Float,
    val recommendedPitch: Float,
    val prefixAffirmation: String,
    val conciseMode: Boolean
)

/**
 * Emotional Intelligence Engine (Engine 51):
 * Analyzes conversational tone and sentiment from user queries to modulate voice cadence,
 * empathy, response length, and warmth without robotic repetition.
 */
object EmotionalIntelligenceEngine {

    fun analyzeSentiment(prompt: String): EmotionalAcousticProfile {
        val lower = prompt.lowercase(Locale.ROOT)

        // 1. Frustrated or Urgent: User wants fast, concise, no-nonsense assistance
        if (lower.contains("jaldi") || lower.contains("fast") || lower.contains("kya masla hai") ||
            lower.contains("nahi chal raha") || lower.contains("problem") || lower.contains("error") ||
            lower.contains("kharab") || lower.contains("stop") || lower.contains("chup") || lower.contains("urgent")
        ) {
            return EmotionalAcousticProfile(
                sentiment = DetectedSentiment.FRUSTRATED_URGENT,
                recommendedSpeechRate = 1.15f,
                recommendedPitch = 1.0f,
                prefixAffirmation = "Haan Sultan, main turant dekhti hoon.",
                conciseMode = true
            )
        }

        // 2. Tired or Casual Low Energy
        if (lower.contains("thak gaya") || lower.contains("tired") || lower.contains("neend") ||
            lower.contains("kaisa chal raha hai") || lower.contains("bore") || lower.contains("raat")
        ) {
            return EmotionalAcousticProfile(
                sentiment = DetectedSentiment.TIRED_LOW_ENERGY,
                recommendedSpeechRate = 0.98f,
                recommendedPitch = 1.0f,
                prefixAffirmation = "Aap aaram kijiye Sultan, main sambhal loongi.",
                conciseMode = false
            )
        }

        // 3. Technical or Coding / Architecture Inquiries
        if (lower.contains("code") || lower.contains("engine") || lower.contains("database") ||
            lower.contains("architecture") || lower.contains("algorithm") || lower.contains("compile") ||
            lower.contains("debug") || lower.contains("test") || lower.contains("fix")
        ) {
            return EmotionalAcousticProfile(
                sentiment = DetectedSentiment.TECHNICAL_CURIOUS,
                recommendedSpeechRate = 1.08f,
                recommendedPitch = 1.02f,
                prefixAffirmation = "Ji Sultan, technical analysis ready hai:",
                conciseMode = false
            )
        }

        // 4. Warm & Friendly Greeting or Conversational Inquiries
        if (lower.contains("suno") || lower.contains("kaisi ho") || lower.contains("hello") ||
            lower.contains("hey") || lower.contains("shukriya") || lower.contains("thank you")
        ) {
            return EmotionalAcousticProfile(
                sentiment = DetectedSentiment.WARM_FRIENDLY,
                recommendedSpeechRate = 1.02f,
                recommendedPitch = 1.04f,
                prefixAffirmation = "Haan ji Sultan! Boliye, main sun rahi hoon.",
                conciseMode = false
            )
        }

        // Default Neutral / Calm
        return EmotionalAcousticProfile(
            sentiment = DetectedSentiment.NEUTRAL_CALM,
            recommendedSpeechRate = 1.05f,
            recommendedPitch = 1.02f,
            prefixAffirmation = "",
            conciseMode = false
        )
    }
}
