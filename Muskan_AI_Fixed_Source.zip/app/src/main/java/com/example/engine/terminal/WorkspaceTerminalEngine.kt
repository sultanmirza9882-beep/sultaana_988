package com.example.engine.terminal

import android.content.Context
import com.example.engine.dev.ApkInspectionEngine
import com.example.engine.dev.ProjectWorkspaceManager
import com.example.engine.network.MuskanWebSocketBridge
import com.example.engine.network.WebRtcSignalingManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Live Terminal & Developer Command Engine.
 * Provides safe in-app command execution, real-time agent telemetry logging,
 * file modification inspection, and static verification diagnostics.
 */
object WorkspaceTerminalEngine {

    enum class TerminalLineType {
        COMMAND,
        SUCCESS,
        ERROR,
        AGENT_EVENT,
        TOOL_EVENT,
        INFO,
        OUTPUT
    }

    data class TerminalLine(
        val type: TerminalLineType,
        val text: String,
        val timestamp: Long = System.currentTimeMillis(),
        val id: String = UUID.randomUUID().toString()
    )

    data class TerminalSessionState(
        val lines: List<TerminalLine> = emptyList(),
        val isExecuting: Boolean = false,
        val lastExecutedCommand: String? = null,
        val activeAgent: String? = null,
        val activeTask: String? = null
    )

    private val _sessionState = MutableStateFlow(
        TerminalSessionState(
            lines = listOf(
                TerminalLine(
                    TerminalLineType.INFO,
                    "Muskan Workspace Terminal initialized. Type 'help' for available developer commands."
                )
            )
        )
    )
    val sessionState: StateFlow<TerminalSessionState> = _sessionState.asStateFlow()

    fun clear() {
        _sessionState.value = TerminalSessionState(lines = emptyList())
    }

    private fun addLine(type: TerminalLineType, text: String) {
        val line = TerminalLine(type = type, text = text)
        val updated = (_sessionState.value.lines + line).takeLast(1000)
        _sessionState.value = _sessionState.value.copy(lines = updated)
    }

    fun logAgentActivity(agent: String, action: String, details: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val line = TerminalLine(
            TerminalLineType.AGENT_EVENT,
            "[$time] [AGENT:$agent] $action: $details"
        )
        val updated = (_sessionState.value.lines + line).takeLast(1000)
        _sessionState.value = _sessionState.value.copy(
            lines = updated,
            activeAgent = agent,
            activeTask = action
        )
    }

    fun logToolEvent(toolName: String, action: String, result: String, durationMs: Long) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        addLine(
            TerminalLineType.TOOL_EVENT,
            "[$time] [TOOL:$toolName] $action -> $result (${durationMs}ms)"
        )
    }

    fun logFileChange(op: String, path: String, summary: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        addLine(
            TerminalLineType.SUCCESS,
            "[$time] [FILE:$op] $path - $summary"
        )
    }

    fun logError(source: String, error: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        addLine(
            TerminalLineType.ERROR,
            "[$time] [ERROR:$source] $error"
        )
    }

    suspend fun executeCommand(context: Context, rawCommand: String): String = withContext(Dispatchers.IO) {
        val command = rawCommand.trim()
        if (command.isBlank()) return@withContext ""

        addLine(TerminalLineType.COMMAND, "$ $command")
        _sessionState.value = _sessionState.value.copy(isExecuting = true, lastExecutedCommand = command)

        val parts = command.split("\\s+".toRegex())
        val cmd = parts[0].lowercase()
        val arg = if (parts.size > 1) command.substringAfter(parts[0]).trim() else null

        val output = try {
            when (cmd) {
                "help" -> getHelpText()
                "clear" -> {
                    clear()
                    "Terminal screen cleared."
                }
                "status" -> handleStatus(context)
                "snapshots" -> handleSnapshots(context)
                "verify" -> handleVerify(context, arg)
                "apk", "inspect-apk" -> handleInspectApk(context, arg)
                "ls", "list" -> handleList(context, arg)
                "cat", "read" -> handleCat(context, arg)
                "ws", "websocket" -> handleWebSocket(context, arg)
                "webrtc", "rtc" -> handleWebRtc(arg)
                "brain" -> handleBrain(context, arg)
                "qwen" -> handleQwen(context, arg)
                "memory" -> handleMemory(context, arg ?: "")
                "workflow" -> handleWorkflow(context, arg ?: "")
                else -> {
                    "[SECURITY] Unknown or disallowed command: '$cmd'. Untrusted shell execution is strictly disabled. Type 'help' for supported commands."
                }
            }
        } catch (e: Exception) {
            "Execution error: ${e.message}"
        }

        val type = if (output.startsWith("[SECURITY]") || output.startsWith("Execution error") || output.startsWith("Error:")) {
            TerminalLineType.ERROR
        } else {
            TerminalLineType.OUTPUT
        }

        addLine(type, output)
        _sessionState.value = _sessionState.value.copy(isExecuting = false)
        output
    }

    private fun getHelpText(): String = """
Available Muskan Developer Workspace Commands:
  help                     Show this command manual
  status                   Display project workspace size, files, and git-less repository health
  snapshots                List verified pre-modification rollback snapshots
  verify [file]            Run Muskan syntax delimiter and structural pattern audit
  apk [path]               Inspect APK bytecode (DEX), native libraries, and manifest permissions
  ls [subpath]             List files in the private workspace source directory
  cat <filepath>           Inspect contents of a workspace Kotlin/XML file
  ws [status|connect|send|disconnect]  Manage full-duplex Muskan WebSocket Bridge
  webrtc [status|join|offer|selftest|hangup]  Manage WebRTC Signaling & SDP/ICE state
  brain [status|auto|offline|online]  Manage Dual-Brain AI Architecture coordination
  qwen [status|download|pause|scan|ask <q>]  Manage Qwen3 1.7B GGUF on-device AI
  clear                    Clear terminal history
""".trimIndent()

    private fun handleStatus(context: Context): String {
        val summary = ProjectWorkspaceManager.getWorkspaceSummary(context)
        return """
Workspace Status:
  Imported: ${summary.isImported}
  Root: ${summary.projectPath}
  Files: ${summary.fileCount}
  Total Size: ${summary.totalSizeBytes / 1024} KB
  Snapshots: ${summary.snapshotCount}
  Last Modified: ${if (summary.lastModified > 0) SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(summary.lastModified)) else "Never"}
""".trimIndent()
    }

    private fun handleSnapshots(context: Context): String {
        val snapshots = ProjectWorkspaceManager.listSnapshots(context)
        if (snapshots.isEmpty()) return "No pre-modification snapshots found in private storage."
        val builder = StringBuilder("Recorded Snapshots (${snapshots.size}):\n")
        snapshots.forEachIndexed { idx, s ->
            val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(s.createdAt))
            builder.append(" [${idx + 1}] ${s.name} ($date) - ${s.fileCount} files, ${s.totalBytes / 1024} KB\n")
        }
        return builder.toString().trimEnd()
    }

    private suspend fun handleVerify(context: Context, path: String?): String {
        val root = ProjectWorkspaceManager.project(context)
        if (!root.exists() || !root.isDirectory) return "Error: No imported project workspace found. Import a source ZIP first."

        val targetFile = if (!path.isNullOrBlank()) {
            val clean = ProjectWorkspaceManager.validatePath(path)
            File(root, clean)
        } else {
            root.walkTopDown().firstOrNull { it.isFile && it.extension.lowercase() == "kt" }
        } ?: return "Error: No Kotlin file found to verify."

        val text = targetFile.readText(Charsets.UTF_8)
        val openBraces = text.count { it == '{' }
        val closeBraces = text.count { it == '}' }
        val openParens = text.count { it == '(' }
        val closeParens = text.count { it == ')' }
        val isSyntaxValid = (openBraces == closeBraces) && (openParens == closeParens)
        val hasBannedPatterns = text.contains("Runtime.getRuntime().exec") || text.contains("ProcessBuilder")
        val isSecurityValid = !hasBannedPatterns
        val isApproved = isSyntaxValid && isSecurityValid

        return """
Muskan Verification Audit: ${targetFile.name}
  Syntax Delimiter Passed: $isSyntaxValid (Braces: $openBraces/$closeBraces, Parens: $openParens/$closeParens)
  Security Pattern Passed: $isSecurityValid
  Approved: $isApproved
  Diagnostics:
    - ${if (isApproved) "All structural delimiters and security checks passed." else "Delimiter imbalance or security violations detected."}
""".trimIndent()
    }

    private suspend fun handleInspectApk(context: Context, path: String?): String {
        val apkFile = if (!path.isNullOrBlank()) {
            val f = File(path)
            if (f.isAbsolute && f.isFile) f else File(context.filesDir, path)
        } else {
            context.filesDir.walkTopDown().firstOrNull { it.isFile && it.extension.lowercase() == "apk" }
        } ?: return "No APK file found to inspect. Pass path to APK or upload an APK into filesDir."

        val report = ApkInspectionEngine.inspectApk(context, apkFile)
        if (!report.isSuccess) return "APK Inspection failed: ${report.message}"
        val meta = report.metadata
        val entries = report.entries
        return """
APK Inspection Report: ${apkFile.name}
  Package: ${meta?.packageName} (v${meta?.versionName}, code ${meta?.versionCode})
  DEX Files (${entries?.dexFileNames?.size ?: 0}): ${entries?.dexFileNames?.joinToString(", ")}
  Native ABIs (${entries?.nativeAbis?.size ?: 0}): ${entries?.nativeAbis?.joinToString(", ")}
  Resource Count: ${entries?.resourceEntryCount ?: 0}
  Signatures: ${entries?.signatureFiles?.joinToString(", ")}
  Permissions (${meta?.permissions?.size ?: 0}): ${meta?.permissions?.take(5)?.joinToString(", ")}${if ((meta?.permissions?.size ?: 0) > 5) "..." else ""}
  Limitations: ${report.limitations.decompilationExplanation}
""".trimIndent()
    }

    private fun handleList(context: Context, subpath: String?): String {
        val root = ProjectWorkspaceManager.project(context)
        if (!root.exists() || !root.isDirectory) return "Empty workspace (no source imported)."

        val targetDir = if (!subpath.isNullOrBlank()) {
            File(root, ProjectWorkspaceManager.validatePath(subpath))
        } else root

        if (!targetDir.exists() || !targetDir.isDirectory) return "Directory does not exist: $subpath"

        val files: List<File> = targetDir.listFiles()?.sortedBy { !it.isDirectory } ?: emptyList()
        if (files.isEmpty()) return "Directory is empty."

        return files.joinToString("\n") { f ->
            val indicator = if (f.isDirectory) "[DIR] " else "      "
            val size = if (f.isFile) " (${f.length()} B)" else ""
            "$indicator${f.name}$size"
        }
    }

    private fun handleCat(context: Context, path: String?): String {
        if (path.isNullOrBlank()) return "Usage: cat <relative_file_path>"
        val root = ProjectWorkspaceManager.project(context)
        val clean = ProjectWorkspaceManager.validatePath(path)
        val f = File(root, clean)
        if (!f.exists() || !f.isFile) return "File not found: $path"
        if (f.length() > 50_000) {
            return f.readText(Charsets.UTF_8).take(2000) + "\n... [truncated; file size: ${f.length()} bytes]"
        }
        return f.readText(Charsets.UTF_8)
    }

    private fun handleWebSocket(context: Context, arg: String?): String {
        MuskanWebSocketBridge.init(context)
        val tokens = arg?.trim()?.split("\\s+".toRegex()).orEmpty()
        val sub = tokens.firstOrNull()?.lowercase().orEmpty()
        val rest = if (tokens.size > 1) arg!!.substringAfter(tokens[0]).trim() else ""
        return when (sub) {
            "", "status" -> {
                val st = MuskanWebSocketBridge.state.value
                """
WebSocket Bridge Status:
  State: ${st.connectionState.label}
  Server URL: ${st.serverUrl}
  Device ID: ${st.deviceId}
  Messages Sent / Received: ${st.messagesSent} / ${st.messagesReceived}
  Outbound Queue: ${st.queuedCount}
  Last Ping RTT: ${st.lastPingRttMs} ms
  Last Error: ${st.lastError ?: "None"}
""".trimIndent()
            }
            "connect" -> {
                MuskanWebSocketBridge.connect(context, rest.ifBlank { null })
                "WebSocket connecting to ${MuskanWebSocketBridge.state.value.serverUrl}..."
            }
            "send" -> {
                if (rest.isBlank()) return "Usage: ws send <text_or_json>"
                val sentNow = MuskanWebSocketBridge.sendText(rest)
                if (sentNow) "WebSocket sent: $rest" else "WebSocket offline; message queued (${MuskanWebSocketBridge.state.value.queuedCount} in queue)."
            }
            "disconnect", "close" -> {
                MuskanWebSocketBridge.disconnect("Closed from Workspace Terminal")
                "WebSocket disconnected."
            }
            else -> "Usage: ws [status | connect <wss://url> | send <msg> | disconnect]"
        }
    }

    private fun handleWebRtc(arg: String?): String {
        val tokens = arg?.trim()?.split("\\s+".toRegex()).orEmpty()
        val sub = tokens.firstOrNull()?.lowercase().orEmpty()
        val rest = if (tokens.size > 1) arg!!.substringAfter(tokens[0]).trim() else ""
        return when (sub) {
            "", "status" -> {
                val st = WebRtcSignalingManager.status.value
                """
WebRTC Signaling Status:
  Signaling State: ${st.signalingState.label}
  Room ID: ${st.roomId.ifBlank { "(none)" }}
  Local Peer ID: ${st.localPeerId}
  Remote Peer ID: ${st.remotePeerId ?: "(waiting)"}
  Local SDP: ${st.localDescription?.type ?: "none"}
  Remote SDP: ${st.remoteDescription?.type ?: "none"}
  ICE Candidates (Local / Applied Remote / Queued Early): ${st.localIceCandidatesCount} / ${st.remoteIceCandidatesAppliedCount} / ${st.pendingEarlyIceCandidatesCount}
  Media Profile: ${st.mediaSummary}
  Last Event: ${st.lastSignalEvent}
""".trimIndent()
            }
            "join" -> {
                val room = rest.ifBlank { "muskan-room-1" }
                WebRtcSignalingManager.joinRoom(room, asInitiator = true)
                "Joined WebRTC signaling room '$room'."
            }
            "offer" -> {
                val res = WebRtcSignalingManager.createAndSendOffer()
                if (res.isSuccess) "Created & dispatched SDP Offer (${res.getOrNull()?.sdp?.lines()?.size ?: 0} lines)."
                else "SDP Offer failed: ${res.exceptionOrNull()?.message}"
            }
            "selftest", "test" -> {
                WebRtcSignalingManager.runLoopbackSelfTest(rest.ifBlank { "muskan-test-room" })
            }
            "hangup", "close" -> {
                WebRtcSignalingManager.closeSession("Hung up from Workspace Terminal")
                "WebRTC signaling session closed."
            }
            else -> "Usage: webrtc [status | join <roomId> | offer | selftest | hangup]"
        }
    }

    private fun handleBrain(context: Context, arg: String?): String {
        val sub = arg?.trim().orEmpty()
        return when {
            sub == "offline" || sub == "force-offline" -> {
                com.example.engine.brain.DualBrainCoordinator.setBrainMode(
                    context,
                    com.example.engine.brain.DualBrainCoordinator.BrainMode.FORCE_OFFLINE
                )
                "Brain switched to FORCE_OFFLINE (100% on-device local reasoning; no internet/API keys)."
            }
            sub == "auto" || sub == "hybrid" -> {
                com.example.engine.brain.DualBrainCoordinator.setBrainMode(
                    context,
                    com.example.engine.brain.DualBrainCoordinator.BrainMode.HYBRID_AUTO
                )
                "Brain switched to HYBRID_AUTO (Gemini Cloud primary with instant <300ms failover to Qwen3)."
            }
            sub == "online" -> {
                com.example.engine.brain.DualBrainCoordinator.setBrainMode(
                    context,
                    com.example.engine.brain.DualBrainCoordinator.BrainMode.ONLINE_ONLY
                )
                "Brain switched to ONLINE_ONLY (Gemini Cloud intelligence)."
            }
            else -> {
                val st = com.example.engine.brain.DualBrainCoordinator.brainState.value
                """
Dual-Brain AI Architecture Status:
  Current Mode: ${st.mode.name} (${st.activeBrainLabel})
  Internet Connectivity: ${if (st.isInternetConnected) "ONLINE (Active)" else "OFFLINE (No Connection)"}
  Gemini Cloud Key: ${if (com.example.engine.brain.DualBrainCoordinator.hasValidGeminiKey()) "CONFIGURED (AI Studio)" else "NOT CONFIGURED"}
  Offline Model Ready: ${if (st.isOfflineModelReady) "YES (Qwen3 GGUF Ready)" else "NO (Fallback SLM active)"}
  Model Filename: ${st.offlineModelName}
  Last Brain Used: ${st.lastBrainUsed?.displayName ?: "None"}
  Total Queries Handled: ${st.totalQueriesHandled}
  Auto Failover Count: ${st.failoverEventsCount}
Usage: brain [status | auto | offline | online]
""".trimIndent()
            }
        }
    }

    private suspend fun handleQwen(context: Context, arg: String?): String {
        val trimmed = arg?.trim().orEmpty()
        val tokens = trimmed.split(" ")
        val sub = tokens.firstOrNull().orEmpty()
        val rest = if (tokens.size > 1) trimmed.substringAfter(sub).trim() else ""

        return when (sub) {
            "status", "" -> {
                val s = com.example.engine.llm.QwenOfflineModelManager.state.value
                val isNative = com.example.engine.llm.LlamaCppBridge.isNativeLibraryAvailable()
                val loadedPath = com.example.engine.llm.LlamaCppBridge.getLoadedModelPath()
                """
Qwen3 1.7B On-Device Model Status:
  Model: ${s.modelName} (~1.28 GB Q4_K_M)
  Hardware Target: ${s.targetHardwareProfile}
  License: ${s.licenseName}
  Downloaded: ${s.isDownloaded} (${s.downloadedBytes / (1024 * 1024)} MB / ${s.totalBytes / (1024 * 1024)} MB)
  Local Path: ${s.localFilePath ?: "(none)"}
  Native JNI Engine: ${if (isNative) "Loaded (libmuskan_llama_jni.so)" else "Fallback Verifier"}
  Model In-Memory: ${if (loadedPath != null) "LOADED" else "UNLOADED"}
  Thinking Mode (/think): ${s.isThinkingModeEnabled}
  Force Offline Brain: ${s.isForceOfflineBrain}
  Status: ${s.statusMessage}
Usage: qwen [status | download | pause | scan | ask <prompt>]
""".trimIndent()
            }
            "download" -> {
                com.example.engine.llm.QwenOfflineModelManager.startOrResumeDownload(context)
                "Started/resumed Qwen3 1.7B GGUF download from official HuggingFace repository."
            }
            "pause" -> {
                com.example.engine.llm.QwenOfflineModelManager.pauseDownload()
                "Paused Qwen3 GGUF model download."
            }
            "scan" -> {
                val found = com.example.engine.llm.QwenOfflineModelManager.scanLocalStorageForGguf(context)
                if (found != null) "Found valid GGUF model: ${found.name} (${found.length() / (1024 * 1024)} MB)"
                else "No existing GGUF models found in app-private storage. Import a .gguf file via Storage Access Framework (SAF) or run 'qwen download'."
            }
            "ask" -> {
                if (rest.isBlank()) return "Usage: qwen ask <your prompt>"
                val res = com.example.engine.llm.LocalOfflineSmallLlmEngine.processOfflineInference(context, rest)
                """
[Qwen3 / Local SLM Reply]
Response: ${res.responseSpeech}
Intent: ${res.intentType.name}
Action: ${res.actionExecuted ?: "Direct Reasoning"}
""".trimIndent()
            }
            else -> "Usage: qwen [status | download | pause | scan | ask <prompt>]"
        }
    }

    private suspend fun handleMemory(context: Context, arg: String): String {
        val parts = arg.trim().split(" ", limit = 2)
        val sub = parts.firstOrNull()?.lowercase(Locale.ROOT) ?: ""
        val rest = if (parts.size > 1) parts[1].trim() else ""
        val db = com.example.data.local.AppDatabase.getDatabase(context)

        return when (sub) {
            "list", "status", "" -> {
                val memories = db.userMemoryDao().getAllMemories()
                if (memories.isEmpty()) {
                    "No permanent memories found in Room SQLite."
                } else {
                    buildString {
                        appendLine("Permanent Memories (${memories.size} total):")
                        memories.forEachIndexed { i, m ->
                            appendLine("  ${i + 1}. [${m.category}] ${m.title}: ${m.detail}")
                        }
                    }.trimEnd()
                }
            }
            "clear" -> {
                db.userMemoryDao().clearAllMemories()
                "All user memories cleared from Room SQLite."
            }
            else -> "Usage: memory [list | clear]"
        }
    }

    private suspend fun handleWorkflow(context: Context, arg: String): String {
        val parts = arg.trim().split(" ", limit = 2)
        val sub = parts.firstOrNull()?.lowercase(Locale.ROOT) ?: ""
        val rest = if (parts.size > 1) parts[1].trim() else ""
        val db = com.example.data.local.AppDatabase.getDatabase(context)

        return when (sub) {
            "list", "status", "" -> {
                com.example.engine.workflow.TaughtWorkflowEngine.ensureDefaultWorkflowsSeeded(context)
                val workflows = db.taughtWorkflowDao().getAllWorkflows()
                buildString {
                    appendLine("Taught Workflows & Routines (${workflows.size} total):")
                    workflows.forEachIndexed { i, wf ->
                        appendLine("  ${i + 1}. '${wf.title}' (Trigger: '${wf.triggerPhrase}') [Enabled: ${wf.isEnabled}, Executed: ${wf.executionCount}x]")
                    }
                }.trimEnd()
            }
            "seed" -> {
                com.example.engine.workflow.TaughtWorkflowEngine.ensureDefaultWorkflowsSeeded(context)
                "Seeded default workflows (Good Morning, Night Routine, Focus Mode)."
            }
            "run" -> {
                if (rest.isBlank()) return "Usage: workflow run <trigger or title>"
                val match = com.example.engine.workflow.TaughtWorkflowEngine.findMatchingWorkflow(context, rest)
                if (match != null) {
                    com.example.engine.workflow.TaughtWorkflowEngine.executeWorkflow(context, match)
                    "Started executing workflow '${match.title}'."
                } else {
                    "No matching workflow found for '$rest'."
                }
            }
            else -> "Usage: workflow [list | seed | run <trigger>]"
        }
    }
}

