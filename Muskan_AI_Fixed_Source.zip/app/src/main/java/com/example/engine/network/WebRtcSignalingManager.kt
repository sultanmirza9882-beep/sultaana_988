package com.example.engine.network

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import java.util.UUID

/**
 * JSEP / RFC 8829 compliant WebRTC Signaling States.
 */
enum class RtcSignalingState(val label: String) {
    IDLE("IDLE"),
    JOINING_ROOM("JOINING_ROOM"),
    WAITING_FOR_PEER("WAITING_FOR_PEER"),
    HAVE_LOCAL_OFFER("HAVE_LOCAL_OFFER"),
    HAVE_REMOTE_OFFER("HAVE_REMOTE_OFFER"),
    STABLE("STABLE (CONNECTED)"),
    CLOSED("CLOSED"),
    ERROR("ERROR")
}

data class RtcSdpPayload(
    val type: String, // "offer" | "answer" | "pranswer" | "rollback"
    val sdp: String
) {
    fun isValid(): Boolean {
        val normalizedType = type.lowercase()
        return normalizedType in setOf("offer", "answer", "pranswer", "rollback") &&
                sdp.contains("v=0") &&
                (sdp.contains("m=audio") || sdp.contains("m=video") || sdp.contains("m=application"))
    }
}

data class RtcIceCandidatePayload(
    val sdpMid: String,
    val sdpMLineIndex: Int,
    val candidate: String,
    val usernameFragment: String? = null
) {
    val candidateType: String
        get() {
            val tokens = candidate.split(" ")
            val typIdx = tokens.indexOf("typ")
            return if (typIdx >= 0 && typIdx + 1 < tokens.size) tokens[typIdx + 1] else "unknown"
        }

    fun toJson(): JSONObject = JSONObject()
        .put("sdpMid", sdpMid)
        .put("sdpMLineIndex", sdpMLineIndex)
        .put("candidate", candidate)
        .apply { if (!usernameFragment.isNullOrBlank()) put("usernameFragment", usernameFragment) }
}

data class RtcIceServerConfig(
    val urls: List<String>,
    val username: String? = null,
    val credential: String? = null
)

data class WebRtcSessionStatus(
    val signalingState: RtcSignalingState = RtcSignalingState.IDLE,
    val roomId: String = "",
    val localPeerId: String = "muskan-peer-${UUID.randomUUID().toString().take(6)}",
    val remotePeerId: String? = null,
    val isInitiator: Boolean = false,
    val localDescription: RtcSdpPayload? = null,
    val remoteDescription: RtcSdpPayload? = null,
    val localIceCandidatesCount: Int = 0,
    val remoteIceCandidatesAppliedCount: Int = 0,
    val pendingEarlyIceCandidatesCount: Int = 0,
    val iceServers: List<RtcIceServerConfig> = defaultIceServers(),
    val mediaSummary: String = "Audio (Opus) + ScreenVideo (VP8/H264) + DataChannel (muskan-control-dc)",
    val lastSignalEvent: String = "No signaling activity yet.",
    val lastError: String? = null,
    val isNativePeerConnectionBound: Boolean = false
)

fun defaultIceServers(): List<RtcIceServerConfig> = listOf(
    RtcIceServerConfig(
        urls = listOf(
            "stun:stun.l.google.com:19302",
            "stun:stun1.l.google.com:19302",
            "stun:stun2.l.google.com:19302"
        )
    )
)

/**
 * WebRTC Signaling Manager for Muskan AI Agent (Redmi 13 5G).
 *
 * Implements:
 * 1. RFC 8829 (JSEP) Offer / Answer / Glare-Resolution state machine.
 * 2. Early Trickle-ICE Candidate Queue (`pendingRemoteCandidates`) that buffers incoming ICE
 *    candidates arriving before `remoteDescription` is set and flushes them automatically once ready.
 * 3. Dual Signaling Transports:
 *    - Real-time WebSocket signaling via `MuskanWebSocketBridge` (`{"type":"webrtc_signal", ...}`)
 *    - Serverless Cloud Firestore signaling (`users/{userId}/rtc_rooms/{roomId}`)
 * 4. Built-in RFC 4566 SDP Offer/Answer & ICE candidate synthesizer for diagnostics and loopback verification.
 */
object WebRtcSignalingManager {

    private val pendingRemoteCandidates = mutableListOf<RtcIceCandidatePayload>()
    private val appliedRemoteCandidates = mutableListOf<RtcIceCandidatePayload>()
    private val localCandidates = mutableListOf<RtcIceCandidatePayload>()

    private val _status = MutableStateFlow(WebRtcSessionStatus())
    val status: StateFlow<WebRtcSessionStatus> = _status.asStateFlow()

    /** External listener for native PeerConnection binding (if attached). */
    var onRemoteDescriptionReady: ((RtcSdpPayload) -> Unit)? = null
    var onRemoteIceCandidateReady: ((RtcIceCandidatePayload) -> Unit)? = null

    fun addTurnServer(url: String, username: String, credential: String) {
        val entry = RtcIceServerConfig(urls = listOf(url.trim()), username = username.trim(), credential = credential)
        _status.update { current ->
            current.copy(
                iceServers = current.iceServers + entry,
                lastSignalEvent = "Added TURN server: $url"
            )
        }
    }

    /**
     * Joins a signaling room over WebSocket (and optionally Firestore) and prepares state machine.
     */
    fun joinRoom(roomId: String, asInitiator: Boolean = true) {
        val cleanRoom = roomId.trim().ifBlank { "muskan-room-1" }
        synchronized(this) {
            pendingRemoteCandidates.clear()
            appliedRemoteCandidates.clear()
            localCandidates.clear()
        }
        _status.update {
            it.copy(
                signalingState = RtcSignalingState.WAITING_FOR_PEER,
                roomId = cleanRoom,
                remotePeerId = null,
                isInitiator = asInitiator,
                localDescription = null,
                remoteDescription = null,
                localIceCandidatesCount = 0,
                remoteIceCandidatesAppliedCount = 0,
                pendingEarlyIceCandidatesCount = 0,
                lastSignalEvent = "Joined room '$cleanRoom' (${if (asInitiator) "Caller/Initiator" else "Callee/Responder"})",
                lastError = null
            )
        }

        val joinEnvelope = buildSignalEnvelope(
            signalType = "peer_join",
            payload = JSONObject().put("role", if (asInitiator) "initiator" else "responder")
        )
        MuskanWebSocketBridge.sendRawJson(joinEnvelope)
    }

    /**
     * Creates and dispatches a local SDP Offer, transitioning state to HAVE_LOCAL_OFFER.
     */
    fun createAndSendOffer(customSdp: String? = null): Result<RtcSdpPayload> {
        val current = _status.value
        if (current.roomId.isBlank()) {
            joinRoom("muskan-room-1", asInitiator = true)
        }
        val sdpText = customSdp ?: createStandardSdp(isOffer = true, peerId = _status.value.localPeerId)
        val offer = RtcSdpPayload(type = "offer", sdp = sdpText)
        if (!offer.isValid()) {
            val err = "Invalid SDP Offer format (missing v=0 or media line)"
            _status.update { it.copy(signalingState = RtcSignalingState.ERROR, lastError = err) }
            return Result.failure(IllegalArgumentException(err))
        }

        _status.update {
            it.copy(
                signalingState = RtcSignalingState.HAVE_LOCAL_OFFER,
                isInitiator = true,
                localDescription = offer,
                lastSignalEvent = "Local SDP Offer created & sent (${sdpText.lines().size} lines)",
                lastError = null
            )
        }

        val payload = JSONObject()
            .put("sdpType", offer.type)
            .put("sdp", offer.sdp)
        MuskanWebSocketBridge.sendRawJson(buildSignalEnvelope("offer", payload))
        return Result.success(offer)
    }

    /**
     * Creates and dispatches a local SDP Answer after receiving a remote Offer, transitioning to STABLE.
     */
    fun createAndSendAnswer(customSdp: String? = null): Result<RtcSdpPayload> {
        val current = _status.value
        if (current.signalingState != RtcSignalingState.HAVE_REMOTE_OFFER) {
            val err = "Cannot create Answer in state ${current.signalingState}; expected HAVE_REMOTE_OFFER"
            _status.update { it.copy(lastError = err) }
            return Result.failure(IllegalStateException(err))
        }
        val sdpText = customSdp ?: createStandardSdp(isOffer = false, peerId = current.localPeerId)
        val answer = RtcSdpPayload(type = "answer", sdp = sdpText)
        if (!answer.isValid()) {
            val err = "Invalid SDP Answer format"
            _status.update { it.copy(signalingState = RtcSignalingState.ERROR, lastError = err) }
            return Result.failure(IllegalArgumentException(err))
        }

        _status.update {
            it.copy(
                signalingState = RtcSignalingState.STABLE,
                localDescription = answer,
                lastSignalEvent = "Local SDP Answer created & sent -> Session STABLE",
                lastError = null
            )
        }

        val payload = JSONObject()
            .put("sdpType", answer.type)
            .put("sdp", answer.sdp)
        MuskanWebSocketBridge.sendRawJson(buildSignalEnvelope("answer", payload))
        drainEarlyIceCandidates()
        return Result.success(answer)
    }

    /**
     * Sends a local Trickle-ICE candidate to the remote peer.
     */
    fun sendLocalIceCandidate(
        sdpMid: String = "0",
        sdpMLineIndex: Int = 0,
        candidate: String = "candidate:1 1 UDP 2122252543 192.168.1.10 54321 typ host"
    ): RtcIceCandidatePayload {
        val ice = RtcIceCandidatePayload(sdpMid = sdpMid, sdpMLineIndex = sdpMLineIndex, candidate = candidate)
        synchronized(this) {
            localCandidates.add(ice)
        }
        _status.update {
            it.copy(
                localIceCandidatesCount = localCandidates.size,
                lastSignalEvent = "Sent local ICE candidate (${ice.candidateType})"
            )
        }
        MuskanWebSocketBridge.sendRawJson(buildSignalEnvelope("ice_candidate", ice.toJson()))
        return ice
    }

    /**
     * Handles an incoming `webrtc_signal` JSON envelope from WebSocket or Firestore.
     */
    fun onSignalEnvelopeReceived(envelope: JSONObject) {
        val signalType = envelope.optString("signalType").ifBlank { envelope.optString("subType") }.lowercase()
        val senderId = envelope.optString("senderId", "remote-peer")
        val roomId = envelope.optString("roomId", _status.value.roomId.ifBlank { "muskan-room-1" })
        val payload = envelope.optJSONObject("payload") ?: envelope

        if (_status.value.roomId.isBlank()) {
            _status.update { it.copy(roomId = roomId) }
        }

        when (signalType) {
            "peer_join" -> {
                _status.update {
                    it.copy(
                        remotePeerId = senderId,
                        lastSignalEvent = "Peer '$senderId' joined room '$roomId'"
                    )
                }
            }
            "offer" -> {
                val sdp = payload.optString("sdp")
                val offer = RtcSdpPayload("offer", sdp)
                if (!offer.isValid()) {
                    _status.update { it.copy(lastError = "Rejected malformed remote SDP Offer") }
                    return
                }
                // Handle glare (simultaneous offer): lower peerId rolls back local offer
                _status.update {
                    it.copy(
                        signalingState = RtcSignalingState.HAVE_REMOTE_OFFER,
                        remotePeerId = senderId,
                        remoteDescription = offer,
                        lastSignalEvent = "Received remote SDP Offer from '$senderId'",
                        lastError = null
                    )
                }
                onRemoteDescriptionReady?.invoke(offer)
                drainEarlyIceCandidates()
            }
            "answer" -> {
                val sdp = payload.optString("sdp")
                val answer = RtcSdpPayload("answer", sdp)
                if (_status.value.signalingState != RtcSignalingState.HAVE_LOCAL_OFFER) {
                    _status.update { it.copy(lastError = "Ignored unexpected SDP Answer in state ${it.signalingState}") }
                    return
                }
                if (!answer.isValid()) {
                    _status.update { it.copy(lastError = "Rejected malformed remote SDP Answer") }
                    return
                }
                _status.update {
                    it.copy(
                        signalingState = RtcSignalingState.STABLE,
                        remotePeerId = senderId,
                        remoteDescription = answer,
                        lastSignalEvent = "Received remote SDP Answer from '$senderId' -> STABLE",
                        lastError = null
                    )
                }
                onRemoteDescriptionReady?.invoke(answer)
                drainEarlyIceCandidates()
            }
            "ice_candidate", "candidate" -> {
                val candStr = payload.optString("candidate")
                if (candStr.isBlank()) return
                val cand = RtcIceCandidatePayload(
                    sdpMid = payload.optString("sdpMid", "0"),
                    sdpMLineIndex = payload.optInt("sdpMLineIndex", 0),
                    candidate = candStr,
                    usernameFragment = payload.optString("usernameFragment").takeIf { it.isNotBlank() }
                )
                val hasRemoteDesc = _status.value.remoteDescription != null
                synchronized(this) {
                    if (hasRemoteDesc) {
                        appliedRemoteCandidates.add(cand)
                        onRemoteIceCandidateReady?.invoke(cand)
                    } else {
                        // Buffer early Trickle-ICE candidate until remote SDP arrives
                        pendingRemoteCandidates.add(cand)
                    }
                    _status.update {
                        it.copy(
                            remoteIceCandidatesAppliedCount = appliedRemoteCandidates.size,
                            pendingEarlyIceCandidatesCount = pendingRemoteCandidates.size,
                            lastSignalEvent = if (hasRemoteDesc) {
                                "Applied remote ICE candidate (${cand.candidateType})"
                            } else {
                                "Buffered early remote ICE candidate (${pendingRemoteCandidates.size} queued)"
                            }
                        )
                    }
                }
            }
            "hangup", "bye" -> {
                closeSession("Remote peer '$senderId' hung up")
            }
        }
    }

    @Synchronized
    private fun drainEarlyIceCandidates() {
        if (_status.value.remoteDescription == null) return
        while (pendingRemoteCandidates.isNotEmpty()) {
            val cand = pendingRemoteCandidates.removeAt(0)
            appliedRemoteCandidates.add(cand)
            onRemoteIceCandidateReady?.invoke(cand)
        }
        _status.update {
            it.copy(
                remoteIceCandidatesAppliedCount = appliedRemoteCandidates.size,
                pendingEarlyIceCandidatesCount = 0
            )
        }
    }

    /**
     * Publishes the current room Offer/Answer state to Cloud Firestore (`users/{userId}/rtc_rooms/{roomId}`)
     * for serverless WebRTC signaling when a direct WebSocket broker is not used.
     */
    fun syncRoomStateToFirestore(userId: String, onResult: (Boolean, String) -> Unit = { _, _ -> }) {
        val st = _status.value
        if (userId.isBlank() || st.roomId.isBlank()) {
            onResult(false, "User ID or Room ID missing for Firestore signaling sync.")
            return
        }
        try {
            val data = hashMapOf<String, Any?>(
                "userId" to userId,
                "roomId" to st.roomId,
                "localPeerId" to st.localPeerId,
                "signalingState" to st.signalingState.name,
                "offerSdp" to st.localDescription?.takeIf { it.type == "offer" }?.sdp,
                "answerSdp" to st.localDescription?.takeIf { it.type == "answer" }?.sdp,
                "updatedAt" to System.currentTimeMillis()
            )
            FirebaseFirestore.getInstance()
                .collection("users")
                .document(userId)
                .collection("rtc_rooms")
                .document(st.roomId)
                .set(data)
                .addOnSuccessListener {
                    _status.update { it.copy(lastSignalEvent = "Synced signaling room '${st.roomId}' to Firestore") }
                    onResult(true, "Synced room '${st.roomId}' to Firestore")
                }
                .addOnFailureListener { e ->
                    onResult(false, "Firestore sync error: ${e.message}")
                }
        } catch (e: Exception) {
            onResult(false, "Firestore unavailable: ${e.message}")
        }
    }

    /**
     * Runs a complete deterministic Loopback Self-Test of the WebRTC Signaling pipeline:
     * Join Room -> Buffer Early Remote ICE -> Send Offer -> Receive Remote Answer -> Flush Early ICE -> STABLE.
     */
    fun runLoopbackSelfTest(roomId: String = "muskan-test-room"): String {
        joinRoom(roomId, asInitiator = true)

        // 1. Simulate an early remote Trickle-ICE candidate arriving BEFORE the Answer
        val earlyIceEnv = JSONObject()
            .put("type", "webrtc_signal")
            .put("signalType", "ice_candidate")
            .put("roomId", roomId)
            .put("senderId", "remote-agent-peer")
            .put("payload", JSONObject()
                .put("sdpMid", "0")
                .put("sdpMLineIndex", 0)
                .put("candidate", "candidate:101 1 UDP 1686052607 203.0.113.45 51000 typ srflx"))
        onSignalEnvelopeReceived(earlyIceEnv)

        // 2. Local peer creates and sends SDP Offer
        createAndSendOffer()
        sendLocalIceCandidate()

        // 3. Simulate remote peer returning SDP Answer
        val remoteAnswerEnv = JSONObject()
            .put("type", "webrtc_signal")
            .put("signalType", "answer")
            .put("roomId", roomId)
            .put("senderId", "remote-agent-peer")
            .put("payload", JSONObject()
                .put("sdpType", "answer")
                .put("sdp", createStandardSdp(isOffer = false, peerId = "remote-agent-peer")))
        onSignalEnvelopeReceived(remoteAnswerEnv)

        val finalState = _status.value
        return "WebRTC Loopback Self-Test: ${finalState.signalingState.label} | " +
                "Room=${finalState.roomId} | LocalICE=${finalState.localIceCandidatesCount} | " +
                "RemoteICEApplied=${finalState.remoteIceCandidatesAppliedCount} | " +
                "PendingEarlyICE=${finalState.pendingEarlyIceCandidatesCount}"
    }

    fun closeSession(reason: String = "Session closed by user") {
        if (_status.value.roomId.isNotBlank()) {
            MuskanWebSocketBridge.sendRawJson(
                buildSignalEnvelope("hangup", JSONObject().put("reason", reason))
            )
        }
        synchronized(this) {
            pendingRemoteCandidates.clear()
        }
        _status.update {
            it.copy(
                signalingState = RtcSignalingState.CLOSED,
                lastSignalEvent = reason
            )
        }
    }

    private fun buildSignalEnvelope(signalType: String, payload: JSONObject): JSONObject {
        val st = _status.value
        return JSONObject()
            .put("type", "webrtc_signal")
            .put("signalType", signalType)
            .put("roomId", st.roomId.ifBlank { "muskan-room-1" })
            .put("senderId", st.localPeerId)
            .put("targetPeerId", st.remotePeerId ?: "broadcast")
            .put("payload", payload)
            .put("ts", System.currentTimeMillis())
    }

    /**
     * Generates an RFC 4566 / JSEP compliant SDP blob for Audio (Opus), Screen Video (VP8), and DataChannel.
     */
    private fun randomIceToken(length: Int): String {
        val alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        val rng = SecureRandom()
        return buildString(length) {
            repeat(length) { append(alphabet[rng.nextInt(alphabet.length)]) }
        }
    }

    private fun randomSha256Fingerprint(): String {
        val bytes = ByteArray(32)
        SecureRandom().nextBytes(bytes)
        return bytes.joinToString(":") { "%02X".format(it) }
    }

    fun createStandardSdp(isOffer: Boolean, peerId: String): String {
        val sessionId = System.currentTimeMillis()
        val setupRole = if (isOffer) "actpass" else "active"
        val iceUfrag = randomIceToken(8)
        val icePwd = randomIceToken(24)
        val fingerprint = randomSha256Fingerprint()
        return """
v=0
o=$peerId $sessionId 2 IN IP4 127.0.0.1
s=Muskan-Redmi13-5G-WebRTC
t=0 0
a=group:BUNDLE 0 1 2
a=msid-semantic: WMS muskan-stream
m=audio 9 UDP/TLS/RTP/SAVPF 111
c=IN IP4 0.0.0.0
a=rtcp:9 IN IP4 0.0.0.0
a=ice-ufrag:$iceUfrag
a=ice-pwd:$icePwd
a=fingerprint:sha-256 $fingerprint
a=setup:$setupRole
a=mid:0
a=sendrecv
a=rtpmap:111 opus/48000/2
m=video 9 UDP/TLS/RTP/SAVPF 96
c=IN IP4 0.0.0.0
a=ice-ufrag:$iceUfrag
a=ice-pwd:$icePwd
a=setup:$setupRole
a=mid:1
a=sendrecv
a=rtpmap:96 VP8/90000
m=application 9 UDP/DTLS/SCTP webrtc-datachannel
c=IN IP4 0.0.0.0
a=ice-ufrag:$iceUfrag
a=ice-pwd:$icePwd
a=setup:$setupRole
a=mid:2
a=sctp-port:5000
""".trimIndent()
    }
}
