package com.example.engine.media

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.util.Base64
import android.util.Log
import androidx.core.content.FileProvider
import com.example.engine.EngineRegistry
import com.example.engine.brain.DualBrainCoordinator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.Locale
import java.util.concurrent.TimeUnit

enum class ImageFilterPreset(val label: String) {
    NONE("Original"),
    WARM("Warm Glow"),
    COOL("Cool Cyan"),
    NOIR("Noir B&W"),
    VIVID("Vivid Pop"),
    CINEMATIC("Cinematic")
}

data class CaptionCue(
    val startMs: Long,
    val endMs: Long,
    val text: String
)

data class MediaGenerationResult(
    val success: Boolean,
    val outputFile: File? = null,
    val usedLocalFallback: Boolean = false,
    val message: String
)

data class MediaOperationResult(
    val success: Boolean,
    val outputFile: File? = null,
    val message: String
)

/**
 * Module 06: AI Image & Video Creation Studio.
 *
 * Capabilities:
 * 1. Cloud Image Generation via Gemini/Imagen REST endpoint (`x-goog-api-key` header via
 *    [DualBrainCoordinator.resolveActiveGeminiKey] / [com.example.api.KeyRotationPoolManager]),
 *    saving output PNGs to app-private `filesDir/media_studio/`.
 * 2. On-device Bitmap + Canvas + ColorMatrix editing (filters, brightness/contrast, 9:16 vertical
 *    Story/Reel framing, wrapped text/caption overlays).
 * 3. Native Android `MediaExtractor` + `MediaMuxer` video trimming and audio/video track muxing
 *    (zero heavy external native binaries required).
 * 4. SubRip (`.srt`) caption file generation and safe `FileProvider` `ACTION_SEND` export.
 */
object MediaStudioEngine {

    private const val TAG = "MediaStudioEngine"
    private const val STUDIO_DIR_NAME = "media_studio"
    private const val IMAGEN_ENDPOINT =
        "https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-002:predict"
    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    private const val MUXER_BUFFER_BYTES = 1024 * 1024 // 1 MB sample buffer

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    fun getStudioDirectory(context: Context): File {
        return File(context.applicationContext.filesDir, STUDIO_DIR_NAME).apply {
            if (!exists()) mkdirs()
        }
    }

    /**
     * Extracts the first Base64-encoded image from an Imagen `:predict` JSON response.
     */
    fun extractImagenBase64Image(json: String): String? {
        if (json.isBlank()) return null
        return runCatching {
            val root = JSONObject(json)
            val predictions = root.optJSONArray("predictions") ?: return null
            if (predictions.length() == 0) return null
            val first = predictions.optJSONObject(0) ?: return null
            first.optString("bytesBase64Encoded").takeIf { it.isNotBlank() }
                ?: first.optString("imageBytes").takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    /**
     * Generates an AI image via the Imagen REST endpoint using `x-goog-api-key` header
     * (never query string) and saves it to `filesDir/media_studio/`.
     * Falls back to an on-device stylized visual card if offline or no API key is configured.
     */
    suspend fun generateCloudImage(
        context: Context,
        prompt: String,
        aspectRatio: String = "1:1"
    ): MediaGenerationResult = withContext(Dispatchers.IO) {
        EngineRegistry.recordInvocation(101, success = true)
        val cleanPrompt = prompt.trim().ifBlank { "Futuristic neon cityscape at twilight" }
        val validRatio = if (aspectRatio in setOf("1:1", "9:16", "16:9", "4:3", "3:4")) aspectRatio else "1:1"
        val apiKey = DualBrainCoordinator.resolveActiveGeminiKey()

        if (apiKey.isBlank()) {
            val fallback = composeVerticalStoryCard(
                context = context,
                sourceBitmap = null,
                headline = cleanPrompt.take(80),
                subtitle = "Created locally by Muskan Media Studio (Add Gemini API key for Imagen cloud generation)",
                filter = ImageFilterPreset.CINEMATIC
            )
            return@withContext MediaGenerationResult(
                success = true,
                outputFile = fallback,
                usedLocalFallback = true,
                message = "Gemini API key configured nahi hai, isliye on-device visual card '${fallback.name}' bana kar save kar diya gaya hai."
            )
        }

        val payload = JSONObject().apply {
            put("instances", JSONArray().put(JSONObject().put("prompt", cleanPrompt)))
            put(
                "parameters",
                JSONObject().apply {
                    put("sampleCount", 1)
                    put("aspectRatio", validRatio)
                }
            )
        }.toString()

        val req = Request.Builder()
            .url(IMAGEN_ENDPOINT)
            .header("x-goog-api-key", apiKey)
            .header("Content-Type", "application/json")
            .post(payload.toRequestBody(JSON_MEDIA_TYPE))
            .build()

        return@withContext runCatching {
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException("Imagen REST HTTP ${resp.code}")
                }
                val rawJson = resp.body?.string().orEmpty()
                val b64 = extractImagenBase64Image(rawJson)
                    ?: throw IllegalStateException("Imagen response missing image bytes")
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                val outFile = File(getStudioDirectory(context), "imagen_${System.currentTimeMillis()}.png")
                FileOutputStream(outFile).use { it.write(bytes) }
                MediaGenerationResult(
                    success = true,
                    outputFile = outFile,
                    usedLocalFallback = false,
                    message = "Sultan, Imagen AI image generate hokar '${outFile.name}' mein save ho gayi hai."
                )
            }
        }.getOrElse { err ->
            Log.w(TAG, "Cloud Imagen failed; falling back to on-device Canvas poster", err)
            val fallback = composeVerticalStoryCard(
                context = context,
                sourceBitmap = null,
                headline = cleanPrompt.take(80),
                subtitle = "Offline/Fallback Visual • Muskan Studio",
                filter = ImageFilterPreset.CINEMATIC
            )
            MediaGenerationResult(
                success = true,
                outputFile = fallback,
                usedLocalFallback = true,
                message = "Cloud Imagen abhi unavailable hai (${err.localizedMessage?.take(45) ?: "error"}), isliye on-device card '${fallback.name}' save kar diya gaya hai."
            )
        }
    }

    /**
     * Applies native Android [ColorMatrix] filters, brightness (`-100..100`), and contrast (`0.5..2.0`)
     * to a source [Bitmap] and returns a new edited [Bitmap].
     */
    fun composeFilteredBitmap(
        source: Bitmap,
        filter: ImageFilterPreset = ImageFilterPreset.NONE,
        brightness: Float = 0f,
        contrast: Float = 1f
    ): Bitmap {
        val safeContrast = contrast.coerceIn(0.4f, 2.2f)
        val safeBrightness = brightness.coerceIn(-120f, 120f)
        val translate = (-0.5f * safeContrast + 0.5f) * 255f + safeBrightness

        val resultMatrix = ColorMatrix(
            floatArrayOf(
                safeContrast, 0f, 0f, 0f, translate,
                0f, safeContrast, 0f, 0f, translate,
                0f, 0f, safeContrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )

        val presetMatrix = when (filter) {
            ImageFilterPreset.NONE -> ColorMatrix()
            ImageFilterPreset.NOIR -> ColorMatrix().apply { setSaturation(0f) }
            ImageFilterPreset.VIVID -> ColorMatrix().apply { setSaturation(1.45f) }
            ImageFilterPreset.WARM -> ColorMatrix(
                floatArrayOf(
                    1.12f, 0f, 0f, 0f, 12f,
                    0f, 1.03f, 0f, 0f, 4f,
                    0f, 0f, 0.90f, 0f, -8f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            ImageFilterPreset.COOL -> ColorMatrix(
                floatArrayOf(
                    0.92f, 0f, 0f, 0f, -6f,
                    0f, 1.02f, 0f, 0f, 4f,
                    0f, 0f, 1.15f, 0f, 14f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            ImageFilterPreset.CINEMATIC -> ColorMatrix(
                floatArrayOf(
                    1.08f, 0f, 0f, 0f, -8f,
                    0f, 1.02f, 0f, 0f, -4f,
                    0f, 0f, 1.12f, 0f, 8f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        }
        resultMatrix.postConcat(presetMatrix)

        val out = Bitmap.createBitmap(
            source.width.coerceAtLeast(1),
            source.height.coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(resultMatrix)
        }
        canvas.drawBitmap(source, 0f, 0f, paint)
        return out
    }

    /**
     * Composes a 9:16 vertical Story/Reel image using native Android [Bitmap] + [Canvas]
     * with optional source photo framing, filter preset, gradient scrim, and wrapped caption text.
     */
    fun composeVerticalStoryCard(
        context: Context,
        sourceBitmap: Bitmap? = null,
        headline: String,
        subtitle: String = "",
        filter: ImageFilterPreset = ImageFilterPreset.CINEMATIC,
        brightness: Float = 0f,
        contrast: Float = 1f,
        width: Int = 1080,
        height: Int = 1920
    ): File {
        EngineRegistry.recordInvocation(101, success = true)
        val safeW = width.coerceIn(180, 2160)
        val safeH = height.coerceIn(320, 3840)
        val outputBitmap = Bitmap.createBitmap(safeW, safeH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outputBitmap)

        if (sourceBitmap != null && !sourceBitmap.isRecycled) {
            val filtered = composeFilteredBitmap(sourceBitmap, filter, brightness, contrast)
            val srcAspect = filtered.width.toFloat() / filtered.height.coerceAtLeast(1).toFloat()
            val dstAspect = safeW.toFloat() / safeH.toFloat()
            val srcRect = if (srcAspect > dstAspect) {
                val targetW = (filtered.height * dstAspect).toInt().coerceAtLeast(1)
                val left = ((filtered.width - targetW) / 2).coerceAtLeast(0)
                Rect(left, 0, (left + targetW).coerceAtMost(filtered.width), filtered.height)
            } else {
                val targetH = (filtered.width / dstAspect).toInt().coerceAtLeast(1)
                val top = ((filtered.height - targetH) / 2).coerceAtLeast(0)
                Rect(0, top, filtered.width, (top + targetH).coerceAtMost(filtered.height))
            }
            canvas.drawBitmap(filtered, srcRect, Rect(0, 0, safeW, safeH), Paint(Paint.FILTER_BITMAP_FLAG))
            if (filtered !== sourceBitmap) filtered.recycle()
        } else {
            val bgPaint = Paint().apply {
                shader = LinearGradient(
                    0f, 0f, safeW.toFloat(), safeH.toFloat(),
                    intArrayOf(Color.rgb(12, 18, 42), Color.rgb(34, 18, 68), Color.rgb(8, 48, 72)),
                    null,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, safeW.toFloat(), safeH.toFloat(), bgPaint)
        }

        // Bottom readability scrim
        val scrimPaint = Paint().apply {
            shader = LinearGradient(
                0f, safeH * 0.45f, 0f, safeH.toFloat(),
                Color.TRANSPARENT, Color.argb(215, 6, 10, 20),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, safeH * 0.45f, safeW.toFloat(), safeH.toFloat(), scrimPaint)

        // Accent bar
        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(56, 189, 248)
        }
        val marginX = safeW * 0.08f
        canvas.drawRect(marginX, safeH * 0.62f, marginX + safeW * 0.16f, safeH * 0.62f + safeH * 0.005f, accentPaint)

        // Headline text (wrapped)
        val headlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = safeW * 0.068f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val maxTextWidth = safeW - marginX * 2f
        val headlineLines = wrapText(headline.trim().ifBlank { "Muskan Studio" }, headlinePaint, maxTextWidth).take(4)
        var cursorY = safeH * 0.68f
        val lineStep = headlinePaint.textSize * 1.28f
        for (line in headlineLines) {
            canvas.drawText(line, marginX, cursorY, headlinePaint)
            cursorY += lineStep
        }

        // Subtitle text
        if (subtitle.isNotBlank()) {
            val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(203, 213, 225)
                textSize = safeW * 0.036f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            }
            cursorY += safeH * 0.015f
            val subLines = wrapText(subtitle.trim(), subPaint, maxTextWidth).take(3)
            for (line in subLines) {
                canvas.drawText(line, marginX, cursorY, subPaint)
                cursorY += subPaint.textSize * 1.35f
            }
        }

        val outFile = File(getStudioDirectory(context), "story_${System.currentTimeMillis()}.png")
        FileOutputStream(outFile).use { fos ->
            outputBitmap.compress(Bitmap.CompressFormat.PNG, 95, fos)
        }
        outputBitmap.recycle()
        return outFile
    }

    /**
     * Native Android [MediaExtractor] + [MediaMuxer] video trimmer (zero external binaries).
     */
    suspend fun trimVideo(
        inputPath: String,
        outputFile: File,
        startMs: Long,
        endMs: Long
    ): MediaOperationResult = withContext(Dispatchers.IO) {
        EngineRegistry.recordInvocation(101, success = true)
        val src = File(inputPath)
        if (!src.exists() || src.length() == 0L) {
            return@withContext MediaOperationResult(false, null, "Input video file does not exist: $inputPath")
        }
        if (endMs <= startMs || startMs < 0L) {
            return@withContext MediaOperationResult(false, null, "Invalid trim range: startMs=$startMs, endMs=$endMs")
        }

        outputFile.parentFile?.mkdirs()
        var extractor: MediaExtractor? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false

        return@withContext try {
            extractor = MediaExtractor().apply { setDataSource(inputPath) }
            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            val trackIndexMap = mutableMapOf<Int, Int>()
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    extractor.selectTrack(i)
                    trackIndexMap[i] = muxer.addTrack(format)
                }
            }
            if (trackIndexMap.isEmpty()) {
                return@withContext MediaOperationResult(false, null, "No audio/video tracks found in input file.")
            }

            muxer.start()
            muxerStarted = true

            val startUs = startMs * 1000L
            val endUs = endMs * 1000L
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            val buffer = ByteBuffer.allocate(MUXER_BUFFER_BYTES)
            val bufferInfo = MediaCodec.BufferInfo()

            while (true) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                val sampleTimeUs = extractor.sampleTime
                if (sampleTimeUs > endUs) break

                val srcTrack = extractor.sampleTrackIndex
                val dstTrack = trackIndexMap[srcTrack]
                if (dstTrack != null && sampleTimeUs >= startUs) {
                    bufferInfo.offset = 0
                    bufferInfo.size = sampleSize
                    bufferInfo.presentationTimeUs = (sampleTimeUs - startUs).coerceAtLeast(0L)
                    bufferInfo.flags = extractor.sampleFlags
                    muxer.writeSampleData(dstTrack, buffer, bufferInfo)
                }
                extractor.advance()
            }

            MediaOperationResult(true, outputFile, "Video trimmed cleanly (${startMs}ms..${endMs}ms) -> ${outputFile.name}")
        } catch (e: Exception) {
            Log.e(TAG, "Video trim failed", e)
            MediaOperationResult(false, null, "Video trim failed: ${e.localizedMessage ?: "Unsupported codec/container"}")
        } finally {
            runCatching { if (muxerStarted) muxer?.stop() }
            runCatching { muxer?.release() }
            runCatching { extractor?.release() }
        }
    }

    /**
     * Native Android [MediaExtractor] + [MediaMuxer] audio-over-video track muxer.
     */
    suspend fun muxVideoWithAudio(
        videoPath: String,
        audioPath: String,
        outputFile: File,
        maxDurationMs: Long? = null
    ): MediaOperationResult = withContext(Dispatchers.IO) {
        EngineRegistry.recordInvocation(101, success = true)
        if (!File(videoPath).exists() || !File(audioPath).exists()) {
            return@withContext MediaOperationResult(false, null, "Video or audio source file is missing.")
        }

        outputFile.parentFile?.mkdirs()
        var videoExtractor: MediaExtractor? = null
        var audioExtractor: MediaExtractor? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false

        return@withContext try {
            videoExtractor = MediaExtractor().apply { setDataSource(videoPath) }
            audioExtractor = MediaExtractor().apply { setDataSource(audioPath) }
            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            var srcVideoTrack = -1
            var dstVideoTrack = -1
            for (i in 0 until videoExtractor.trackCount) {
                val fmt = videoExtractor.getTrackFormat(i)
                if (fmt.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("video/")) {
                    srcVideoTrack = i
                    videoExtractor.selectTrack(i)
                    dstVideoTrack = muxer.addTrack(fmt)
                    break
                }
            }

            var srcAudioTrack = -1
            var dstAudioTrack = -1
            for (i in 0 until audioExtractor.trackCount) {
                val fmt = audioExtractor.getTrackFormat(i)
                if (fmt.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")) {
                    srcAudioTrack = i
                    audioExtractor.selectTrack(i)
                    dstAudioTrack = muxer.addTrack(fmt)
                    break
                }
            }

            if (srcVideoTrack < 0 || srcAudioTrack < 0) {
                return@withContext MediaOperationResult(false, null, "Missing video or audio track for muxing.")
            }

            muxer.start()
            muxerStarted = true

            val limitUs = maxDurationMs?.let { it * 1000L } ?: Long.MAX_VALUE
            val buffer = ByteBuffer.allocate(MUXER_BUFFER_BYTES)
            val info = MediaCodec.BufferInfo()

            // Copy video samples
            while (true) {
                val size = videoExtractor.readSampleData(buffer, 0)
                if (size < 0) break
                val pts = videoExtractor.sampleTime
                if (pts > limitUs) break
                info.offset = 0
                info.size = size
                info.presentationTimeUs = pts.coerceAtLeast(0L)
                info.flags = videoExtractor.sampleFlags
                muxer.writeSampleData(dstVideoTrack, buffer, info)
                videoExtractor.advance()
            }

            // Copy audio samples
            while (true) {
                val size = audioExtractor.readSampleData(buffer, 0)
                if (size < 0) break
                val pts = audioExtractor.sampleTime
                if (pts > limitUs) break
                info.offset = 0
                info.size = size
                info.presentationTimeUs = pts.coerceAtLeast(0L)
                info.flags = audioExtractor.sampleFlags
                muxer.writeSampleData(dstAudioTrack, buffer, info)
                audioExtractor.advance()
            }

            MediaOperationResult(true, outputFile, "Video and audio tracks muxed cleanly -> ${outputFile.name}")
        } catch (e: Exception) {
            Log.e(TAG, "Audio/video muxing failed", e)
            MediaOperationResult(false, null, "Audio/video muxing failed: ${e.localizedMessage ?: "Unsupported format"}")
        } finally {
            runCatching { if (muxerStarted) muxer?.stop() }
            runCatching { muxer?.release() }
            runCatching { videoExtractor?.release() }
            runCatching { audioExtractor?.release() }
        }
    }

    /**
     * Formats milliseconds into strict SubRip timestamp format `HH:MM:SS,mmm`.
     */
    fun formatSrtTimestamp(ms: Long): String {
        val safe = ms.coerceAtLeast(0L)
        val hours = safe / 3_600_000L
        val minutes = (safe % 3_600_000L) / 60_000L
        val seconds = (safe % 60_000L) / 1_000L
        val millis = safe % 1_000L
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
    }

    /**
     * Splits a script into timed [CaptionCue] chunks for Reels/Shorts subtitles.
     */
    fun generateAutoCaptionsFromScript(
        script: String,
        wordsPerCue: Int = 7,
        msPerWord: Long = 420L
    ): List<CaptionCue> {
        val words = script.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return emptyList()
        val chunkSize = wordsPerCue.coerceIn(2, 16)
        val wordDuration = msPerWord.coerceIn(200L, 1500L)

        val cues = mutableListOf<CaptionCue>()
        var cursorMs = 0L
        words.chunked(chunkSize).forEach { chunk ->
            val duration = (chunk.size * wordDuration).coerceAtLeast(1200L)
            cues.add(CaptionCue(startMs = cursorMs, endMs = cursorMs + duration, text = chunk.joinToString(" ")))
            cursorMs += duration
        }
        return cues
    }

    /**
     * Formats a list of [CaptionCue]s into standard `.srt` SubRip subtitle text.
     */
    fun generateSrtContent(cues: List<CaptionCue>): String {
        if (cues.isEmpty()) return ""
        return buildString {
            cues.forEachIndexed { index, cue ->
                val end = if (cue.endMs > cue.startMs) cue.endMs else cue.startMs + 1000L
                append(index + 1).append('\n')
                append(formatSrtTimestamp(cue.startMs))
                    .append(" --> ")
                    .append(formatSrtTimestamp(end))
                    .append('\n')
                append(cue.text.trim()).append("\n\n")
            }
        }
    }

    /**
     * Writes an `.srt` subtitle file into app-private `filesDir/media_studio/`.
     */
    fun writeSrtFile(
        context: Context,
        cues: List<CaptionCue>,
        baseName: String = "captions"
    ): File {
        val safeBase = baseName.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "captions" }
        val file = File(getStudioDirectory(context), "${safeBase}_${System.currentTimeMillis()}.srt")
        file.writeText(generateSrtContent(cues), Charsets.UTF_8)
        return file
    }

    /**
     * Builds a safe `ACTION_SEND` export intent using [FileProvider] (`FLAG_GRANT_READ_URI_PERMISSION`).
     */
    fun createShareIntent(
        context: Context,
        file: File,
        mimeType: String,
        captionText: String = ""
    ): Intent {
        val uri: Uri = runCatching {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }.getOrElse { Uri.fromFile(file) }

        return Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            if (captionText.isNotBlank()) {
                putExtra(Intent.EXTRA_TEXT, captionText)
            }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    /**
     * Voice/chat command handler for Module 06 Media Studio requests.
     */
    suspend fun handleVoiceMediaCommand(context: Context, prompt: String): String {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        return when {
            lower.contains("srt") || lower.contains("subtitle") || lower.contains("caption file") -> {
                val script = prompt
                    .replace(Regex("(?i)(srt|subtitle|caption file|banao|generate karo|create)"), "")
                    .trim()
                    .ifBlank { "Namaste dosto! Welcome to Sultan Mirza's Muskan AI Studio." }
                val cues = generateAutoCaptionsFromScript(script)
                val file = writeSrtFile(context, cues, "reel_captions")
                "Sultan, ${cues.size} cues ke saath .srt subtitle file '${file.name}' media_studio mein save ho gayi hai."
            }
            lower.contains("story") || lower.contains("reel") || lower.contains("poster") || lower.contains("9:16") -> {
                val headline = prompt
                    .replace(Regex("(?i)(story|reel|poster|card|banao|create|9:16|vertical)"), "")
                    .trim()
                    .ifBlank { "Muskan AI Studio" }
                val file = composeVerticalStoryCard(
                    context = context,
                    sourceBitmap = null,
                    headline = headline,
                    subtitle = "9:16 Ready • Created by Muskan",
                    filter = ImageFilterPreset.CINEMATIC
                )
                "Sultan, 9:16 vertical Story/Reel visual '${file.name}' save ho gaya hai aur share ke liye ready hai."
            }
            else -> {
                val aspect = if (lower.contains("vertical") || lower.contains("9:16")) "9:16" else "1:1"
                val result = generateCloudImage(context, prompt, aspectRatio = aspect)
                result.message
            }
        }
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return emptyList()
        val lines = mutableListOf<String>()
        var current = StringBuilder()
        for (word in words) {
            val candidate = if (current.isEmpty()) word else "$current $word"
            if (paint.measureText(candidate) <= maxWidth || current.isEmpty()) {
                current = StringBuilder(candidate)
            } else {
                lines.add(current.toString())
                current = StringBuilder(word)
            }
        }
        if (current.isNotEmpty()) lines.add(current.toString())
        return lines
    }
}
