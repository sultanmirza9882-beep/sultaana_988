package com.example.engine.email

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Base64
import android.util.Log
import com.example.engine.EngineRegistry
import com.example.engine.approval.OwnerApprovalGate
import com.example.engine.approval.SensitiveActionType
import com.example.engine.brain.DualBrainCoordinator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.TimeUnit

data class EmailMessage(
    val id: String,
    val threadId: String = "",
    val from: String,
    val to: String = "",
    val subject: String,
    val snippet: String,
    val bodyPreview: String = "",
    val date: String = "",
    val isUnread: Boolean = true
)

data class EmailDraft(
    val to: String,
    val subject: String,
    val body: String,
    val draftId: String? = null,
    val createdViaApi: Boolean = false
)

data class EmailOperationResult(
    val success: Boolean,
    val messageId: String? = null,
    val usedMailtoFallback: Boolean = false,
    val approvalDenied: Boolean = false,
    val message: String
)

/**
 * Module 05: AI Email Management Engine.
 * Supports Gmail REST API v1 (`messages.list`, `messages.get`, `drafts.create`, `messages.send`)
 * via OkHttp when an OAuth2 Bearer token is available, plus an offline/no-token `mailto:` /
 * `ACTION_SENDTO` compose fallback.
 * Uses [DualBrainCoordinator] for unread inbox summarization and professional Hindi/Hinglish/English
 * reply drafting, and gates every outbound send behind [OwnerApprovalGate].
 */
object EmailEngine {

    private const val TAG = "EmailEngine"
    private const val GMAIL_API_BASE = "https://gmail.googleapis.com/gmail/v1/users/me"
    private const val PREFS_NAME = "muskan_email_oauth_prefs"
    private const val KEY_OAUTH_ACCESS_TOKEN = "gmail_oauth_access_token"
    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    private fun securePrefs(context: Context) =
        com.example.api.SecurePreferences.openMigrating(context, PREFS_NAME)

    fun setOAuthAccessToken(context: Context, token: String?) {
        val prefs = securePrefs(context)
        if (token.isNullOrBlank()) {
            prefs.edit().remove(KEY_OAUTH_ACCESS_TOKEN).apply()
        } else {
            prefs.edit().putString(KEY_OAUTH_ACCESS_TOKEN, token.trim()).apply()
        }
    }

    fun getOAuthAccessToken(context: Context): String? {
        val prefs = securePrefs(context)
        return prefs.getString(KEY_OAUTH_ACCESS_TOKEN, null)?.takeIf { it.isNotBlank() }
    }

    /**
     * Parses message IDs from a Gmail REST API `messages.list` JSON payload.
     */
    fun parseMessageListIds(json: String): List<String> {
        if (json.isBlank()) return emptyList()
        return runCatching {
            val root = JSONObject(json)
            val messages = root.optJSONArray("messages") ?: return emptyList()
            buildList {
                for (i in 0 until messages.length()) {
                    val id = messages.optJSONObject(i)?.optString("id")?.trim().orEmpty()
                    if (id.isNotBlank()) add(id)
                }
            }
        }.getOrDefault(emptyList())
    }

    /**
     * Parses a Gmail REST API `messages.get` JSON payload into a clean [EmailMessage],
     * extracting `From`, `To`, `Subject`, `Date`, `UNREAD` label, snippet, and base64url body text.
     */
    fun parseGmailMessageJson(json: String): EmailMessage {
        val root = JSONObject(json)
        val id = root.optString("id", "")
        val threadId = root.optString("threadId", "")
        val snippet = root.optString("snippet", "").trim()

        val labelIds = root.optJSONArray("labelIds")
        var isUnread = false
        if (labelIds != null) {
            for (i in 0 until labelIds.length()) {
                if (labelIds.optString(i).equals("UNREAD", ignoreCase = true)) {
                    isUnread = true
                    break
                }
            }
        }

        val payload = root.optJSONObject("payload")
        val headers = payload?.optJSONArray("headers")
        var from = ""
        var to = ""
        var subject = ""
        var date = ""
        if (headers != null) {
            for (i in 0 until headers.length()) {
                val h = headers.optJSONObject(i) ?: continue
                when (h.optString("name").lowercase(Locale.ROOT)) {
                    "from" -> from = h.optString("value").trim()
                    "to" -> to = h.optString("value").trim()
                    "subject" -> subject = h.optString("value").trim()
                    "date" -> date = h.optString("value").trim()
                }
            }
        }

        val decodedBody = extractPlainTextBody(payload).ifBlank { snippet }
        return EmailMessage(
            id = id,
            threadId = threadId,
            from = from.ifBlank { "Unknown Sender" },
            to = to,
            subject = subject.ifBlank { "(No Subject)" },
            snippet = snippet,
            bodyPreview = decodedBody.take(600),
            date = date,
            isUnread = isUnread
        )
    }

    /**
     * Builds an RFC 2822 UTF-8 email payload encoded in URL-safe Base64 without padding,
     * as required by Gmail REST API `drafts.create` and `messages.send`.
     */
    fun buildRawMimeBase64Url(to: String, subject: String, body: String): String {
        val cleanTo = to.replace("\r", "").replace("\n", "").trim()
        val cleanSubject = subject.replace("\r", "").replace("\n", "").trim()
        val rfc2822 = buildString {
            append("To: ").append(cleanTo).append("\r\n")
            append("Subject: ").append(cleanSubject).append("\r\n")
            append("MIME-Version: 1.0\r\n")
            append("Content-Type: text/plain; charset=\"UTF-8\"\r\n")
            append("\r\n")
            append(body)
        }
        return Base64.encodeToString(
            rfc2822.toByteArray(StandardCharsets.UTF_8),
            Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
        )
    }

    /**
     * Lists unread emails using Gmail REST API v1 (`messages.list` + `messages.get`).
     * Returns an empty list if no OAuth2 Bearer token is configured or the network request fails.
     */
    suspend fun listUnreadEmails(
        context: Context,
        maxResults: Int = 5,
        accessToken: String? = null
    ): Result<List<EmailMessage>> = withContext(Dispatchers.IO) {
        EngineRegistry.recordInvocation(103, success = true)
        val token = accessToken?.takeIf { it.isNotBlank() } ?: getOAuthAccessToken(context)
            ?: return@withContext Result.failure(
                IllegalStateException("Gmail OAuth2 access token not configured.")
            )

        return@withContext runCatching {
            val clamped = maxResults.coerceIn(1, 20)
            val listUrl = "$GMAIL_API_BASE/messages?q=is:unread&maxResults=$clamped"
            val listReq = Request.Builder()
                .url(listUrl)
                .header("Authorization", "Bearer $token")
                .header("Accept", "application/json")
                .get()
                .build()

            val listBody = httpClient.newCall(listReq).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException("Gmail messages.list failed with HTTP ${resp.code}")
                }
                resp.body?.string().orEmpty()
            }

            val ids = parseMessageListIds(listBody)
            val emails = mutableListOf<EmailMessage>()
            for (id in ids) {
                getMessage(id, token).getOrNull()?.let { emails.add(it) }
            }
            emails
        }
    }

    /**
     * Fetches a single Gmail message via `GET /users/me/messages/{id}?format=full`.
     */
    suspend fun getMessage(
        messageId: String,
        accessToken: String
    ): Result<EmailMessage> = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder()
                .url("$GMAIL_API_BASE/messages/${Uri.encode(messageId)}?format=full")
                .header("Authorization", "Bearer $accessToken")
                .header("Accept", "application/json")
                .get()
                .build()

            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException("Gmail messages.get failed with HTTP ${resp.code}")
                }
                val raw = resp.body?.string().orEmpty()
                parseGmailMessageJson(raw)
            }
        }
    }

    /**
     * Creates a Gmail draft via `POST /users/me/drafts` when an OAuth2 token is available,
     * or returns a ready local [EmailDraft] when operating without a token.
     */
    suspend fun createDraft(
        context: Context,
        to: String,
        subject: String,
        body: String,
        accessToken: String? = null
    ): EmailDraft = withContext(Dispatchers.IO) {
        EngineRegistry.recordInvocation(103, success = true)
        val token = accessToken?.takeIf { it.isNotBlank() } ?: getOAuthAccessToken(context)
        if (token == null) {
            return@withContext EmailDraft(to = to, subject = subject, body = body, createdViaApi = false)
        }

        val rawMime = buildRawMimeBase64Url(to, subject, body)
        val payload = JSONObject().put("message", JSONObject().put("raw", rawMime)).toString()
        val req = Request.Builder()
            .url("$GMAIL_API_BASE/drafts")
            .header("Authorization", "Bearer $token")
            .post(payload.toRequestBody(JSON_MEDIA_TYPE))
            .build()

        return@withContext runCatching {
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    Log.w(TAG, "Gmail drafts.create returned HTTP ${resp.code}")
                    EmailDraft(to = to, subject = subject, body = body, createdViaApi = false)
                } else {
                    val draftId = JSONObject(resp.body?.string().orEmpty()).optString("id").takeIf { it.isNotBlank() }
                    EmailDraft(to = to, subject = subject, body = body, draftId = draftId, createdViaApi = true)
                }
            }
        }.getOrElse { err ->
            Log.e(TAG, "Gmail drafts.create error", err)
            EmailDraft(to = to, subject = subject, body = body, createdViaApi = false)
        }
    }

    /**
     * Sends an email ONLY after explicit owner confirmation via [OwnerApprovalGate].
     * Uses Gmail REST API `POST /users/me/messages/send` when an OAuth2 Bearer token is available,
     * or falls back cleanly to an Android `mailto:` / `ACTION_SENDTO` compose intent when offline/no-token.
     */
    suspend fun sendEmail(
        context: Context,
        to: String,
        subject: String,
        body: String,
        accessToken: String? = null
    ): EmailOperationResult = withContext(Dispatchers.IO) {
        val recipient = to.trim().ifBlank { "recipient@example.com" }
        val cleanSubject = subject.trim().ifBlank { "Message from Sultan Mirza" }

        val approved = OwnerApprovalGate.requestSensitiveActionApproval(
            actionType = SensitiveActionType.EMAIL_SEND,
            recipient = recipient,
            summary = "Sultan, '$recipient' ko email bhejne ke liye aapki explicit approval chahiye (Subject: \"$cleanSubject\").",
            payloadPreview = "To: $recipient\nSubject: $cleanSubject\n\n${body.take(300)}",
            technicalDetails = "EmailEngine.sendEmail (Gmail REST API v1 / mailto fallback) to '$recipient'."
        )
        if (!approved) {
            return@withContext EmailOperationResult(
                success = false,
                approvalDenied = true,
                message = "Approval denied: Email to '$recipient' was cancelled."
            )
        }

        val token = accessToken?.takeIf { it.isNotBlank() } ?: getOAuthAccessToken(context)
        if (token != null) {
            val apiResult = runCatching {
                val rawMime = buildRawMimeBase64Url(recipient, cleanSubject, body)
                val payload = JSONObject().put("raw", rawMime).toString()
                val req = Request.Builder()
                    .url("$GMAIL_API_BASE/messages/send")
                    .header("Authorization", "Bearer $token")
                    .post(payload.toRequestBody(JSON_MEDIA_TYPE))
                    .build()

                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        throw IllegalStateException("Gmail messages.send HTTP ${resp.code}")
                    }
                    JSONObject(resp.body?.string().orEmpty()).optString("id").takeIf { it.isNotBlank() }
                }
            }
            if (apiResult.isSuccess) {
                EngineRegistry.recordInvocation(103, success = true)
                return@withContext EmailOperationResult(
                    success = true,
                    messageId = apiResult.getOrNull(),
                    usedMailtoFallback = false,
                    message = "Sultan, '$recipient' ko email Gmail API ke zariye send kar diya gaya hai."
                )
            }
            Log.w(TAG, "Gmail API send failed; falling back to mailto compose", apiResult.exceptionOrNull())
        }

        return@withContext launchMailtoFallback(context, recipient, cleanSubject, body)
    }

    /**
     * Summarizes unread emails in natural Hinglish/Hindi/English via [DualBrainCoordinator].
     */
    suspend fun summarizeUnreadEmails(
        context: Context,
        emails: List<EmailMessage>,
        languageHint: String = "Hinglish"
    ): String {
        if (emails.isEmpty()) {
            return "Sultan, aapke inbox mein abhi koi unread email nahi hai."
        }
        val compactList = emails.take(5).mapIndexed { idx, email ->
            "${idx + 1}. From: ${email.from} | Subject: ${email.subject} | Snippet: ${email.snippet.take(160)}"
        }.joinToString("\n")

        val prompt = """
            You are Muskan, Sultan Mirza's executive AI assistant.
            Summarize these ${emails.size} unread emails clearly and concisely in $languageHint (max 5 short bullet points, highlighting urgent items first):
            $compactList
        """.trimIndent()

        val aiResponse = runCatching {
            DualBrainCoordinator.executeReasoning(context, prompt).responseText.trim()
        }.getOrNull()

        return if (!aiResponse.isNullOrBlank() && aiResponse.length > 12) {
            aiResponse
        } else {
            "Sultan, aapke ${emails.size} unread emails hain:\n$compactList"
        }
    }

    /**
     * Drafts a professional Hindi/Hinglish/English email reply or new message via [DualBrainCoordinator].
     */
    suspend fun draftEmailReply(
        context: Context,
        recipient: String,
        subject: String,
        instruction: String,
        originalEmail: EmailMessage? = null
    ): EmailDraft {
        val contextSection = originalEmail?.let {
            "\nOriginal Email from ${it.from} (Subject: ${it.subject}):\n${it.bodyPreview.take(400)}"
        }.orEmpty()

        val prompt = """
            You are Muskan, Sultan Mirza's AI Email Assistant.
            Draft a polite, clear, professional email body matching the language/tone requested by the user (Hindi, Hinglish, or English).
            Recipient: $recipient
            Subject: $subject
            User Instruction: $instruction$contextSection
            Output ONLY the email body text (no markdown fences).
        """.trimIndent()

        val draftedBody = runCatching {
            DualBrainCoordinator.executeReasoning(context, prompt).responseText.trim()
        }.getOrNull()?.takeIf { it.isNotBlank() }
            ?: "Hello,\n\n$instruction\n\nBest regards,\nSultan Mirza"

        return createDraft(
            context = context,
            to = recipient,
            subject = subject,
            body = draftedBody
        )
    }

    /**
     * Voice and chat entry point for email commands (e.g., "unread emails padho", "email draft karo",
     * "rahul@example.com ko email bhejo ...").
     */
    suspend fun handleVoiceEmailCommand(context: Context, prompt: String): String {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        val isUnreadRead = lower.contains("unread") ||
            lower.contains("inbox") ||
            lower.contains("emails padho") ||
            lower.contains("email padho") ||
            lower.contains("mail padho") ||
            lower.contains("email check") ||
            lower.contains("emails check") ||
            lower.contains("नए ईमेल") ||
            lower.contains("ईमेल पढ़ो")

        if (isUnreadRead) {
            val result = listUnreadEmails(context, maxResults = 5)
            return result.fold(
                onSuccess = { emails -> summarizeUnreadEmails(context, emails) },
                onFailure = { err ->
                    if (err is IllegalStateException && err.message?.contains("OAuth2", ignoreCase = true) == true) {
                        "Sultan, unread Gmail inbox padhne ke liye abhi Gmail OAuth2 token linked nahi hai. Aap chahein toh main abhi mail compose ya AI draft tayyar kar sakti hoon."
                    } else {
                        "Sultan, Gmail inbox fetch nahi ho saka: ${err.localizedMessage ?: "Network error"}"
                    }
                }
            )
        }

        val emailRegex = Regex("""[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}""")
        val recipient = emailRegex.find(prompt)?.value ?: ""
        val subject = extractSubjectHint(prompt)
        val draft = draftEmailReply(
            context = context,
            recipient = recipient.ifBlank { "recipient" },
            subject = subject,
            instruction = prompt
        )

        val wantsImmediateSend = lower.contains("bhejo") ||
            lower.contains("send email") ||
            lower.contains("send mail") ||
            lower.contains("भेजो")

        if (wantsImmediateSend) {
            val sendRes = sendEmail(
                context = context,
                to = recipient,
                subject = draft.subject,
                body = draft.body
            )
            return sendRes.message
        }

        val apiNote = if (draft.createdViaApi) " (Gmail Drafts mein save ho gaya)" else " (Offline draft ready)"
        return "Sultan, aapka email draft tayyar hai$apiNote:\nTo: ${draft.to}\nSubject: ${draft.subject}\n\n${draft.body}"
    }

    private fun launchMailtoFallback(
        context: Context,
        to: String,
        subject: String,
        body: String
    ): EmailOperationResult {
        val mailtoUri = Uri.parse(
            "mailto:${Uri.encode(to)}?subject=${Uri.encode(subject)}&body=${Uri.encode(body)}"
        )
        val intent = Intent(Intent.ACTION_SENDTO, mailtoUri).apply {
            if (to.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            EngineRegistry.recordInvocation(103, success = true)
            EmailOperationResult(
                success = true,
                usedMailtoFallback = true,
                message = "Sultan, aapki email app mein '$to' ke liye compose screen open kar di hai."
            )
        } catch (e: Exception) {
            Log.e(TAG, "mailto fallback failed", e)
            EmailOperationResult(
                success = false,
                usedMailtoFallback = true,
                message = "Email app open nahi ho saki: ${e.localizedMessage ?: "No email client installed"}"
            )
        }
    }

    private fun extractPlainTextBody(payload: JSONObject?): String {
        if (payload == null) return ""
        val mimeType = payload.optString("mimeType")
        val directData = payload.optJSONObject("body")?.optString("data").orEmpty()
        if (directData.isNotBlank() && (mimeType.isBlank() || mimeType.startsWith("text/plain", ignoreCase = true))) {
            return decodeBase64Url(directData)
        }
        val parts: JSONArray? = payload.optJSONArray("parts")
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                if (part.optString("mimeType").startsWith("text/plain", ignoreCase = true)) {
                    val data = part.optJSONObject("body")?.optString("data").orEmpty()
                    if (data.isNotBlank()) return decodeBase64Url(data)
                }
                val nested = extractPlainTextBody(part)
                if (nested.isNotBlank()) return nested
            }
        }
        return if (directData.isNotBlank()) decodeBase64Url(directData) else ""
    }

    private fun decodeBase64Url(encoded: String): String {
        return runCatching {
            val normalized = encoded.replace('-', '+').replace('_', '/')
            val padded = when (normalized.length % 4) {
                2 -> "$normalized=="
                3 -> "$normalized="
                else -> normalized
            }
            String(Base64.decode(padded, Base64.DEFAULT), StandardCharsets.UTF_8).trim()
        }.getOrDefault("")
    }

    private fun extractSubjectHint(prompt: String): String {
        val subjectMatch = Regex("""(?i)(?:subject|vishay|about|ke baare mein)\s*[:\-]?\s*([^.\n]{3,60})""").find(prompt)
        return subjectMatch?.groupValues?.getOrNull(1)?.trim()?.ifBlank { null }
            ?: "Quick Follow-Up"
    }
}
