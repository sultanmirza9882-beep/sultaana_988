package com.example.engine.dev

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Task steps for Muskan's direct autonomous development pipeline.
 */
data class WorkspaceTaskStep(
    val stepIndex: Int,
    val title: String,
    val isCompleted: Boolean = false,
    val outcome: String? = null
)

/**
 * Represents an active autonomous developer task managed directly by Muskan.
 */
data class AutonomousWorkspaceTask(
    val taskId: String,
    val objective: String,
    val steps: List<WorkspaceTaskStep>,
    val draftId: String? = null,
    val status: String = "IN_PROGRESS",
    val resultMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Persists and manages active autonomous developer tasks for Muskan.
 */
object MuskanTaskManager {

    private const val FILE_NAME = "muskan_active_task.json"

    private val _activeTask = MutableStateFlow<AutonomousWorkspaceTask?>(null)
    val activeTask: StateFlow<AutonomousWorkspaceTask?> = _activeTask.asStateFlow()

    private fun taskFile(context: Context): File = File(context.filesDir, FILE_NAME)

    fun restoreActiveTask(task: AutonomousWorkspaceTask?) {
        _activeTask.value = task
    }

    suspend fun saveActiveTask(context: Context, task: AutonomousWorkspaceTask) = withContext(Dispatchers.IO) {
        val root = JSONObject().apply {
            put("taskId", task.taskId)
            put("objective", task.objective)
            put("draftId", task.draftId)
            put("status", task.status)
            put("resultMessage", task.resultMessage)
            put("createdAt", task.createdAt)

            val stepsArray = JSONArray()
            task.steps.forEach { step ->
                val s = JSONObject().apply {
                    put("stepIndex", step.stepIndex)
                    put("title", step.title)
                    put("isCompleted", step.isCompleted)
                    put("outcome", step.outcome)
                }
                stepsArray.put(s)
            }
            put("steps", stepsArray)
        }
        taskFile(context).writeText(root.toString(2), Charsets.UTF_8)
        _activeTask.value = task
    }

    suspend fun loadPersistedTask(context: Context): AutonomousWorkspaceTask? = withContext(Dispatchers.IO) {
        val f = taskFile(context)
        if (!f.exists() || f.length() <= 0L) return@withContext null

        runCatching {
            val json = JSONObject(f.readText(Charsets.UTF_8))
            val stepsList = mutableListOf<WorkspaceTaskStep>()
            val stepsArray = json.optJSONArray("steps") ?: JSONArray()
            for (i in 0 until stepsArray.length()) {
                val s = stepsArray.getJSONObject(i)
                stepsList.add(
                    WorkspaceTaskStep(
                        stepIndex = s.optInt("stepIndex", i),
                        title = s.optString("title", "Task Step"),
                        isCompleted = s.optBoolean("isCompleted", false),
                        outcome = s.optString("outcome").takeIf { it.isNotBlank() }
                    )
                )
            }

            val task = AutonomousWorkspaceTask(
                taskId = json.optString("taskId", "unknown"),
                objective = json.optString("objective", ""),
                steps = stepsList,
                draftId = json.optString("draftId").takeIf { it.isNotBlank() },
                status = json.optString("status", "IN_PROGRESS"),
                resultMessage = json.optString("resultMessage").takeIf { it.isNotBlank() },
                createdAt = json.optLong("createdAt", System.currentTimeMillis())
            )
            _activeTask.value = task
            task
        }.getOrNull()
    }

    suspend fun clearActiveTask(context: Context) = withContext(Dispatchers.IO) {
        taskFile(context).delete()
        _activeTask.value = null
    }
}
