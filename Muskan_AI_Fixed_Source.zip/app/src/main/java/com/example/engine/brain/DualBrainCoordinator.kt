package com.example.engine.brain

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.BuildConfig
import com.example.api.ApiKeySlot
import com.example.api.KeyRotationPoolManager
import com.example.data.GeminiClient
import com.example.engine.llm.LlamaCppBridge
import com.example.engine.llm.LocalOfflineSmallLlmEngine
import com.example.engine.llm.QwenOfflineModelManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext

/**
 * Muskaan Dual-Brain AI Coordinator.
 * Seamlessly bonds Google Gemini (Online Cloud) and Alibaba Qwen3 1.7B GGUF via llama.cpp (On-Device Offline)
 * into a single unified, ultra-reliable reasoning architecture.
 *
 * Operational Standards:
 * 1. Hybrid Auto Mode: Prefers Gemini Live / Gemini 2.0-2.5 Flash for high-bandwidth complex queries.
 * 2. Instant Zero-Delay Failover (<300ms): If network drops, timeout occurs, or HTTP 429 quota exhaustion strikes,
 *    switches instantly to Qwen3 1.7B GGUF on-device without crashing or showing error dialogs.
 * 3. Force Offline Mode: 100% local operation without internet, API keys, or cloud dependencies.
 * 4. Context Preservation: Feeds multi-turn Room SQLite history and learned user memories to both brains.
 */
object DualBrainCoordinator {

    enum class BrainMode {
        HYBRID_AUTO,
        FORCE_OFFLINE,
        ONLINE_ONLY
    }

    enum class BrainSource(val displayName: String, val isLocal: Boolean) {
        GEMINI_LIVE("Gemini Live Multimodal", false),
        GEMINI_FLASH("Gemini 2.0 Flash Cloud", false),
        QWEN3_OFFLINE("Qwen3 1.7B GGUF Native", true),
        OFFLINE_DEVICE_SLM("Muskan Local On-Device SLM", true)
    }

    data class BrainResult(
        val responseText: String,
        val source: BrainSource,
        val isOffline: Boolean,
        val latencyMs: Long,
        val detailNotice: String? = null
    )

    data class BrainStatusState(
        val mode: BrainMode = BrainMode.HYBRID_AUTO,
        val activeBrainLabel: String = "Dual-Brain (Auto)",
        val isInternetConnected: Boolean = true,
        val isOfflineModelReady: Boolean = false,
        val offlineModelName: String = QwenOfflineModelManager.PRIMARY_MODEL_FILENAME,
        val lastBrainUsed: BrainSource? = null,
        val totalQueriesHandled: Long = 0L,
        val failoverEventsCount: Long = 0L
    )

    private val _brainState = MutableStateFlow(BrainStatusState())
    val brainState: StateFlow<BrainStatusState> = _brainState.asStateFlow()

    fun initialize(context: Context) {
        val qwenState = QwenOfflineModelManager.initialize(context)
        val isNet = isNetworkAvailable(context)
        val mode = if (qwenState.isForceOfflineBrain) BrainMode.FORCE_OFFLINE else BrainMode.HYBRID_AUTO

        _brainState.update {
            it.copy(
                mode = mode,
                activeBrainLabel = if (mode == BrainMode.FORCE_OFFLINE) "Offline Qwen3 Brain" else "Dual-Brain (Auto)",
                isInternetConnected = isNet,
                isOfflineModelReady = qwenState.isDownloaded && qwenState.isNativeEngineLoaded,
                offlineModelName = qwenState.modelName
            )
        }
    }

    fun setBrainMode(context: Context, mode: BrainMode) {
        val forceOffline = mode == BrainMode.FORCE_OFFLINE
        QwenOfflineModelManager.setForceOfflineBrain(context, forceOffline)
        val label = when (mode) {
            BrainMode.FORCE_OFFLINE -> "Offline Qwen3 Brain (Forced)"
            BrainMode.ONLINE_ONLY -> "Gemini Online Cloud Only"
            BrainMode.HYBRID_AUTO -> "Dual-Brain Auto Failover"
        }
        _brainState.update {
            it.copy(
                mode = mode,
                activeBrainLabel = label
            )
        }
    }

    suspend fun executeReasoning(
        context: Context,
        prompt: String,
        recentHistory: List<Pair<String, String>> = emptyList(),
        learnedFacts: List<String> = emptyList()
    ): BrainResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val currentMode = _brainState.value.mode
        val hasNet = isNetworkAvailable(context)
        val activeKey = resolveActiveGeminiKey()
        val hasKey = activeKey.isNotBlank()

        // 1. Force Offline Mode -> execute Offline Brain directly
        if (currentMode == BrainMode.FORCE_OFFLINE) {
            val offlineRes = executeOfflineBrain(context, prompt, recentHistory, learnedFacts)
            val duration = System.currentTimeMillis() - startTime
            recordQueryResult(offlineRes.source)
            return@withContext offlineRes.copy(latencyMs = duration)
        }

        // 2. ONLINE_ONLY Mode -> strictly refuse offline failover if disconnected or missing key
        if (currentMode == BrainMode.ONLINE_ONLY) {
            if (!hasNet) {
                val duration = System.currentTimeMillis() - startTime
                return@withContext BrainResult(
                    responseText = "Internet connection unavailable. Online-Only mode cannot fall back to offline brain.",
                    source = BrainSource.GEMINI_FLASH,
                    isOffline = false,
                    latencyMs = duration,
                    detailNotice = "ONLINE_ONLY: Network offline"
                )
            }
            if (!hasKey) {
                val duration = System.currentTimeMillis() - startTime
                return@withContext BrainResult(
                    responseText = "Gemini API key configured nahi hai. Online-Only mode ke liye Settings mein key add karein.",
                    source = BrainSource.GEMINI_FLASH,
                    isOffline = false,
                    latencyMs = duration,
                    detailNotice = "ONLINE_ONLY: No valid Gemini API key"
                )
            }
        }

        // 3. Hybrid Auto Mode when disconnected or missing key -> Offline Brain
        if (currentMode == BrainMode.HYBRID_AUTO && (!hasNet || !hasKey)) {
            val offlineRes = executeOfflineBrain(context, prompt, recentHistory, learnedFacts)
            val duration = System.currentTimeMillis() - startTime
            recordQueryResult(offlineRes.source)
            return@withContext offlineRes.copy(latencyMs = duration)
        }

        // 4. Online Cloud Reasoning (ONLINE_ONLY or HYBRID_AUTO)
        try {
            val cloudResult = GeminiClient.askGemini(
                apiKey = activeKey,
                prompt = prompt,
                recentHistory = recentHistory,
                learnedFacts = learnedFacts
            )

            if (cloudResult.isSuccess) {
                val text = cloudResult.getOrThrow()
                val duration = System.currentTimeMillis() - startTime
                recordQueryResult(BrainSource.GEMINI_FLASH)
                return@withContext BrainResult(
                    responseText = text,
                    source = BrainSource.GEMINI_FLASH,
                    isOffline = false,
                    latencyMs = duration
                )
            } else {
                val errMsg = cloudResult.exceptionOrNull()?.message?.take(80) ?: "Unknown cloud error"
                if (currentMode == BrainMode.ONLINE_ONLY) {
                    val duration = System.currentTimeMillis() - startTime
                    return@withContext BrainResult(
                        responseText = "Online Gemini request failed: $errMsg",
                        source = BrainSource.GEMINI_FLASH,
                        isOffline = false,
                        latencyMs = duration,
                        detailNotice = "ONLINE_ONLY: Cloud call failed without offline failover"
                    )
                }
                // HYBRID_AUTO: Seamless Instant Failover to Offline Brain
                _brainState.update { it.copy(failoverEventsCount = it.failoverEventsCount + 1) }
                val offlineRes = executeOfflineBrain(context, prompt, recentHistory, learnedFacts)
                val duration = System.currentTimeMillis() - startTime
                recordQueryResult(offlineRes.source)
                return@withContext offlineRes.copy(
                    latencyMs = duration,
                    detailNotice = "Online Gemini unavailable (${errMsg.take(40)}). Qwen3 offline brain active."
                )
            }
        } catch (e: Exception) {
            if (currentMode == BrainMode.ONLINE_ONLY) {
                val duration = System.currentTimeMillis() - startTime
                return@withContext BrainResult(
                    responseText = "Online Gemini error: ${e.message?.take(80) ?: "Transport failure"}",
                    source = BrainSource.GEMINI_FLASH,
                    isOffline = false,
                    latencyMs = duration,
                    detailNotice = "ONLINE_ONLY: Cloud exception without offline failover"
                )
            }
            // HYBRID_AUTO: Unhandled network / transport error -> Instant Failover
            _brainState.update { it.copy(failoverEventsCount = it.failoverEventsCount + 1) }
            val offlineRes = executeOfflineBrain(context, prompt, recentHistory, learnedFacts)
            val duration = System.currentTimeMillis() - startTime
            recordQueryResult(offlineRes.source)
            return@withContext offlineRes.copy(
                latencyMs = duration,
                detailNotice = "Cloud error: ${e.message?.take(40)}. Local brain active."
            )
        }
    }

    private suspend fun executeOfflineBrain(
        context: Context,
        prompt: String,
        recentHistory: List<Pair<String, String>>,
        learnedFacts: List<String>
    ): BrainResult {
        val result = LocalOfflineSmallLlmEngine.processOfflineInference(
            context = context,
            rawPrompt = prompt,
            recentHistory = recentHistory,
            learnedFacts = learnedFacts
        )

        val source = if (result.actionExecuted?.contains("Qwen3", ignoreCase = true) == true) {
            BrainSource.QWEN3_OFFLINE
        } else {
            BrainSource.OFFLINE_DEVICE_SLM
        }

        return BrainResult(
            responseText = result.responseSpeech,
            source = source,
            isOffline = true,
            latencyMs = 0L,
            detailNotice = result.actionExecuted
        )
    }

    private fun recordQueryResult(source: BrainSource) {
        _brainState.update {
            it.copy(
                totalQueriesHandled = it.totalQueriesHandled + 1,
                lastBrainUsed = source
            )
        }
    }

    fun isNetworkAvailable(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (_: Exception) {
            false
        }
    }

    fun resolveActiveGeminiKey(): String {
        val poolKey = runCatching { KeyRotationPoolManager.getActiveGeminiKey().trim() }.getOrDefault("")
        if (poolKey.isNotBlank() && !ApiKeySlot.isPlaceholderKey(poolKey)) {
            return poolKey
        }
        val buildKey = BuildConfig.GEMINI_API_KEY.trim()
        if (buildKey.isNotBlank() &&
            !ApiKeySlot.isPlaceholderKey(buildKey) &&
            !buildKey.equals("YOUR_GEMINI_API_KEY", ignoreCase = true) &&
            !buildKey.equals("INSERT_API_KEY_HERE", ignoreCase = true)
        ) {
            return buildKey
        }
        return ""
    }

    fun hasValidGeminiKey(): Boolean = resolveActiveGeminiKey().isNotBlank()
}
