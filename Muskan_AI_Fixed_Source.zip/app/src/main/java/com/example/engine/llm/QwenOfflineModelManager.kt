package com.example.engine.llm

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Manages on-device GGUF model storage, discovery, verification, and resumable downloading
 * for Muskan's Offline Brain (Qwen3 1.7B Q4_K_M on Snapdragon 4 Gen 2 / 8 GB RAM).
 *
 * Official Model Repository:
 * https://huggingface.co/Qwen/Qwen3-1.7B-GGUF
 */
object QwenOfflineModelManager {

    const val PRIMARY_MODEL_FILENAME = "Qwen3-1.7B-Q4_K_M.gguf"
    const val PRIMARY_MODEL_HF_URL =
        "https://huggingface.co/Qwen/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf?download=true"
    const val PRIMARY_MODEL_APPROX_BYTES = 1_374_389_534L // ~1.28 GiB

    const val LIGHT_MODEL_FILENAME = "Qwen3-0.6B-Q4_K_M.gguf"
    const val LIGHT_MODEL_HF_URL =
        "https://huggingface.co/Qwen/Qwen3-0.6B-GGUF/resolve/main/Qwen3-0.6B-Q4_K_M.gguf?download=true"

    private const val PREFS_NAME = "muskan_qwen_offline_prefs"
    private const val KEY_FORCE_OFFLINE_BRAIN = "force_offline_brain"
    private const val KEY_THINKING_MODE = "qwen3_thinking_mode"
    private const val KEY_ACTIVE_MODEL_PATH = "active_gguf_model_path"

    data class GgufHeaderInfo(
        val isValidGguf: Boolean,
        val version: Int = 0,
        val tensorCount: Long = 0L,
        val metadataKvCount: Long = 0L,
        val fileSizeBytes: Long = 0L,
        val message: String = ""
    )

    data class OfflineModelState(
        val modelName: String = PRIMARY_MODEL_FILENAME,
        val modelRepoUrl: String = "https://huggingface.co/Qwen/Qwen3-1.7B-GGUF",
        val licenseName: String = "Apache 2.0",
        val targetHardwareProfile: String = "Snapdragon 4 Gen 2 • 8 GB RAM • ARM64",
        val isDownloaded: Boolean = false,
        val isDownloading: Boolean = false,
        val downloadProgress: Float = 0f,
        val downloadedBytes: Long = 0L,
        val totalBytes: Long = PRIMARY_MODEL_APPROX_BYTES,
        val localFilePath: String? = null,
        val isNativeEngineLoaded: Boolean = false,
        val isForceOfflineBrain: Boolean = false,
        val isThinkingModeEnabled: Boolean = false,
        val statusMessage: String = "Ready to download Qwen3 1.7B Q4_K_M (~1.28 GB) or import via Storage Access Framework"
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var downloadJob: Job? = null

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val _state = MutableStateFlow(OfflineModelState())
    val state: StateFlow<OfflineModelState> = _state.asStateFlow()

    /**
     * Returns the canonical app-private models directory inside `context.filesDir`.
     */
    fun getModelsDirectory(context: Context): File {
        val dir = File(context.filesDir, "models")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    private fun getAppPrivateModelDirectories(context: Context): List<File> {
        val dirs = mutableListOf(getModelsDirectory(context))
        try {
            context.getExternalFilesDir("models")?.let { extPrivateDir ->
                if (extPrivateDir.exists() && extPrivateDir.canonicalPath != dirs.first().canonicalPath) {
                    dirs.add(extPrivateDir)
                }
            }
        } catch (_: Exception) {}
        return dirs
    }

    private fun isInsideAppPrivateStorage(context: Context, file: File): Boolean {
        return try {
            val filePath = file.canonicalPath
            val allowedRoots = buildList {
                add(context.filesDir.canonicalPath)
                context.getExternalFilesDir(null)?.canonicalPath?.let { add(it) }
            }
            allowedRoots.any { root ->
                filePath == root || filePath.startsWith("$root${File.separator}")
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Initializes model state, checks app-private storage for an existing valid `.gguf` model
     * (imported via SAF or downloaded in-app), and loads the native llama.cpp session if available.
     */
    fun initialize(context: Context): OfflineModelState {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val forceOffline = prefs.getBoolean(KEY_FORCE_OFFLINE_BRAIN, false)
        val thinkingMode = prefs.getBoolean(KEY_THINKING_MODE, false)

        val discoveredFile = findExistingGgufModel(context)
        val header = if (discoveredFile != null) inspectGgufHeader(discoveredFile) else null

        if (discoveredFile != null && header != null && header.isValidGguf) {
            val loaded = LlamaCppBridge.ensureModelLoaded(
                modelPath = discoveredFile.absolutePath,
                nThreads = 6,
                nCtx = 2048
            )
            val sizeMb = String.format(Locale.US, "%.1f MB", discoveredFile.length() / (1024.0 * 1024.0))
            _state.update {
                it.copy(
                    modelName = discoveredFile.name,
                    isDownloaded = true,
                    isDownloading = false,
                    downloadProgress = 1.0f,
                    downloadedBytes = discoveredFile.length(),
                    totalBytes = discoveredFile.length(),
                    localFilePath = discoveredFile.absolutePath,
                    isNativeEngineLoaded = loaded,
                    isForceOfflineBrain = forceOffline,
                    isThinkingModeEnabled = thinkingMode,
                    statusMessage = if (loaded) {
                        "Active: ${discoveredFile.name} ($sizeMb • GGUF v${header.version} • llama.cpp Ready)"
                    } else {
                        "Verified GGUF: ${discoveredFile.name} ($sizeMb • GGUF v${header.version})"
                    }
                )
            }
        } else {
            val partialFile = File(getModelsDirectory(context), "$PRIMARY_MODEL_FILENAME.part")
            val partialBytes = if (partialFile.exists()) partialFile.length() else 0L
            val progress = if (partialBytes > 0L) {
                (partialBytes.toFloat() / PRIMARY_MODEL_APPROX_BYTES.toFloat()).coerceIn(0f, 0.99f)
            } else 0f
            _state.update {
                it.copy(
                    isDownloaded = false,
                    isDownloading = false,
                    downloadProgress = progress,
                    downloadedBytes = partialBytes,
                    localFilePath = null,
                    isNativeEngineLoaded = LlamaCppBridge.isNativeLibraryAvailable(),
                    isForceOfflineBrain = forceOffline,
                    isThinkingModeEnabled = thinkingMode,
                    statusMessage = if (partialBytes > 0L) {
                        val mb = partialBytes / (1024 * 1024)
                        "Download paused at $mb MB / 1280 MB • Tap Resume to complete"
                    } else {
                        "Model not downloaded yet (~1.28 GB • Qwen3 1.7B Q4_K_M)"
                    }
                )
            }
        }
        return _state.value
    }

    fun setForceOfflineBrain(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_FORCE_OFFLINE_BRAIN, enabled)
            .apply()
        _state.update {
            it.copy(
                isForceOfflineBrain = enabled,
                statusMessage = if (enabled) {
                    "Offline Brain forced ON (No API Key / No Internet used)"
                } else {
                    "Dual-Brain AUTO mode (Gemini Online + Qwen3 Offline)"
                }
            )
        }
    }

    fun setThinkingMode(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_THINKING_MODE, enabled)
            .apply()
        _state.update { it.copy(isThinkingModeEnabled = enabled) }
    }

    fun scanLocalStorageForGguf(context: Context): File? = findExistingGgufModel(context)

    /**
     * Searches app-private model storage (`filesDir/models` and app-private external files dir)
     * for valid Qwen3 GGUF files. External user files must be imported via Storage Access Framework
     * (`importModelFromUri`), never by scanning legacy public `/sdcard/Download`.
     */
    fun findExistingGgufModel(context: Context): File? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedPath = prefs.getString(KEY_ACTIVE_MODEL_PATH, null)
        if (!savedPath.isNullOrBlank()) {
            val f = File(savedPath)
            if (isInsideAppPrivateStorage(context, f) && f.exists() && f.isFile && inspectGgufHeader(f).isValidGguf) {
                return f
            }
        }

        val candidates = mutableListOf<File>()
        getAppPrivateModelDirectories(context).forEach { dir ->
            dir.listFiles()?.filter { it.isFile && it.extension.equals("gguf", ignoreCase = true) }?.let {
                candidates.addAll(it)
            }
        }

        // Prefer Qwen3-1.7B-Q4_K_M.gguf first, then any valid GGUF file
        val prioritized = candidates.sortedByDescending { file ->
            when {
                file.name.equals(PRIMARY_MODEL_FILENAME, ignoreCase = true) -> 3
                file.name.contains("qwen3", ignoreCase = true) -> 2
                else -> 1
            }
        }

        return prioritized.firstOrNull { inspectGgufHeader(it).isValidGguf }
    }

    /**
     * Reads and validates the binary GGUF header ("GGUF" magic bytes + version + tensor/kv counts).
     * Never loads the whole 1.28 GB file into memory.
     */
    fun inspectGgufHeader(file: File): GgufHeaderInfo {
        if (!file.exists() || !file.isFile || file.length() < 24L) {
            return GgufHeaderInfo(
                isValidGguf = false,
                fileSizeBytes = if (file.exists()) file.length() else 0L,
                message = "File is missing or smaller than minimum GGUF header (24 bytes)."
            )
        }
        return try {
            RandomAccessFile(file, "r").use { raf ->
                val magic = ByteArray(4)
                raf.readFully(magic)
                val magicStr = String(magic, Charsets.US_ASCII)
                if (magicStr != "GGUF") {
                    return GgufHeaderInfo(
                        isValidGguf = false,
                        fileSizeBytes = file.length(),
                        message = "Invalid magic header '$magicStr' (expected 'GGUF')."
                    )
                }
                // Little-endian uint32 version, uint64 tensor_count, uint64 metadata_kv_count
                val version = Integer.reverseBytes(raf.readInt())
                val tensorCount = java.lang.Long.reverseBytes(raf.readLong())
                val kvCount = java.lang.Long.reverseBytes(raf.readLong())
                val validVersion = version in 2..3 && tensorCount >= 0 && kvCount >= 0
                GgufHeaderInfo(
                    isValidGguf = validVersion,
                    version = version,
                    tensorCount = tensorCount,
                    metadataKvCount = kvCount,
                    fileSizeBytes = file.length(),
                    message = if (validVersion) {
                        "Valid GGUF v$version ($tensorCount tensors, $kvCount metadata keys)"
                    } else {
                        "Unsupported GGUF version: $version"
                    }
                )
            }
        } catch (e: Exception) {
            GgufHeaderInfo(
                isValidGguf = false,
                fileSizeBytes = file.length(),
                message = "Failed to read GGUF header: ${e.message}"
            )
        }
    }

    /**
     * Imports a user-selected `.gguf` file via Android Storage Access Framework (`Uri`).
     */
    suspend fun importModelFromUri(context: Context, uri: Uri, targetFileName: String = PRIMARY_MODEL_FILENAME): Result<File> =
        withContext(Dispatchers.IO) {
            try {
                val destDir = getModelsDirectory(context)
                val tempFile = File(destDir, "$targetFileName.import_tmp")
                val finalFile = File(destDir, targetFileName)

                _state.update {
                    it.copy(
                        isDownloading = true,
                        statusMessage = "Importing GGUF model into private storage…"
                    )
                }

                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tempFile).use { output ->
                        val buffer = ByteArray(256 * 1024)
                        var copied = 0L
                        var read: Int
                        while (input.read(buffer).also { read = it } != -1) {
                            output.write(buffer, 0, read)
                            copied += read
                            _state.update { st ->
                                st.copy(
                                    downloadedBytes = copied,
                                    downloadProgress = (copied.toFloat() / PRIMARY_MODEL_APPROX_BYTES.toFloat()).coerceIn(0f, 0.99f)
                                )
                            }
                        }
                        output.fd.sync()
                    }
                } ?: return@withContext Result.failure(IllegalStateException("Could not open input stream for selected URI."))

                val header = inspectGgufHeader(tempFile)
                if (!header.isValidGguf) {
                    tempFile.delete()
                    _state.update {
                        it.copy(
                            isDownloading = false,
                            statusMessage = "Import rejected: ${header.message}"
                        )
                    }
                    return@withContext Result.failure(IllegalArgumentException(header.message))
                }

                if (finalFile.exists()) finalFile.delete()
                check(tempFile.renameTo(finalFile)) { "Failed to finalize imported GGUF file." }

                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_ACTIVE_MODEL_PATH, finalFile.absolutePath)
                    .apply()

                initialize(context)
                Result.success(finalFile)
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        isDownloading = false,
                        statusMessage = "Import error: ${e.message}"
                    )
                }
                Result.failure(e)
            }
        }

    /**
     * Starts or resumes downloading `Qwen3-1.7B-Q4_K_M.gguf` from Hugging Face using HTTP Range requests.
     */
    fun startOrResumeDownload(
        context: Context,
        downloadUrl: String = PRIMARY_MODEL_HF_URL,
        fileName: String = PRIMARY_MODEL_FILENAME,
        onComplete: ((Boolean, String) -> Unit)? = null
    ) {
        if (_state.value.isDownloading) return

        val appCtx = context.applicationContext
        downloadJob?.cancel()
        downloadJob = scope.launch {
            val modelsDir = getModelsDirectory(appCtx)
            val finalFile = File(modelsDir, fileName)
            val partFile = File(modelsDir, "$fileName.part")

            try {
                if (finalFile.exists() && inspectGgufHeader(finalFile).isValidGguf) {
                    initialize(appCtx)
                    onComplete?.invoke(true, "Model ${finalFile.name} is already downloaded and verified.")
                    return@launch
                }

                val existingBytes = if (partFile.exists()) partFile.length() else 0L
                _state.update {
                    it.copy(
                        modelName = fileName,
                        isDownloading = true,
                        downloadedBytes = existingBytes,
                        statusMessage = if (existingBytes > 0L) {
                            "Resuming $fileName from ${existingBytes / (1024 * 1024)} MB…"
                        } else {
                            "Connecting to Hugging Face ($fileName)…"
                        }
                    )
                }

                val requestBuilder = Request.Builder()
                    .url(downloadUrl)
                    .header("User-Agent", "MuskanVoiceAssistant/1.0 (Android 16; Redmi 13 5G)")
                if (existingBytes > 0L) {
                    requestBuilder.header("Range", "bytes=$existingBytes-")
                }

                httpClient.newCall(requestBuilder.build()).execute().use { response ->
                    if (!response.isSuccessful && response.code != 206) {
                        val msg = "Download failed (HTTP ${response.code}). Check internet connection."
                        _state.update { it.copy(isDownloading = false, statusMessage = msg) }
                        onComplete?.invoke(false, msg)
                        return@launch
                    }

                    val isResumed = response.code == 206 && existingBytes > 0L
                    val body = response.body ?: throw IllegalStateException("Empty HTTP response body")
                    val contentLength = body.contentLength()
                    val totalExpected = when {
                        isResumed && contentLength > 0L -> existingBytes + contentLength
                        contentLength > 0L -> contentLength
                        else -> PRIMARY_MODEL_APPROX_BYTES
                    }

                    FileOutputStream(partFile, isResumed).use { output ->
                        body.byteStream().use { input ->
                            val buffer = ByteArray(128 * 1024)
                            var bytesWritten = if (isResumed) existingBytes else 0L
                            var lastUiUpdateMs = 0L
                            var read: Int

                            while (input.read(buffer).also { read = it } != -1) {
                                output.write(buffer, 0, read)
                                bytesWritten += read

                                val now = System.currentTimeMillis()
                                if (now - lastUiUpdateMs >= 250L) {
                                    lastUiUpdateMs = now
                                    val pct = (bytesWritten.toFloat() / totalExpected.toFloat()).coerceIn(0f, 0.99f)
                                    val dlMb = bytesWritten / (1024 * 1024)
                                    val totMb = totalExpected / (1024 * 1024)
                                    _state.update {
                                        it.copy(
                                            isDownloading = true,
                                            downloadedBytes = bytesWritten,
                                            totalBytes = totalExpected,
                                            downloadProgress = pct,
                                            statusMessage = "Downloading $fileName: $dlMb MB / $totMb MB (${(pct * 100).toInt()}%)"
                                        )
                                    }
                                }
                            }
                            output.fd.sync()
                        }
                    }
                }

                val header = inspectGgufHeader(partFile)
                if (!header.isValidGguf) {
                    partFile.delete()
                    val errMsg = "Downloaded file failed GGUF verification: ${header.message}"
                    _state.update { it.copy(isDownloading = false, statusMessage = errMsg) }
                    onComplete?.invoke(false, errMsg)
                    return@launch
                }

                if (finalFile.exists()) finalFile.delete()
                check(partFile.renameTo(finalFile)) { "Could not rename completed GGUF file." }

                appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_ACTIVE_MODEL_PATH, finalFile.absolutePath)
                    .apply()

                val updated = initialize(appCtx)
                onComplete?.invoke(true, updated.statusMessage)
            } catch (ce: CancellationException) {
                _state.update {
                    it.copy(
                        isDownloading = false,
                        statusMessage = "Download paused at ${it.downloadedBytes / (1024 * 1024)} MB • Tap Resume anytime"
                    )
                }
                throw ce
            } catch (e: Exception) {
                val msg = "Download interrupted (${e.message ?: "network error"}). Tap Resume to continue."
                _state.update { it.copy(isDownloading = false, statusMessage = msg) }
                onComplete?.invoke(false, msg)
            }
        }
    }

    fun pauseDownload() {
        downloadJob?.cancel()
        downloadJob = null
        _state.update {
            it.copy(
                isDownloading = false,
                statusMessage = "Download paused at ${it.downloadedBytes / (1024 * 1024)} MB • Tap Resume anytime"
            )
        }
    }
}
