package com.example.engine.business

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import com.example.engine.EngineRegistry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.roundToLong

enum class ProjectStatus(val label: String) {
    LEAD("Lead"),
    IN_PROGRESS("In Progress"),
    REVIEW("In Review"),
    DELIVERED("Delivered"),
    PAID("Paid")
}

data class ProjectMilestone(
    val title: String,
    val amount: Double,
    val completed: Boolean = false
)

data class ClientProject(
    val id: String = "proj-${UUID.randomUUID().toString().take(8)}",
    val clientName: String,
    val clientEmail: String = "",
    val clientPhone: String = "",
    val projectTitle: String,
    val scope: String,
    val currency: String = "INR",
    val totalPrice: Double,
    val milestones: List<ProjectMilestone> = emptyList(),
    val status: ProjectStatus = ProjectStatus.IN_PROGRESS,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class InvoiceLineItem(
    val description: String,
    val quantity: Int = 1,
    val unitPrice: Double
) {
    val lineTotal: Double
        get() = round2(quantity.coerceAtLeast(1) * unitPrice.coerceAtLeast(0.0))
}

data class InvoiceCalculation(
    val subtotal: Double,
    val taxRatePercent: Double,
    val taxAmount: Double,
    val discountAmount: Double,
    val grandTotal: Double
)

data class InvoiceRecord(
    val invoiceNumber: String,
    val clientName: String,
    val clientEmail: String = "",
    val projectTitle: String,
    val currency: String = "INR",
    val items: List<InvoiceLineItem>,
    val calculation: InvoiceCalculation,
    val pdfFile: File,
    val issuedDate: String
)

private fun round2(value: Double): Double = (value * 100.0).roundToLong() / 100.0

/**
 * Module 13: Client Work & Business Engine.
 *
 * Provides:
 * 1. Persistent JSON-backed Client & Project CRM in app-private `filesDir/business/crm_store.json`
 *    tracking client details, project scope, pricing, milestones, and delivery/payment status.
 * 2. Real Android `android.graphics.pdf.PdfDocument` itemized Tax/Business Invoice Generator
 *    saving formatted A4 PDF invoices to `filesDir/invoices/` with `FileProvider` share support.
 */
object BusinessEngine {

    private const val TAG = "BusinessEngine"
    private const val BUSINESS_DIR = "business"
    private const val INVOICES_DIR = "invoices"
    private const val CRM_FILENAME = "crm_store.json"

    private val _projects = MutableStateFlow<List<ClientProject>>(emptyList())
    val projects: StateFlow<List<ClientProject>> = _projects.asStateFlow()

    fun getBusinessDir(context: Context): File =
        File(context.applicationContext.filesDir, BUSINESS_DIR).apply { if (!exists()) mkdirs() }

    fun getInvoicesDir(context: Context): File =
        File(context.applicationContext.filesDir, INVOICES_DIR).apply { if (!exists()) mkdirs() }

    private fun getCrmFile(context: Context): File = File(getBusinessDir(context), CRM_FILENAME)

    /**
     * Loads all persisted client projects from `filesDir/business/crm_store.json`.
     */
    fun loadProjects(context: Context): List<ClientProject> {
        EngineRegistry.recordInvocation(123, success = true)
        val file = getCrmFile(context)
        if (!file.exists()) {
            _projects.value = emptyList()
            return emptyList()
        }
        val parsed = runCatching {
            val raw = file.readText(Charsets.UTF_8)
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(parseProjectJson(obj))
                }
            }
        }.getOrElse { err ->
            Log.e(TAG, "Failed reading CRM store", err)
            emptyList()
        }
        _projects.value = parsed
        return parsed
    }

    /**
     * Inserts or updates a [ClientProject] and persists immediately to `filesDir/business/crm_store.json`.
     */
    fun upsertProject(context: Context, project: ClientProject): ClientProject {
        EngineRegistry.recordInvocation(123, success = true)
        val existing = loadProjects(context)
        val updated = project.copy(updatedAt = System.currentTimeMillis())
        val merged = listOf(updated) + existing.filter { it.id != updated.id }
        saveProjects(context, merged)
        return updated
    }

    /**
     * Updates delivery/payment status for an existing project.
     */
    fun updateProjectStatus(context: Context, projectId: String, status: ProjectStatus): ClientProject? {
        val existing = loadProjects(context)
        val target = existing.firstOrNull { it.id == projectId } ?: return null
        val updated = target.copy(status = status, updatedAt = System.currentTimeMillis())
        val merged = existing.map { if (it.id == projectId) updated else it }
        saveProjects(context, merged)
        return updated
    }

    fun findProjectsByClient(context: Context, clientQuery: String): List<ClientProject> {
        val q = clientQuery.trim().lowercase(Locale.ROOT)
        return loadProjects(context).filter {
            it.clientName.lowercase(Locale.ROOT).contains(q) ||
                it.projectTitle.lowercase(Locale.ROOT).contains(q)
        }
    }

    fun getPipelineSummary(context: Context): String {
        val list = loadProjects(context)
        if (list.isEmpty()) {
            return "Sultan, CRM mein abhi koi active client project saved nahi hai."
        }
        val totalValue = round2(list.sumOf { it.totalPrice })
        val activeCount = list.count { it.status == ProjectStatus.IN_PROGRESS || it.status == ProjectStatus.REVIEW }
        val paidValue = round2(list.filter { it.status == ProjectStatus.PAID }.sumOf { it.totalPrice })
        return "Sultan, CRM mein kul ${list.size} projects hain ($activeCount active). Total pipeline: INR $totalValue, Paid: INR $paidValue."
    }

    /**
     * Pure invoice totals calculator with 2-decimal precision.
     */
    fun calculateInvoiceTotals(
        items: List<InvoiceLineItem>,
        taxRatePercent: Double = 18.0,
        discountAmount: Double = 0.0
    ): InvoiceCalculation {
        val safeTaxRate = taxRatePercent.coerceIn(0.0, 50.0)
        val subtotal = round2(items.sumOf { it.lineTotal })
        val safeDiscount = round2(discountAmount.coerceIn(0.0, subtotal))
        val taxableBase = round2((subtotal - safeDiscount).coerceAtLeast(0.0))
        val taxAmount = round2(taxableBase * (safeTaxRate / 100.0))
        val grandTotal = round2((taxableBase + taxAmount).coerceAtLeast(0.0))
        return InvoiceCalculation(
            subtotal = subtotal,
            taxRatePercent = safeTaxRate,
            taxAmount = taxAmount,
            discountAmount = safeDiscount,
            grandTotal = grandTotal
        )
    }

    /**
     * Generates a real itemized A4 PDF invoice using native Android [PdfDocument]
     * and writes it to `filesDir/invoices/invoice_<invoiceNumber>.pdf`.
     */
    fun generatePdfInvoice(
        context: Context,
        invoiceNumber: String,
        clientName: String,
        projectTitle: String,
        items: List<InvoiceLineItem>,
        taxRatePercent: Double = 18.0,
        discountAmount: Double = 0.0,
        currency: String = "INR",
        clientEmail: String = "",
        notes: String = "Payment due within 7 days. Thank you for working with Sultan Mirza."
    ): InvoiceRecord {
        EngineRegistry.recordInvocation(123, success = true)
        val safeInvoiceNo = invoiceNumber.trim().ifBlank { "INV-${System.currentTimeMillis().toString().takeLast(6)}" }
        val safeItems = items.ifEmpty { listOf(InvoiceLineItem(projectTitle.ifBlank { "Consulting Services" }, 1, 0.0)) }
        val calc = calculateInvoiceTotals(safeItems, taxRatePercent, discountAmount)
        val issuedDate = SimpleDateFormat("dd MMM yyyy", Locale.US).format(Date())

        val pdfFile = File(
            getInvoicesDir(context),
            "invoice_${safeInvoiceNo.replace(Regex("[^A-Za-z0-9_-]"), "_")}.pdf"
        )

        val document = PdfDocument()
        val nativeSuccess = try {
            // Standard A4 in PostScript points (595 x 842)
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            val headerBgPaint = Paint().apply { color = Color.rgb(15, 23, 42) }
            val accentPaint = Paint().apply { color = Color.rgb(14, 165, 233) }
            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 22f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            }
            val subHeaderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(203, 213, 225)
                textSize = 11f
            }
            val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(15, 23, 42)
                textSize = 13f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            }
            val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(51, 65, 85)
                textSize = 11f
            }
            val dividerPaint = Paint().apply {
                color = Color.rgb(203, 213, 225)
                strokeWidth = 1f
            }

            // Top Banner
            canvas.drawRect(0f, 0f, 595f, 108f, headerBgPaint)
            canvas.drawRect(0f, 104f, 595f, 108f, accentPaint)
            canvas.drawText("SULTAN MIRZA • MUSKAN STUDIO", 40f, 48f, titlePaint)
            canvas.drawText("TAX / PROJECT INVOICE", 40f, 70f, subHeaderPaint)
            canvas.drawText("Invoice #: $safeInvoiceNo", 390f, 48f, subHeaderPaint)
            canvas.drawText("Date: $issuedDate", 390f, 68f, subHeaderPaint)

            // Bill To Block
            var y = 144f
            canvas.drawText("BILL TO", 40f, y, sectionPaint)
            y += 20f
            canvas.drawText(clientName.ifBlank { "Valued Client" }, 40f, y, bodyPaint)
            if (clientEmail.isNotBlank()) {
                y += 16f
                canvas.drawText(clientEmail, 40f, y, bodyPaint)
            }
            y += 18f
            canvas.drawText("Project: ${projectTitle.ifBlank { "Client Engagement" }}", 40f, y, bodyPaint)

            // Table Header
            y += 34f
            canvas.drawLine(40f, y, 555f, y, dividerPaint)
            y += 18f
            canvas.drawText("DESCRIPTION", 42f, y, sectionPaint)
            canvas.drawText("QTY", 330f, y, sectionPaint)
            canvas.drawText("RATE", 395f, y, sectionPaint)
            canvas.drawText("AMOUNT", 480f, y, sectionPaint)
            y += 10f
            canvas.drawLine(40f, y, 555f, y, dividerPaint)

            // Line Items
            for (item in safeItems.take(16)) {
                y += 22f
                canvas.drawText(item.description.take(44), 42f, y, bodyPaint)
                canvas.drawText(item.quantity.toString(), 335f, y, bodyPaint)
                canvas.drawText("$currency ${formatMoney(item.unitPrice)}", 395f, y, bodyPaint)
                canvas.drawText("$currency ${formatMoney(item.lineTotal)}", 480f, y, bodyPaint)
            }

            // Totals Section
            y += 22f
            canvas.drawLine(320f, y, 555f, y, dividerPaint)
            y += 20f
            canvas.drawText("Subtotal:", 340f, y, bodyPaint)
            canvas.drawText("$currency ${formatMoney(calc.subtotal)}", 475f, y, bodyPaint)

            if (calc.discountAmount > 0.0) {
                y += 18f
                canvas.drawText("Discount:", 340f, y, bodyPaint)
                canvas.drawText("-$currency ${formatMoney(calc.discountAmount)}", 475f, y, bodyPaint)
            }

            y += 18f
            canvas.drawText("Tax (${formatMoney(calc.taxRatePercent)}%):", 340f, y, bodyPaint)
            canvas.drawText("$currency ${formatMoney(calc.taxAmount)}", 475f, y, bodyPaint)

            y += 12f
            canvas.drawLine(320f, y, 555f, y, dividerPaint)
            y += 22f
            canvas.drawText("GRAND TOTAL:", 340f, y, sectionPaint)
            canvas.drawText("$currency ${formatMoney(calc.grandTotal)}", 468f, y, sectionPaint)

            // Notes & Footer
            y += 48f
            canvas.drawText("NOTES", 40f, y, sectionPaint)
            y += 18f
            canvas.drawText(notes.take(86), 40f, y, bodyPaint)

            document.finishPage(page)
            FileOutputStream(pdfFile).use { fos ->
                document.writeTo(fos)
            }
            true
        } catch (e: Throwable) {
            Log.w(TAG, "Native PdfDocument unavailable (${e.javaClass.simpleName}); using PDF 1.4 writer fallback")
            false
        } finally {
            runCatching { document.close() }
        }

        if (!nativeSuccess) {
            writeStandardPdf14Invoice(
                outFile = pdfFile,
                invoiceNumber = safeInvoiceNo,
                issuedDate = issuedDate,
                clientName = clientName.ifBlank { "Valued Client" },
                clientEmail = clientEmail,
                projectTitle = projectTitle.ifBlank { "Client Engagement" },
                currency = currency,
                items = safeItems,
                calc = calc,
                notes = notes
            )
        }

        return InvoiceRecord(
            invoiceNumber = safeInvoiceNo,
            clientName = clientName,
            clientEmail = clientEmail,
            projectTitle = projectTitle,
            currency = currency,
            items = safeItems,
            calculation = calc,
            pdfFile = pdfFile,
            issuedDate = issuedDate
        )
    }

    /**
     * Builds a safe `ACTION_SEND` PDF share intent via [FileProvider].
     */
    fun createShareInvoiceIntent(
        context: Context,
        pdfFile: File,
        clientName: String,
        invoiceNumber: String
    ): Intent {
        val uri: Uri = runCatching {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", pdfFile)
        }.getOrElse { Uri.fromFile(pdfFile) }

        return Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Invoice $invoiceNumber — $clientName")
            putExtra(Intent.EXTRA_TEXT, "Please find attached Invoice $invoiceNumber for $clientName.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    /**
     * Natural-language Hindi/Hinglish/English handler for Client CRM and Invoice requests.
     */
    fun handleVoiceBusinessCommand(context: Context, prompt: String): String {
        val lower = prompt.lowercase(Locale.ROOT).trim()

        if (lower.contains("invoice") || lower.contains("bill banao") || lower.contains("इनवॉइस")) {
            val amount = Regex("""(\d+(?:\.\d+)?)""").find(prompt)?.groupValues?.get(1)?.toDoubleOrNull() ?: 15000.0
            val client = Regex("""(?i)(?:for|client|ke liye)\s+([A-Za-z0-9 ]{2,28})""").find(prompt)
                ?.groupValues?.getOrNull(1)?.trim()?.ifBlank { null } ?: "Client"
            val invNo = "INV-${System.currentTimeMillis().toString().takeLast(5)}"
            val record = generatePdfInvoice(
                context = context,
                invoiceNumber = invNo,
                clientName = client,
                projectTitle = "AI & Digital Consulting",
                items = listOf(InvoiceLineItem("Project Delivery & Consulting", 1, amount))
            )
            return "Sultan, $client ke liye PDF invoice ${record.invoiceNumber} (Grand Total: ${record.currency} ${formatMoney(record.calculation.grandTotal)}) '${record.pdfFile.name}' mein save ho gaya hai."
        }

        if (lower.contains("add client") || lower.contains("client add") || lower.contains("naya client") || lower.contains("new project")) {
            val amount = Regex("""(\d+(?:\.\d+)?)""").find(prompt)?.groupValues?.get(1)?.toDoubleOrNull() ?: 25000.0
            val clientName = prompt
                .replace(Regex("(?i)(add client|client add karo|naya client|new project|crm|project|inr|rs|rupees)"), " ")
                .replace(Regex("""\d+(?:\.\d+)?"""), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
                .ifBlank { "New Client" }
            val saved = upsertProject(
                context,
                ClientProject(
                    clientName = clientName,
                    projectTitle = "$clientName Engagement",
                    scope = prompt,
                    totalPrice = amount
                )
            )
            return "Sultan, client '${saved.clientName}' (INR ${formatMoney(saved.totalPrice)}) CRM mein save ho gaya hai."
        }

        return getPipelineSummary(context)
    }

    fun resetForTest(context: Context) {
        _projects.value = emptyList()
        runCatching { getCrmFile(context).delete() }
    }

    private fun saveProjects(context: Context, list: List<ClientProject>) {
        val array = JSONArray()
        list.forEach { array.put(toProjectJson(it)) }
        getCrmFile(context).writeText(array.toString(2), Charsets.UTF_8)
        _projects.value = list
    }

    private fun toProjectJson(p: ClientProject): JSONObject {
        val milestonesArr = JSONArray()
        p.milestones.forEach { m ->
            milestonesArr.put(
                JSONObject().apply {
                    put("title", m.title)
                    put("amount", m.amount)
                    put("completed", m.completed)
                }
            )
        }
        return JSONObject().apply {
            put("id", p.id)
            put("clientName", p.clientName)
            put("clientEmail", p.clientEmail)
            put("clientPhone", p.clientPhone)
            put("projectTitle", p.projectTitle)
            put("scope", p.scope)
            put("currency", p.currency)
            put("totalPrice", p.totalPrice)
            put("milestones", milestonesArr)
            put("status", p.status.name)
            put("createdAt", p.createdAt)
            put("updatedAt", p.updatedAt)
        }
    }

    private fun parseProjectJson(obj: JSONObject): ClientProject {
        val milestones = mutableListOf<ProjectMilestone>()
        val mArr = obj.optJSONArray("milestones")
        if (mArr != null) {
            for (i in 0 until mArr.length()) {
                val m = mArr.optJSONObject(i) ?: continue
                milestones.add(
                    ProjectMilestone(
                        title = m.optString("title"),
                        amount = m.optDouble("amount", 0.0),
                        completed = m.optBoolean("completed", false)
                    )
                )
            }
        }
        val status = runCatching { ProjectStatus.valueOf(obj.optString("status", ProjectStatus.IN_PROGRESS.name)) }
            .getOrDefault(ProjectStatus.IN_PROGRESS)
        return ClientProject(
            id = obj.optString("id"),
            clientName = obj.optString("clientName"),
            clientEmail = obj.optString("clientEmail"),
            clientPhone = obj.optString("clientPhone"),
            projectTitle = obj.optString("projectTitle"),
            scope = obj.optString("scope"),
            currency = obj.optString("currency", "INR"),
            totalPrice = obj.optDouble("totalPrice", 0.0),
            milestones = milestones,
            status = status,
            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
            updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
        )
    }

    private fun writeStandardPdf14Invoice(
        outFile: File,
        invoiceNumber: String,
        issuedDate: String,
        clientName: String,
        clientEmail: String,
        projectTitle: String,
        currency: String,
        items: List<InvoiceLineItem>,
        calc: InvoiceCalculation,
        notes: String
    ) {
        fun esc(s: String): String = s
            .replace("\\", "\\\\")
            .replace("(", "\\(")
            .replace(")", "\\)")
            .replace("\r", " ")
            .replace("\n", " ")

        val lines = buildList {
            add("SULTAN MIRZA - MUSKAN STUDIO | TAX INVOICE")
            add("Invoice #: $invoiceNumber | Date: $issuedDate")
            add("Bill To: $clientName" + if (clientEmail.isNotBlank()) " ($clientEmail)" else "")
            add("Project: $projectTitle")
            add("------------------------------------------------------------")
            items.take(16).forEach { item ->
                add("${item.description.take(36)} | Qty ${item.quantity} | $currency ${formatMoney(item.lineTotal)}")
            }
            add("------------------------------------------------------------")
            add("Subtotal: $currency ${formatMoney(calc.subtotal)}")
            if (calc.discountAmount > 0.0) {
                add("Discount: -$currency ${formatMoney(calc.discountAmount)}")
            }
            add("Tax (${formatMoney(calc.taxRatePercent)}%): $currency ${formatMoney(calc.taxAmount)}")
            add("GRAND TOTAL: $currency ${formatMoney(calc.grandTotal)}")
            add("Notes: ${notes.take(80)}")
        }

        val contentStream = buildString {
            append("BT\n/F1 11 Tf\n40 790 Td\n16 TL\n")
            lines.forEachIndexed { idx, line ->
                if (idx == 0) {
                    append("(${esc(line)}) Tj\n")
                } else {
                    append("T* (${esc(line)}) Tj\n")
                }
            }
            append("ET\n")
        }
        val contentBytes = contentStream.toByteArray(Charsets.US_ASCII)

        val objects = listOf(
            "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n",
            "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n",
            "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>\nendobj\n",
            "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n",
            "5 0 obj\n<< /Length ${contentBytes.size} >>\nstream\n${contentStream}endstream\nendobj\n"
        )

        val sb = StringBuilder("%PDF-1.4\n")
        val offsets = mutableListOf(0)
        for (obj in objects) {
            offsets.add(sb.length)
            sb.append(obj)
        }
        val xrefPos = sb.length
        sb.append("xref\n0 ${objects.size + 1}\n")
        sb.append("0000000000 65535 f \n")
        for (i in 1..objects.size) {
            sb.append(String.format(Locale.US, "%010d 00000 n \n", offsets[i]))
        }
        sb.append("trailer\n<< /Size ${objects.size + 1} /Root 1 0 R >>\n")
        sb.append("startxref\n$xrefPos\n%%EOF\n")
        outFile.writeBytes(sb.toString().toByteArray(Charsets.US_ASCII))
    }

    private fun formatMoney(value: Double): String = String.format(Locale.US, "%.2f", value)
}
