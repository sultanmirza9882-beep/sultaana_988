package com.example.engine.network

import android.content.Context
import android.os.Build
import com.example.automation.ScreenPerceptionEngine
import com.example.automation.UniversalPhoneAgent
import com.example.engine.EngineRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

enum class WebSocketConnectionState(val label: String) {
    DISCONNECTED("DISCONNECTED"),
    CONNECTING("CONNECTING…"),
    CONNECTED("CONNECTED"),
    RECONNECTING("RECONNECTING…"),
    ERROR("ERROR")
}

data class WebSocketLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val direction: String, // "IN" | "OUT" | "SYS"
    val type: String,
    val preview: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class WebSocketBridgeState(
    val isEnabled: Boolean = false,
    val connectionState: WebSocketConnectionState = WebSocketConnectionState.DISCONNECTED,
    val serverUrl: String = "",
    val deviceId: String = "redmi-13-5g-${(Build.MODEL ?: "android").replace(" ", "-").lowercase()}",
    val connectedSince: Long = 0L,
    val reconnectAttempt: Int = 0,
    val messagesSent: Int = 0,
    val messagesReceived: Int = 0,
    val queuedCount: Int = 0,
    val lastPingRttMs: Long = 0L,
    val lastError: String? = null,
    val logs: List<WebSocketLogEntry> = emptyList()
)

/**
 * Full-Duplex WebSocket Integration Bridge for Muskan AI Agent.
 *
 * Features:
 * 1. Persistent OkHttp WebSocket connection with automatic exponential-backoff reconnect.
 * 2. Outbound message queue (buffers up to 100 messages while offline/reconnecting and flushes on connect).
 * 3. Application-level JSON ping/pong heartbeat with live RTT latency tracking.
 * 4. Remote AI Agent Command execution (`{"type":"agent_command","goal":"..."}` -> `UniversalPhoneAgent`).
 * 5. Live Screen Snapshot telemetry (`{"type":"screen_snapshot_request"}` -> `ScreenPerceptionEngine`).
 * 6. Native transport pipe for `WebRtcSignalingManager` (`{"type":"webrtc_signal", ...}`).
 */
object MuskanWebSocketBridge {

    private const val PREFS_NAME = "muskan_websocket_prefs"
    private const val KEY_WS_ENABLED = "ws_enabled"
    private const val KEY_WS_URL = "ws_url"
    private const val KEY_AUTH_TOKEN = "ws_auth_token"
    private const val MAX_QUEUE_SIZE = 100
    private const val MAX_LOG_ENTRIES = 60

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // Full-duplex continuous stream
        .writeTimeout(15, TimeUnit.SECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .build()

    @Volatile private var appContext: Context? = null
    @Volatile private var webSocket: WebSocket? = null
    @Volatile private var authToken: String = ""
    private val userRequestedConnect = AtomicBoolean(false)

    private var reconnectJob: Job? = null
    private var heartbeatJob: Job? = null
    @Volatile private var lastPingSentAt: Long = 0L

    private val outboundQueue = ArrayDeque<String>()

    private val _state = MutableStateFlow(WebSocketBridgeState())
    val state: StateFlow<WebSocketBridgeState> = _state.asStateFlow()

    private fun openPrefs(context: Context) =
        com.example.api.SecurePreferences.openMigrating(context.applicationContext, PREFS_NAME)

    fun init(context: Context) {
        val ctx = context.applicationContext
        appContext = ctx
        val prefs = openPrefs(ctx)
        val savedEnabled = prefs.getBoolean(KEY_WS_ENABLED, false)
        val savedUrl = prefs.getString(KEY_WS_URL, null)
        val savedToken = prefs.getString(KEY_AUTH_TOKEN, null)
        val validatedUrl = savedUrl?.let { runCatching { normalizeWsUrl(it) }.getOrNull() }.orEmpty()
        _state.update {
            it.copy(
                isEnabled = savedEnabled,
                serverUrl = validatedUrl
            )
        }
        if (!savedToken.isNullOrBlank()) {
            authToken = savedToken
        }
    }

    fun setEnabled(context: Context? = appContext, enabled: Boolean) {
        if (context != null) appContext = context.applicationContext
        _state.update { it.copy(isEnabled = enabled, lastError = null) }
        appContext?.let { ctx ->
            openPrefs(ctx).edit().putBoolean(KEY_WS_ENABLED, enabled).apply()
        }
        if (!enabled) {
            disconnect("WebSocket bridge disabled")
        }
    }

    fun configure(context: Context? = appContext, serverUrl: String, bearerToken: String = "") {
        val cleanUrl = normalizeWsUrl(serverUrl)
        authToken = bearerToken.trim()
        _state.update { it.copy(serverUrl = cleanUrl, lastError = null) }
        (context ?: appContext)?.let { ctx ->
            openPrefs(ctx).edit()
                .putString(KEY_WS_URL, cleanUrl)
                .putString(KEY_AUTH_TOKEN, authToken)
                .apply()
        }
    }

    fun normalizeWsUrl(rawUrl: String): String {
        val trimmed = rawUrl.trim()
        return when {
            trimmed.isBlank() -> throw IllegalArgumentException("WebSocket server URL is required (wss://).")
            trimmed.startsWith("ws://", ignoreCase = true) || trimmed.startsWith("http://", ignoreCase = true) ->
                throw IllegalArgumentException("Cleartext ws:// and http:// URLs are rejected. Use secure wss://.")
            trimmed.startsWith("wss://", ignoreCase = true) -> trimmed
            trimmed.startsWith("https://", ignoreCase = true) -> "wss://" + trimmed.substring(8)
            else -> "wss://$trimmed"
        }
    }

    fun connect(context: Context? = appContext, customUrl: String? = null) {
        if (context != null) appContext = context.applicationContext
        if (!_state.value.isEnabled) {
            val msg = "WebSocket bridge is disabled by default. Enable it explicitly with a trusted wss:// server."
            _state.update {
                it.copy(
                    connectionState = WebSocketConnectionState.DISCONNECTED,
                    lastError = msg
                )
            }
            appendLog("SYS", "blocked", msg)
            return
        }
        if (!customUrl.isNullOrBlank()) {
            try {
                configure(appContext, customUrl, authToken)
            } catch (e: IllegalArgumentException) {
                val msg = e.message ?: "Cleartext WebSocket URL rejected."
                _state.update {
                    it.copy(
                        connectionState = WebSocketConnectionState.ERROR,
                        lastError = msg
                    )
                }
                appendLog("SYS", "error", msg)
                return
            }
        }
        val activeUrl = _state.value.serverUrl
        val validatedUrl = try {
            normalizeWsUrl(activeUrl)
        } catch (e: IllegalArgumentException) {
            val msg = e.message ?: "A valid wss:// URL is required."
            _state.update {
                it.copy(
                    connectionState = WebSocketConnectionState.ERROR,
                    lastError = msg
                )
            }
            appendLog("SYS", "error", msg)
            return
        }
        if (validatedUrl != activeUrl) {
            _state.update { it.copy(serverUrl = validatedUrl) }
        }
        userRequestedConnect.set(true)
        reconnectJob?.cancel()
        openSocket(isReconnect = false)
    }

    fun disconnect(reason: String = "Client disconnected") {
        userRequestedConnect.set(false)
        reconnectJob?.cancel()
        heartbeatJob?.cancel()
        try {
            webSocket?.close(1000, reason)
        } catch (_: Exception) {}
        webSocket = null
        _state.update {
            it.copy(
                connectionState = WebSocketConnectionState.DISCONNECTED,
                connectedSince = 0L,
                reconnectAttempt = 0
            )
        }
        appendLog("SYS", "disconnect", reason)
    }

    private fun openSocket(isReconnect: Boolean) {
        val url = _state.value.serverUrl
        if (!url.startsWith("wss://", ignoreCase = true)) {
            val msg = "Refused non-TLS WebSocket connection: only wss:// is permitted."
            _state.update {
                it.copy(
                    connectionState = WebSocketConnectionState.ERROR,
                    lastError = msg
                )
            }
            appendLog("SYS", "error", msg)
            return
        }
        try {
            webSocket?.cancel()
        } catch (_: Exception) {}

        _state.update {
            it.copy(
                connectionState = if (isReconnect) WebSocketConnectionState.RECONNECTING else WebSocketConnectionState.CONNECTING,
                lastError = null
            )
        }
        appendLog("SYS", "connect", "Opening WebSocket -> $url")

        val reqBuilder = Request.Builder().url(url)
            .header("X-Device-Id", _state.value.deviceId)
            .header("X-Client-Agent", "Muskan-Universal-Agent-v9")
        if (authToken.isNotBlank()) {
            reqBuilder.header("Authorization", "Bearer $authToken")
        }

        val req = try {
            reqBuilder.build()
        } catch (e: Exception) {
            _state.update {
                it.copy(
                    connectionState = WebSocketConnectionState.ERROR,
                    lastError = "Invalid WebSocket URL: ${e.message}"
                )
            }
            appendLog("SYS", "error", "Invalid URL: ${e.message}")
            return
        }

        webSocket = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                EngineRegistry.recordInvocation(64, true)
                _state.update {
                    it.copy(
                        connectionState = WebSocketConnectionState.CONNECTED,
                        connectedSince = System.currentTimeMillis(),
                        reconnectAttempt = 0,
                        lastError = null
                    )
                }
                appendLog("SYS", "open", "Connected (HTTP ${response.code})")
                sendHandshake()
                flushOutboundQueue(ws)
                startHeartbeatLoop()
            }

            override fun onMessage(ws: WebSocket, text: String) {
                _state.update { it.copy(messagesReceived = it.messagesReceived + 1) }
                handleIncomingMessage(text)
            }

            override fun onClosing(ws: WebSocket, code: Int, reason: String) {
                ws.close(1000, null)
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                heartbeatJob?.cancel()
                appendLog("SYS", "closed", "Code $code: ${reason.ifBlank { "Closed" }}")
                if (userRequestedConnect.get()) {
                    scheduleReconnect()
                } else {
                    _state.update {
                        it.copy(
                            connectionState = WebSocketConnectionState.DISCONNECTED,
                            connectedSince = 0L
                        )
                    }
                }
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                heartbeatJob?.cancel()
                EngineRegistry.recordInvocation(64, false)
                val err = t.message ?: "WebSocket transport failure"
                _state.update {
                    it.copy(
                        connectionState = if (userRequestedConnect.get()) WebSocketConnectionState.RECONNECTING else WebSocketConnectionState.ERROR,
                        lastError = err
                    )
                }
                appendLog("SYS", "failure", err)
                if (userRequestedConnect.get()) {
                    scheduleReconnect()
                }
            }
        })
    }

    private fun scheduleReconnect() {
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            val nextAttempt = _state.value.reconnectAttempt + 1
            val backoffMs = (1000L * (1L shl nextAttempt.coerceAtMost(5))).coerceAtMost(30_000L)
            _state.update {
                it.copy(
                    connectionState = WebSocketConnectionState.RECONNECTING,
                    reconnectAttempt = nextAttempt
                )
            }
            delay(backoffMs)
            if (userRequestedConnect.get()) {
                openSocket(isReconnect = true)
            }
        }
    }

    private fun startHeartbeatLoop() {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive && _state.value.connectionState == WebSocketConnectionState.CONNECTED) {
                delay(20_000L)
                lastPingSentAt = System.currentTimeMillis()
                val ping = JSONObject()
                    .put("type", "ping")
                    .put("deviceId", _state.value.deviceId)
                    .put("ts", lastPingSentAt)
                sendRawJson(ping)
            }
        }
    }

    private fun sendHandshake() {
        val hello = JSONObject()
            .put("type", "device_hello")
            .put("deviceId", _state.value.deviceId)
            .put("manufacturer", Build.MANUFACTURER ?: "android")
            .put("model", Build.MODEL ?: "android")
            .put("sdkInt", Build.VERSION.SDK_INT)
            .put("capabilities", JSONArray(listOf("universal_phone_agent", "screen_snapshot", "webrtc_signaling")))
            .put("ts", System.currentTimeMillis())
        sendRawJson(hello)
    }

    /**
     * Sends a JSON payload over the active WebSocket, or queues it in memory if currently disconnected/reconnecting.
     */
    fun sendRawJson(json: JSONObject): Boolean {
        return sendText(json.toString(), json.optString("type", "json"))
    }

    fun sendText(payload: String, logType: String = "message"): Boolean {
        val ws = webSocket
        val isConnected = _state.value.connectionState == WebSocketConnectionState.CONNECTED && ws != null
        return if (isConnected) {
            val sent = try { ws!!.send(payload) } catch (_: Exception) { false }
            if (sent) {
                _state.update { it.copy(messagesSent = it.messagesSent + 1) }
                appendLog("OUT", logType, payload.take(120))
                true
            } else {
                enqueueMessage(payload, logType)
                false
            }
        } else {
            enqueueMessage(payload, logType)
            false
        }
    }

    @Synchronized
    private fun enqueueMessage(payload: String, logType: String) {
        if (outboundQueue.size >= MAX_QUEUE_SIZE) {
            outboundQueue.pollFirst()
        }
        outboundQueue.addLast(payload)
        _state.update { it.copy(queuedCount = outboundQueue.size) }
        appendLog("SYS", "queued:$logType", "Queued (${outboundQueue.size} pending): ${payload.take(80)}")
    }

    @Synchronized
    private fun flushOutboundQueue(ws: WebSocket) {
        while (outboundQueue.isNotEmpty()) {
            val msg = outboundQueue.pollFirst() ?: break
            try {
                if (ws.send(msg)) {
                    _state.update { it.copy(messagesSent = it.messagesSent + 1) }
                }
            } catch (_: Exception) {
                break
            }
        }
        _state.update { it.copy(queuedCount = outboundQueue.size) }
    }

    @Synchronized
    fun clearQueue() {
        outboundQueue.clear()
        _state.update { it.copy(queuedCount = 0) }
    }

    /**
     * Parses and routes incoming WebSocket messages (JSON envelopes or plain text).
     * Publicly exposed so unit tests and loopback diagnostics can inject envelopes deterministically.
     */
    fun handleIncomingMessage(rawText: String) {
        val trimmed = rawText.trim()
        if (!trimmed.startsWith("{") || !trimmed.endsWith("}")) {
            appendLog("IN", "text", trimmed.take(120))
            return
        }
        val json = try {
            JSONObject(trimmed)
        } catch (_: Exception) {
            appendLog("IN", "raw", trimmed.take(120))
            return
        }

        val type = json.optString("type", "unknown").lowercase()
        appendLog("IN", type, trimmed.take(140))

        when (type) {
            "ping" -> {
                val pong = JSONObject()
                    .put("type", "pong")
                    .put("deviceId", _state.value.deviceId)
                    .put("echoTs", json.optLong("ts", System.currentTimeMillis()))
                    .put("ts", System.currentTimeMillis())
                sendRawJson(pong)
            }
            "pong" -> {
                val echoTs = json.optLong("echoTs", lastPingSentAt)
                if (echoTs > 0L) {
                    val rtt = (System.currentTimeMillis() - echoTs).coerceAtLeast(1L)
                    _state.update { it.copy(lastPingRttMs = rtt) }
                }
            }
            "webrtc_signal" -> {
                WebRtcSignalingManager.onSignalEnvelopeReceived(json)
            }
            "screen_snapshot_request" -> {
                if (!_state.value.isEnabled || authToken.isBlank()) {
                    appendLog("SYS", "blocked", "Rejected unauthorized screen_snapshot_request.")
                    return
                }
                val snap = ScreenPerceptionEngine.captureScreenSnapshot()
                val elementsArr = JSONArray()
                snap.clickableElements.take(40).forEach { el ->
                    elementsArr.put(
                        JSONObject()
                            .put("text", el.text)
                            .put("desc", el.contentDescription)
                            .put("bounds", el.boundsString)
                    )
                }
                val reply = JSONObject()
                    .put("type", "screen_snapshot")
                    .put("deviceId", _state.value.deviceId)
                    .put("foregroundPackage", snap.foregroundPackage)
                    .put("isKeyboardVisible", snap.isKeyboardVisible)
                    .put("elementsCount", snap.totalElementsObserved)
                    .put("elements", elementsArr)
                    .put("ts", System.currentTimeMillis())
                sendRawJson(reply)
            }
            "agent_command" -> {
                if (!_state.value.isEnabled || authToken.isBlank()) {
                    appendLog("SYS", "blocked", "Rejected unauthorized remote agent_command.")
                    return
                }
                val goal = json.optString("goal").ifBlank { json.optString("command") }.trim()
                val requestId = json.optString("requestId", UUID.randomUUID().toString())
                val ctx = appContext
                if (goal.isNotBlank() && ctx != null) {
                    sendRawJson(
                        JSONObject()
                            .put("type", "agent_ack")
                            .put("requestId", requestId)
                            .put("goal", goal)
                            .put("status", "started")
                    )
                    UniversalPhoneAgent.start(ctx, goal) { success, feedback ->
                        sendRawJson(
                            JSONObject()
                                .put("type", "agent_result")
                                .put("requestId", requestId)
                                .put("goal", goal)
                                .put("success", success)
                                .put("message", feedback)
                                .put("ts", System.currentTimeMillis())
                        )
                    }
                }
            }
        }
    }

    private fun appendLog(direction: String, type: String, preview: String) {
        val entry = WebSocketLogEntry(direction = direction, type = type, preview = preview)
        _state.update { current ->
            current.copy(logs = (current.logs + entry).takeLast(MAX_LOG_ENTRIES))
        }
    }
}
