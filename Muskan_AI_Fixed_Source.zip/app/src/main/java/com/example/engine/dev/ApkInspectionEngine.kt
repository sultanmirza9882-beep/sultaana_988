package com.example.engine.dev

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.util.zip.ZipInputStream

/**
 * Engine for inspecting Android Package (APK) files on device.
 * Analyzes DEX bytecode entries, native ABI architectures, resources,
 * and signature manifests while clearly articulating on-device decompilation limitations.
 */
object ApkInspectionEngine {

    data class ApkMetadata(
        val packageName: String? = null,
        val versionName: String? = null,
        val versionCode: Long = 0L,
        val minSdk: Int = 0,
        val targetSdk: Int = 0,
        val permissions: List<String> = emptyList()
    )

    data class ApkZipEntries(
        val dexFileNames: List<String> = emptyList(),
        val nativeAbis: List<String> = emptyList(),
        val resourceEntryCount: Int = 0,
        val signatureFiles: List<String> = emptyList(),
        val totalEntries: Int = 0
    )

    data class DeviceLimitations(
        val decompilationSupportedOnDevice: Boolean = false,
        val decompilationExplanation: String = "Compiled Android bytecode (.dex) cannot be reliably decompiled back into original Kotlin source code directly on device.",
        val signingRequirement: String = "APK packaging and installation requires cryptographic signing via keystore."
    )

    data class ApkInspectionReport(
        val isSuccess: Boolean,
        val message: String,
        val metadata: ApkMetadata? = null,
        val entries: ApkZipEntries? = null,
        val limitations: DeviceLimitations = DeviceLimitations()
    )

    suspend fun inspectApk(context: Context, apkFile: File): ApkInspectionReport = withContext(Dispatchers.IO) {
        if (!apkFile.exists() || apkFile.length() <= 0L) {
            return@withContext ApkInspectionReport(
                isSuccess = false,
                message = "APK file '${apkFile.name}' does not exist or is empty."
            )
        }

        val dexNames = mutableListOf<String>()
        val abis = mutableSetOf<String>()
        var resCount = 0
        val sigFiles = mutableListOf<String>()
        var totalEntries = 0

        try {
            ZipInputStream(FileInputStream(apkFile)).use { zis ->
                while (true) {
                    val entry = zis.nextEntry ?: break
                    totalEntries++
                    val name = entry.name
                    if (name.endsWith(".dex", ignoreCase = true)) {
                        dexNames.add(name.substringAfterLast('/'))
                    } else if (name.startsWith("lib/") && "/" in name.substring(4)) {
                        val abi = name.substring(4).substringBefore('/')
                        if (abi.isNotBlank()) abis.add(abi)
                    } else if (name.startsWith("res/") || name == "resources.arsc") {
                        resCount++
                    } else if (name.startsWith("META-INF/") && (name.endsWith(".RSA") || name.endsWith(".DSA") || name.endsWith(".EC") || name.endsWith(".SF"))) {
                        sigFiles.add(name.substringAfterLast('/'))
                    }
                    zis.closeEntry()
                }
            }
        } catch (e: Exception) {
            return@withContext ApkInspectionReport(
                isSuccess = false,
                message = "Failed reading APK archive: ${e.message}"
            )
        }

        val pm = context.packageManager
        val pkgInfo = runCatching {
            pm.getPackageArchiveInfo(apkFile.absolutePath, PackageManager.GET_PERMISSIONS)
        }.getOrNull()

        val metadata = ApkMetadata(
            packageName = pkgInfo?.packageName ?: "Unknown",
            versionName = pkgInfo?.versionName ?: "1.0",
            versionCode = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                pkgInfo?.longVersionCode ?: 1L
            } else {
                @Suppress("DEPRECATION")
                (pkgInfo?.versionCode?.toLong() ?: 1L)
            },
            permissions = pkgInfo?.requestedPermissions?.toList() ?: emptyList()
        )

        val entries = ApkZipEntries(
            dexFileNames = dexNames,
            nativeAbis = abis.toList(),
            resourceEntryCount = resCount,
            signatureFiles = sigFiles,
            totalEntries = totalEntries
        )

        ApkInspectionReport(
            isSuccess = true,
            message = "APK inspected successfully: ${apkFile.name} (${metadata.packageName})",
            metadata = metadata,
            entries = entries
        )
    }
}
