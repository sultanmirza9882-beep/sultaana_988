package com.example.engine

import com.example.engine.approval.ApprovalProposal
import com.example.engine.approval.OwnerApprovalGate
import com.example.engine.approval.ProposalCategory
import com.example.engine.emotion.EmotionalAcousticProfile
import com.example.engine.emotion.EmotionalIntelligenceEngine
import com.example.engine.selfimprovement.SelfImprovementEngine
import com.example.engine.tools.ToolRegistryEngine
import java.util.Locale

/**
 * Central Engine Orchestrator:
 * Inspects prompt intent, routes task-specific subset of engines (minimizing latency & power),
 * executes emotional intelligence tuning, evaluates safety/approval gates, and tracks metrics.
 */
object EngineOrchestrator {

    fun orchestrate(prompt: String): OrchestrationDecision {
        val lower = prompt.lowercase(Locale.ROOT).trim()

        // 1. Analyze Emotional Tone via EmotionalIntelligenceEngine (Engine 51)
        val emotionalProfile = EmotionalIntelligenceEngine.analyzeSentiment(prompt)

        // 2. Classify task type and select dedicated engine subset
        val selectedEngineIds = mutableListOf<Int>()
        var rationale = ""
        var requiresApproval = false
        val matchedTools = mutableListOf<String>()

        // Core foundational engines always active in minimal loop
        selectedEngineIds.addAll(listOf(1, 2, 5, 10, 11)) // Reasoning, Intent, Context, Orchestration, Response

        when {
            // A. Microphone / Audio Diagnostics Request
            lower.contains("mic") || lower.contains("microphone") || lower.contains("audio") ||
            lower.contains("awaz") || lower.contains("volume") || lower.contains("sound") -> {
                selectedEngineIds.addAll(listOf(37, 40, 41, 54, 83)) // Mic Input, Streaming, VAD, Latency, Audio Diagnostics
                matchedTools.add("tool_audio_diagnostics")
                rationale = "Invoked Audio Diagnostics & Acoustic Stream engines to inspect microphone signal and noise floor."
                EngineRegistry.recordInvocation(83)
            }

            // B. Phone Automation Request (WhatsApp, YouTube, Screen tap/read)
            lower.contains("whatsapp") || lower.contains("message") || lower.contains("youtube") ||
            lower.contains("click") || lower.contains("scroll") || lower.contains("screen") -> {
                selectedEngineIds.addAll(listOf(92, 93, 94, 95, 98, 103, 104)) // Screen Perception, OCR, Actions, Navigation, Approval
                if (lower.contains("whatsapp") || lower.contains("bhejo") || lower.contains("send")) {
                    matchedTools.add("tool_whatsapp_compose")
                    requiresApproval = true
                }
                if (lower.contains("youtube")) {
                    matchedTools.add("tool_youtube_search")
                }
                rationale = "Routed to Phone Interaction & Accessibility engines with human confirmation gate."
                EngineRegistry.recordInvocation(94)
            }

            // C. Coding, Compilation, or Architecture Task
            lower.contains("code") || lower.contains("build") || lower.contains("compile") ||
            lower.contains("debug") || lower.contains("gradle") || lower.contains("test") -> {
                selectedEngineIds.addAll(listOf(55, 56, 57, 60, 61, 68, 85, 128)) // Code Gen, AST, Edit, Bug Detect, Build, CI
                rationale = "Activated Software Engineering & Android Build engines for code inspection and repair."
                EngineRegistry.recordInvocation(85)
            }

            // D. Research or Search Inquiries
            lower.contains("search") || lower.contains("google") || lower.contains("kya hai") ||
            lower.contains("who is") || lower.contains("what is") || lower.contains("tell me about") -> {
                selectedEngineIds.addAll(listOf(13, 14, 18, 20, 24)) // Web Search, Deep Research, Verification, Summary, Cache
                rationale = "Dispatched Search & Fact Verification engines for live knowledge retrieval."
                EngineRegistry.recordInvocation(13)
            }

            // E. Memory, Facts, or History Inquiries
            lower.contains("yaad") || lower.contains("remember") || lower.contains("memory") ||
            lower.contains("history") || lower.contains("preference") -> {
                selectedEngineIds.addAll(listOf(6, 7, 25, 26, 27, 31, 35)) // Memory Retrieval, Knowledge, Short/Long Memory, Graph, Quality
                matchedTools.add("tool_memory_export")
                rationale = "Consulted Room SQLite Persistent Memory & Knowledge Graph engines."
                EngineRegistry.recordInvocation(26)
            }

            // F. UIController & Modular Dashboard Request
            lower.contains("widget") || lower.contains("dashboard") || lower.contains("container") || lower.contains("modular") -> {
                selectedEngineIds.addAll(listOf(66, 81, 82)) // UI Development, Project Modification, Android UI Repair
                matchedTools.add("tool_ui_controller")
                rationale = "Routed to UIController & Modular HUD engines to dynamically add, remove, or modify dashboard components."
                EngineRegistry.recordInvocation(66)
            }

            // G. Standard Conversational Turn
            else -> {
                selectedEngineIds.addAll(listOf(3, 4, 25, 48, 50, 51)) // NLU, Planning, Short-term, Voice Personality, Multilingual, Emotion
                rationale = "Standard conversational turn routed through Voice Personality and Gemini 3.5 Flash."
            }
        }

        // Record invocations across active engines
        selectedEngineIds.forEach { id ->
            EngineRegistry.recordInvocation(id, success = true)
        }

        return OrchestrationDecision(
            selectedEngineIds = selectedEngineIds.distinct(),
            rationale = rationale,
            requiresApproval = requiresApproval,
            estimatedLatencyMs = (40L + (selectedEngineIds.size * 5L)),
            emotionalTone = "${emotionalProfile.sentiment.name} (${if (emotionalProfile.conciseMode) "Concise" else "Warm"})",
            matchedTools = matchedTools
        )
    }

    /**
     * Synthesizes self-improvement proposal when an unsupported or failed command is encountered.
     */
    fun reportCapabilityGap(unsupportedQuery: String) {
        SelfImprovementEngine.recordCapabilityGap(
            domain = "Intent: '$unsupportedQuery'",
            description = "User query could not be mapped to existing automation tool or native phone action.",
            solution = "Generate specialized agentic execution workflow and request owner approval.",
            priority = "HIGH"
        )
    }
}
