package com.example.engine.backup

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.local.ConversationTurnEntity
import com.example.data.local.UserMemoryEntity
import com.example.ui.controller.MuskanUIController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Google Drive Backup & Cloud Sync Engine.
 * Linked to Sultan Mirza's verified Google account: sultaan.m33@gmail.com.
 * Automatically bundles persistent Room memories, learned procedures, and conversation history
 * for scheduled daily backup and seamless restore after reinstall or update.
 */
object GoogleDriveBackupEngine {

    private const val TAG = "DriveBackupEngine"
    const val TARGET_ACCOUNT = "configured-google-account"
    private const val PREFS_NAME = "muskan_drive_backup_prefs"
    private const val KEY_LAST_BACKUP_TIME = "last_backup_timestamp"
    private const val KEY_AUTO_SYNC_ENABLED = "auto_sync_enabled"
    private const val KEY_TARGET_ACCOUNT = "target_google_account"

    fun setTargetAccount(context: Context, email: String?) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (email.isNullOrBlank()) prefs.edit().remove(KEY_TARGET_ACCOUNT).apply()
        else prefs.edit().putString(KEY_TARGET_ACCOUNT, email.trim()).apply()
    }

    fun getTargetAccount(context: Context): String {
        val saved = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_TARGET_ACCOUNT, null)
        return saved?.takeIf { it.isNotBlank() } ?: TARGET_ACCOUNT
    }

    data class BackupMetadata(
        val lastBackupTime: Long = 0L,
        val totalMemoriesCount: Int = 0,
        val totalTurnsCount: Int = 0,
        val backupSizeBytes: Long = 0L,
        val isAutoSyncActive: Boolean = true,
        val statusMessage: String = "Ready for Google Drive backup"
    )

    private val _metadataFlow = MutableStateFlow(BackupMetadata())
    val metadataFlow: StateFlow<BackupMetadata> = _metadataFlow.asStateFlow()

    fun initialize(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val lastTime = prefs.getLong(KEY_LAST_BACKUP_TIME, 0L)
        val autoSync = prefs.getBoolean(KEY_AUTO_SYNC_ENABLED, true)
        _metadataFlow.value = _metadataFlow.value.copy(
            lastBackupTime = lastTime,
            isAutoSyncActive = autoSync
        )
    }

    fun setAutoSyncEnabled(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_AUTO_SYNC_ENABLED, enabled).apply()
        _metadataFlow.value = _metadataFlow.value.copy(isAutoSyncActive = enabled)
    }

    /**
     * Builds a comprehensive JSON backup payload of all persistent memories and turns.
     */
    suspend fun generateBackupJson(context: Context): String = withContext(Dispatchers.IO) {
        val db = AppDatabase.getDatabase(context)
        val memories = db.userMemoryDao().getAllMemories()
        val turns = db.conversationTurnDao().getAllTurns()

        val root = JSONObject()
        root.put("app", "Muskan Autonomous AI Assistant")
        root.put("version", "2.0")
        root.put("owner", "Sultan Mirza")
        root.put("googleAccount", getTargetAccount(context))
        root.put("exportTimestamp", System.currentTimeMillis())
        root.put("formattedDate", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))

        // Memories array
        val memArray = JSONArray()
        for (m in memories) {
            val item = JSONObject()
            item.put("category", m.category)
            item.put("title", m.title)
            item.put("detail", m.detail)
            item.put("timestamp", m.timestamp)
            item.put("isPinned", m.isPinned)
            memArray.put(item)
        }
        root.put("userMemories", memArray)

        // Conversation history array
        val turnsArray = JSONArray()
        for (t in turns.take(500)) { // Preserve up to 500 recent turns
            val item = JSONObject()
            item.put("timestamp", t.timestamp)
            item.put("userQuery", t.userQuery)
            item.put("assistantResponse", t.assistantResponse)
            item.put("isAutomationAction", t.isAutomationAction)
            item.put("actionTag", t.actionTag)
            turnsArray.put(item)
        }
        root.put("conversationTurns", turnsArray)

        // Modular UI snapshot count
        root.put("containersCount", MuskanUIController.containersFlow.value.size)

        return@withContext root.toString(2)
    }

    /**
     * Creates an Intent to launch Android's Storage Access Framework for saving
     * the backup JSON file directly to Google Drive.
     */
    fun createDriveSaveIntent(): Intent {
        val dateSuffix = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
        val fileName = "muskan_backup_$dateSuffix.json"
        return Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, fileName)
        }
    }

    /**
     * Creates an Intent to open a backup file from Google Drive for restoration.
     */
    fun createDriveRestoreIntent(): Intent {
        return Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/plain"))
        }
    }

    /**
     * Writes the backup JSON payload to an OutputStream (e.g. from Google Drive SAF uri).
     */
    suspend fun writeBackupToStream(context: Context, outputStream: OutputStream): Boolean = withContext(Dispatchers.IO) {
        try {
            val json = generateBackupJson(context)
            outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }

            val now = System.currentTimeMillis()
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putLong(KEY_LAST_BACKUP_TIME, now)
                .apply()

            val db = AppDatabase.getDatabase(context)
            val count = db.userMemoryDao().getAllMemories().size

            _metadataFlow.value = _metadataFlow.value.copy(
                lastBackupTime = now,
                totalMemoriesCount = count,
                backupSizeBytes = json.length.toLong(),
                statusMessage = "Backup saved successfully (${getTargetAccount(context)})"
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed writing backup to Google Drive stream", e)
            _metadataFlow.value = _metadataFlow.value.copy(statusMessage = "Backup failed: ${e.message}")
            false
        }
    }

    /**
     * Reads a backup JSON payload from an InputStream (e.g. from Google Drive SAF uri)
     * and restores all memories and conversation turns into Room Database.
     */
    suspend fun restoreFromStream(context: Context, inputStream: InputStream): Boolean = withContext(Dispatchers.IO) {
        try {
            val jsonStr = inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(jsonStr)

            val db = AppDatabase.getDatabase(context)
            val memoryDao = db.userMemoryDao()
            val turnsDao = db.conversationTurnDao()

            var restoredMemoriesCount = 0
            if (root.has("userMemories")) {
                val memArray = root.getJSONArray("userMemories")
                for (i in 0 until memArray.length()) {
                    val obj = memArray.getJSONObject(i)
                    val memory = UserMemoryEntity(
                        category = obj.optString("category", "CUSTOM"),
                        title = obj.optString("title", "Restored Fact"),
                        detail = obj.optString("detail", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        isPinned = obj.optBoolean("isPinned", false)
                    )
                    memoryDao.insertMemory(memory)
                    restoredMemoriesCount++
                }
            }

            var restoredTurnsCount = 0
            if (root.has("conversationTurns")) {
                val turnsArray = root.getJSONArray("conversationTurns")
                for (i in 0 until turnsArray.length()) {
                    val obj = turnsArray.getJSONObject(i)
                    val turn = ConversationTurnEntity(
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        userQuery = obj.optString("userQuery", obj.optString("prompt", "")),
                        assistantResponse = obj.optString("assistantResponse", obj.optString("response", "")),
                        isAutomationAction = obj.optBoolean("isAutomationAction", obj.optBoolean("isAutomation", false)),
                        actionTag = obj.optString("actionTag", "Restored")
                    )
                    turnsDao.insertTurn(turn)
                    restoredTurnsCount++
                }
            }

            _metadataFlow.value = _metadataFlow.value.copy(
                totalMemoriesCount = memoryDao.getAllMemories().size,
                statusMessage = "Successfully restored $restoredMemoriesCount memories & $restoredTurnsCount turns from Drive"
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed restoring from Google Drive backup", e)
            _metadataFlow.value = _metadataFlow.value.copy(statusMessage = "Restore failed: ${e.message}")
            false
        }
    }

    /**
     * Performs an automatic local cache sync for daily backup persistence.
     */
    suspend fun performDailyAutoSync(context: Context) = withContext(Dispatchers.IO) {
        try {
            val backupDir = File(context.filesDir, "drive_backup")
            if (!backupDir.exists()) backupDir.mkdirs()
            val backupFile = File(backupDir, "daily_muskan_drive_snapshot.json")
            val json = generateBackupJson(context)
            backupFile.writeText(json, Charsets.UTF_8)
            Log.i(TAG, "Daily auto-sync completed at ${backupFile.absolutePath}")
        } catch (e: Exception) {
            Log.e(TAG, "Error in daily auto-sync", e)
        }
    }

    /**
     * Direct Google Drive REST API v3 multipart upload when an OAuth2 Bearer token is provided.
     * Falls back cleanly without throwing if network or token is unavailable.
     */
    suspend fun uploadBackupToDriveApi(context: Context, oauthAccessToken: String): Boolean = withContext(Dispatchers.IO) {
        val token = oauthAccessToken.trim()
        if (token.isBlank()) {
            _metadataFlow.value = _metadataFlow.value.copy(
                statusMessage = "Google Drive OAuth2 token not configured; use SAF file export."
            )
            return@withContext false
        }
        try {
            val json = generateBackupJson(context)
            val dateSuffix = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
            val boundary = "muskan_drive_boundary_${System.currentTimeMillis()}"
            val metadataJson = JSONObject()
                .put("name", "muskan_backup_$dateSuffix.json")
                .put("mimeType", "application/json")
                .toString()

            val multipartBody = buildString {
                append("--").append(boundary).append("
")
                append("Content-Type: application/json; charset=UTF-8

")
                append(metadataJson).append("
")
                append("--").append(boundary).append("
")
                append("Content-Type: application/json; charset=UTF-8

")
                append(json).append("
")
                append("--").append(boundary).append("--")
            }

            val client = OkHttpClient()
            val request = Request.Builder()
                .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart")
                .addHeader("Authorization", "Bearer $token")
                .post(multipartBody.toRequestBody("multipart/related; boundary=$boundary".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    _metadataFlow.value = _metadataFlow.value.copy(
                        statusMessage = "Drive API upload failed (HTTP ${response.code})."
                    )
                    return@withContext false
                }
            }

            val now = System.currentTimeMillis()
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putLong(KEY_LAST_BACKUP_TIME, now)
                .apply()

            _metadataFlow.value = _metadataFlow.value.copy(
                lastBackupTime = now,
                backupSizeBytes = json.length.toLong(),
                statusMessage = "Cloud backup uploaded via Google Drive API v3"
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "Direct Google Drive API upload failed", e)
            _metadataFlow.value = _metadataFlow.value.copy(
                statusMessage = "Drive API upload error: ${e.message}"
            )
            false
        }
    }
}
