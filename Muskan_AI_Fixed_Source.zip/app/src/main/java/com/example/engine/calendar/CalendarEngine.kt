package com.example.engine.calendar

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.CalendarContract
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.engine.EngineRegistry
import com.example.engine.approval.OwnerApprovalGate
import com.example.engine.approval.SensitiveActionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class CalendarEvent(
    val id: Long,
    val calendarId: Long,
    val title: String,
    val description: String = "",
    val startMillis: Long,
    val endMillis: Long,
    val location: String = "",
    val allDay: Boolean = false
)

data class AvailabilityResult(
    val isAvailable: Boolean,
    val conflictingEvents: List<CalendarEvent>,
    val summary: String,
    val missingPermission: Boolean = false
)

data class CalendarOperationResult(
    val success: Boolean,
    val eventId: Long? = null,
    val usedIntentFallback: Boolean = false,
    val approvalDenied: Boolean = false,
    val message: String
)

/**
 * Module 09: Calendar & Appointment Engine.
 * Integrates directly with Android [CalendarContract.Events] and [CalendarContract.Instances]
 * (automatically synced with Google Calendar on-device) while gating all mutating operations
 * (create, reschedule, delete) behind [OwnerApprovalGate].
 */
object CalendarEngine {

    private const val TAG = "CalendarEngine"
    private const val ONE_HOUR_MS = 60L * 60L * 1000L
    private const val ONE_DAY_MS = 24L * ONE_HOUR_MS

    fun hasReadPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

    fun hasWritePermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

    /**
     * Pure interval-overlap conflict detector: two half-open intervals [aStart, aEnd)
     * and [bStart, bEnd) conflict iff aStart < bEnd && aEnd > bStart.
     */
    fun findConflictingEvents(
        events: List<CalendarEvent>,
        startMillis: Long,
        endMillis: Long
    ): List<CalendarEvent> {
        if (endMillis <= startMillis) return emptyList()
        return events.filter { event ->
            val evEnd = if (event.endMillis > event.startMillis) event.endMillis else event.startMillis + ONE_HOUR_MS
            event.startMillis < endMillis && evEnd > startMillis
        }.sortedBy { it.startMillis }
    }

    /**
     * Lists upcoming calendar events over the next [daysAhead] days using [CalendarContract.Instances].
     * Returns an empty list gracefully if [Manifest.permission.READ_CALENDAR] is not granted.
     */
    suspend fun listUpcomingEvents(
        context: Context,
        daysAhead: Int = 7,
        fromMillis: Long = System.currentTimeMillis()
    ): List<CalendarEvent> = withContext(Dispatchers.IO) {
        EngineRegistry.recordInvocation(122, success = true)
        if (!hasReadPermission(context)) {
            Log.w(TAG, "READ_CALENDAR permission not granted; returning empty event list.")
            return@withContext emptyList()
        }
        val clampedDays = daysAhead.coerceIn(1, 90)
        val endMillis = fromMillis + clampedDays * ONE_DAY_MS
        queryInstancesInRange(context, fromMillis, endMillis)
    }

    /**
     * Checks availability for [startMillis]..[endMillis] and reports any overlapping events.
     */
    suspend fun checkAvailability(
        context: Context,
        startMillis: Long,
        endMillis: Long
    ): AvailabilityResult = withContext(Dispatchers.IO) {
        EngineRegistry.recordInvocation(122, success = true)
        if (endMillis <= startMillis) {
            return@withContext AvailabilityResult(
                isAvailable = false,
                conflictingEvents = emptyList(),
                summary = "Invalid time window: end time must be after start time."
            )
        }
        if (!hasReadPermission(context)) {
            return@withContext AvailabilityResult(
                isAvailable = true,
                conflictingEvents = emptyList(),
                summary = "Calendar read permission not granted; conflict check skipped.",
                missingPermission = true
            )
        }
        val windowEvents = queryInstancesInRange(context, startMillis - ONE_DAY_MS, endMillis + ONE_DAY_MS)
        val conflicts = findConflictingEvents(windowEvents, startMillis, endMillis)
        if (conflicts.isEmpty()) {
            AvailabilityResult(
                isAvailable = true,
                conflictingEvents = emptyList(),
                summary = "Slot bilkul free hai (${formatTimeRange(startMillis, endMillis)})."
            )
        } else {
            val names = conflicts.joinToString(", ") { "'${it.title}' (${formatShortTime(it.startMillis)})" }
            AvailabilityResult(
                isAvailable = false,
                conflictingEvents = conflicts,
                summary = "Is waqt ${conflicts.size} conflict hai: $names."
            )
        }
    }

    /**
     * Creates a calendar event after explicit owner approval via [OwnerApprovalGate].
     * Uses [CalendarContract.Events] when [Manifest.permission.WRITE_CALENDAR] is granted,
     * and gracefully falls back to an [Intent.ACTION_INSERT] calendar intent otherwise.
     */
    suspend fun createEvent(
        context: Context,
        title: String,
        startMillis: Long,
        endMillis: Long,
        description: String = "",
        location: String = ""
    ): CalendarOperationResult = withContext(Dispatchers.IO) {
        val cleanTitle = title.trim().ifBlank { "Muskan Scheduled Meeting" }
        val safeEnd = if (endMillis > startMillis) endMillis else startMillis + ONE_HOUR_MS
        val timeRange = formatTimeRange(startMillis, safeEnd)

        val availability = checkAvailability(context, startMillis, safeEnd)
        val conflictNote = if (!availability.isAvailable && availability.conflictingEvents.isNotEmpty()) {
            " (Warning: ${availability.summary})"
        } else {
            ""
        }

        val approved = OwnerApprovalGate.requestSensitiveActionApproval(
            actionType = SensitiveActionType.CALENDAR_CREATE,
            recipient = cleanTitle,
            summary = "Sultan, kya main calendar par '$cleanTitle' ($timeRange) add kar doon?$conflictNote",
            payloadPreview = buildString {
                append("Title: $cleanTitle\nTime: $timeRange")
                if (description.isNotBlank()) append("\nNotes: $description")
                if (location.isNotBlank()) append("\nLocation: $location")
                if (conflictNote.isNotBlank()) append("\n$conflictNote")
            },
            technicalDetails = "CalendarContract.Events insert for '$cleanTitle' [$startMillis..$safeEnd]."
        )
        if (!approved) {
            return@withContext CalendarOperationResult(
                success = false,
                approvalDenied = true,
                message = "Approval denied: Calendar event '$cleanTitle' was cancelled."
            )
        }

        if (!hasWritePermission(context)) {
            return@withContext launchInsertEventIntent(context, cleanTitle, startMillis, safeEnd, description, location)
        }

        val primaryCalendarId = findPrimaryCalendarId(context)
        if (primaryCalendarId == null) {
            return@withContext launchInsertEventIntent(context, cleanTitle, startMillis, safeEnd, description, location)
        }

        return@withContext try {
            val values = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, primaryCalendarId)
                put(CalendarContract.Events.TITLE, cleanTitle)
                put(CalendarContract.Events.DESCRIPTION, description)
                put(CalendarContract.Events.EVENT_LOCATION, location)
                put(CalendarContract.Events.DTSTART, startMillis)
                put(CalendarContract.Events.DTEND, safeEnd)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
            }
            val uri = context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
            val id = uri?.lastPathSegment?.toLongOrNull()
            if (id != null) {
                EngineRegistry.recordInvocation(122, success = true)
                CalendarOperationResult(
                    success = true,
                    eventId = id,
                    usedIntentFallback = false,
                    message = "Sultan, '$cleanTitle' ($timeRange) aapke calendar mein save kar diya gaya hai."
                )
            } else {
                launchInsertEventIntent(context, cleanTitle, startMillis, safeEnd, description, location)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Direct CalendarContract insert failed; falling back to ACTION_INSERT", e)
            launchInsertEventIntent(context, cleanTitle, startMillis, safeEnd, description, location)
        }
    }

    /**
     * Reschedules an existing calendar event after explicit owner approval.
     */
    suspend fun rescheduleEvent(
        context: Context,
        eventId: Long,
        newStartMillis: Long,
        newEndMillis: Long,
        titleHint: String = "Event #$eventId"
    ): CalendarOperationResult = withContext(Dispatchers.IO) {
        val safeEnd = if (newEndMillis > newStartMillis) newEndMillis else newStartMillis + ONE_HOUR_MS
        val rangeLabel = formatTimeRange(newStartMillis, safeEnd)

        val approved = OwnerApprovalGate.requestSensitiveActionApproval(
            actionType = SensitiveActionType.CALENDAR_RESCHEDULE,
            recipient = titleHint,
            summary = "Sultan, kya main '$titleHint' ko reschedule karke $rangeLabel par shift kar doon?",
            payloadPreview = "Event ID: $eventId\nNew Time: $rangeLabel",
            technicalDetails = "CalendarContract.Events update for eventId=$eventId [$newStartMillis..$safeEnd]."
        )
        if (!approved) {
            return@withContext CalendarOperationResult(
                success = false,
                approvalDenied = true,
                message = "Approval denied: Rescheduling '$titleHint' was cancelled."
            )
        }

        if (!hasWritePermission(context)) {
            return@withContext CalendarOperationResult(
                success = false,
                message = "WRITE_CALENDAR permission granted nahi hai. Calendar edit karne ke liye permission allow karein."
            )
        }

        return@withContext try {
            val updateUri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId)
            val values = ContentValues().apply {
                put(CalendarContract.Events.DTSTART, newStartMillis)
                put(CalendarContract.Events.DTEND, safeEnd)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
            }
            val rows = context.contentResolver.update(updateUri, values, null, null)
            if (rows > 0) {
                EngineRegistry.recordInvocation(122, success = true)
                CalendarOperationResult(
                    success = true,
                    eventId = eventId,
                    message = "Sultan, '$titleHint' ko $rangeLabel par reschedule kar diya gaya hai."
                )
            } else {
                CalendarOperationResult(
                    success = false,
                    eventId = eventId,
                    message = "Event #$eventId calendar mein nahi mila."
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to reschedule event $eventId", e)
            CalendarOperationResult(
                success = false,
                eventId = eventId,
                message = "Event reschedule nahi ho saka: ${e.localizedMessage ?: "Unknown error"}"
            )
        }
    }

    /**
     * Deletes an existing calendar event after explicit owner approval.
     */
    suspend fun deleteEvent(
        context: Context,
        eventId: Long,
        titleHint: String = "Event #$eventId"
    ): CalendarOperationResult = withContext(Dispatchers.IO) {
        val approved = OwnerApprovalGate.requestSensitiveActionApproval(
            actionType = SensitiveActionType.CALENDAR_DELETE,
            recipient = titleHint,
            summary = "Sultan, kya main '$titleHint' ko aapke calendar se delete kar doon?",
            payloadPreview = "Delete Event ID: $eventId ($titleHint)",
            technicalDetails = "CalendarContract.Events delete for eventId=$eventId."
        )
        if (!approved) {
            return@withContext CalendarOperationResult(
                success = false,
                approvalDenied = true,
                message = "Approval denied: Deleting '$titleHint' was cancelled."
            )
        }

        if (!hasWritePermission(context)) {
            return@withContext CalendarOperationResult(
                success = false,
                message = "WRITE_CALENDAR permission granted nahi hai. Calendar event delete karne ke liye permission allow karein."
            )
        }

        return@withContext try {
            val deleteUri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId)
            val rows = context.contentResolver.delete(deleteUri, null, null)
            if (rows > 0) {
                EngineRegistry.recordInvocation(122, success = true)
                CalendarOperationResult(
                    success = true,
                    eventId = eventId,
                    message = "Sultan, '$titleHint' calendar se delete kar diya gaya hai."
                )
            } else {
                CalendarOperationResult(
                    success = false,
                    eventId = eventId,
                    message = "Event #$eventId calendar mein nahi mila."
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete event $eventId", e)
            CalendarOperationResult(
                success = false,
                eventId = eventId,
                message = "Event delete nahi ho saka: ${e.localizedMessage ?: "Unknown error"}"
            )
        }
    }

    /**
     * Natural-language Hinglish/Hindi/English handler for voice and chat calendar requests
     * (e.g., "aaj ka schedule", "kal 10 baje meeting set karo", "upcoming meetings").
     */
    suspend fun handleVoiceCalendarCommand(context: Context, prompt: String): String {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        val isCreateIntent = lower.contains("set karo") ||
            lower.contains("add karo") ||
            lower.contains("book karo") ||
            lower.contains("fix karo") ||
            lower.contains("schedule karo") ||
            lower.contains("schedule a") ||
            lower.contains("schedule meeting") ||
            lower.contains("create event") ||
            lower.contains("meeting rakho") ||
            lower.contains("बुक करो") ||
            lower.contains("सेट करो")

        if (isCreateIntent) {
            val parsed = parseNaturalScheduleRequest(prompt)
            val result = createEvent(
                context = context,
                title = parsed.title,
                startMillis = parsed.startMillis,
                endMillis = parsed.endMillis,
                description = "Scheduled via Muskan Voice Assistant: $prompt"
            )
            return result.message
        }

        if (!hasReadPermission(context)) {
            return "Sultan, aapka schedule dekhne ke liye READ_CALENDAR permission chahiye. Kripya App Settings mein Calendar permission allow karein."
        }

        val daysAhead = when {
            lower.contains("week") || lower.contains("hafte") || lower.contains("hafta") -> 7
            lower.contains("kal") || lower.contains("tomorrow") -> 2
            else -> 1
        }
        val events = listUpcomingEvents(context, daysAhead = daysAhead)
        if (events.isEmpty()) {
            val label = if (daysAhead == 1) "aaj" else "agle $daysAhead dinon mein"
            return "Sultan, $label aapke calendar par koi scheduled meeting ya event nahi hai."
        }

        val summaryLines = events.take(5).mapIndexed { index, event ->
            "${index + 1}. ${event.title} (${formatTimeRange(event.startMillis, event.endMillis)})"
        }
        return "Sultan, aapke calendar par ${events.size} upcoming events hain:\n" + summaryLines.joinToString("\n")
    }

    internal data class ParsedScheduleRequest(
        val title: String,
        val startMillis: Long,
        val endMillis: Long
    )

    internal fun parseNaturalScheduleRequest(
        prompt: String,
        nowMillis: Long = System.currentTimeMillis()
    ): ParsedScheduleRequest {
        val lower = prompt.lowercase(Locale.ROOT)
        val cal = Calendar.getInstance().apply { timeInMillis = nowMillis }

        when {
            lower.contains("parso") || lower.contains("day after tomorrow") -> cal.add(Calendar.DAY_OF_YEAR, 2)
            lower.contains("kal") || lower.contains("tomorrow") || lower.contains("कल") -> cal.add(Calendar.DAY_OF_YEAR, 1)
        }

        // Parse time such as "10 baje", "10:30 am", "4 pm", "16:00"
        val timeRegex = Regex("""(\d{1,2})(?::(\d{2}))?\s*(am|pm|baje|बजे)?""")
        val timeMatch = timeRegex.find(lower)
        if (timeMatch != null) {
            var hour = timeMatch.groupValues[1].toIntOrNull()?.coerceIn(0, 23) ?: 10
            val minute = timeMatch.groupValues[2].toIntOrNull()?.coerceIn(0, 59) ?: 0
            val suffix = timeMatch.groupValues[3]
            if (suffix == "pm" && hour in 1..11) {
                hour += 12
            } else if (suffix == "am" && hour == 12) {
                hour = 0
            } else if ((lower.contains("shaam") || lower.contains("sham") || lower.contains("raat") || lower.contains("evening")) && hour in 1..11) {
                hour += 12
            }
            cal.set(Calendar.HOUR_OF_DAY, hour)
            cal.set(Calendar.MINUTE, minute)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
        } else {
            // Default to next whole hour
            cal.add(Calendar.HOUR_OF_DAY, 1)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
        }

        val cleanedTitle = prompt
            .replace(Regex("(?i)\\b(muskan|muskaan|kal|aaj|parso|tomorrow|today|set karo|add karo|book karo|fix karo|schedule karo|schedule|create event|calendar par|meeting rakho|baje|am|pm)\\b"), " ")
            .replace(Regex("""\b\d{1,2}(:\d{2})?\b"""), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .ifBlank { "Meeting" }

        val start = cal.timeInMillis
        val end = start + ONE_HOUR_MS
        return ParsedScheduleRequest(title = cleanedTitle, startMillis = start, endMillis = end)
    }

    private fun queryInstancesInRange(
        context: Context,
        startMillis: Long,
        endMillis: Long
    ): List<CalendarEvent> {
        val events = mutableListOf<CalendarEvent>()
        try {
            val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(builder, startMillis)
            ContentUris.appendId(builder, endMillis)
            val projection = arrayOf(
                CalendarContract.Instances.EVENT_ID,
                CalendarContract.Instances.CALENDAR_ID,
                CalendarContract.Instances.TITLE,
                CalendarContract.Instances.DESCRIPTION,
                CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.END,
                CalendarContract.Instances.EVENT_LOCATION,
                CalendarContract.Instances.ALL_DAY
            )
            context.contentResolver.query(
                builder.build(),
                projection,
                null,
                null,
                "${CalendarContract.Instances.BEGIN} ASC"
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    events.add(
                        CalendarEvent(
                            id = cursor.getLong(0),
                            calendarId = cursor.getLong(1),
                            title = cursor.getString(2).orEmpty().ifBlank { "Untitled Event" },
                            description = cursor.getString(3).orEmpty(),
                            startMillis = cursor.getLong(4),
                            endMillis = cursor.getLong(5),
                            location = cursor.getString(6).orEmpty(),
                            allDay = cursor.getInt(7) == 1
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed querying CalendarContract.Instances", e)
        }
        return events
    }

    private fun findPrimaryCalendarId(context: Context): Long? {
        return try {
            val projection = arrayOf(
                CalendarContract.Calendars._ID,
                CalendarContract.Calendars.IS_PRIMARY,
                CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL
            )
            val selection = "${CalendarContract.Calendars.VISIBLE} = 1 AND " +
                "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL} >= ${CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR}"
            var fallbackId: Long? = null
            context.contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI,
                projection,
                selection,
                null,
                null
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(0)
                    val isPrimary = cursor.getInt(1) == 1
                    if (isPrimary) return id
                    if (fallbackId == null) fallbackId = id
                }
            }
            fallbackId
        } catch (e: Exception) {
            Log.e(TAG, "Error resolving primary calendar ID", e)
            null
        }
    }

    private fun launchInsertEventIntent(
        context: Context,
        title: String,
        startMillis: Long,
        endMillis: Long,
        description: String,
        location: String
    ): CalendarOperationResult {
        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
            putExtra(CalendarContract.Events.TITLE, title)
            putExtra(CalendarContract.Events.DESCRIPTION, description)
            if (location.isNotBlank()) {
                putExtra(CalendarContract.Events.EVENT_LOCATION, location)
            }
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            EngineRegistry.recordInvocation(122, success = true)
            CalendarOperationResult(
                success = true,
                usedIntentFallback = true,
                message = "Sultan, Calendar app mein '$title' (${formatTimeRange(startMillis, endMillis)}) ready kar diya hai — bas Save tap karein."
            )
        } catch (e: Exception) {
            Log.e(TAG, "Calendar ACTION_INSERT fallback failed", e)
            CalendarOperationResult(
                success = false,
                usedIntentFallback = true,
                message = "Calendar app open nahi ho paya: ${e.localizedMessage ?: "No calendar app available"}"
            )
        }
    }

    private fun formatTimeRange(startMillis: Long, endMillis: Long): String {
        val dayFmt = SimpleDateFormat("dd MMM, h:mm a", Locale.US)
        val endFmt = SimpleDateFormat("h:mm a", Locale.US)
        return "${dayFmt.format(Date(startMillis))} - ${endFmt.format(Date(endMillis))}"
    }

    private fun formatShortTime(millis: Long): String {
        val fmt = SimpleDateFormat("h:mm a", Locale.US)
        return fmt.format(Date(millis))
    }
}
