package com.example.engine.llm

import java.io.File

/**
 * JNI Bridge to `llama.cpp` (`libmuskan_llama_jni.so`) for running Qwen3 1.7B Q4_K_M GGUF
 * on Android ARM64 (`arm64-v8a`, Snapdragon 4 Gen 2 Accelerated Edition, 8 GB RAM).
 *
 * Also constructs Qwen3 ChatML prompts with `/no_think` (fast low-latency voice mode)
 * or `/think` (reasoning mode), injecting multi-turn Room SQLite conversation history
 * and user memories.
 */
object LlamaCppBridge {

    private var nativeLibLoaded = false
    @Volatile
    private var loadedModelPath: String? = null

    init {
        try {
            System.loadLibrary("muskan_llama_jni")
            nativeLibLoaded = true
        } catch (_: Throwable) {
            nativeLibLoaded = false
        }
    }

    fun isNativeLibraryAvailable(): Boolean = nativeLibLoaded

    fun getLoadedModelPath(): String? = loadedModelPath

    /**
     * Builds a Qwen3 ChatML prompt with system persona, user memories, multi-turn conversation
     * context, and Qwen3's `/no_think` or `/think` directive.
     */
    fun buildQwen3ChatMlPrompt(
        userPrompt: String,
        recentHistory: List<Pair<String, String>> = emptyList(),
        learnedFacts: List<String> = emptyList(),
        enableThinking: Boolean = false
    ): String {
        val sb = StringBuilder()
        val thinkDirective = if (enableThinking) "/think" else "/no_think"

        sb.append("<|im_start|>system\n")
        sb.append("You are Muskan (मुस्कान), Sultan Mirza's loyal, warm, and intelligent personal voice assistant running offline on his Xiaomi Redmi 13 5G (Snapdragon 4 Gen 2, 8 GB RAM).\n")
        sb.append("Rules:\n")
        sb.append("1. Reply naturally in Hindi (देवनागरी) or Hinglish matching the user's language.\n")
        sb.append("2. Keep spoken responses clear, concise (1 to 3 sentences for normal questions), and directly helpful for Text-to-Speech.\n")
        sb.append("3. Remember the conversation context and Sultan's saved memories below.\n")
        if (learnedFacts.isNotEmpty()) {
            sb.append("Sultan's Saved Memories:\n")
            learnedFacts.take(10).forEach { fact ->
                sb.append("- ").append(fact.trim()).append("\n")
            }
        }
        sb.append(thinkDirective).append("<|im_end|>\n")

        // Include up to last 5 conversation turns for context continuity
        recentHistory.takeLast(5).forEach { (prevUser, prevAssistant) ->
            if (prevUser.isNotBlank() && prevAssistant.isNotBlank()) {
                sb.append("<|im_start|>user\n").append(prevUser.trim()).append("<|im_end|>\n")
                sb.append("<|im_start|>assistant\n").append(prevAssistant.trim()).append("<|im_end|>\n")
            }
        }

        sb.append("<|im_start|>user\n").append(userPrompt.trim()).append(" ").append(thinkDirective).append("<|im_end|>\n")
        sb.append("<|im_start|>assistant\n")
        return sb.toString()
    }

    /**
     * Strips `<think>...</think>` blocks and ChatML stop tags from raw Qwen3 output so TTS never
     * reads internal reasoning tags aloud.
     */
    fun cleanQwen3Output(rawOutput: String): String {
        return rawOutput
            .replace(Regex("<think>[\\s\\S]*?</think>"), "")
            .replace("<|im_end|>", "")
            .replace("<|endoftext|>", "")
            .replace("<|im_start|>assistant", "")
            .trim()
    }

    @Synchronized
    fun ensureModelLoaded(
        modelPath: String,
        nThreads: Int = 6,
        nCtx: Int = 2048
    ): Boolean {
        val file = File(modelPath)
        if (!file.exists() || !file.isFile) return false
        if (!QwenOfflineModelManager.inspectGgufHeader(file).isValidGguf) return false

        if (!nativeLibLoaded) return false
        if (loadedModelPath == modelPath && isModelLoadedNative()) {
            return true
        }
        return try {
            val ok = loadModelNative(modelPath, nThreads, nCtx)
            if (ok) {
                loadedModelPath = modelPath
            }
            ok
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Runs local Qwen3 1.7B GGUF inference via `llama.cpp` if the native engine and GGUF model
     * are loaded; returns `null` if unavailable so caller can seamlessly use the built-in
     * context-aware Hindi/Hinglish offline engine.
     */
    @Synchronized
    fun generateOfflineReply(
        prompt: String,
        recentHistory: List<Pair<String, String>> = emptyList(),
        learnedFacts: List<String> = emptyList(),
        maxTokens: Int = 192,
        temperature: Float = 0.6f,
        enableThinking: Boolean = false
    ): String? {
        if (!nativeLibLoaded) return null
        val path = loadedModelPath ?: return null
        if (!File(path).exists()) return null

        return try {
            if (!isModelLoadedNative()) {
                val loaded = loadModelNative(path, 6, 2048)
                if (!loaded) return null
            }
            val chatMl = buildQwen3ChatMlPrompt(
                userPrompt = prompt,
                recentHistory = recentHistory,
                learnedFacts = learnedFacts,
                enableThinking = enableThinking
            )
            val raw = generateCompletionNative(chatMl, maxTokens, temperature)
            val cleaned = cleanQwen3Output(raw)
            if (cleaned.isBlank() || cleaned.startsWith("[LLAMA_STUB")) null else cleaned
        } catch (_: Throwable) {
            null
        }
    }

    @Synchronized
    fun releaseModel() {
        loadedModelPath = null
        if (nativeLibLoaded) {
            try {
                freeModelNative()
            } catch (_: Throwable) {}
        }
    }

    // --- Native JNI Declarations (implemented in app/src/main/cpp/llama_jni.cpp) ---
    @JvmStatic
    private external fun loadModelNative(modelPath: String, nThreads: Int, nCtx: Int): Boolean

    @JvmStatic
    private external fun isModelLoadedNative(): Boolean

    @JvmStatic
    private external fun generateCompletionNative(
        formattedPrompt: String,
        maxTokens: Int,
        temperature: Float
    ): String

    @JvmStatic
    private external fun freeModelNative()
}
