package com.example.engine.tools

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class ToolStatus {
    ACTIVE_VERIFIED,
    PENDING_APPROVAL,
    SANDBOX_TESTING,
    DISABLED
}

data class RegisteredTool(
    val id: String,
    val name: String,
    val purpose: String,
    val inputSchema: String,
    val outputSchema: String,
    val requiredPermissions: List<String>,
    val version: String = "1.0.0",
    val status: ToolStatus = ToolStatus.ACTIVE_VERIFIED,
    val executionCount: Int = 0,
    val failureCount: Int = 0,
    val requiresExplicitOwnerConfirmation: Boolean = true
)

/**
 * Searchable Registry of native and autonomous phone tools for Muskaan.
 * Enforces strict permission boundaries and human confirmation before invocation.
 */
object ToolRegistryEngine {

    private val _tools = MutableStateFlow<List<RegisteredTool>>(emptyList())
    val tools: StateFlow<List<RegisteredTool>> = _tools.asStateFlow()

    init {
        seedInitialTools()
    }

    private fun seedInitialTools() {
        _tools.value = listOf(
            RegisteredTool(
                id = "tool_accessibility_click",
                name = "Accessibility UI Clicker",
                purpose = "Simulates click on an on-screen element identified by text or node resource ID",
                inputSchema = "{ \"targetText\": String, \"exactMatch\": Boolean }",
                outputSchema = "{ \"success\": Boolean, \"clickedNode\": String }",
                requiredPermissions = listOf("android.permission.BIND_ACCESSIBILITY_SERVICE"),
                status = ToolStatus.ACTIVE_VERIFIED,
                executionCount = 42,
                requiresExplicitOwnerConfirmation = true
            ),
            RegisteredTool(
                id = "tool_screen_read",
                name = "Screen Text Perception",
                purpose = "Extracts all visible text and clickable elements from the current foreground app",
                inputSchema = "{}",
                outputSchema = "{ \"visibleElements\": List<String>, \"focusedApp\": String }",
                requiredPermissions = listOf("android.permission.BIND_ACCESSIBILITY_SERVICE"),
                status = ToolStatus.ACTIVE_VERIFIED,
                executionCount = 18,
                requiresExplicitOwnerConfirmation = false
            ),
            RegisteredTool(
                id = "tool_whatsapp_compose",
                name = "WhatsApp Message Drafter",
                purpose = "Opens WhatsApp and types a drafted message into the chat field, awaiting confirmation",
                inputSchema = "{ \"recipient\": String, \"messageBody\": String }",
                outputSchema = "{ \"drafted\": Boolean, \"awaitingUserSend\": Boolean }",
                requiredPermissions = listOf("android.permission.BIND_ACCESSIBILITY_SERVICE"),
                status = ToolStatus.ACTIVE_VERIFIED,
                executionCount = 12,
                requiresExplicitOwnerConfirmation = true
            ),
            RegisteredTool(
                id = "tool_youtube_search",
                name = "YouTube Video Navigator",
                purpose = "Launches YouTube and inputs search query to play requested video or playlist",
                inputSchema = "{ \"searchQuery\": String }",
                outputSchema = "{ \"launched\": Boolean, \"querySubmitted\": Boolean }",
                requiredPermissions = listOf("android.permission.BIND_ACCESSIBILITY_SERVICE"),
                status = ToolStatus.ACTIVE_VERIFIED,
                executionCount = 27,
                requiresExplicitOwnerConfirmation = false
            ),
            RegisteredTool(
                id = "tool_audio_diagnostics",
                name = "Audio DSP & VAD Diagnostic",
                purpose = "Analyzes microphone signal level, Butterworth filter response, and near-field voice harmonics",
                inputSchema = "{ \"sampleDurationMs\": Int }",
                outputSchema = "{ \"rms\": Float, \"isNearField\": Boolean, \"biometricMatchScore\": Float }",
                requiredPermissions = listOf("android.permission.RECORD_AUDIO"),
                status = ToolStatus.ACTIVE_VERIFIED,
                executionCount = 95,
                requiresExplicitOwnerConfirmation = false
            ),
            RegisteredTool(
                id = "tool_memory_export",
                name = "Room Memory Exporter",
                purpose = "Exports persistent conversation turns and learned facts to JSON format for backup",
                inputSchema = "{ \"includeLearnedFacts\": Boolean }",
                outputSchema = "{ \"jsonExport\": String, \"totalTurns\": Int }",
                requiredPermissions = emptyList(),
                status = ToolStatus.ACTIVE_VERIFIED,
                executionCount = 5,
                requiresExplicitOwnerConfirmation = true
            ),
            RegisteredTool(
                id = "tool_ui_controller",
                name = "Modular UIController API",
                purpose = "Allows AI Agent to dynamically add, remove, and modify modular dashboard containers and components",
                inputSchema = "{ \"action\": \"add_container\"|\"remove_container\"|\"add_component\"|\"remove_component\"|\"modify_component\", \"parameters\": Object }",
                outputSchema = "{ \"success\": Boolean, \"affectedId\": String, \"statusMessage\": String }",
                requiredPermissions = emptyList(),
                status = ToolStatus.ACTIVE_VERIFIED,
                executionCount = 64,
                requiresExplicitOwnerConfirmation = false
            )
        )
    }

    fun findTools(query: String): List<RegisteredTool> {
        val q = query.lowercase().trim()
        if (q.isBlank()) return _tools.value
        return _tools.value.filter {
            it.name.lowercase().contains(q) ||
            it.purpose.lowercase().contains(q) ||
            it.id.lowercase().contains(q)
        }
    }

    fun registerTool(tool: RegisteredTool) {
        _tools.update { list ->
            listOf(tool) + list.filter { it.id != tool.id }
        }
    }

    fun recordExecution(id: String, success: Boolean) {
        _tools.update { list ->
            list.map {
                if (it.id == id) {
                    it.copy(
                        executionCount = it.executionCount + 1,
                        failureCount = if (!success) it.failureCount + 1 else it.failureCount
                    )
                } else it
            }
        }
    }
}
