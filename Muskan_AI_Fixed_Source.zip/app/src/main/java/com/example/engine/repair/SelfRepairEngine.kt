package com.example.engine.repair

import android.graphics.Rect
import com.example.automation.ActionResult
import com.example.automation.ActionResultCode
import com.example.automation.ScreenPerceptionEngine
import com.example.data.GeminiClient
import com.example.service.MuskanAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.UUID

enum class FailureCategory {
    RUNTIME_EXCEPTION,
    UI_AUTOMATION_TARGET_MISSING,
    UI_VERIFICATION_TIMEOUT,
    SCHEMA_SERIALIZATION_ERROR,
    DEX_VERIFICATION_REJECTION,
    NETWORK_TIMEOUT
}

data class DiagnosticReport(
    val errorId: String = UUID.randomUUID().toString(),
    val failureCategory: FailureCategory,
    val stackTraceSummary: String,
    val rootCauseGuess: String,
    val proposedFixStrategy: String,
    val retryCount: Int = 1,
    val isResolved: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class SelfRepairState(
    val isHealingActive: Boolean = false,
    val currentAttempt: Int = 0,
    val maxAttempts: Int = 3,
    val lastDiagnosedError: String? = null,
    val lastFixApplied: String? = null,
    val totalHealedCount: Int = 0,
    val recentReports: List<DiagnosticReport> = emptyList()
)

/**
 * Autonomous Self-Diagnosis, Runtime Repair & Error Healing Engine.
 * Intercepts background coroutine crashes, verification rejections,
 * serialization failures, and UI coordinate drifts with closed-loop auto-correction.
 */
object SelfRepairEngine {

    private val _repairState = MutableStateFlow(SelfRepairState())
    val repairState: StateFlow<SelfRepairState> = _repairState.asStateFlow()

    fun diagnoseFailure(throwable: Throwable, context: String = ""): DiagnosticReport {
        val msg = throwable.message.orEmpty()
        val stack = throwable.stackTraceToString().take(300)

        val category = when {
            msg.contains("timeout", ignoreCase = true) -> FailureCategory.NETWORK_TIMEOUT
            msg.contains("json", ignoreCase = true) || msg.contains("parse", ignoreCase = true) -> FailureCategory.SCHEMA_SERIALIZATION_ERROR
            msg.contains("target", ignoreCase = true) || msg.contains("node", ignoreCase = true) -> FailureCategory.UI_AUTOMATION_TARGET_MISSING
            else -> FailureCategory.RUNTIME_EXCEPTION
        }

        val rootCause = when (category) {
            FailureCategory.NETWORK_TIMEOUT -> "Network latency or endpoint timeout in $context"
            FailureCategory.SCHEMA_SERIALIZATION_ERROR -> "JSON contract payload mismatch"
            FailureCategory.UI_AUTOMATION_TARGET_MISSING -> "Target UI node not visible or coordinates drifted"
            else -> "Runtime exception: ${throwable.javaClass.simpleName}"
        }

        val strategy = when (category) {
            FailureCategory.NETWORK_TIMEOUT -> "Switch to local heuristic cache and retry with exponential backoff"
            FailureCategory.SCHEMA_SERIALIZATION_ERROR -> "Sanitize JSON delimiters and wrap with safe Moshi parser"
            FailureCategory.UI_AUTOMATION_TARGET_MISSING -> "Execute fuzzy text search, coordinate re-computation, and safe scroll"
            else -> "Apply defensive try-catch boundary and synthesize fallback artifact"
        }

        val report = DiagnosticReport(
            failureCategory = category,
            stackTraceSummary = stack,
            rootCauseGuess = rootCause,
            proposedFixStrategy = strategy
        )

        _repairState.update { current ->
            current.copy(
                recentReports = (current.recentReports + report).takeLast(15)
            )
        }

        return report
    }

    fun diagnoseVerificationRejection(
        diagnostics: List<String>,
        feedback: String?,
        artifactTitle: String,
        syntaxScore: Float = 0f,
        securityScore: Float = 0f
    ): DiagnosticReport {
        val issues = diagnostics.joinToString("; ")
        val proposedFix = feedback ?: "Re-audit syntax and security constraints"

        val report = DiagnosticReport(
            failureCategory = FailureCategory.DEX_VERIFICATION_REJECTION,
            stackTraceSummary = "Verification diagnostics: $issues",
            rootCauseGuess = "Artifact '$artifactTitle' failed verification gates (Security: $securityScore, Syntax: $syntaxScore)",
            proposedFixStrategy = proposedFix
        )

        _repairState.update { current ->
            current.copy(
                recentReports = (current.recentReports + report).takeLast(15)
            )
        }

        return report
    }

    suspend fun generateRepairStrategy(report: DiagnosticReport, originalPrompt: String): String = withContext(Dispatchers.IO) {
        val directivePrompt = buildString {
            appendLine("You are the Self-Repair Diagnostic Agent for Sultan Mirza's AI.")
            appendLine("Original User Directive: \"$originalPrompt\"")
            appendLine("Failure Category: ${report.failureCategory.name}")
            appendLine("Root Cause: ${report.rootCauseGuess}")
            appendLine("Stack / Diagnostics: ${report.stackTraceSummary}")
            appendLine("Analyze this execution error, identify what broke, and generate the corrected parameter/code fix concisely.")
        }

        val geminiResult = GeminiClient.askGemini(prompt = directivePrompt)
        if (geminiResult.isSuccess) {
            val response = geminiResult.getOrNull().orEmpty().trim()
            if (response.isNotBlank()) {
                return@withContext response.take(200)
            }
        }

        // Resilient deterministic fallback fix
        return@withContext report.proposedFixStrategy
    }

    fun recordHealingAttempt(attempt: Int, errorSummary: String) {
        _repairState.update { current ->
            current.copy(
                isHealingActive = true,
                currentAttempt = attempt,
                lastDiagnosedError = errorSummary
            )
        }
    }

    fun recordSuccessfulHealing(errorId: String, fixApplied: String) {
        _repairState.update { current ->
            current.copy(
                isHealingActive = false,
                currentAttempt = 0,
                lastFixApplied = fixApplied,
                totalHealedCount = current.totalHealedCount + 1,
                recentReports = current.recentReports.map {
                    if (it.errorId == errorId) it.copy(isResolved = true) else it
                }
            )
        }
    }

    fun resetHealingState() {
        _repairState.update { current ->
            current.copy(
                isHealingActive = false,
                currentAttempt = 0
            )
        }
    }

    fun resetAllForTesting() {
        _repairState.value = SelfRepairState()
    }

    fun getHealingSummaryForVoice(): String {
        val snap = _repairState.value
        return when {
            snap.isHealingActive -> {
                "Sultan, ek runtime error diagnose ho raha hai aur self-healing attempt ${snap.currentAttempt} active hai."
            }
            snap.totalHealedCount > 0 -> {
                "Sultan, ek error diagnose karke khud hi fix kar liya hai, kaam continuous chal raha hai."
            }
            else -> {
                "Sultan, abhi system bilkul stable hai, koi error nahi hai aur sabhi modules operational hain."
            }
        }
    }

    /**
     * Resilient Screen Automation with 3-tier Adaptive Fallbacks:
     * 1. Standard verified click.
     * 2. Fallback A: Fuzzy OCR / text token search across visible elements.
     * 3. Fallback B: Relative coordinate re-computation and tap.
     * 4. Fallback C: Safe scroll down/up to bring element into visible viewport.
     */
    suspend fun executeResilientClick(
        targetQuery: String,
        onFallbackAttempt: ((String) -> Unit)? = null
    ): ActionResult = withContext(Dispatchers.IO) {
        val cleanQuery = targetQuery.lowercase(Locale.ROOT).trim()

        // Tier 1: Direct Verified Click
        val initialResult = ScreenPerceptionEngine.executeVerifiedClick(targetQuery)
        if (initialResult.isSuccess) {
            return@withContext initialResult
        }

        recordHealingAttempt(1, "Target '$targetQuery' click failed (${initialResult.code})")
        onFallbackAttempt?.invoke("Fallback 1: Fuzzy Text Search")
        delay(200L)

        // Tier 2 - Fallback A: Fuzzy OCR/Text fallback search
        val snapshot = ScreenPerceptionEngine.captureScreenSnapshot()
        val fuzzyMatch = snapshot.visibleTexts.firstOrNull { text ->
            val cleanText = text.lowercase(Locale.ROOT)
            cleanText.contains(cleanQuery) || cleanQuery.contains(cleanText) ||
                    (cleanQuery.split(" ").any { it.length > 3 && cleanText.contains(it) })
        }

        if (fuzzyMatch != null) {
            val fuzzyResult = ScreenPerceptionEngine.executeVerifiedClick(fuzzyMatch)
            if (fuzzyResult.isSuccess) {
                recordSuccessfulHealing(UUID.randomUUID().toString(), "Resolved via Fuzzy OCR Match: $fuzzyMatch")
                return@withContext ActionResult(
                    code = ActionResultCode.SUCCESS_VERIFIED,
                    message = "Resilient healing: matched '$fuzzyMatch' instead of '$targetQuery' successfully."
                )
            }
        }

        // Tier 2 - Fallback B: Normalized relative coordinate re-computation
        recordHealingAttempt(2, "Coordinate re-computation for '$targetQuery'")
        onFallbackAttempt?.invoke("Fallback 2: Relative Coordinate Tap")
        val service = MuskanAccessibilityService.instance
        if (service != null && snapshot.clickableElements.isNotEmpty()) {
            val closestElement = snapshot.clickableElements.firstOrNull { el ->
                el.text.contains(cleanQuery, ignoreCase = true) ||
                        el.contentDescription.contains(cleanQuery, ignoreCase = true)
            } ?: snapshot.clickableElements.firstOrNull()

            if (closestElement != null && closestElement.bounds.width() > 0) {
                val cx = closestElement.bounds.exactCenterX()
                val cy = closestElement.bounds.exactCenterY()
                service.dispatchCoordinateTap(cx, cy)
                delay(300L)
                val postSnap = ScreenPerceptionEngine.captureScreenSnapshot()
                if (postSnap.visibleTexts != snapshot.visibleTexts) {
                    recordSuccessfulHealing(UUID.randomUUID().toString(), "Resolved via Relative Coordinate Dispatch")
                    return@withContext ActionResult(
                        code = ActionResultCode.SUCCESS_VERIFIED,
                        message = "Resilient healing: coordinate tap at ($cx, $cy) succeeded."
                    )
                }
            }
        }

        // Tier 2 - Fallback C: Safe scroll down/up to bring element into visible viewport
        recordHealingAttempt(3, "Safe scroll viewport discovery for '$targetQuery'")
        onFallbackAttempt?.invoke("Fallback 3: Viewport Scroll Search")
        val scrollDownResult = ScreenPerceptionEngine.executeVerifiedScroll(scrollDown = true)
        if (scrollDownResult.isSuccess) {
            delay(300L)
            val retryAfterScroll = ScreenPerceptionEngine.executeVerifiedClick(targetQuery)
            if (retryAfterScroll.isSuccess) {
                recordSuccessfulHealing(UUID.randomUUID().toString(), "Resolved via Viewport Scroll Down")
                return@withContext retryAfterScroll
            }
        }

        val scrollUpResult = ScreenPerceptionEngine.executeVerifiedScroll(scrollDown = false)
        if (scrollUpResult.isSuccess) {
            delay(300L)
            val retryAfterScrollUp = ScreenPerceptionEngine.executeVerifiedClick(targetQuery)
            if (retryAfterScrollUp.isSuccess) {
                recordSuccessfulHealing(UUID.randomUUID().toString(), "Resolved via Viewport Scroll Up")
                return@withContext retryAfterScrollUp
            }
        }

        resetHealingState()
        return@withContext ActionResult(
            code = ActionResultCode.TARGET_NOT_FOUND,
            message = "All 3 resilient fallback strategies exhausted for '$targetQuery'."
        )
    }
}
