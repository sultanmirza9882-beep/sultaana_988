package com.example.engine.dev

import android.content.Context
import com.example.data.GeminiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Prompt-to-source workspace for Muskan. Generated files are staged as a reviewable
 * patch bundle; they are never silently injected into the installed APK.
 */
object SelfDevelopmentEngine {
    data class ResultBundle(
        val success: Boolean,
        val message: String,
        val draftId: String? = null,
        val fileCount: Int = 0,
        val zipPath: String? = null
    )

    private val blockedNames = setOf(
        "google-services.json", "local.properties", "gradle.properties", ".env",
        "debug.keystore", "release.keystore", "keystore.properties"
    )

    fun isSelfDevelopmentPrompt(prompt: String): Boolean {
        val p = prompt.lowercase()
        val hasBuildIntent = listOf(
            "create an agent", "make an agent", "add an agent", "new agent", "agent banao",
            "agent बनाओ", "agent जोड़", "एजेंट बनाओ", "एजेंट जोड़ो", "कोई एजेंट",
            "code change", "modify code", "change code", "create file", "add file",
            "new feature", "feature add", "feature जोड़", "नया फीचर", "नई सुविधा",
            "अपने code", "अपने कोड", "कोड में बदलाव", "फाइल बनाओ", "फाइल जोड़ो", "नई फाइल",
            "self develop", "self-development", "update your code", "project code",
            "muskan mein feature", "muskan me feature", "muskan mein change", "muskan me change",
            "muskan ka code", "muskan ke code", "is project mein", "iss project mein",
            "add this feature", "implement this feature", "change this project", "edit this project",
            "add a review screen", "review screen", "approval screen",
            "fix this in the app", "app mein feature", "app me feature", "app mein change",
            "फीचर जोड़ो", "फीचर जोड़ना", "इस प्रोजेक्ट में", "इस ऐप में बदलाव", "ऐप में फीचर", "इस ऐप में approval screen",
            "कोड बदलो", "कोड ठीक करो", "प्रोजेक्ट में बदलाव", "इसमें बदलाव करो",
            // Common short voice/chat commands in Hindi, Hinglish and English.
            "muskan ka code theek", "muskan ka code ठीक", "muskan ka voice issue",
            "voice issue fix", "fix voice issue", "audio issue fix", "fix audio issue", "please fix the audio issue",
            "sound issue fix", "fix sound issue", "audio bug", "voice bug",
            "sound nahi aa rahi", "आवाज़ नहीं आ रही", "आवाज नहीं आ रही",
            "इस ऐप का कोड", "इस app ka code", "इस ऐप को ठीक करो", "ऐप ठीक करो",
            "app theek karo", "app ko theek karo", "feature add karo", "फीचर ऐड करो",
            "फीचर डालो", "इसमें नया फीचर", "इसमें नया feature", "कोड में सुधार करो",
            "इसका बग ठीक", "bug theek karo", "bug ठीक करो", "मौजूदा कोड बदलो",
            // Additional natural speech variants commonly used in chat and voice.
            "meri app ki awaaz", "मेरी ऐप की आवाज", "मेरी ऐप की आवाज़",
            "voice theek karo", "voice ठीक करो", "awaaz theek karo", "आवाज़ ठीक करो",
            "audio theek karo", "sound theek karo", "sound ठीक करो",
            "is bug ko fix", "इस bug को ठीक", "इस बग को ठीक", "ये बग ठीक करो",
            "ye bug fix", "yeh bug fix", "isme change kar do", "इसमें बदलाव कर दो",
            "इसमें कोड बदल दो", "कोड में बदलाव कर दो", "कोड में सुधार करो",
            "add kar do", "जोड़कर दो", "जोड़ दो", "बना कर दो", "बनाकर दो",
            "fix kar do", "ठीक कर दो", "ठीक कर देना"
        ).any { p.contains(it) }
        return hasBuildIntent
    }

    suspend fun generatePatch(context: Context, userPrompt: String): ResultBundle = withContext(Dispatchers.IO) {
        val sourceContext = ProjectWorkspaceManager.buildPromptContext(context, userPrompt)
        val system = """
You are Muskan's autonomous code-change engine. Produce a small, concrete source-code patch for an Android Kotlin project.
Return ONLY valid JSON with this exact shape:
{"summary":"...","files":[{"path":"app/src/main/java/example/NewComponent.kt","content":"full file content"}],"checks":["..."],"risks":["..."]}
Rules: paths must be relative project paths; do not use absolute paths or ..; never include secrets, API keys, signing keys, local.properties, google-services.json, .env, gradle.properties, or binary files. Limit to 12 files and 120000 characters per file. Prefer additive, compile-conscious changes. If the prompt lacks enough project context, return files=[] and explain what context is needed in summary. Do not claim tests were run. Do not claim a source patch changes the already-installed APK. Escape JSON strings correctly.
Project context: Android Kotlin app, package root com.example. Muskan is a single unified autonomous AI assistant. Use the supplied imported source context as the authoritative existing code. When the requested change belongs in an existing file, return that exact existing relative path with a complete, carefully updated file; do not create a disconnected replacement class. If relevant source is not included in the bounded context, ask for it in summary instead of guessing. Never apply changes without explicit review/approval.
""".trimIndent()

        val response = GeminiClient.askGemini(
            prompt = "$system\n\nCURRENT SOURCE CONTEXT:\n$sourceContext\n\nUSER CHANGE REQUEST:\n$userPrompt\n\nGenerate the proposed source patch now.",
            recentHistory = emptyList(),
            learnedFacts = listOf("Muskan is an Action-First unified autonomous AI assistant.")
        ).getOrElse { error ->
            return@withContext ResultBundle(false, "Code generation could not reach the configured AI service: ${error.message ?: "unknown error"}")
        }
        val jsonText = response.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val root = try { JSONObject(jsonText) } catch (e: Exception) {
            return@withContext ResultBundle(false, "AI response was not valid patch JSON. No files were written; retry with a more specific request.")
        }
        val files = root.optJSONArray("files") ?: JSONArray()
        if (files.length() == 0) {
            return@withContext ResultBundle(false, root.optString("summary", "No safe source files could be generated from this prompt."))
        }
        if (files.length() > 12) return@withContext ResultBundle(false, "Patch rejected: maximum 12 files per draft.")

        val draftId = "patch_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}"
        val draftsRoot = File(context.filesDir, "self_development/drafts")
        val draftDir = File(draftsRoot, draftId)
        val sourceDir = File(draftDir, "source")
        if (!sourceDir.mkdirs() && !sourceDir.isDirectory) {
            return@withContext ResultBundle(false, "Could not create the private source-draft workspace.")
        }

        val manifestFiles = JSONArray()
        try {
            for (i in 0 until files.length()) {
                val item = files.optJSONObject(i) ?: throw IllegalArgumentException("File entry $i is invalid")
                val rawPath = item.optString("path").trim().replace('\\', '/')
                val content = item.optString("content")
                val path = validateRelativePath(rawPath)
                if (path.substringAfterLast('/') in blockedNames || path.startsWith(".git/")) {
                    throw IllegalArgumentException("Sensitive or protected path rejected: $path")
                }
                if (content.isBlank() || content.length > 120_000) throw IllegalArgumentException("Empty or oversized file rejected: $path")
                val out = File(sourceDir, path)
                if (!out.canonicalPath.startsWith(sourceDir.canonicalPath + File.separator)) {
                    throw IllegalArgumentException("Unsafe file path rejected: $path")
                }
                out.parentFile?.mkdirs()
                out.writeText(content, Charsets.UTF_8)
                manifestFiles.put(JSONObject().put("path", path).put("characters", content.length))
            }

            val manifest = JSONObject()
                .put("draftId", draftId)
                .put("createdAt", System.currentTimeMillis())
                .put("userPrompt", userPrompt)
                .put("summary", root.optString("summary", "Generated source patch"))
                .put("checks", root.optJSONArray("checks") ?: JSONArray())
                .put("risks", root.optJSONArray("risks") ?: JSONArray())
                .put("files", manifestFiles)
                .put("status", "DRAFT_REQUIRES_REVIEW")
                .put("note", "This bundle is not applied to the installed APK and has not been built or tested.")
            File(draftDir, "PATCH_MANIFEST.json").writeText(manifest.toString(2), Charsets.UTF_8)

            val zipFile = File(draftsRoot, "$draftId.zip")
            ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
                zos.putNextEntry(ZipEntry("PATCH_MANIFEST.json"))
                zos.write(manifest.toString(2).toByteArray(Charsets.UTF_8))
                zos.closeEntry()
                sourceDir.walkTopDown().filter { it.isFile }.forEach { file ->
                    val rel = file.relativeTo(sourceDir).path.replace('\\', '/')
                    zos.putNextEntry(ZipEntry("source/$rel"))
                    file.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
            // Structural verification only; no Android compile is claimed here.
            java.util.zip.ZipFile(zipFile).use { zip ->
                if (zip.getEntry("PATCH_MANIFEST.json") == null || zip.size() < 2) throw IllegalStateException("Patch bundle integrity check failed")
            }
            ResultBundle(
                success = true,
                message = "${root.optString("summary", "Source patch generated.")} Draft created with ${files.length()} file(s). It is staged for review, not applied to the installed app; Android build and tests have not run.",
                draftId = draftId,
                fileCount = files.length(),
                zipPath = zipFile.absolutePath
            )
        } catch (e: Exception) {
            draftDir.deleteRecursively()
            ResultBundle(false, "Patch rejected and discarded: ${e.message ?: "validation failed"}")
        }
    }

    data class PendingDraft(val draftId: String, val summary: String, val createdAt: Long, val fileCount: Int, val zipPath: String)

    /** Lists generated drafts that are still available for explicit user review. */
    fun listPendingDrafts(context: Context): List<PendingDraft> {
        val draftsRoot = File(context.filesDir, "self_development/drafts")
        return draftsRoot.listFiles()?.filter { it.isDirectory && it.name.startsWith("patch_") }
            ?.mapNotNull { dir ->
                val manifestFile = File(dir, "PATCH_MANIFEST.json")
                if (!manifestFile.isFile) return@mapNotNull null
                runCatching {
                    val manifest = JSONObject(manifestFile.readText(Charsets.UTF_8))
                    if (manifest.optString("status") != "DRAFT_REQUIRES_REVIEW") return@runCatching null
                    PendingDraft(dir.name, manifest.optString("summary", "Source patch"), manifest.optLong("createdAt"), manifest.optJSONArray("files")?.length() ?: 0, File(draftsRoot, "${dir.name}.zip").absolutePath)
                }.getOrNull()
            }?.sortedByDescending { it.createdAt }.orEmpty()
    }

    fun markDraftApplied(context: Context, draftId: String) {
        require(draftId.matches(Regex("patch_[0-9]+_[A-Za-z0-9]+"))) { "Invalid draft identifier." }
        val dir = File(context.filesDir, "self_development/drafts/$draftId")
        val canonicalRoot = File(context.filesDir, "self_development/drafts").canonicalPath + File.separator
        require(dir.canonicalPath.startsWith(canonicalRoot) && dir.isDirectory) { "Draft not found." }
        val manifestFile = File(dir, "PATCH_MANIFEST.json")
        val manifest = JSONObject(manifestFile.readText(Charsets.UTF_8))
        manifest.put("status", "APPLIED_TO_PRIVATE_SOURCE_WORKSPACE")
        manifest.put("appliedAt", System.currentTimeMillis())
        manifest.put("note", "Applied to private source workspace after explicit user approval. Installed APK unchanged; build/tests not run.")
        manifestFile.writeText(manifest.toString(2), Charsets.UTF_8)
    }

    /** Loads a selected draft as path/content entries; nothing is applied by this method. */
    fun loadDraftFilesForReview(context: Context, draftId: String): JSONArray {
        require(draftId.matches(Regex("patch_[0-9]+_[A-Za-z0-9]+"))) { "Invalid draft identifier." }
        val dir = File(context.filesDir, "self_development/drafts/$draftId")
        val canonicalRoot = File(context.filesDir, "self_development/drafts").canonicalPath + File.separator
        require(dir.canonicalPath.startsWith(canonicalRoot) && dir.isDirectory) { "Draft not found." }
        val manifest = JSONObject(File(dir, "PATCH_MANIFEST.json").readText(Charsets.UTF_8))
        require(manifest.optString("status") == "DRAFT_REQUIRES_REVIEW") { "Draft is not awaiting review." }
        val files = manifest.optJSONArray("files") ?: JSONArray()
        require(files.length() in 1..12) { "Draft file count is invalid." }
        val result = JSONArray()
        for (i in 0 until files.length()) {
            val path = validateRelativePath(files.getJSONObject(i).optString("path"))
            val source = File(dir, "source/$path")
            require(source.canonicalPath.startsWith(File(dir, "source").canonicalPath + File.separator) && source.isFile) { "Draft file missing or unsafe: $path" }
            result.put(JSONObject().put("path", path).put("content", source.readText(Charsets.UTF_8)))
        }
        return result
    }

    private fun validateRelativePath(path: String): String {
        require(path.isNotBlank()) { "File path is blank" }
        require(!path.startsWith("/") && !path.matches(Regex("^[A-Za-z]:.*"))) { "Absolute paths are not allowed" }
        val segments = path.split('/')
        require(segments.none { it.isBlank() || it == "." || it == ".." }) { "Path traversal is not allowed" }
        require(segments.all { it.matches(Regex("[A-Za-z0-9_.-]+")) }) { "Path contains unsupported characters" }
        return segments.joinToString("/")
    }
}
