package com.example.dsp

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Heavy-duty Audio DSP Processor:
 * 1. 2nd-order IIR Butterworth High-pass Filter (80 Hz cut-off) to strip low-frequency rumbles,
 *    motorcycle engines, auto-rickshaw thumping, and HVAC rumble.
 * 2. 2nd-order IIR Low-pass Filter (3800 Hz cut-off) to eliminate high-frequency hiss, squeals, and wind noise.
 * 3. 50/60 Hz Notch Filters to neutralize electrical power hum.
 * 4. Sudden Impulse Suppressor & Dynamic Peak Limiter to clamp sharp transients (door slams, dropped objects, cutlery).
 * 5. Adaptive Spectral Subtraction / Stationary Noise Gating for traffic & fan suppression.
 * 6. High-Precision Near-Field Voice Activity Detection (VAD).
 */
class AudioDspProcessor(
    val sampleRate: Int = 16000
) {
    // High-pass filter state (80 Hz)
    private var hpX1 = 0f
    private var hpX2 = 0f
    private var hpY1 = 0f
    private var hpY2 = 0f
    private val hpB0: Float
    private val hpB1: Float
    private val hpB2: Float
    private val hpA1: Float
    private val hpA2: Float

    // Low-pass filter state (3800 Hz)
    private var lpX1 = 0f
    private var lpX2 = 0f
    private var lpY1 = 0f
    private var lpY2 = 0f
    private val lpB0: Float
    private val lpB1: Float
    private val lpB2: Float
    private val lpA1: Float
    private val lpA2: Float

    // Notch filter (50 Hz and 60 Hz electrical hum)
    private var notch50X1 = 0f
    private var notch50X2 = 0f
    private var notch50Y1 = 0f
    private var notch50Y2 = 0f
    private val notch50Cos: Float
    private val notch50R = 0.95f

    private var notch60X1 = 0f
    private var notch60X2 = 0f
    private var notch60Y1 = 0f
    private var notch60Y2 = 0f
    private val notch60Cos: Float
    private val notch60R = 0.95f

    // Running noise floor tracker for adaptive spectral subtraction (RNNoise / Wiener style)
    private var runningNoiseFloor = 0.015f
    private var smoothedEnergy = 0.02f

    // Impulse transient detector state
    private var prevSample = 0f
    private var runningTransientThreshold = 0.65f

    init {
        // Calculate 2nd-order Butterworth High-Pass coefficients at 80 Hz
        val hpCutoff = 80.0
        val hpOmega = 2.0 * PI * hpCutoff / sampleRate
        val hpAlpha = sin(hpOmega) / (2.0 * 0.7071)
        val hpCosW = cos(hpOmega)
        val hpA0 = 1.0 + hpAlpha

        hpB0 = (((1.0 + hpCosW) / 2.0) / hpA0).toFloat()
        hpB1 = ((-(1.0 + hpCosW)) / hpA0).toFloat()
        hpB2 = (((1.0 + hpCosW) / 2.0) / hpA0).toFloat()
        hpA1 = ((-2.0 * hpCosW) / hpA0).toFloat()
        hpA2 = ((1.0 - hpAlpha) / hpA0).toFloat()

        // Calculate 2nd-order Butterworth Low-Pass coefficients at 3800 Hz
        val lpCutoff = 3800.0
        val lpOmega = 2.0 * PI * lpCutoff / sampleRate
        val lpAlpha = sin(lpOmega) / (2.0 * 0.7071)
        val lpCosW = cos(lpOmega)
        val lpA0 = 1.0 + lpAlpha

        lpB0 = (((1.0 - lpCosW) / 2.0) / lpA0).toFloat()
        lpB1 = (((1.0 - lpCosW)) / lpA0).toFloat()
        lpB2 = (((1.0 - lpCosW) / 2.0) / lpA0).toFloat()
        lpA1 = ((-2.0 * lpCosW) / lpA0).toFloat()
        lpA2 = ((1.0 - lpAlpha) / lpA0).toFloat()

        // Precompute 50 Hz Notch filter (power line hum)
        val notch50W = 2.0 * PI * 50.0 / sampleRate
        notch50Cos = cos(notch50W).toFloat()

        // Precompute 60 Hz Notch filter (power line hum)
        val notch60W = 2.0 * PI * 60.0 / sampleRate
        notch60Cos = cos(notch60W).toFloat()
    }

    /**
     * Complete DSP processing pass on a 16-bit PCM audio buffer.
     * Returns cleaned float samples normalized to [-1.0, 1.0].
     */
    fun processFrame(pcmBuffer: ShortArray, length: Int = pcmBuffer.size): FloatArray {
        val output = FloatArray(length)
        if (length == 0) return output

        // 1. Convert to normalized Float and apply High-Pass & Low-Pass & Notch
        for (i in 0 until length) {
            var sample = pcmBuffer[i] / 32768.0f

            // High-pass filter (80 Hz) - removes sub-bass rumble
            val hpOut = (hpB0 * sample) + (hpB1 * hpX1) + (hpB2 * hpX2) - (hpA1 * hpY1) - (hpA2 * hpY2)
            hpX2 = hpX1
            hpX1 = sample
            hpY2 = hpY1
            hpY1 = hpOut
            sample = hpOut

            // Low-pass filter (3800 Hz) - removes sharp high-pitch screech
            val lpOut = (lpB0 * sample) + (lpB1 * lpX1) + (lpB2 * lpX2) - (lpA1 * lpY1) - (lpA2 * lpY2)
            lpX2 = lpX1
            lpX1 = sample
            lpY2 = lpY1
            lpY1 = lpOut
            sample = lpOut

            // 50 Hz Notch filter (power line hum)
            val n50Out = sample - (2f * notch50Cos * notch50X1) + notch50X2 + (2f * notch50R * notch50Cos * notch50Y1) - (notch50R * notch50R * notch50Y2)
            notch50X2 = notch50X1
            notch50X1 = sample
            notch50Y2 = notch50Y1
            notch50Y1 = n50Out
            sample = n50Out

            // 60 Hz Notch filter (power line hum)
            val n60Out = sample - (2f * notch60Cos * notch60X1) + notch60X2 + (2f * notch60R * notch60Cos * notch60Y1) - (notch60R * notch60R * notch60Y2)
            notch60X2 = notch60X1
            notch60X1 = sample
            notch60Y2 = notch60Y1
            notch60Y1 = n60Out
            sample = n60Out

            // Sudden sharp impulse suppression (transient limiter)
            val delta = abs(sample - prevSample)
            prevSample = sample
            if (delta > runningTransientThreshold) {
                // Soft-knee limiter compression for sudden bangs/clinks
                sample = if (sample > 0f) {
                    runningTransientThreshold + ((sample - runningTransientThreshold) * 0.15f)
                } else {
                    -runningTransientThreshold + ((sample + runningTransientThreshold) * 0.15f)
                }
            }

            output[i] = sample.coerceIn(-1.0f, 1.0f)
        }

        // 2. Adaptive Spectral Gating & Stationary Noise Subtraction
        applySpectralNoiseSuppression(output)

        return output
    }

    /**
     * Adaptive stationary noise subtraction (Wiener / RNNoise style spectral floor).
     * Suppresses steady background traffic hum, auto-rickshaw noise, and fan sounds.
     */
    private fun applySpectralNoiseSuppression(frame: FloatArray) {
        var frameEnergy = 0f
        for (s in frame) {
            frameEnergy += s * s
        }
        val rms = sqrt(frameEnergy / max(1, frame.size))

        // Update background noise estimate during low-energy portions
        if (rms < smoothedEnergy * 0.7f || rms < 0.04f) {
            runningNoiseFloor = (runningNoiseFloor * 0.96f) + (rms * 0.04f)
        }
        smoothedEnergy = (smoothedEnergy * 0.90f) + (rms * 0.10f)

        // Spectral subtraction gain factor
        val snr = rms / max(0.0001f, runningNoiseFloor)
        val suppressionGain = when {
            snr < 1.4f -> 0.08f // Stationary background noise: attenuate by ~92%
            snr < 2.5f -> 0.45f // Transition region
            else -> 1.0f        // Prominent voice activity
        }

        for (i in frame.indices) {
            frame[i] = frame[i] * suppressionGain
        }
    }

    /**
     * Near-Field Voice Activity Detection (VAD).
     * Distinguishes close-proximity vocal speech from far-field room chatter or distant babble.
     */
    fun isNearFieldVoice(frame: FloatArray): Boolean {
        if (frame.isEmpty()) return false

        // 1. Short-Time Energy
        var energy = 0f
        var zeroCrossings = 0
        for (i in frame.indices) {
            energy += frame[i] * frame[i]
            if (i > 0 && ((frame[i] >= 0 && frame[i - 1] < 0) || (frame[i] < 0 && frame[i - 1] >= 0))) {
                zeroCrossings++
            }
        }
        val rms = sqrt(energy / frame.size)
        val zcr = zeroCrossings.toFloat() / frame.size

        // Far-field chatter or background noise has low SNR and irregular zero crossing rate
        // Near-field vocal speech has defined RMS (> 0.035) and ZCR between 0.03 and 0.35
        if (rms < 0.032f) return false
        if (zcr < 0.025f || zcr > 0.40f) return false

        // 2. Autocorrelation Pitch Periodicity Test (voiced speech shows strong lag correlation)
        var maxAutocorr = 0f
        val minLag = (sampleRate / 400) // 400 Hz (high pitch)
        val maxLag = (sampleRate / 80)  // 80 Hz (low pitch)

        for (lag in minLag..min(maxLag, frame.size / 2)) {
            var corr = 0f
            var norm = 0f
            for (i in 0 until (frame.size - lag)) {
                corr += frame[i] * frame[i + lag]
                norm += frame[i] * frame[i]
            }
            if (norm > 0f) {
                val normalizedCorr = corr / norm
                if (normalizedCorr > maxAutocorr) {
                    maxAutocorr = normalizedCorr
                }
            }
        }

        // Near-field human vocal cords exhibit harmonic periodicity > 0.28
        return maxAutocorr >= 0.26f
    }
}
