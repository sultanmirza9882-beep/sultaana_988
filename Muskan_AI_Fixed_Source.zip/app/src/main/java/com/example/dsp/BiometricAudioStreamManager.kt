package com.example.dsp

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.example.BiometricVerdict
import com.example.data.gemini.GeminiLiveSessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.Closeable
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Manages live microphone audio recording, DSP processing, near-field VAD,
 * and biometric voice isolation for Muskan.
 */
class BiometricAudioStreamManager(
    private val context: Context,
    val biometricsEngine: VoiceBiometricsEngine = VoiceBiometricsEngine(context),
    private val isLiveMicOwnerActive: () -> Boolean = { GeminiLiveSessionManager.isLiveMicActive() }
) : Closeable {
    private var scopeJob = SupervisorJob()
    private var scope = CoroutineScope(scopeJob + Dispatchers.Default)
    private val isReleased = AtomicBoolean(false)
    private var recordJob: Job? = null
    private var audioRecord: AudioRecord? = null

    private val _verificationResult = MutableStateFlow(
        BiometricVerificationResult(
            verdict = BiometricVerdict.IDLE,
            confidenceScore = 0f,
            matchedSpeaker = "Unverified",
            isVerified = false,
            latencyMs = 0L,
            message = "Awaiting voice biometric verification"
        )
    )
    val verificationResult: StateFlow<BiometricVerificationResult> = _verificationResult.asStateFlow()

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _liveAudioLevel = MutableStateFlow(0f)
    val liveAudioLevel: StateFlow<Float> = _liveAudioLevel.asStateFlow()

    private val sampleRate = 16000
    private val channelConfig = AudioFormat.CHANNEL_IN_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT
    private val bufferSize = maxOf(
        AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat),
        3200 // 100ms buffer chunk
    )

    /**
     * Starts continuous background audio monitoring for live voice verification and DSP filtering.
     */
    @SuppressLint("MissingPermission")
    fun startLiveVerificationStream(
        onVerifiedSpeechDetected: (pcmBuffer: ShortArray, score: Float) -> Unit = { _, _ -> },
        onSecondarySpeakerDiscarded: (score: Float) -> Unit = {}
    ) {
        if (isReleased.get() || _isRecording.value) return
        // Prevent hardware AudioRecord contention while GeminiLiveSessionManager owns the microphone
        if (isLiveMicOwnerActive()) {
            _verificationResult.value = BiometricVerificationResult(
                verdict = BiometricVerdict.IDLE,
                confidenceScore = 0f,
                matchedSpeaker = "Deferred",
                isVerified = false,
                latencyMs = 0L,
                message = "Biometric stream deferred: Gemini Live owns microphone"
            )
            return
        }
        if (!scopeJob.isActive) {
            scopeJob = SupervisorJob()
            scope = CoroutineScope(scopeJob + Dispatchers.Default)
        }

        recordJob?.cancel()
        recordJob = scope.launch(Dispatchers.IO) {
            try {
                if (isLiveMicOwnerActive()) return@launch
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    bufferSize
                )

                if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                    return@launch
                }

                audioRecord?.startRecording()
                _isRecording.value = true

                val buffer = ShortArray(1600) // 100ms frames
                val accumulatedVoice = mutableListOf<Short>()

                while (isActive && _isRecording.value && !isLiveMicOwnerActive()) {
                    val readSamples = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (readSamples > 0) {
                        // Calculate RMS level for UI
                        var sum = 0.0
                        for (i in 0 until readSamples) {
                            sum += buffer[i] * buffer[i]
                            accumulatedVoice.add(buffer[i])
                        }
                        val rms = kotlin.math.sqrt(sum / readSamples) / 32768.0
                        _liveAudioLevel.update { (rms.toFloat() * 6f).coerceIn(0f, 1f) }

                        // Every 300ms (4800 samples), perform biometric verification
                        if (accumulatedVoice.size >= 4800) {
                            val chunk = accumulatedVoice.toShortArray()
                            accumulatedVoice.clear()

                            val result = biometricsEngine.verifyAudioStream(chunk)
                            _verificationResult.value = result

                            if (result.isVerified) {
                                onVerifiedSpeechDetected(chunk, result.confidenceScore)
                            } else if (result.verdict == BiometricVerdict.REJECTED_UNKNOWN) {
                                onSecondarySpeakerDiscarded(result.confidenceScore)
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                stopStream()
            }
        }
    }

    /**
     * Records a single prompt for Sultan Mirza's voice enrollment flow.
     */
    @SuppressLint("MissingPermission")
    suspend fun recordEnrollmentSample(durationMs: Long = 2500): ShortArray {
        if (isReleased.get() || isLiveMicOwnerActive()) return ShortArray(0)
        val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val recorded = ShortArray(totalSamples)
        var offset = 0

        try {
            val recorder = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )
            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                try { recorder.release() } catch (_: Exception) {}
                return ShortArray(0)
            }

            try {
                recorder.startRecording()
                val chunk = ShortArray(800)
                while (offset < totalSamples && !isLiveMicOwnerActive()) {
                    val toRead = minOf(chunk.size, totalSamples - offset)
                    val read = recorder.read(chunk, 0, toRead)
                    if (read > 0) {
                        System.arraycopy(chunk, 0, recorded, offset, read)
                        offset += read

                        // RMS update
                        var sum = 0.0
                        for (i in 0 until read) sum += chunk[i] * chunk[i]
                        val rms = kotlin.math.sqrt(sum / read) / 32768.0
                        _liveAudioLevel.update { (rms.toFloat() * 6f).coerceIn(0f, 1f) }
                    }
                }
            } finally {
                try { recorder.stop() } catch (_: Exception) {}
                try { recorder.release() } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            return ShortArray(0)
        }

        return recorded
    }

    fun updateExternalVerificationResult(result: BiometricVerificationResult) {
        _verificationResult.value = result
    }

    fun stopStream() {
        _isRecording.value = false
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null
        recordJob?.cancel()
        recordJob = null
    }

    fun release() {
        isReleased.set(true)
        stopStream()
        scopeJob.cancelChildren()
        scopeJob.cancel()
    }

    override fun close() {
        release()
    }
}
