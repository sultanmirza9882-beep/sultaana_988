package com.example.service

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.random.Random
import kotlin.math.cos
import kotlin.math.sin

/**
 * AgentTouchVisualizer
 *
 * A real, always-visible little BOT (robot head on a pointer) drawn over the whole display so the
 * user can watch exactly where Muskan is moving, tapping, typing, scrolling or sketching, live.
 * The tip of the bot's pointer is the exact touch point.
 *
 * - One full-screen, non-touchable overlay (touches pass through to the app underneath).
 * - Uses TYPE_ACCESSIBILITY_OVERLAY when the accessibility service is connected (needs no extra
 *   "draw over other apps" permission); otherwise falls back to TYPE_APPLICATION_OVERLAY.
 * - The bot glides smoothly to each target, shows a click ripple, an action label
 *   ("Tap", "Typing...", "Scroll"), a motion trail for swipes, and can draw sketches/circles.
 * - Stays on screen while the agent is active (persistent), instead of vanishing after 2 seconds.
 */
class AgentTouchVisualizer private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())

    private var overlay: CursorOverlayView? = null
    private var attachedWindowManager: WindowManager? = null
    private var persistent = true
    private var hideRunnable: Runnable? = null

    companion object {
        @Volatile
        private var INSTANCE: AgentTouchVisualizer? = null

        /** Updated synchronously whenever Muskan itself taps/types/scrolls. */
        @Volatile
        var lastAgentActionAt: Long = 0L
            private set

        fun markAgentAction() { lastAgentActionAt = System.currentTimeMillis() }

        fun getInstance(context: Context): AgentTouchVisualizer {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AgentTouchVisualizer(context).also { INSTANCE = it }
            }
        }
    }

    // ---------------------------------------------------------------- public API

    @Volatile private var knownX = -1f
    @Volatile private var knownY = -1f

    /**
     * Human-hand movement: the cursor travels along a gentle curve (never a straight robot line),
     * speeds up then slows down, with a tiny natural tremor. Returns the travel time in ms so the
     * caller can wait for the "finger" to arrive before touching.
     */
    fun humanMoveTo(x: Float, y: Float, label: String? = null): Long {
        markAgentAction()
        val dm = appContext.resources.displayMetrics
        if (knownX < 0f) { knownX = dm.widthPixels / 2f; knownY = dm.heightPixels / 2f }
        val dist = hypot(x - knownX, y - knownY)
        val dur = (230 + dist * 0.30f + Random.nextInt(0, 140)).toLong().coerceIn(230L, 950L)
        knownX = x; knownY = y
        mainHandler.post {
            val view = ensureOverlay() ?: return@post
            view.curveTo(x, y, dur, label)
            touch()
        }
        return dur
    }

    /** The finger presses down: cursor shrinks a little and a ripple spreads (like a real touch). */
    fun press() {
        markAgentAction()
        mainHandler.post { overlay?.pressDown() }
    }

    /** Keep the cursor on screen all the time (default) or let it auto-hide after idling. */
    fun setPersistent(value: Boolean) {
        persistent = value
        mainHandler.post { if (!value) scheduleAutoHide() else cancelAutoHide() }
    }

    /** Shows the cursor (at screen centre the first time) without moving it anywhere. */
    fun show() {
        mainHandler.post {
            val view = ensureOverlay() ?: return@post
            view.visibility = View.VISIBLE
            cancelAutoHide()
        }
    }

    /** Glide the cursor to (x, y). If isClick, also play a click ripple on arrival. */
    fun showPointer(targetX: Float, targetY: Float, isClick: Boolean = false, label: String? = null) {
        markAgentAction()
        knownX = targetX; knownY = targetY
        mainHandler.post {
            val view = ensureOverlay() ?: return@post
            view.glideTo(targetX, targetY, 200L, label) { if (isClick) view.ripple() }
            if (isClick && label == null) view.setLabel("Tap")
            touch()
        }
    }

    /** Glide to (x, y) and show a label such as "Typing: ..." (cursor stays there). */
    fun showAction(x: Float, y: Float, label: String, isClick: Boolean = false) {
        showPointer(x, y, isClick, label)
    }

    /** Swipe/scroll: cursor drags from start to end leaving a fading trail. */
    fun animateSwipe(startX: Float, startY: Float, endX: Float, endY: Float, durationMs: Long = 320L) {
        markAgentAction()
        knownX = endX; knownY = endY
        mainHandler.post {
            val view = ensureOverlay() ?: return@post
            view.swipe(startX, startY, endX, endY, durationMs)
            touch()
        }
    }

    /** The cursor traces a circle (visible in the air; also leaves a stroke if [sketch]). */
    fun drawCircle(cx: Float, cy: Float, radius: Float, sketch: Boolean = true, durationMs: Long = 1400L) {
        val pts = (0..72).map { i ->
            val a = (2 * PI * i / 72.0).toFloat()
            PointF(cx + radius * cos(a), cy + radius * sin(a))
        }
        drawPath(pts, sketch, durationMs)
    }

    /** Cursor follows [points] one after another; with [sketch] a neon stroke stays behind. */
    fun drawPath(points: List<PointF>, sketch: Boolean = true, durationMs: Long = 1600L) {
        if (points.size < 2) return
        markAgentAction()
        knownX = points.last().x; knownY = points.last().y
        mainHandler.post {
            val view = ensureOverlay() ?: return@post
            view.followPath(points, sketch, durationMs)
            touch()
        }
    }

    fun clearSketch() {
        mainHandler.post { overlay?.clearSketch() }
    }

    /** Hides and removes the overlay completely (service stopped / user turned the agent off). */
    fun hidePointer() {
        mainHandler.post {
            cancelAutoHide()
            val view = overlay ?: return@post
            try { attachedWindowManager?.removeView(view) } catch (_: Exception) {}
            overlay = null
            attachedWindowManager = null
        }
    }

    // ---------------------------------------------------------------- internals

    private fun touch() {
        if (persistent) cancelAutoHide() else scheduleAutoHide()
    }

    private fun cancelAutoHide() {
        hideRunnable?.let { mainHandler.removeCallbacks(it) }
        hideRunnable = null
    }

    private fun scheduleAutoHide(delayMs: Long = 4000L) {
        cancelAutoHide()
        hideRunnable = Runnable { hidePointer() }.also { mainHandler.postDelayed(it, delayMs) }
    }

    private fun canDrawOverlays(): Boolean {
        if (MuskanAccessibilityService.instance != null) return true // accessibility overlay needs no permission
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(appContext) else true
    }

    private fun ensureOverlay(): CursorOverlayView? {
        overlay?.let { return it }
        if (!canDrawOverlays()) return null

        val service = MuskanAccessibilityService.instance
        val wm = (service ?: appContext).getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val type = when {
            service != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1 ->
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O -> WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else -> @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        val view = CursorOverlayView(service ?: appContext)
        return try {
            wm.addView(view, params)
            overlay = view
            attachedWindowManager = wm
            val dm = appContext.resources.displayMetrics
            view.placeAt(dm.widthPixels / 2f, dm.heightPixels / 2f)
            view
        } catch (_: Exception) {
            null
        }
    }

    // ---------------------------------------------------------------- the overlay view

    private class CursorOverlayView(context: Context) : View(context) {

        private val density = resources.displayMetrics.density

        private var cx = 0f
        private var cy = 0f
        private var label: String? = null
        private var labelClearAt = 0L

        private var rippleRadius = 0f
        private var rippleAlpha = 0

        // trail for swipes (fading), sketch strokes (kept until cleared)
        private val trail = ArrayList<PointF>()
        private val sketchPaths = ArrayList<Path>()
        private var currentSketch: Path? = null

        private var moveAnim: ValueAnimator? = null
        private var cursorScale = 1f

        // --- Muskan bot cursor paints ---
        private val botGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FF6B57"); style = Paint.Style.STROKE; strokeWidth = 6f * density
            strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND; alpha = 105
        }
        private val botPointerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF6B57"); style = Paint.Style.FILL }
        private val botBody = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1D1529"); style = Paint.Style.FILL }
        private val botEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FF6B57"); style = Paint.Style.STROKE; strokeWidth = 2.2f * density
            strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
        }
        private val botEye = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#5EEAD4"); style = Paint.Style.FILL }
        private val botBulb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFB84D"); style = Paint.Style.FILL }
        private val botMouth = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFF1E0"); style = Paint.Style.STROKE; strokeWidth = 1.7f * density; strokeCap = Paint.Cap.ROUND
        }
        private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FF6B57"); style = Paint.Style.STROKE; strokeWidth = 3f * density
        }
        private val trailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFB84D"); style = Paint.Style.STROKE; strokeWidth = 4f * density
            strokeCap = Paint.Cap.ROUND
        }
        private val sketchPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#10B981"); style = Paint.Style.STROKE; strokeWidth = 5f * density
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        private val labelBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E61D1529") }
        private val labelText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFF1E0"); textSize = 12f * density
        }

        // Bot geometry. Hotspot (the exact touch point) is the tip of the pointer at (0,0). Units are dp.
        private val botHead = RectF(-16f * density, -46f * density, 16f * density, -16f * density)
        private val botMouthRect = RectF(-6f * density, -30f * density, 6f * density, -19f * density)
        private val botPointer = Path().apply {
            moveTo(-6f * density, -17f * density)
            lineTo(0f, 0f)
            lineTo(6f * density, -17f * density)
            close()
        }

        private fun drawBot(canvas: Canvas) {
            val d = density
            val r = 9f * d
            // glow
            canvas.drawPath(botPointer, botGlow)
            canvas.drawRoundRect(botHead, r, r, botGlow)
            // pointer + antenna + ears
            canvas.drawPath(botPointer, botPointerFill)
            canvas.drawLine(0f, -46f * d, 0f, -53f * d, botEdge)
            canvas.drawCircle(0f, -55.5f * d, 3f * d, botBulb)
            canvas.drawRoundRect(RectF(-20f * d, -36f * d, -16f * d, -26f * d), 2f * d, 2f * d, botPointerFill)
            canvas.drawRoundRect(RectF(16f * d, -36f * d, 20f * d, -26f * d), 2f * d, 2f * d, botPointerFill)
            // head
            canvas.drawRoundRect(botHead, r, r, botBody)
            canvas.drawRoundRect(botHead, r, r, botEdge)
            // face
            canvas.drawCircle(-6f * d, -34f * d, 3.2f * d, botEye)
            canvas.drawCircle(6f * d, -34f * d, 3.2f * d, botEye)
            canvas.drawArc(botMouthRect, 25f, 130f, false, botMouth)
        }

        fun placeAt(x: Float, y: Float) { cx = x; cy = y; invalidate() }

        fun setLabel(text: String?) {
            label = text
            labelClearAt = System.currentTimeMillis() + 2500L
            invalidate()
        }

        fun glideTo(x: Float, y: Float, durationMs: Long, newLabel: String?, onArrive: () -> Unit = {}) {
            if (newLabel != null) setLabel(newLabel)
            moveAnim?.cancel()
            val sx = cx; val sy = cy
            moveAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = durationMs
                interpolator = AccelerateDecelerateInterpolator()
                addUpdateListener {
                    val f = it.animatedFraction
                    cx = sx + (x - sx) * f
                    cy = sy + (y - sy) * f
                    invalidate()
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) { onArrive() }
                })
                start()
            }
        }

        fun curveTo(x: Float, y: Float, durationMs: Long, newLabel: String?) {
            if (newLabel != null) setLabel(newLabel)
            moveAnim?.cancel()
            val sx = cx; val sy = cy
            val dx = x - sx; val dy = y - sy
            val dist = hypot(dx, dy).coerceAtLeast(1f)
            // control point: midpoint pushed sideways by ~12-18% of the distance (a natural arc)
            val bend = dist * (0.12f + Random.nextFloat() * 0.06f) * (if (Random.nextBoolean()) 1f else -1f)
            val qx = (sx + x) / 2f + (-dy / dist) * bend
            val qy = (sy + y) / 2f + (dx / dist) * bend
            moveAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = durationMs
                interpolator = AccelerateDecelerateInterpolator()
                addUpdateListener {
                    val t = it.animatedFraction
                    val u = 1f - t
                    val tremor = sin(t * 38f) * (1.1f * density) * (1f - t)   // fades out as the hand settles
                    cx = u * u * sx + 2f * u * t * qx + t * t * x + tremor
                    cy = u * u * sy + 2f * u * t * qy + t * t * y + tremor
                    invalidate()
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) { cx = x; cy = y; invalidate() }
                })
                start()
            }
        }

        fun pressDown() {
            ValueAnimator.ofFloat(1f, 0.78f, 1f).apply {
                duration = 240L
                addUpdateListener { cursorScale = it.animatedValue as Float; invalidate() }
                start()
            }
            ripple()
        }

        fun ripple() {
            ValueAnimator.ofFloat(6f * density, 34f * density).apply {
                duration = 380L
                addUpdateListener {
                    rippleRadius = it.animatedValue as Float
                    rippleAlpha = ((1f - it.animatedFraction) * 255).toInt().coerceIn(0, 255)
                    invalidate()
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) { rippleAlpha = 0; invalidate() }
                })
                start()
            }
        }

        fun swipe(sx: Float, sy: Float, ex: Float, ey: Float, durationMs: Long) {
            setLabel("Swipe")
            trail.clear()
            moveAnim?.cancel()
            cx = sx; cy = sy
            moveAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = durationMs
                addUpdateListener {
                    val f = it.animatedFraction
                    cx = sx + (ex - sx) * f
                    cy = sy + (ey - sy) * f
                    trail.add(PointF(cx, cy))
                    if (trail.size > 24) trail.removeAt(0)
                    invalidate()
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        postDelayed({ trail.clear(); invalidate() }, 350L)
                    }
                })
                start()
            }
        }

        fun followPath(points: List<PointF>, sketch: Boolean, durationMs: Long) {
            setLabel(if (sketch) "Sketching" else "Moving")
            moveAnim?.cancel()
            val path = if (sketch) Path().also { p ->
                p.moveTo(points[0].x, points[0].y); sketchPaths.add(p); currentSketch = p
            } else null
            val last = points.size - 1
            moveAnim = ValueAnimator.ofFloat(0f, last.toFloat()).apply {
                duration = durationMs
                addUpdateListener {
                    val pos = it.animatedValue as Float
                    val i = pos.toInt().coerceAtMost(last - 1)
                    val f = pos - i
                    val a = points[i]; val b = points[i + 1]
                    val nx = a.x + (b.x - a.x) * f
                    val ny = a.y + (b.y - a.y) * f
                    if (path != null) path.lineTo(nx, ny)
                    cx = nx; cy = ny
                    invalidate()
                }
                start()
            }
        }

        fun clearSketch() { sketchPaths.clear(); currentSketch = null; invalidate() }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            for (p in sketchPaths) canvas.drawPath(p, sketchPaint)

            if (trail.size > 1) {
                for (i in 1 until trail.size) {
                    trailPaint.alpha = (255f * i / trail.size).toInt()
                    canvas.drawLine(trail[i - 1].x, trail[i - 1].y, trail[i].x, trail[i].y, trailPaint)
                }
            }

            if (rippleAlpha > 0) {
                ripplePaint.alpha = rippleAlpha
                canvas.drawCircle(cx, cy, rippleRadius, ripplePaint)
            }

            // Bot with the tip of its pointer at (cx, cy)
            canvas.save()
            canvas.translate(cx, cy)
            canvas.scale(cursorScale, cursorScale)
            drawBot(canvas)
            canvas.restore()

            val text = label
            if (text != null) {
                if (System.currentTimeMillis() > labelClearAt) {
                    label = null
                } else {
                    val pad = 6f * density
                    val w = labelText.measureText(text) + pad * 2
                    val h = labelText.textSize + pad
                    val lx = (cx + 20f * density).coerceAtMost(width - w - 4f * density)
                    val ly = (cy + 26f * density).coerceAtMost(height - h - 4f * density)
                    canvas.drawRoundRect(lx, ly, lx + w, ly + h, 8f * density, 8f * density, labelBg)
                    canvas.drawText(text, lx + pad, ly + labelText.textSize, labelText)
                    postInvalidateDelayed(400L)
                }
            }
        }
    }
}
