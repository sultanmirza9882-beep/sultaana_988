package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.example.VoiceSessionManager
import java.util.Locale

class MuskanAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        VoiceSessionManager.setAccessibilityServiceConnected(true)
        // Always-on arrow cursor so the user can watch everything Muskan does, live.
        AgentTouchVisualizer.getInstance(this).show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // Manual User Touch Override:
        // When user taps, clicks, scrolls, or gestures manually on the screen,
        // immediately cancel any ongoing autonomous agentic tasks and yield control!
        when (event.eventType) {
            AccessibilityEvent.TYPE_GESTURE_DETECTION_START,
            AccessibilityEvent.TYPE_TOUCH_INTERACTION_START -> {
                // Only physical user touch triggers TYPE_TOUCH_INTERACTION_START / TYPE_GESTURE_DETECTION_START.
                // App-initiated scrolls/clicks (TYPE_VIEW_SCROLLED / TYPE_VIEW_CLICKED) must NOT cancel the agent.
                val ownAction = System.currentTimeMillis() - AgentTouchVisualizer.lastAgentActionAt < 2500L
                val isBusy = VoiceSessionManager.uiState.value.isAgenticTaskRunning ||
                        com.example.automation.UniversalPhoneAgent.isRunning
                if (!ownAction && isBusy) {
                    com.example.automation.UniversalPhoneAgent.cancel()
                    VoiceSessionManager.notifyUserManualTouchDetected()
                }
            }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
        }
        AgentTouchVisualizer.getInstance(this).hidePointer()
        VoiceSessionManager.setAccessibilityServiceConnected(false)
    }

    // --- Global Actions ---

    fun triggerHome(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_HOME)
    }

    fun triggerBack(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun triggerRecents(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    fun triggerNotifications(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    }

    fun triggerQuickSettings(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
    }

    fun triggerLockScreen(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        } else {
            performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
        }
    }

    fun triggerTakeScreenshot(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        } else {
            false
        }
    }

    /**
     * Programmatic screenshot capture supported on Android 11+ (API 30+).
     * Provides an in-memory Bitmap for OCR or visual perception without writing to disk.
     */
    fun takeScreenCaptureBitmap(callback: (android.graphics.Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val executor = androidx.core.content.ContextCompat.getMainExecutor(this)
            try {
                takeScreenshot(
                    android.view.Display.DEFAULT_DISPLAY,
                    executor,
                    object : TakeScreenshotCallback {
                        override fun onSuccess(screenshotResult: ScreenshotResult) {
                            try {
                                val buffer = screenshotResult.hardwareBuffer
                                val colorSpace = screenshotResult.colorSpace
                                val hwBitmap = android.graphics.Bitmap.wrapHardwareBuffer(buffer, colorSpace)
                                buffer.close()
                                val swBitmap = hwBitmap?.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
                                callback(swBitmap)
                            } catch (_: Exception) {
                                callback(null)
                            }
                        }

                        override fun onFailure(errorCode: Int) {
                            callback(null)
                        }
                    }
                )
            } catch (_: Exception) {
                callback(null)
            }
        } else {
            callback(null)
        }
    }

    // --- On-Screen Node Interactions ---

    /**
     * Finds visible UI elements matching the query text or content description
     * and performs a tap/click action.
     */
    fun clickElementByText(query: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val cleanQuery = query.lowercase(Locale.ROOT).trim()

        val matchingNodes = mutableListOf<AccessibilityNodeInfo>()
        collectMatchingNodes(root, cleanQuery, matchingNodes)

        val target = matchingNodes.firstOrNull() ?: return false
        return performClickOnNode(target)
    }

    private fun collectMatchingNodes(
        node: AccessibilityNodeInfo?,
        query: String,
        results: MutableList<AccessibilityNodeInfo>
    ) {
        if (node == null) return

        val text = node.text?.toString()?.lowercase(Locale.ROOT) ?: ""
        val contentDesc = node.contentDescription?.toString()?.lowercase(Locale.ROOT) ?: ""

        if (text.contains(query) || contentDesc.contains(query)) {
            results.add(node)
        }

        for (i in 0 until node.childCount) {
            collectMatchingNodes(node.getChild(i), query, results)
        }
    }

    /**
     * Automatically scrolls the active screen view up or down.
     */
    fun performScroll(scrollDown: Boolean): Boolean {
        val root = rootInActiveWindow
        AgentTouchVisualizer.markAgentAction()

        // Reels / Shorts / feeds are pager-style: ACTION_SCROLL_FORWARD often "succeeds" without moving.
        // A real swipe gesture is what actually changes the video.
        val pkg = root?.packageName?.toString().orEmpty()
        val swipeFirst = listOf("instagram", "youtube", "facebook", "sharechat", "snapchat", "tiktok", "moj")
            .any { pkg.contains(it, ignoreCase = true) }
        if (swipeFirst) return performSwipeGesture(scrollDown)

        val scrollableNode = findScrollableNode(root)

        if (scrollableNode != null) {
            val action = if (scrollDown) {
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            } else {
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            }
            val result = scrollableNode.performAction(action)
            val dm = resources.displayMetrics
            AgentTouchVisualizer.getInstance(this).animateSwipe(
                dm.widthPixels / 2f, if (scrollDown) dm.heightPixels * 0.7f else dm.heightPixels * 0.3f,
                dm.widthPixels / 2f, if (scrollDown) dm.heightPixels * 0.3f else dm.heightPixels * 0.7f
            )
            return result
        }

        // Fallback: Gesture swipe if scrollable node is not directly exposed
        return performSwipeGesture(scrollDown)
    }

    private fun findScrollableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isScrollable) return node

        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            val found = findScrollableNode(child)
            if (found != null) return found
        }
        return null
    }

    /**
     * Really draws a circle on screen with a touch gesture (works in any drawing app) while the
     * neon cursor traces and sketches it so the user can watch.
     */
    fun dispatchCircleGesture(cx: Float, cy: Float, radius: Float, durationMs: Long = 1400L): Boolean {
        val path = Path()
        val steps = 48
        for (i in 0..steps) {
            val a = (2 * Math.PI * i / steps).toFloat()
            val x = cx + radius * Math.cos(a.toDouble()).toFloat()
            val y = cy + radius * Math.sin(a.toDouble()).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        AgentTouchVisualizer.getInstance(this).drawCircle(cx, cy, radius, sketch = true, durationMs = durationMs)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    /**
     * A swipe the way a finger really moves: slightly curved, with natural speed. The neon cursor
     * follows exactly the same path so the user sees what is being done.
     */
    fun dispatchHumanSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 420L): Boolean {
        val dx = x2 - x1; val dy = y2 - y1
        val dist = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat().coerceAtLeast(1f)
        val bend = dist * 0.06f * (if (Math.random() < 0.5) 1f else -1f)
        val qx = (x1 + x2) / 2f + (-dy / dist) * bend
        val qy = (y1 + y2) / 2f + (dx / dist) * bend
        val path = Path()
        val pts = ArrayList<android.graphics.PointF>()
        val steps = 24
        for (i in 0..steps) {
            val t = i / steps.toFloat(); val u = 1f - t
            val px = u * u * x1 + 2f * u * t * qx + t * t * x2
            val py = u * u * y1 + 2f * u * t * qy + t * t * y2
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            pts.add(android.graphics.PointF(px, py))
        }
        AgentTouchVisualizer.markAgentAction()
        AgentTouchVisualizer.getInstance(this).drawPath(pts, sketch = false, durationMs = durationMs)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    private fun performSwipeGesture(scrollDown: Boolean): Boolean {
        val displayMetrics = resources.displayMetrics
        val width = displayMetrics.widthPixels.toFloat()
        val height = displayMetrics.heightPixels.toFloat()

        val startX = width / 2f
        val startY = if (scrollDown) height * 0.75f else height * 0.25f
        val endY = if (scrollDown) height * 0.25f else height * 0.75f

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(startX, endY)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 300))
            .build()

        AgentTouchVisualizer.getInstance(this).animateSwipe(startX, startY, startX, endY)
        return dispatchGesture(gesture, null, null)
    }

    /**
     * Precision coordinate tap on any (x, y) location on screen with neon pointer.
     */
    fun dispatchCoordinateTap(
        x: Float,
        y: Float,
        durationMs: Long = 50L,
        animatePointer: Boolean = true,
        callback: (Boolean) -> Unit = {}
    ): Boolean {
        AgentTouchVisualizer.markAgentAction()
        if (animatePointer) {
            AgentTouchVisualizer.getInstance(this).showPointer(x, y, isClick = true)
        }
        val path = Path().apply {
            moveTo(x, y)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()

        return dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback(false)
            }
        }, null)
    }

    /**
     * Precision coordinate double tap with neon pointer.
     */
    fun dispatchDoubleTap(
        x: Float,
        y: Float,
        callback: (Boolean) -> Unit = {}
    ): Boolean {
        AgentTouchVisualizer.getInstance(this).showPointer(x, y, isClick = true)
        val path1 = Path().apply { moveTo(x, y) }
        val stroke1 = GestureDescription.StrokeDescription(path1, 0, 50)
        val path2 = Path().apply { moveTo(x, y) }
        val stroke2 = GestureDescription.StrokeDescription(path2, 110, 50)
        val gesture = GestureDescription.Builder()
            .addStroke(stroke1)
            .addStroke(stroke2)
            .build()

        return dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback(false)
            }
        }, null)
    }

    private fun performClickOnNode(target: AccessibilityNodeInfo): Boolean {
        var clickableNode: AccessibilityNodeInfo? = target
        while (clickableNode != null && !clickableNode.isClickable) {
            clickableNode = clickableNode.parent
        }
        val targetToClick = clickableNode ?: target
        val rect = Rect()
        targetToClick.getBoundsInScreen(rect)
        if (rect.width() > 0 && rect.height() > 0) {
            AgentTouchVisualizer.getInstance(this).showPointer(rect.exactCenterX(), rect.exactCenterY(), isClick = true)
        }
        return targetToClick.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /**
     * Finds and clicks Skip Ad button on YouTube or video streaming apps.
     * Uses text search, View ID search, and coordinate fallback.
     */
    fun performSkipAd(): Boolean {
        // 1. Accessibility text search for Skip Ad buttons
        val queries = listOf("skip ad", "skip ads", "skip", "skip advertisement", "विज्ञापन छोड़ें", "छोड़ें")
        for (q in queries) {
            val clicked = clickElementByText(q)
            if (clicked) return true
        }

        // 2. Search by YouTube View IDs
        val root = rootInActiveWindow
        if (root != null) {
            val ids = listOf(
                "com.google.android.youtube:id/skip_ad_button",
                "com.google.android.youtube:id/subskip_ad_button",
                "com.google.android.youtube:id/modern_skip_ad_button",
                "com.google.android.youtube:id/ad_skip_button"
            )
            for (id in ids) {
                val nodes = root.findAccessibilityNodeInfosByViewId(id)
                if (!nodes.isNullOrEmpty()) {
                    val clicked = performClickOnNode(nodes[0])
                    if (clicked) return true
                }
            }
        }

        // 3. Fallback coordinate tap on standard YouTube Skip Ad button location
        val metrics = resources.displayMetrics
        val skipX = metrics.widthPixels * 0.88f
        val skipY = metrics.heightPixels * 0.36f // Standard bottom-right of video frame in portrait
        return dispatchCoordinateTap(skipX, skipY)
    }

    /**
     * Precision coordinate long press.
     */
    fun dispatchCoordinateLongPress(
        x: Float,
        y: Float,
        durationMs: Long = 650L,
        callback: (Boolean) -> Unit = {}
    ): Boolean {
        val path = Path().apply {
            moveTo(x, y)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()

        return dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback(false)
            }
        }, null)
    }

    /**
     * Precision drag/swipe from (startX, startY) to (endX, endY).
     */
    fun dispatchCoordinateDrag(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long = 350L,
        callback: (Boolean) -> Unit = {}
    ): Boolean {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()

        return dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback(false)
            }
        }, null)
    }

    /**
     * Captures all visible screen elements with their bounding rectangles and center coordinates.
     */
    fun captureVisibleScreenElements(): List<ScreenElement> {
        val root = rootInActiveWindow ?: return emptyList()
        val elements = mutableListOf<ScreenElement>()
        collectScreenElements(root, elements)
        return elements
    }

    private fun collectScreenElements(node: AccessibilityNodeInfo?, list: MutableList<ScreenElement>) {
        if (node == null) return
        val rect = Rect()
        node.getBoundsInScreen(rect)

        val text = node.text?.toString().orEmpty().trim()
        val desc = node.contentDescription?.toString().orEmpty().trim()
        val cls = node.className?.toString().orEmpty()

        if (text.isNotBlank() || desc.isNotBlank() || node.isClickable || node.isEditable) {
            list.add(
                ScreenElement(
                    text = text,
                    contentDescription = desc,
                    className = cls,
                    isClickable = node.isClickable,
                    isEditable = node.isEditable,
                    bounds = rect,
                    centerX = rect.exactCenterX(),
                    centerY = rect.exactCenterY()
                )
            )
        }

        for (i in 0 until node.childCount) {
            collectScreenElements(node.getChild(i), list)
        }
    }


    /**
     * Injects dictated text into the currently focused or first available editable field.
     */
    fun typeTextIntoFocusedField(textToType: String): Boolean {
        val root = rootInActiveWindow ?: return false

        // 1. Check focused input field
        val focusedNode = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY)
            ?: findFirstEditableNode(root)

        if (focusedNode != null && focusedNode.isEditable) {
            // Give the field real focus first (YouTube's search box is only an icon until tapped)
            focusedNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            focusedNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val arguments = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    textToType
                )
            }
            val success = focusedNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            return success
        }

        return false
    }

    /**
     * Presses the keyboard "Search/Enter" action on the focused text field.
     * ACTION_SET_TEXT only fills text; it never submits it.
     */
    fun submitFocusedTextField(): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: findFirstEditableNode(root)
            ?: return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return true
        }
        // Fallback 1: Try an on-screen "search" or "send" button
        if (clickElementByText("search") || clickElementByText("खोज") || clickElementByText("send")) {
            return true
        }
        // Fallback 2: Tap bottom-right IME Search/Enter/Action key scaled dynamically to device DisplayMetrics
        val dm = resources.displayMetrics
        val imeBounds = try {
            windows?.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }?.let { imeWin ->
                Rect().also { imeWin.getBoundsInScreen(it) }
            }
        } catch (_: Exception) {
            null
        }
        val (tapX, tapY) = computeScaledImeActionKeyCoordinates(dm, imeBounds)
        return dispatchCoordinateTap(tapX, tapY)
    }

    /** True when YouTube search results (real video cards) are visible. */
    fun hasVideoResults(): Boolean {
        val root = rootInActiveWindow ?: return false
        val out = mutableListOf<AccessibilityNodeInfo>()
        collectVideoCandidates(root, resources.displayMetrics.heightPixels, out)
        return out.isNotEmpty()
    }

    /** Clicks the top-most real video card (skips the search bar and sponsored items). */
    fun clickFirstVideoResult(): Boolean {
        val root = rootInActiveWindow ?: return false
        val out = mutableListOf<AccessibilityNodeInfo>()
        collectVideoCandidates(root, resources.displayMetrics.heightPixels, out)
        val target = out.minByOrNull {
            val r = Rect()
            it.getBoundsInScreen(r)
            r.top
        } ?: return false
        return performClickOnNode(target)
    }

    private fun collectVideoCandidates(
        node: AccessibilityNodeInfo?,
        screenHeight: Int,
        out: MutableList<AccessibilityNodeInfo>
    ) {
        if (node == null) return
        val desc = node.contentDescription?.toString()?.lowercase(Locale.ROOT).orEmpty()
        val rect = Rect()
        node.getBoundsInScreen(rect)
        val looksLikeVideo = desc.length > 25 &&
            (desc.contains("play video") || desc.contains("वीडियो चलाएं") ||
                (desc.contains(" - ") && (desc.contains("views") || desc.contains("व्यू"))))
        val sponsored = desc.contains("sponsored") || desc.contains("विज्ञापन")
        if (looksLikeVideo && !sponsored && !node.isEditable &&
            rect.width() > 0 && rect.top > screenHeight * 0.15f
        ) {
            out.add(node)
        }
        for (i in 0 until node.childCount) {
            collectVideoCandidates(node.getChild(i), screenHeight, out)
        }
    }

    private fun findFirstEditableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable) return node

        for (i in 0 until node.childCount) {
            val found = findFirstEditableNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    companion object {
        private const val REF_SCREEN_WIDTH = 1080f
        private const val REF_SCREEN_HEIGHT = 2460f
        private const val IME_ACTION_KEY_X_RATIO = 985f / REF_SCREEN_WIDTH
        private const val IME_ACTION_KEY_Y_RATIO = 2255f / REF_SCREEN_HEIGHT
        private const val IME_WINDOW_ACTION_KEY_Y_RATIO = 0.87f

        var instance: MuskanAccessibilityService? = null
            private set

        fun isConnected(): Boolean = instance != null

        /**
         * Computes screen-resolution-scaled coordinates for the bottom-right IME action key
         * using the device's [DisplayMetrics] (and actual IME window bounds when exposed).
         */
        fun computeScaledImeActionKeyCoordinates(
            displayMetrics: DisplayMetrics,
            imeWindowBounds: Rect? = null
        ): Pair<Float, Float> {
            val maxW = displayMetrics.widthPixels.toFloat().coerceAtLeast(1f)
            val maxH = displayMetrics.heightPixels.toFloat().coerceAtLeast(1f)
            if (imeWindowBounds != null && imeWindowBounds.width() > 0 && imeWindowBounds.height() > 0) {
                val x = (imeWindowBounds.left + imeWindowBounds.width() * IME_ACTION_KEY_X_RATIO).coerceIn(0f, maxW)
                val y = (imeWindowBounds.top + imeWindowBounds.height() * IME_WINDOW_ACTION_KEY_Y_RATIO).coerceIn(0f, maxH)
                return x to y
            }
            val scaledX = (maxW * IME_ACTION_KEY_X_RATIO).coerceIn(0f, maxW)
            val scaledY = (maxH * IME_ACTION_KEY_Y_RATIO).coerceIn(0f, maxH)
            return scaledX to scaledY
        }

        /**
         * Checks if the Accessibility Service is enabled in Android System Settings.
         */
        fun isAccessibilitySettingsEnabled(context: Context): Boolean {
            val expectedServiceName = "${context.packageName}/${MuskanAccessibilityService::class.java.canonicalName}"
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            return enabledServices.contains(expectedServiceName) || instance != null
        }

        /**
         * Opens System Accessibility Settings page.
         */
        fun openAccessibilitySettings(context: Context) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }

        /**
         * Launches any installed application matching the name query.
         */
        fun launchAppByName(context: Context, appQuery: String): Boolean {
            val query = appQuery.lowercase(Locale.ROOT).trim()
            val pm = context.packageManager

            // Common aliases for all 16 primary target apps & system tools
            val packageAliases = mapOf(
                // 1. Instagram
                "instagram" to "com.instagram.android",
                "insta" to "com.instagram.android",
                "इंस्टाग्राम" to "com.instagram.android",
                // 2. YouTube
                "youtube" to "com.google.android.youtube",
                "युटुब" to "com.google.android.youtube",
                "yt" to "com.google.android.youtube",
                // 3. Facebook
                "facebook" to "com.facebook.katana",
                "fb" to "com.facebook.katana",
                "फेसबुक" to "com.facebook.katana",
                // 4. Telegram
                "telegram" to "org.telegram.messenger",
                "टेलीग्राम" to "org.telegram.messenger",
                // 5. WhatsApp
                "whatsapp" to "com.whatsapp",
                "व्हाट्सएप" to "com.whatsapp",
                // 6. Call logs
                "call log" to "com.google.android.dialer",
                "call logs" to "com.google.android.dialer",
                "कॉल लॉग्स" to "com.google.android.dialer",
                "call history" to "com.google.android.dialer",
                // 7. SMS / Messages
                "sms" to "com.google.android.apps.messaging",
                "messages" to "com.google.android.apps.messaging",
                "message" to "com.google.android.apps.messaging",
                "मैसेज" to "com.google.android.apps.messaging",
                // 8. ShareChat
                "sharechat" to "in.mohalla.sharechat",
                "शेयरचैट" to "in.mohalla.sharechat",
                // 9 & 10. Chrome & Browser
                "chrome" to "com.android.chrome",
                "browser" to "com.android.chrome",
                "ब्राउज़र" to "com.android.chrome",
                "क्रोम" to "com.android.chrome",
                // 11. Android Studio Workspace
                "android studio" to context.packageName,
                "एंड्राइड स्टूडियो" to context.packageName,
                "studio" to context.packageName,
                // 12. ChatGPT
                "chatgpt" to "com.openai.chatgpt",
                "chet gpt" to "com.openai.chatgpt",
                "chat gpt" to "com.openai.chatgpt",
                // 13. Gemini
                "gemini" to "com.google.android.apps.bard",
                "bard" to "com.google.android.apps.bard",
                // 14. Notes (Nots)
                "notes" to "com.google.android.keep",
                "nots" to "com.google.android.keep",
                "keep" to "com.google.android.keep",
                "नोट्स" to "com.google.android.keep",
                // 15. Google Drive
                "drive" to "com.google.android.apps.docs",
                "google drive" to "com.google.android.apps.docs",
                "ड्राइव" to "com.google.android.apps.docs",
                // 16. TeraBox
                "terabox" to "com.dubox.drive",
                "टेराबॉक्स" to "com.dubox.drive",
                // Auxiliary & Xiaomi HyperOS (Redmi 13 5G) Native System Tools
                "camera" to "com.android.camera",
                "कैमरा" to "com.android.camera",
                "gcam" to "com.google.android.GoogleCamera",
                "maps" to "com.google.android.apps.maps",
                "मैप्स" to "com.google.android.apps.maps",
                "gallery" to "com.miui.gallery",
                "गैलरी" to "com.miui.gallery",
                "photos" to "com.google.android.apps.photos",
                "settings" to "com.android.settings",
                "सेटिंग्स" to "com.android.settings",
                "सेटिंग" to "com.android.settings",
                "calculator" to "com.miui.calculator",
                "कैलकुलेटर" to "com.miui.calculator",
                "clock" to "com.android.deskclock",
                "alarm" to "com.android.deskclock",
                "अलार्म" to "com.android.deskclock",
                "file manager" to "com.mi.android.globalFileexplorer",
                "files" to "com.mi.android.globalFileexplorer",
                "फाइल मैनेजर" to "com.mi.android.globalFileexplorer",
                "mi remote" to "com.duokan.phone.remotecontroller",
                "remote" to "com.duokan.phone.remotecontroller",
                "रिमोट" to "com.duokan.phone.remotecontroller",
                "security" to "com.miui.securitycenter",
                "mi notes" to "com.miui.notes",
                "gmail" to "com.google.android.gm"
            )

            val secondaryPackageFallbacks = mapOf(
                "com.android.camera" to "com.google.android.GoogleCamera",
                "com.miui.gallery" to "com.google.android.apps.photos",
                "com.miui.calculator" to "com.google.android.calculator",
                "com.android.deskclock" to "com.google.android.deskclock",
                "com.google.android.keep" to "com.miui.notes"
            )

            // 1. Direct alias check (with Xiaomi HyperOS <-> Google package fallback)
            for ((alias, packageName) in packageAliases) {
                if (query.contains(alias)) {
                    val primaryIntent = pm.getLaunchIntentForPackage(packageName)
                    val fallbackPkg = secondaryPackageFallbacks[packageName]
                    val launchIntent = primaryIntent ?: (if (fallbackPkg != null) pm.getLaunchIntentForPackage(fallbackPkg) else null)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(launchIntent)
                        return true
                    }
                }
            }

            // 2. Query all installed launcher activities
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val pkgAppsList = pm.queryIntentActivities(mainIntent, 0)

            for (resolveInfo in pkgAppsList) {
                val label = resolveInfo.loadLabel(pm).toString().lowercase(Locale.ROOT)
                val packageName = resolveInfo.activityInfo.packageName.lowercase(Locale.ROOT)

                if (label.contains(query) || query.contains(label) || packageName.contains(query)) {
                    val launchIntent = pm.getLaunchIntentForPackage(resolveInfo.activityInfo.packageName)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(launchIntent)
                        return true
                    }
                }
            }

            // 3. Resilient Fallbacks (System Intents or Web Destinations)
            try {
                when {
                    query.contains("call log") || query.contains("calls") || query.contains("कॉल") -> {
                        val callLogIntent = Intent(Intent.ACTION_VIEW).apply {
                            type = android.provider.CallLog.Calls.CONTENT_TYPE
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        try {
                            context.startActivity(callLogIntent)
                            return true
                        } catch (_: Exception) {
                            val dialerIntent = Intent(Intent.ACTION_DIAL).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                            context.startActivity(dialerIntent)
                            return true
                        }
                    }
                    query.contains("sms") || query.contains("messages") || query.contains("message") || query.contains("मैसेज") -> {
                        val smsIntent = Intent(Intent.ACTION_MAIN).apply {
                            addCategory(Intent.CATEGORY_APP_MESSAGING)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        try {
                            context.startActivity(smsIntent)
                            return true
                        } catch (_: Exception) {
                            val fallbackSms = Intent(Intent.ACTION_VIEW, Uri.parse("sms:")).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                            context.startActivity(fallbackSms)
                            return true
                        }
                    }
                    query.contains("telegram") || query.contains("टेलीग्राम") -> {
                        val tgIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://web.telegram.org")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(tgIntent)
                        return true
                    }
                    query.contains("facebook") || query.contains("fb") || query.contains("फेसबुक") -> {
                        val fbIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(fbIntent)
                        return true
                    }
                    query.contains("sharechat") || query.contains("शेयरचैट") -> {
                        val scIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://sharechat.com")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(scIntent)
                        return true
                    }
                    query.contains("chatgpt") || query.contains("chet gpt") || query.contains("chat gpt") -> {
                        val gptIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(gptIntent)
                        return true
                    }
                    query.contains("gemini") -> {
                        val geminiIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://gemini.google.com")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(geminiIntent)
                        return true
                    }
                    query.contains("notes") || query.contains("nots") || query.contains("keep") || query.contains("नोट्स") -> {
                        val keepIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://keep.google.com")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(keepIntent)
                        return true
                    }
                    query.contains("drive") || query.contains("ड्राइव") -> {
                        val driveIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://drive.google.com")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(driveIntent)
                        return true
                    }
                    query.contains("terabox") || query.contains("टेराबॉक्स") -> {
                        val tbIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.terabox.com")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(tbIntent)
                        return true
                    }
                    query.contains("android studio") || query.contains("studio") || query.contains("एंड्राइड स्टूडियो") -> {
                        val studioIntent = pm.getLaunchIntentForPackage(context.packageName)?.apply {
                            putExtra("OPEN_WORKSPACE", true)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        if (studioIntent != null) {
                            context.startActivity(studioIntent)
                            return true
                        }
                    }
                    query.contains("youtube") || query.contains("युटुब") -> {
                        val ytIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(ytIntent)
                        return true
                    }
                    query.contains("instagram") || query.contains("insta") || query.contains("इंस्टाग्राम") -> {
                        val instaIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(instaIntent)
                        return true
                    }
                    query.contains("whatsapp") || query.contains("व्हाट्सएप") -> {
                        val waIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(waIntent)
                        return true
                    }
                    query.contains("camera") -> {
                        val camIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(camIntent)
                        return true
                    }
                    query.contains("maps") -> {
                        val mapIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=maps")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(mapIntent)
                        return true
                    }
                    query.contains("settings") -> {
                        val setIntent = Intent(Settings.ACTION_SETTINGS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(setIntent)
                        return true
                    }
                    query.contains("chrome") || query.contains("browser") || query.contains("ब्राउज़र") || query.contains("google") -> {
                        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(webIntent)
                        return true
                    }
                }
            } catch (_: Exception) {}

            return false
        }
    }
}

/**
 * Represents a recognized interactive UI element on the screen.
 */
data class ScreenElement(
    val text: String,
    val contentDescription: String,
    val className: String,
    val isClickable: Boolean,
    val isEditable: Boolean,
    val bounds: Rect,
    val centerX: Float,
    val centerY: Float
)
