package com.example.service

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class CapturedNotification(
    val key: String,
    val packageName: String,
    val title: String,
    val text: String,
    val postTime: Long
)

/**
 * Permission-gated NotificationListenerService so Muskan can read incoming
 * WhatsApp, SMS, and app notifications only when explicitly enabled by the owner.
 */
class MuskanNotificationListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        _isConnected.value = true
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        _isConnected.value = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (sbn.packageName == packageName) return

        val extras = sbn.notification?.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString()?.trim().orEmpty()

        if (title.isBlank() && text.isBlank()) return

        val item = CapturedNotification(
            key = sbn.key,
            packageName = sbn.packageName,
            title = title,
            text = text,
            postTime = sbn.postTime
        )

        _recentNotifications.update { current ->
            (listOf(item) + current.filterNot { it.key == item.key }).take(MAX_STORED_NOTIFICATIONS)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null) return
        _recentNotifications.update { current -> current.filterNot { it.key == sbn.key } }
    }

    companion object {
        private const val MAX_STORED_NOTIFICATIONS = 50

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _recentNotifications = MutableStateFlow<List<CapturedNotification>>(emptyList())
        val recentNotifications: StateFlow<List<CapturedNotification>> = _recentNotifications.asStateFlow()

        fun isNotificationAccessEnabled(context: Context): Boolean {
            val enabledListeners = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false
            val component = ComponentName(context, MuskanNotificationListenerService::class.java)
            return enabledListeners.contains(component.flattenToString()) ||
                enabledListeners.contains(component.flattenToShortString())
        }

        fun getRecentForPackage(packageName: String, limit: Int = 5): List<CapturedNotification> {
            return _recentNotifications.value
                .filter { it.packageName == packageName }
                .take(limit)
        }

        fun clearCaptured() {
            _recentNotifications.value = emptyList()
        }
    }
}
