package com.example.service

import android.animation.ValueAnimator
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import com.example.AssistantState
import com.example.MainActivity
import com.example.R
import com.example.VoiceSessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Lightweight, draggable floating assistant bubble staying visible across all apps
 * using Android WindowManager (TYPE_APPLICATION_OVERLAY).
 * Supports:
 * - Dynamic pulsing/glow states: Standby, Listening, Thinking, Speaking
 * - Smooth drag-to-move, tap-to-activate, and drag-to-dismiss physics
 * - Seamless zero-touch integration with VoiceSessionManager
 */
class FloatingBubbleService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var windowManager: WindowManager? = null
    private var overlayRootView: FrameLayout? = null
    private var bubbleContainer: FrameLayout? = null
    private var pulseRingView: View? = null
    private var innerCoreView: View? = null
    private var bubbleIcon: ImageView? = null
    private var statusBadge: TextView? = null
    private var dismissTargetZone: FrameLayout? = null

    private lateinit var bubbleLayoutParams: WindowManager.LayoutParams
    private lateinit var dismissLayoutParams: WindowManager.LayoutParams

    private var pulseAnimator: ValueAnimator? = null
    private var currentState: AssistantState = AssistantState.IDLE

    // Touch gesture tracking
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false
    private var touchStartTime = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!hasOverlayPermission(this)) {
            stopSelf()
            return
        }

        promoteToForegroundSafely()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        initOverlayViews()
        observeAssistantState()
        VoiceSessionManager.setFloatingBubbleActive(true)
    }

    private fun promoteToForegroundSafely() {
        try {
            val channelId = "muskan_floating_bubble_channel"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val manager = getSystemService(NotificationManager::class.java)
                val channel = NotificationChannel(
                    channelId,
                    "Muskan Floating Bubble",
                    NotificationManager.IMPORTANCE_MIN
                ).apply { setShowBadge(false) }
                manager?.createNotificationChannel(channel)
            }
            val notification = NotificationCompat.Builder(this, channelId)
                .setContentTitle("Muskan Bubble Active")
                .setContentText("Tap bubble anytime to talk to Muskan")
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(1002, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(1002, notification)
            }
        } catch (_: Exception) {
            // Keep overlay running even if FGS promotion is restricted in unit tests or OEM policy
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_BUBBLE -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_PULSE_STANDBY -> {
                updateBubbleVisualState(AssistantState.IDLE, isStandby = true)
            }
        }
        return START_STICKY
    }

    private fun initOverlayViews() {
        val wm = windowManager ?: return
        val displayMetrics = resources.displayMetrics
        val density = displayMetrics.density
        val bubbleSizePx = (64 * density).toInt()

        // Setup WindowManager LayoutParams for Bubble with Non-Intrusive, Non-Blocking Flags
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        bubbleLayoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = displayMetrics.widthPixels - bubbleSizePx - (16 * density).toInt()
            y = (displayMetrics.heightPixels * 0.35f).toInt()
        }

        // Build bubble view programmatically for speed, resilience, and standalone simplicity
        overlayRootView = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            clipChildren = false
            clipToPadding = false
        }

        val ringSizePx = (80 * density).toInt()

        // 1. Pulsing ring around bubble
        pulseRingView = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(ringSizePx, ringSizePx).apply {
                gravity = Gravity.CENTER
            }
            background = createGlowDrawable(Color.parseColor("#448A2BE2"))
            alpha = 0f
        }
        overlayRootView?.addView(pulseRingView)

        // 2. Interactive bubble container
        bubbleContainer = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(bubbleSizePx, bubbleSizePx).apply {
                gravity = Gravity.CENTER
            }
            elevation = 12 * density
        }

        // Inner glowing core
        innerCoreView = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            background = createCircleDrawable(
                fillColor = Color.parseColor("#1E1035"),
                strokeColor = Color.parseColor("#A855F7"),
                strokeWidthPx = (3 * density).toInt()
            )
        }
        bubbleContainer?.addView(innerCoreView)

        // Center Muskan Icon / mic
        bubbleIcon = ImageView(this).apply {
            val iconSize = (32 * density).toInt()
            layoutParams = FrameLayout.LayoutParams(iconSize, iconSize).apply {
                gravity = Gravity.CENTER
            }
            setImageResource(android.R.drawable.ic_btn_speak_now)
            setColorFilter(Color.parseColor("#E9D5FF"))
        }
        bubbleContainer?.addView(bubbleIcon)

        // Tiny floating status pill badge
        statusBadge = TextView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomMargin = (-10 * density).toInt()
            }
            setPadding((6 * density).toInt(), (2 * density).toInt(), (6 * density).toInt(), (2 * density).toInt())
            textSize = 9f
            setTextColor(Color.WHITE)
            background = createPillDrawable(Color.parseColor("#CC1E1035"))
            text = "Muskan"
            visibility = View.VISIBLE
        }
        bubbleContainer?.addView(statusBadge)

        overlayRootView?.addView(bubbleContainer)

        // Setup Dismiss Target Zone (Bottom Red Cross Circle)
        setupDismissTargetZone(wm, displayMetrics, density)

        // Attach touch listener for dragging, physics snapping, tap activation & dismiss
        bubbleContainer?.setOnTouchListener { _, event ->
            handleBubbleTouch(event, wm, displayMetrics, bubbleSizePx)
        }

        try {
            wm.addView(overlayRootView, bubbleLayoutParams)
        } catch (_: Exception) {}

        // Initial idle pulse
        updateBubbleVisualState(AssistantState.IDLE, isStandby = true)
    }

    private fun setupDismissTargetZone(
        wm: WindowManager,
        displayMetrics: android.util.DisplayMetrics,
        density: Float
    ) {
        val targetSizePx = (80 * density).toInt()
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        dismissLayoutParams = WindowManager.LayoutParams(
            targetSizePx,
            targetSizePx,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = (48 * density).toInt()
        }

        dismissTargetZone = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(targetSizePx, targetSizePx)
            background = createCircleDrawable(
                fillColor = Color.parseColor("#D9EF4444"),
                strokeColor = Color.WHITE,
                strokeWidthPx = (2 * density).toInt()
            )
            visibility = View.GONE
            elevation = 16 * density

            val closeIcon = ImageView(this@FloatingBubbleService).apply {
                val icSize = (28 * density).toInt()
                layoutParams = FrameLayout.LayoutParams(icSize, icSize).apply {
                    gravity = Gravity.CENTER
                }
                setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
                setColorFilter(Color.WHITE)
            }
            addView(closeIcon)
        }

        try {
            wm.addView(dismissTargetZone, dismissLayoutParams)
        } catch (_: Exception) {}
    }

    private fun handleBubbleTouch(
        event: MotionEvent,
        wm: WindowManager,
        displayMetrics: android.util.DisplayMetrics,
        bubbleSizePx: Int
    ): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = bubbleLayoutParams.x
                initialY = bubbleLayoutParams.y
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                touchStartTime = System.currentTimeMillis()
                isDragging = false
                dismissTargetZone?.visibility = View.VISIBLE
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - initialTouchX
                val dy = event.rawY - initialTouchY

                if (hypot(dx.toDouble(), dy.toDouble()) > 10) {
                    isDragging = true
                }

                if (isDragging) {
                    bubbleLayoutParams.x = (initialX + dx).toInt()
                    bubbleLayoutParams.y = (initialY + dy).toInt()
                    try {
                        wm.updateViewLayout(overlayRootView, bubbleLayoutParams)
                    } catch (_: Exception) {}

                    // Check if hovering over dismiss zone
                    val screenCenterX = displayMetrics.widthPixels / 2f
                    val dismissCenterY = displayMetrics.heightPixels - (88 * resources.displayMetrics.density)
                    val distToDismiss = hypot((event.rawX - screenCenterX).toDouble(), (event.rawY - dismissCenterY).toDouble())
                    if (distToDismiss < 120) {
                        dismissTargetZone?.scaleX = 1.25f
                        dismissTargetZone?.scaleY = 1.25f
                        bubbleContainer?.alpha = 0.5f
                    } else {
                        dismissTargetZone?.scaleX = 1.0f
                        dismissTargetZone?.scaleY = 1.0f
                        bubbleContainer?.alpha = 1.0f
                    }
                }
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dismissTargetZone?.visibility = View.GONE
                bubbleContainer?.alpha = 1.0f

                val screenCenterX = displayMetrics.widthPixels / 2f
                val dismissCenterY = displayMetrics.heightPixels - (88 * resources.displayMetrics.density)
                val distToDismiss = hypot((event.rawX - screenCenterX).toDouble(), (event.rawY - dismissCenterY).toDouble())

                // 1. Dragged to dismiss target -> close floating bubble
                if (isDragging && distToDismiss < 120) {
                    stopSelf()
                    return true
                }

                // 2. Click / Tap vs Long Press -> Activate Muskan or Toggle Mute
                val touchDuration = System.currentTimeMillis() - touchStartTime
                if (!isDragging) {
                    if (touchDuration >= 500) {
                        onBubbleLongPressed()
                    } else {
                        onBubbleTapped()
                    }
                    return true
                }

                // 3. Smooth edge snap physics
                val midX = displayMetrics.widthPixels / 2
                val targetX = if (bubbleLayoutParams.x + (bubbleSizePx / 2) < midX) {
                    16 // Snap to left edge
                } else {
                    displayMetrics.widthPixels - bubbleSizePx - 16 // Snap to right edge
                }

                animateBubbleX(bubbleLayoutParams.x, targetX, wm)
                return true
            }
        }
        return false
    }

    private fun animateBubbleX(fromX: Int, toX: Int, wm: WindowManager) {
        val animator = ValueAnimator.ofInt(fromX, toX).apply {
            duration = 240L
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { va ->
                bubbleLayoutParams.x = va.animatedValue as Int
                try {
                    wm.updateViewLayout(overlayRootView, bubbleLayoutParams)
                } catch (_: Exception) {}
            }
        }
        animator.start()
    }

    private fun onBubbleTapped() {
        val state = VoiceSessionManager.uiState.value
        when {
            state.isTtsSpeaking -> {
                VoiceSessionManager.stopTts()
            }
            state.state == AssistantState.LISTENING -> {
                VoiceSessionManager.stopListening()
            }
            state.isMuted -> {
                VoiceSessionManager.setMuted(false)
                VoiceSessionManager.startExplicitListening()
            }
            else -> {
                VoiceSessionManager.startExplicitListening()
            }
        }
    }

    private fun onBubbleLongPressed() {
        // Quick floating toggle / one-tap gesture to instantly mute or pause active listening
        val currentMuted = VoiceSessionManager.isMuted()
        VoiceSessionManager.setMuted(!currentMuted)
        if (!currentMuted) {
            VoiceSessionManager.stopListening()
            VoiceSessionManager.stopTts()
        }
    }

    private fun observeAssistantState() {
        serviceScope.launch {
            VoiceSessionManager.uiState.collectLatest { state ->
                currentState = state.state
                updateBubbleVisualState(
                    state = state.state,
                    isStandby = state.isWakeWordStandby || state.isWakeWordEnabled,
                    isMuted = state.isMuted,
                    audioRms = state.audioRmsLevel,
                    audioOutput = state.audioOutputLevel,
                    taskRunning = state.isAgenticTaskRunning,
                    taskTitle = state.currentAgenticPlanTitle,
                    isGamingMode = state.isGamingMode
                )
                // While Muskan is operating the phone, hide the bubble so only the arrow cursor is visible
                // (the bubble used to sit on top of the screen and hide what was being done).
                bubbleContainer?.visibility = if (state.isAgenticTaskRunning) View.INVISIBLE else View.VISIBLE
            }
        }
    }

    private fun updateBubbleVisualState(
        state: AssistantState,
        isStandby: Boolean = false,
        isMuted: Boolean = false,
        audioRms: Float = 0f,
        audioOutput: Float = 0f,
        taskRunning: Boolean = false,
        taskTitle: String? = null,
        isGamingMode: Boolean = false
    ) {
        val density = resources.displayMetrics.density

        // Gaming / Full-screen optimization mode:
        // Minimize bubble into a tiny, unobtrusive edge indicator to never obstruct games or video controls
        if (isGamingMode) {
            bubbleContainer?.scaleX = 0.65f
            bubbleContainer?.scaleY = 0.65f
            bubbleContainer?.alpha = if (state == AssistantState.LISTENING || state == AssistantState.SPEAKING) 0.9f else 0.45f
            statusBadge?.visibility = View.GONE
        } else {
            bubbleContainer?.scaleX = 1.0f
            bubbleContainer?.scaleY = 1.0f
            bubbleContainer?.alpha = 1.0f
            statusBadge?.visibility = View.VISIBLE
        }

        when {
            taskRunning -> {
                // Autonomous Agentic Task Executing: Cyan / Emerald Glow
                setBubbleColors(
                    fillColor = Color.parseColor("#064E3B"),
                    strokeColor = Color.parseColor("#10B981"),
                    ringColor = Color.parseColor("#4410B981")
                )
                statusBadge?.text = taskTitle?.take(10) ?: "Agent"
                startPulseAnimation(durationMs = 900L, minScale = 1.0f, maxScale = 1.35f)
            }

            isMuted -> {
                // Muted state
                setBubbleColors(
                    fillColor = Color.parseColor("#262626"),
                    strokeColor = Color.parseColor("#737373"),
                    ringColor = Color.parseColor("#22737373")
                )
                statusBadge?.text = "Muted"
                stopPulseAnimation()
            }

            state == AssistantState.LISTENING -> {
                // Listening state: Vibrant Coral Pink / Red glow expanding with RMS level
                setBubbleColors(
                    fillColor = Color.parseColor("#4C0519"),
                    strokeColor = Color.parseColor("#F43F5E"),
                    ringColor = Color.parseColor("#66F43F5E")
                )
                statusBadge?.text = "Listening"
                val scale = 1.0f + (audioRms * 0.45f).coerceIn(0f, 0.5f)
                pulseRingView?.scaleX = scale
                pulseRingView?.scaleY = scale
                pulseRingView?.alpha = (0.35f + audioRms * 0.65f).coerceIn(0f, 1f)
            }

            state == AssistantState.PROCESSING -> {
                // Thinking / Agentic Planning state: Amber / Yellow shimmer
                setBubbleColors(
                    fillColor = Color.parseColor("#451A03"),
                    strokeColor = Color.parseColor("#F59E0B"),
                    ringColor = Color.parseColor("#55F59E0B")
                )
                statusBadge?.text = "Thinking…"
                startPulseAnimation(durationMs = 700L, minScale = 1.0f, maxScale = 1.25f)
            }

            state == AssistantState.SPEAKING -> {
                // Speaking state: Indigo / Purple energetic sound waves
                setBubbleColors(
                    fillColor = Color.parseColor("#1E1B4B"),
                    strokeColor = Color.parseColor("#8B5CF6"),
                    ringColor = Color.parseColor("#668B5CF6")
                )
                statusBadge?.text = "Speaking"
                val scale = 1.05f + (audioOutput * 0.4f).coerceIn(0f, 0.45f)
                pulseRingView?.scaleX = scale
                pulseRingView?.scaleY = scale
                pulseRingView?.alpha = (0.4f + audioOutput * 0.5f).coerceIn(0f, 1f)
            }

            else -> {
                // Standby / Idle: Gentle purple heartbeat
                setBubbleColors(
                    fillColor = Color.parseColor("#1E1035"),
                    strokeColor = Color.parseColor("#A855F7"),
                    ringColor = Color.parseColor("#33A855F7")
                )
                statusBadge?.text = "Muskan"
                startPulseAnimation(durationMs = 2400L, minScale = 1.0f, maxScale = 1.15f)
            }
        }
    }

    private fun setBubbleColors(fillColor: Int, strokeColor: Int, ringColor: Int) {
        val density = resources.displayMetrics.density
        innerCoreView?.background = createCircleDrawable(
            fillColor = fillColor,
            strokeColor = strokeColor,
            strokeWidthPx = (3 * density).toInt()
        )
        pulseRingView?.background = createGlowDrawable(ringColor)
    }

    private fun startPulseAnimation(durationMs: Long, minScale: Float, maxScale: Float) {
        pulseAnimator?.cancel()
        val ring = pulseRingView ?: return
        ring.alpha = 0.5f

        pulseAnimator = ValueAnimator.ofFloat(minScale, maxScale).apply {
            duration = durationMs
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { va ->
                val scale = va.animatedValue as Float
                ring.scaleX = scale
                ring.scaleY = scale
                ring.alpha = 0.6f - ((scale - minScale) / (maxScale - minScale) * 0.35f)
            }
        }
        pulseAnimator?.start()
    }

    private fun stopPulseAnimation() {
        pulseAnimator?.cancel()
        pulseAnimator = null
        pulseRingView?.alpha = 0f
    }

    private fun createCircleDrawable(fillColor: Int, strokeColor: Int, strokeWidthPx: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fillColor)
            setStroke(strokeWidthPx, strokeColor)
        }
    }

    private fun createGlowDrawable(color: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
    }

    private fun createPillDrawable(color: Int): GradientDrawable {
        val density = resources.displayMetrics.density
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 12 * density
            setColor(color)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        stopPulseAnimation()
        try {
            overlayRootView?.let { windowManager?.removeView(it) }
            dismissTargetZone?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {}
        VoiceSessionManager.setFloatingBubbleActive(false)
    }

    companion object {
        const val ACTION_STOP_BUBBLE = "com.example.service.ACTION_STOP_BUBBLE"
        const val ACTION_PULSE_STANDBY = "com.example.service.ACTION_PULSE_STANDBY"

        fun hasOverlayPermission(context: Context): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(context)
            } else {
                true
            }
        }

        fun openOverlaySettings(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:${context.packageName}")
                ).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            }
        }

        fun start(context: Context) {
            if (hasOverlayPermission(context)) {
                val intent = Intent(context, FloatingBubbleService::class.java)
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingBubbleService::class.java).apply {
                action = ACTION_STOP_BUBBLE
            }
            context.startService(intent)
        }
    }
}
