package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Restarts Muskan's hands-free voice service after device reboot or app update
 * when the user has enabled auto-start on boot in preferences.
 */
class MuskanBootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val autoStartEnabled = prefs.getBoolean(KEY_AUTO_START_ON_BOOT, true)
        if (!autoStartEnabled) {
            Log.i(TAG, "Auto-start on boot disabled by user preference.")
            return
        }

        try {
            Log.i(TAG, "Received $action; starting MuskanVoiceService.")
            MuskanVoiceService.start(context.applicationContext)
        } catch (e: Exception) {
            // On Android 14+, microphone FGS from BOOT_COMPLETED may be restricted until app launch
            Log.w(TAG, "Unable to start MuskanVoiceService from $action: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "MuskanBootReceiver"
        private const val PREFS_NAME = "muskan_boot_prefs"
        private const val KEY_AUTO_START_ON_BOOT = "auto_start_on_boot"

        fun setAutoStartEnabled(context: Context, enabled: Boolean) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_AUTO_START_ON_BOOT, enabled)
                .apply()
        }

        fun isAutoStartEnabled(context: Context): Boolean {
            return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_AUTO_START_ON_BOOT, true)
        }
    }
}
