package com.example.service

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.Connection
import android.util.Log
import androidx.annotation.RequiresApi
import com.example.engine.calling.CallingEngine

/**
 * Android API 29+ [CallScreeningService] registered with `android.permission.BIND_SCREENING_SERVICE`.
 *
 * Screens incoming calls via [CallingEngine] using local spam/scam heuristics, STIR/SHAKEN
 * verification status (API 30+), and user allowlist/blocklist, then logs every screened call
 * into memory and Room without requiring privileged cellular audio injection.
 *
 * Note: Android does not permit third-party apps to inject TTS audio directly into the cellular
 * uplink call audio stream; Muskan instead provides call screening, summaries, and owner-approved
 * SMS/WhatsApp follow-ups.
 */
@RequiresApi(Build.VERSION_CODES.Q)
class MuskanCallScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return
        }

        // Only screen incoming calls
        if (callDetails.callDirection != Call.Details.DIRECTION_INCOMING) {
            respondToCall(callDetails, CallResponse.Builder().build())
            return
        }

        CallingEngine.initialize(applicationContext)

        val rawNumber = callDetails.handle?.schemeSpecificPart
        val callerDisplayName = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            callDetails.callerDisplayName
        } else {
            null
        }
        val stirFailed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            callDetails.callerNumberVerificationStatus == Connection.VERIFICATION_STATUS_FAILED
        } else {
            false
        }

        val decision = CallingEngine.evaluateIncomingCall(
            rawNumber = rawNumber,
            callerDisplayName = callerDisplayName,
            stirVerificationFailed = stirFailed
        )

        CallingEngine.logScreenedCall(
            context = applicationContext,
            rawNumber = rawNumber,
            callerDisplayName = callerDisplayName,
            decision = decision,
            isMissedOrRejected = decision.shouldReject
        )

        Log.i(
            TAG,
            "Screened incoming call=${decision.normalizedNumber} verdict=${decision.verdict} score=${decision.riskScore}"
        )

        val response = CallResponse.Builder()
            .setDisallowCall(decision.shouldReject)
            .setRejectCall(decision.shouldReject)
            .setSilenceCall(decision.shouldSilence)
            .setSkipCallLog(false)
            .setSkipNotification(decision.skipNotification)
            .build()

        respondToCall(callDetails, response)
    }

    companion object {
        private const val TAG = "MuskanCallScreeningSvc"

        fun isCallScreeningRoleSupported(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

        fun isCallScreeningRoleHeld(context: Context): Boolean {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
            val roleManager = context.getSystemService(RoleManager::class.java) ?: return false
            return roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
        }

        fun createRequestCallScreeningRoleIntent(context: Context): Intent? {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
            val roleManager = context.getSystemService(RoleManager::class.java) ?: return null
            return if (roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
                !roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
            ) {
                roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING)
            } else {
                null
            }
        }
    }
}
