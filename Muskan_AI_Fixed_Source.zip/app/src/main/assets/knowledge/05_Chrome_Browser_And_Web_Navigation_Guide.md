# Module 5: Google Chrome Browser & Website Control Guide for AI Agent
*(क्रोम ब्राउज़र के सभी आइकॉन, सेटिंग्स और किसी भी वेबसाइट को कंट्रोल करने के नियम)*

## 5.1 Google Chrome UI Layout (`com.android.chrome` — `1080 x 2460`) ([Google Chrome Help](https://support.google.com/chrome/answer/2391819?hl=en&co=GENIE.Platform%3DAndroid))

### A. Top Toolbar & Omnibox (Address Bar — `Y: 185`)
Chrome में डिफ़ॉल्ट रूप से एड्रेस बार सबसे ऊपर (`Y: 185`) होती है (यूजर चाहें तो इसे लॉन्ग-प्रेस करके नीचे भी शिफ्ट कर सकते हैं — [Google Chrome Help](https://support.google.com/chrome/answer/14181646?hl=en&co=GENIE.Platform%3DAndroid)):
1. **Home Icon (`🏠` सबसे बाएं):** `X: 75, Y: 185` — एक टैप में Google New Tab पेज पर ले जाता है।
2. **Omnibox / Address & Search Bar (बीच की पट्टी):** `X: 430, Y: 185` ([Google Chrome Help](https://support.google.com/chrome/answer/95426?hl=en&co=GENIE.Platform%3DAndroid))
   * जब कोई वेबसाइट खुली हो, तो इस बार के बाएं हिस्से (`X: 210, Y: 185`) पर **Site Info / Tune Icon (`🎚️` या `🔒`)** होता है जहाँ से उस वेबसाइट की **Permissions (Camera, Location, Pop-ups)** और **Cookies** कंट्रोल होती हैं।
   * जब आप नया टैब खोलते हैं या एड्रेस बार पर टैप करते हैं:
     * **Voice Search Mic (`🎤`):** `X: 780, Y: 185` (या होम पेज सर्च बॉक्स में `X: 820, Y: 720`)
     * **Google Lens Camera (`📷`):** `X: 900, Y: 185` (या होम पेज सर्च बॉक्स में `X: 930, Y: 720`)
3. **New Tab / Custom Shortcut Button (`➕`):** `X: 780, Y: 185` ([Google Chrome Help](https://support.google.com/chrome/answer/14835450?hl=en&co=GENIE.Platform%3DAndroid))
4. **Tab Switcher Box (`[1]` चौकोर डिब्बा जिसमें खुले टैब की संख्या लिखी होती है):** `X: 895, Y: 185` ([Google Chrome Help](https://support.google.com/chrome/answer/2391819?hl=en&co=GENIE.Platform%3DAndroid))
   * **टिप:** इस डिब्बे पर उंगली रखकर बाएं/दाएं स्वाइप करने से खुले हुए टैब्स के बीच तुरंत स्विच होता है!
   * इस पर टैप करने से सारे खुले टैब्स कार्ड्स के रूप में दिखते हैं; ऊपर बाएं **`+` (`X: 90, Y: 185`)** से नया टैब और ऊपर बीच में **Incognito Icon (`🕵️`, `X: 580, Y: 185`)** से प्राइवेट टैब खुलता है।
5. **More Options (`⋮` 3-Dots Menu — सबसे ऊपर दाएं कोने में):** `X: 1005, Y: 185` ([Google Chrome Help](https://support.google.com/chrome/thread/376771358/a-blank-bar-is-added-to-the-bottom-of-chrome-140-on-android?hl=en))

### B. Complete 3-Dots Menu (`⋮` at `X: 1005, Y: 185`) Directory
जब एजेंट Chrome के `⋮` मेनू पर टैप करता है, तो ऊपर 5 आइकॉन और नीचे लिस्ट खुलती है:
* **Top Icon Row inside `⋮` Menu (`Y: 220`):**
  * **Forward (`→`):** `X: 480, Y: 220` | **Bookmark Star (`☆`):** `X: 610, Y: 220` | **Download Page (`⬇`):** `X: 740, Y: 220` | **Site Info (`ℹ`):** `X: 870, Y: 220` | **Reload / Refresh (`↻`):** `X: 990, Y: 220`
* **List Items inside `⋮` Menu (ऊपर से नीचे तक):**
  1. **New tab (`➕`):** `Y: 350` — नया टैब खोलें।
  2. **New Incognito tab (`🕵️`):** `Y: 470` — बिना हिस्ट्री सेव किए प्राइवेट ब्राउज़िंग।
  3. **History (`🕒`):** `Y: 610` — पुरानी देखी गई वेबसाइट्स और `Clear browsing data...`।
  4. **Delete browsing data... (`🗑️`):** `Y: 730` — कैश और हिस्ट्री तुरंत साफ करने के लिए।
  5. **Downloads (`⬇`):** `Y: 850` — डाउनलोड की गई PDF, फोटो, APK और फाइलें देखने के लिए।
  6. **Bookmarks (`★`):** `Y: 970` — सेव किए गए वेबपेज।
  7. **Recent tabs (`📱`):** `Y: 1090` — हाल ही में बंद किए गए या दूसरे डिवाइस के टैब्स।
  8. **Share... (`<`):** `Y: 1210` — वेबसाइट का लिंक WhatsApp पर भेजने या कॉपी करने के लिए।
  9. **Find in page (`🔍`):** `Y: 1330` — खुले हुए वेबपेज के अंदर कोई खास शब्द ढूंढने के लिए (यह AI एजेंट के लिए सबसे उपयोगी टूल है!)।
  10. **Translate... (`जी/A`):** `Y: 1450` — पूरी अंग्रेजी वेबसाइट को एक क्लिक में **हिंदी** में बदलने के लिए।
  11. **Add to Home screen (`📲`):** `Y: 1570` — किसी भी वेबसाइट का ऐप जैसा आइकॉन फोन की होम स्क्रीन पर बनाने के लिए।
  12. **Desktop site (`🖥️` चेकबॉक्स):** `Y: 1690` — मोबाइल वेबसाइट को कंप्यूटर (PC) जैसा खोलने के लिए।
  13. **Settings (`⚙️`):** `Y: 1810` — Search engine, Password Manager, Payment methods, Addresses, Notifications, Privacy and security, Site settings.

---

## 5.2 How the AI Agent Navigates Any Website Inside Chrome (वेबसाइट कंट्रोल नियम)
जब यूजर किसी भी वेबसाइट (जैसे Amazon, Flipkart, IRCTC, सरकारी पोर्टल, या न्यूज़ साइट) पर काम करने को कहे, तो AI एजेंट को ये 6 नियम फॉलो करने चाहिए:

1. **Direct URL / Search Launch:**
   * यदि वेबसाइट का पता मालूम है, तो सीधे Intent से खोलें: `am start -a android.intent.action.VIEW -d "https://..." com.android.chrome`
   * या Chrome खोलकर `X: 430, Y: 185` (Omnibox) पर टैप करें → टेक्स्ट या URL डालें → कीबोर्ड के निचले दाएं कोने में **`🔍` / `↵` (`X: 985, Y: 2255`)** पर टैप करें।
2. **Mobile Website Standard Layout Recognition:**
   * **Website Hamburger Menu (`☰`):** 90% मोबाइल वेबसाइट्स में अपना नेविगेशन मेनू `Y: 260 – 380` (Chrome की एड्रेस बार के ठीक नीचे) बाएं कोने (`X: 80, Y: 320`) या दाएं कोने (`X: 990, Y: 320`) में होता है।
   * **Website Internal Search Bar:** आमतौर पर `Y: 320 – 480` पर या ऊपर दाएं `🔍` आइकॉन पर होती है।
3. **Using "Find in Page" to Locate Any Button Instantly:**
   * अगर किसी लंबी वेबसाइट पर कोई बटन (जैसे `"Apply Online"`, `"Download Admit Card"`, `"Buy Now"`, `"Login"`) स्क्रीन पर नहीं दिख रहा है, तो एजेंट को अंधाधुंध स्क्रॉल करने के बजाय:
     1. Chrome `⋮` मेनू (`X: 1005, Y: 185`) पर टैप करना चाहिए।
     2. **`Find in page` (`X: 540, Y: 1330`)** पर टैप करना चाहिए।
     3. बटन का नाम टाइप करना चाहिए — Chrome अपने आप पेज को स्क्रॉल करके उस बटन को पीले/नारंगी रंग में हाइलाइट कर देगा!
4. **Handling Web Forms, Dropdowns & Date Pickers:**
   * **Text Inputs (`<input>`):** बॉक्स पर टैप करें → Gboard खुलेगा → टाइप करें → यदि अगला बॉक्स भरना है तो कीबोर्ड का `Next (→)` बटन (`X: 985, Y: 2255`) दबाएं।
   * **Dropdown Menus (`<select>`):** बॉक्स पर टैप करने से Android या Chrome की पॉपअप लिस्ट खुलती है → विकल्प पर टैप करें।
   * **File Upload (`Choose File` / `Browse`):** टैप करने पर Android का **File Picker / Media Picker** खुलता है जहाँ से `Camera` या `Browse / Files` चुनकर डॉक्यूमेंट/फोटो अपलोड होती है।
5. **Handling Pop-ups, Cookie Banners & Permission Dialogs:**
   * **Cookie Banner:** वेबसाइट खुलने पर नीचे (`Y: 1900 – 2250`) अक्सर `"Accept All"` या `"Reject"` आता है — एजेंट उसे पढ़कर बंद करे।
   * **Location / Camera Permission Popup:** यदि वेबसाइट लोकेशन या कैमरा मांगे, तो स्क्रीन के बीच/नीचे Android का डायलॉग आता है: `While using the app` (`X: 540, Y: 1820`), `Only this time` (`X: 540, Y: 1950`), `Don't allow` (`X: 540, Y: 2080`)।
6. **Pull-to-Refresh & Page Back:**
   * पेज रीफ्रेश करने के लिए बीच से नीचे स्वाइप (`Y: 500 -> 1600`) करें।
   * पिछले वेबपेज पर जाने के लिए सिस्टम `Back` बटन (`X: 840, Y: 2400` या साइड स्वाइप) दबाएं।
