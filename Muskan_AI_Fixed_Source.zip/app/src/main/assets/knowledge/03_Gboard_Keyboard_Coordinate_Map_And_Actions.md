# Module 3: Keyboard (Gboard) Complete Layout, Icons & Coordinate Matrix
*(कीबोर्ड (Gboard) की पूरी जानकारी — कौन सा बटन/आइकॉन कहाँ होता है और एजेंट कैसे टाइप करेगा)*

Redmi 13 5G में डिफ़ॉल्ट कीबोर्ड **[Google Gboard](https://play.google.com/store/apps/details?id=com.google.android.inputmethod.latin&hl=en)** होता है ([Choctaw Nation Gboard Guide](https://www.choctawnation.com/wp-content/uploads/2026/08/setting-up-gboard.pdf))। जब भी किसी ऐप (WhatsApp, YouTube, Chrome) के टेक्स्ट बॉक्स पर टैप किया जाता है, तो कीबोर्ड स्क्रीन के निचले हिस्से (`Y: 1480` से `Y: 2340` तक) में खुलता है।

## 3.1 How to Open Keyboard Settings (कीबोर्ड की सेटिंग कहाँ से खुलेगी)
1. **तरीका 1 (कीबोर्ड के ऊपर से):** किसी भी टेक्स्ट बॉक्स पर टैप करें → कीबोर्ड की सबसे ऊपरी पट्टी (Toolbar) में **`⚙️` (Settings Gear Icon, `X: 540, Y: 1530`)** पर टैप करें ([Choctaw Nation Gboard Guide](https://www.choctawnation.com/wp-content/uploads/2026/08/setting-up-gboard.pdf))।
2. **तरीका 2 (फोन की सेटिंग्स से):** `Settings > Additional settings > Languages & input > Manage keyboards > Gboard` पर टैप करें ([wikiHow Gboard Guide](https://www.wikihow.com/Edit-Gboard-Keyboard-Settings))।
3. **तरीका 3 (कमाई/कॉमा बटन से):** कीबोर्ड में स्पेसबार के बाईं ओर **`,` (Comma key, `X: 215, Y: 2260`)** को 1 सेकंड दबाए रखें (Long-press) और उंगली `⚙️` पर छोड़ दें।

---

## 3.2 Gboard Top Toolbar & Suggestion Strip (`Y: 1480 – 1600`)
कीबोर्ड में अक्षरों (QWERTY) के ठीक ऊपर एक पट्टी होती है ([Android Authority Gboard Guide](https://www.androidauthority.com/gboard-features-3533885/)):
* **जब आपने कुछ टाइप नहीं किया है (Action Toolbar Icons):**
  1. **Features Menu Icon (4-Square Grid `⊞` या `>` बाएं कोने में):** `X: 80, Y: 1535` — इसे दबाने पर सारे छुपे हुए टूल्स (Text Editing, One-handed, Floating keyboard) दिखते हैं ([Choctaw Nation Gboard Guide](https://www.choctawnation.com/wp-content/uploads/2026/08/setting-up-gboard.pdf))।
  2. **GIF / Sticker Icon:** `X: 230, Y: 1535`
  3. **Clipboard Icon (`📋` क्लिपबोर्ड):** `X: 385, Y: 1535` — कॉपी किए गए सभी टेक्स्ट, लिंक और स्क्रीनशॉट यहाँ सेव रहते हैं; किसी भी आइटम पर टैप करने से वह तुरंत पेस्ट हो जाता है ([Android Authority Gboard Guide](https://www.androidauthority.com/gboard-features-3533885/))।
  4. **Settings Gear (`⚙️`):** `X: 540, Y: 1535` — Gboard सेटिंग्स (Languages, Preferences, Theme, Text correction, Glide typing, Voice typing, Clipboard, Dictionary) खोलने के लिए।
  5. **Google Translate Icon (`जी/A` अनुवाद):** `X: 695, Y: 1535` — आप हिंदी में लिखेंगे और ऊपर बॉक्स में अपने आप अंग्रेज़ी (English) में टाइप होगा!
  6. **Theme / One-Handed Icon:** `X: 850, Y: 1535`
  7. **Voice Typing Microphone (`🎤` माइक आइकॉन — सबसे दाएं कोने में):** `X: 1000, Y: 1535` — इस पर टैप करके यूजर जो भी बोलेगा, फोन उसे तुरंत टाइप कर देगा ([Google Play Gboard](https://play.google.com/store/apps/details?id=com.google.android.inputmethod.latin&hl=en))।
* **जब आप टाइप कर रहे होते हैं (3 Word Suggestions Strip):**
  * **Left Suggestion:** `X: 180, Y: 1535`
  * **Center (Best/Auto-correct) Suggestion:** `X: 540, Y: 1535`
  * **Right Suggestion:** `X: 900, Y: 1535`

---

## 3.3 Exact Pixel Coordinates of Every Key on Gboard (`1080 x 2460` Portrait)
*(Number Row ऑन होने पर भी और स्टैंडर्ड लेआउट में भी कोऑर्डिनेट मैप)*

### Row 0: Number Row (यदि `Preferences > Number row` ऑन है, `Y: 1640`)
* `1`: `(54, 1640)` | `2`: `(162, 1640)` | `3`: `(270, 1640)` | `4`: `(378, 1640)` | `5`: `(486, 1640)` | `6`: `(594, 1640)` | `7`: `(702, 1640)` | `8`: `(810, 1640)` | `9`: `(918, 1640)` | `0`: `(1026, 1640)`

### Row 1: Top Letter Row (`Q W E R T Y U I O P` — `Y: 1775`)
| Key | X (px) | Y (px) | Long-Press Symbol | Key | X (px) | Y (px) | Long-Press Symbol |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Q** | `54` | `1775` | `1` | **Y** | `594` | `1775` | `6` |
| **W** | `162` | `1775` | `2` | **U** | `702` | `1775` | `7` |
| **E** | `270` | `1775` | `3` | **I** | `810` | `1775` | `8` |
| **R** | `378` | `1775` | `4` | **O** | `918` | `1775` | `9` |
| **T** | `486` | `1775` | `5` | **P** | `1026` | `1775` | `0` |

### Row 2: Middle Letter Row (`A S D F G H J K L` — `Y: 1935`)
| Key | X (px) | Y (px) | Key | X (px) | Y (px) | Key | X (px) | Y (px) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **A** | `108` | `1935` | **F** | `432` | `1935` | **J** | `756` | `1935` |
| **S** | `216` | `1935` | **G** | `540` | `1935` | **K** | `864` | `1935` |
| **D** | `324` | `1935` | **H** | `648` | `1935` | **L** | `972` | `1935` |

### Row 3: Bottom Letter Row + Shift & Backspace (`Y: 2095`)
| Key / Icon | Position Description | X (px) | Y (px) | Special Behavior for AI Agent |
| :--- | :--- | :--- | :--- | :--- |
| **Shift / Caps (`⇧`)** | सबसे बाएं | `80` | `2095` | 1 बार टैप = अगला अक्षर Capital; **2 बार जल्दी टैप (Double-tap)** = **CAPS LOCK ON** |
| **Z** | Shift के दाएं | `216` | `2095` | अक्षर Z |
| **X** | Z के दाएं | `324` | `2095` | अक्षर X |
| **C** | X के दाएं | `432` | `2095` | अक्षर C |
| **V** | बीच में बाएं | `540` | `2095` | अक्षर V |
| **B** | बीच में दाएं | `648` | `2095` | अक्षर B |
| **N** | B के दाएं | `756` | `2095` | अक्षर N |
| **M** | N के दाएं | `864` | `2095` | अक्षर M |
| **Backspace (`⌫`)** | सबसे दाएं | `1000` | `2095` | 1 टैप = 1 अक्षर मिटाएं; **दबाकर बाईं ओर स्लाइड करें** = पूरे शब्द एक साथ सलेक्ट करके मिटाएं ([Android Authority Gboard Guide](https://www.androidauthority.com/gboard-features-3533885/)) |

### Row 4: Bottom Action & Spacebar Row (`Y: 2255`)
| Key / Icon | Position Description | X (px) | Y (px) | What It Opens / Does |
| :--- | :--- | :--- | :--- | :--- |
| **`?123` (Numbers/Symbols)** | सबसे बाएं नीचे कोने में | `95` | `2255` | नंबर (`1-0`) और सिंबल (`@ # ₹ % & - + ( ) / * " ' : ; ! ?`) कीबोर्ड खोलता है (वहाँ `=\<` दबाने पर `~ ` | • √ π ÷ × § ∆ £ $ € ^ ° = { } \ % © ® ™ ✓ [ ]` खुलते हैं) |
| **`,` (Comma / Settings)** | `?123` के बगल में | `215` | `2255` | टैप = अल्पविराम `,`; लॉन्ग-प्रेस = Settings (`⚙️`) या One-Handed Mode |
| **Emoji / Globe (`😊` / `🌐`)** | Spacebar के बाईं ओर | `315` | `2255` | `😊` इमोजी पैनल खोलता है; `🌐` (Globe) एक टैप में **English ↔ हिंदी (ABC → अ आ इ)** भाषा बदलता है ([Choctaw Nation Gboard Guide](https://www.choctawnation.com/wp-content/uploads/2026/08/setting-up-gboard.pdf)) |
| **Spacebar (`English / भारत`)** | बीच की सबसे चौड़ी पट्टी | `540` | `2255` | खाली जगह (Space) देता है; **Spacebar पर उंगली बाएं/दाएं स्लाइड करने से कर्सर (Cursor) अक्षरों के बीच आगे-पीछे चलता है!** **Spacebar को 2 सेकंड दबाए रखने (Long-press) से भाषा बदलने (Language Switch) का पॉपअप खुलता है!** |
| **`.` (Full Stop / Period)** | Spacebar के दाईं ओर | `845` | `2255` | टैप = `.` (फुल स्टॉप); लॉन्ग-प्रेस = `@ # ! ? , - _ " ' : ; /` के त्वरित शॉर्टकट |
| **Action Key (`↵` / `🔍` / `➤`)** | सबसे दाएं नीचे कोने में | `985` | `2255` | ऐप के हिसाब से बदलता है: Chrome/YouTube में **Search (`🔍`)**, WhatsApp में **New Line (`↵`)**, Forms में **Next (`→`)** या **Done (`✓`)** |
| **Hide Keyboard (`⌄`)** | सबसे नीचे बाएं (System Bar में) | `100` | `2400` | कीबोर्ड को स्क्रीन से नीचे छुपाने (Close) के लिए |

---

## 3.4 How to Add Hindi & Hinglish (ABC → हिंदी) in Gboard
यदि यूजर बोले *"कीबोर्ड में हिंदी भाषा चालू करो"*:
1. कीबोर्ड की टॉप पट्टी में **`⚙️` (Settings, `X: 540, Y: 1535`)** पर टैप करें ([Choctaw Nation Gboard Guide](https://www.choctawnation.com/wp-content/uploads/2026/08/setting-up-gboard.pdf))।
2. सबसे पहले विकल्प **`Languages` (`X: 540, Y: 380`)** पर टैप करें।
3. नीचे **`Add keyboard` (`X: 540, Y: 2250`)** बटन पर टैप करें।
4. **`Hindi (भारत)`** चुनें → अब वहां दो लेआउट टिक करें:
   * **`ABC → हिंदी` (Transliteration / Hinglish):** आप `kya haal hai` टाइप करेंगे और वह अपने आप `क्या हाल है` लिखेगा।
   * **`हिंदी` (Devanagari Script):** सीधे `क ख ग` और मात्राओं वाला कीबोर्ड।
5. नीचे **`Done` (`X: 880, Y: 2250`)** पर टैप करें। अब स्पेसबार को लॉन्ग-प्रेस करके या `🌐` बटन (`X: 315, Y: 2255`) दबाकर कभी भी हिंदी और इंग्लिश बदल सकते हैं।
