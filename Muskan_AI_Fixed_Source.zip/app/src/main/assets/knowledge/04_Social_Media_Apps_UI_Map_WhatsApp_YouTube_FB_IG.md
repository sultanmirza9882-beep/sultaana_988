# Module 4: Social Media Apps Complete UI, Icon Coordinates & Workflows
*(व्हाट्सएप, यूट्यूब, फेसबुक, इंस्टाग्राम और टेलीग्राम/एक्स के हर आइकॉन की सटीक जगह और कंट्रोल गाइड)*

---

## 4.1 WhatsApp (व्हाट्सएप — `com.whatsapp`)
WhatsApp खोलने पर सबसे पहले **Chats** स्क्रीन खुलती है और नेविगेशन बार स्क्रीन के **सबसे नीचे (`Y: 2240`)** होती है ([WhatsApp Help Center](https://faq.whatsapp.com/1189188245314343))।

### A. Home Screen Icons & Positions (`1080 x 2460`)
1. **Top Header Bar (`Y: 185`):**
   * **WhatsApp Logo (Left):** `X: 200, Y: 185`
   * **QR Scanner / Camera Icon (`📷`):** `X: 730, Y: 185` — तुरंत फोटो खींचकर स्टेटस लगाने या भेजने के लिए।
   * **Search Icon / Meta AI Search Bar (`🔍`):** `X: 860, Y: 185` (या ठीक नीचे `X: 540, Y: 310` पर `Ask Meta AI or Search` बार)।
   * **More Options (`⋮` 3-Dots Menu — सबसे ऊपर दाएं कोने में):** `X: 995, Y: 185` ([WhatsApp Help Center](https://faq.whatsapp.com/1189188245314343))
     * इसके अंदर विकल्प: `New group`, `New broadcast`, `Linked devices` (लैपटॉप से जोड़ने के लिए), `Starred messages`, `Payments` (UPI पैसे भेजने के लिए), **`Settings`**।
2. **Filter Chips Below Search Bar (`Y: 430`):** ([WhatsApp Help Center](https://faq.whatsapp.com/1102928584767164))
   * `All` (`X: 120, Y: 430`), `Unread` (`X: 280, Y: 430`), `Favourites` (`X: 480, Y: 430`), `Groups` (`X: 680, Y: 430`)।
3. **Floating Action Buttons (Bottom Right — चैट लिस्ट के ऊपर):**
   * **Meta AI Ring Icon (नीला-बैंगनी गोल आइकॉन):** `X: 950, Y: 1830`
   * **New Chat / Plus Button (`💬+` हरा चौकोर बटन):** `X: 950, Y: 2020` — नया नंबर ढूंढने या नया कांटेक्ट सेव करने के लिए।
4. **Bottom Navigation Bar (`Y: 2240` — 4 मुख्य टैब्स):** ([WhatsApp Help Center](https://faq.whatsapp.com/1189188245314343))
   * **Tab 1 — Chats (`💬` सबसे बाएं):** `X: 135, Y: 2240` — सभी पर्सनल और ग्रुप चैट्स।
   * **Tab 2 — Updates (`⭕` बाएं से दूसरा):** `X: 405, Y: 2240` — ऊपर **Status** (24 घंटे की स्टोरीज़) और नीचे **Channels** ([WhatsApp Help Center](https://faq.whatsapp.com/549900560675125))।
   * **Tab 3 — Communities (`👥` दाएं से दूसरा):** `X: 675, Y: 2240` — कम्युनिटी और अनाउंसमेंट ग्रुप्स ([WhatsApp Help Center](https://faq.whatsapp.com/495856382464992))।
   * **Tab 4 — Calls (`📞` सबसे दाएं):** `X: 945, Y: 2240` — ऑडियो और वीडियो कॉल हिस्ट्री व नई कॉल करने का बटन।

### B. Inside an Individual Chat Screen (किसी की चैट खोलने पर आइकॉन कहाँ होते हैं)
* **Chat Top Bar (`Y: 185`):**
  * **Back Button + Profile DP (`←`):** `X: 90, Y: 185`
  * **Contact Name (प्रोफाइल डिटेल देखने के लिए):** `X: 380, Y: 185`
  * **Video Call Icon (`📹` वीडियो कॉल):** `X: 740, Y: 185`
  * **Voice/Audio Call Icon (`📞` ऑडियो कॉल):** `X: 870, Y: 185`
  * **3-Dots Menu (`⋮`):** `X: 995, Y: 185` (View contact, Search, Mute notifications, Disappearing messages, Wallpaper, More > Block / Clear chat)।
* **Bottom Message Input Bar (जब कीबोर्ड बंद हो: `Y: 2240`; जब कीबोर्ड खुला हो: `Y: 1410`):**
  * **Emoji Icon (`😊` टेक्स्ट बॉक्स के बाएं अंदर):** `X: 95`
  * **Message Text Box (`Message`):** `X: 420` (यहाँ टैप करने पर कीबोर्ड खुलता है)
  * **Attachment Paperclip Icon (`📎` पेपरक्लिप):** `X: 700` — इसे दबाने पर 8 आइकॉन खुलते हैं:
    * `Document` (PDF/फाइल भेजने के लिए), `Camera`, `Gallery` (फोटो/वीडियो), `Audio` (गाना/रिकॉर्डिंग), `Location` (लाइव लोकेशन), `Payment (₹)`, `Contact`, `Poll`।
  * **Rupee / Payment Icon (`₹`):** `X: 790`
  * **Camera Icon (`📷`):** `X: 875`
  * **Voice Note Mic / Send Plane Button (`🎤` / `➤` हरा गोल बटन — सबसे दाएं):** `X: 990`
    * *जब बॉक्स खाली हो:* यह **`🎤` (Mic)** होता है — इसे दबाए रखकर (Hold) या ऊपर स्वाइप (Lock) करके वॉयस मैसेज रिकॉर्ड करते हैं।
    * *जब बॉक्स में कुछ टाइप हो जाए:* यह तुरंत **`➤` (Send Paper Plane)** बन जाता है — एक टैप में मैसेज चला जाता है!

---

## 4.2 YouTube (यूट्यूब — `com.google.android.youtube`)

### A. Home Screen & Bottom Navigation (`1080 x 2460`)
1. **Top Bar (`Y: 185`):**
   * **YouTube Logo:** बाएं कोने में (`X: 200, Y: 185`)
   * **Cast to TV Icon (`📺`):** `X: 670, Y: 185`
   * **Notifications Bell (`🔔`):** `X: 810, Y: 185`
   * **Search Magnifying Glass (`🔍`):** सबसे दाएं (`X: 960, Y: 185`) — इस पर टैप करने पर सर्च बॉक्स (`X: 450, Y: 185`) और उसके दाएं **Voice Search Mic (`🎤`, `X: 980, Y: 185`)** खुलता है।
2. **Topic Filter Chips Row (`Y: 295`):** बाएं कोने में **Compass Icon (`🧭` Explore/Trending, `X: 85, Y: 295`)** और उसके बगल में `All`, `Music`, `News`, `Live`, `Gaming`।
3. **Bottom Navigation Bar (`Y: 2240` — 5 मुख्य आइकॉन्स):** ([Google YouTube Support](https://support.google.com/youtube/thread/348335603))
   * **1. Home (`🏠` सबसे बाएं):** `X: 110, Y: 2240` — मुख्य वीडियो फीड।
   * **2. Shorts (`⚡` बाएं से दूसरा):** `X: 325, Y: 2240` — छोटी वर्टिकल रील्स/शॉर्ट्स (अगला शॉर्ट देखने के लिए नीचे से ऊपर स्वाइप करें `Y: 1800 -> 400`)।
   * **3. Create (`⊕` बिल्कुल बीच में बड़ा प्लस बटन):** `X: 540, Y: 2240` — अपना वीडियो, शॉर्ट या लाइव स्ट्रीम अपलोड करने के लिए।
   * **4. Subscriptions (`📺` दाएं से दूसरा):** `X: 755, Y: 2240` — जिन चैनलों को आपने सब्सक्राइब किया है उनके नए वीडियो।
   * **5. You / Profile (`👤` सबसे दाएं कोने में):** `X: 970, Y: 2240` — आपकी **Watch History**, **Playlists**, **Downloads**, **Liked videos**, और ऊपर दाएं कोने में **`⚙️` Settings (`X: 980, Y: 185`)**।

### B. Video Player Controls (जब कोई वीडियो चल रहा हो)
* **Video Player Box (Portrait Mode):** `Y: 120 – 730`
  * वीडियो पर एक बार टैप (`X: 540, Y: 420`) करने पर कंट्रोल आइकॉन्स 3 सेकंड के लिए दिखते हैं:
  * **Play / Pause (`▶` / `⏸`):** बीच में (`X: 540, Y: 420`)
  * **Previous / Next Video (`⏮` / `⏭`):** बाएं (`X: 300, Y: 420`) और दाएं (`X: 780, Y: 420`)
  * **10 Seconds Forward / Rewind:** वीडियो के दाएं हिस्से (`X: 850, Y: 420`) पर **Double-Tap** = `+10 sec`; बाएं हिस्से (`X: 230, Y: 420`) पर **Double-Tap** = `-10 sec`।
  * **2x Speed Fast-Forward:** वीडियो पर कहीं भी उंगली दबाए रखें (Long-press) = जब तक उंगली रखी रहेगी वीडियो `2x` स्पीड पर चलेगा।
  * **Video Settings Gear (`⚙️` Quality, Playback Speed, Captions):** वीडियो बॉक्स के ऊपरी दाएं कोने में (`X: 995, Y: 175`)।
  * **Full Screen Icon (`⛶`):** वीडियो बॉक्स के निचले दाएं कोने में (`X: 1015, Y: 685`) — या वीडियो पर ऊपर की ओर स्वाइप करें।
* **Below Video Player Actions (`Y: 920 – 1120`):**
  * **Subscribe Button (काला या लाल पिल बटन):** चैनल के नाम के दाएं (`X: 910, Y: 940`)।
  * **Like (`👍`):** `X: 140, Y: 1070` | **Dislike (`👎`):** `X: 280, Y: 1070` | **Share (`↗`):** `X: 460, Y: 1070` | **Download (`⬇`):** `X: 680, Y: 1070`
  * **Comments Section Preview Bar:** `X: 540, Y: 1220` — टैप करने पर कमेंट्स खुलते हैं और नीचे `Add a comment...` बॉक्स (`X: 540, Y: 2240`) आता है।

---

## 4.3 Instagram (इंस्टाग्राम — `com.instagram.android`)

### A. Home Screen & Bottom Navigation (`1080 x 2460`) ([Google Play Instagram](https://play.google.com/store/apps/details?id=com.instagram.android))
1. **Top Bar (`Y: 185`):**
   * **Instagram Logo (Left):** `X: 230, Y: 185` (टैप करने पर `Following` और `Favorites` ड्रॉपडाउन खुलता है)।
   * **Notifications / Activity Heart (`♡`):** ऊपर दाएं से दूसरा (`X: 840, Y: 185`) — किसने लाइक, कमेंट या फॉलो किया।
   * **Direct Messages / DM (`💬` या Messenger/Paper-Plane आइकॉन):** सबसे ऊपर दाएं कोने में (`X: 985, Y: 185`) — या होम स्क्रीन पर कहीं भी **दाएं से बाएं स्वाइप (`X: 950 -> 150`)** करने से सीधे DMs (चैट्स) खुल जाते हैं!
2. **Stories Row (`Y: 360`):**
   * **Your Story (`+` आपकी प्रोफाइल फोटो):** सबसे बाएं (`X: 125, Y: 360`)
   * बाकी दोस्तों की गोल स्टोरी रिंग्स (`X: 320, 515, 710, 905, Y: 360`) — बाएं स्वाइप करके और स्टोरीज़ देखें।
3. **Bottom Navigation Bar (`Y: 2240` — 5 आइकॉन्स):** ([Design Bootcamp Instagram Nav Guide](https://medium.com/design-bootcamp/why-instagrams-navigation-bar-looks-different-for-new-and-old-users-45c53138b4a9))
   * **1. Home (`🏠` सबसे बाएं):** `X: 110, Y: 2240` — होम फीड।
   * **2. Search & Explore (`🔍` बाएं से दूसरा):** `X: 325, Y: 2240` — टैप करने पर एक्सप्लोर ग्रिड खुलती है और सबसे ऊपर **Search Bar (`X: 540, Y: 185`)** आती है जहाँ किसी भी अकाउंट/रिल को सर्च कर सकते हैं।
   * **3. Create / New Post (`➕` बिल्कुल बीच में चौकोर प्लस):** `X: 540, Y: 2240` — नई Post, Story, Reel या Live शुरू करने के लिए।
   * **4. Reels (`🎬` क्लैपरबोर्ड आइकॉन — दाएं से दूसरा):** `X: 755, Y: 2240` — फुल-स्क्रीन रील्स देखने के लिए।
   * **5. Profile (`👤` आपकी छोटी गोल फोटो — सबसे दाएं):** `X: 970, Y: 2240` — आपकी प्रोफाइल, बायो, फॉलोअर्स, और ऊपर दाएं कोने में **`☰` (3-Lines Hamburger Menu, `X: 985, Y: 185`)** जहाँ से **Settings and activity**, **Saved**, **Archive**, और **Log out** खुलता है।

### B. Reels Screen Controls (जब Reels चल रही हों)
* **अगली रील (Next Reel):** नीचे से ऊपर स्वाइप करें (`Y: 1900 -> 400`)।
* **लाइक (Like):** स्क्रीन के बीच में **Double-Tap (`X: 540, Y: 1100`)** करें या दाईं पट्टी में **Heart (`♡`, `X: 985, Y: 1420`)** पर टैप करें।
* **कमेंट (Comment `💬`):** दाईं पट्टी में Heart के नीचे (`X: 985, Y: 1600`)।
* **शेयर (Share / Send to DM `➢`):** कमेंट के नीचे (`X: 985, Y: 1780`)।
* **More (`⋮` Save / Remix):** `X: 985, Y: 1940`।
* **Audio / Song Track Icon:** सबसे नीचे दाएं कोने में (`X: 985, Y: 2080`)।

---

## 4.4 Facebook (फेसबुक — `com.facebook.katana`)

### A. Top Bar & Navigation Tabs (`1080 x 2460`) ([CNET Facebook Navigation](https://www.cnet.com/tech/mobile/facebook-is-personalizing-the-navigation-bar-on-its-mobile-app/))
1. **Top Row (`Y: 185`):**
   * **Facebook Logo:** बाएं (`X: 220, Y: 185`)
   * **Create Post (`➕` प्लस आइकॉन):** `X: 710, Y: 185` (Post, Story, Reel, Live)।
   * **Search Icon (`🔍`):** `X: 850, Y: 185` — किसी भी व्यक्ति, पेज या वीडियो को खोजने के लिए।
   * **Messenger Icon (`💬` बिजली के निशान वाला चैट बबल):** सबसे दाएं (`X: 985, Y: 185`) — फेसबुक चैट्स खोलने के लिए।
2. **Main 6-Tab Navigation Bar (Top Bar के ठीक नीचे `Y: 310` पर):**
   * **Tab 1 — Home (`🏠`):** `X: 90, Y: 310` — न्यूज़ फीड।
   * **Tab 2 — Video / Watch (`📺`):** `X: 270, Y: 310` — फेसबुक वीडियो और रील्स।
   * **Tab 3 — Friends (`👥`):** `X: 450, Y: 310` — Friend Requests स्वीकार (Confirm) या डिलीट करने के लिए।
   * **Tab 4 — Marketplace / Profile (`🏪` या `👤`):** `X: 630, Y: 310`
   * **Tab 5 — Notifications (`🔔` घंटी):** `X: 810, Y: 310` — सारे अलर्ट्स।
   * **Tab 6 — Menu (`☰` 3-Lines / Profile Icon):** सबसे दाएं (`X: 990, Y: 310`) — यहाँ से **Settings & privacy (`⚙️` ऊपर दाएं `X: 900, Y: 185` पर भी गियर आइकॉन होता है)**, **Saved**, **Groups**, **Memories**, **Events**, और सबसे नीचे स्क्रॉल करने पर **Log out** बटन मिलता है।
3. **What's on your mind? (नई पोस्ट लिखने का बॉक्स):** होम फीड में सबसे ऊपर (`X: 480, Y: 460`) और उसके दाएं **Photo/Gallery Icon (`🖼️`, `X: 980, Y: 460`)**।
4. **Each Post's Bottom Action Bar:**
   * **Like (`👍`):** बाएं (`X: 180`) — लॉन्ग-प्रेस करने पर `Love ❤️`, `Care 🤗`, `Haha 😂`, `Wow 😮`, `Sad 😢`, `Angry 😡` रिएक्शन खुलते हैं।
   * **Comment (`💬`):** बीच में (`X: 540`)
   * **Share (`↗`):** दाएं (`X: 900`)

---

## 4.5 Telegram & X (Twitter) — Bonus 5th Social Media Accounts
* **Telegram (`org.telegram.messenger`):**
  * **Top Left Hamburger Menu (`☰`):** `X: 90, Y: 185` — इसके अंदर `My Profile`, `New Group`, `Contacts`, `Calls`, `Saved Messages` (क्लाउड स्टोरेज), और **`Settings`**।
  * **Top Right Search (`🔍`):** `X: 985, Y: 185` — कोई भी चैनल, ग्रुप या मूवी/फाइल सर्च करने के लिए।
  * **Bottom Right Floating Pencil (`✏️`):** `X: 950, Y: 2020` — नया मैसेज/चैनल शुरू करने के लिए।
* **X / Twitter (`com.twitter.android`):**
  * **Top Left Profile Icon (`👤`):** `X: 90, Y: 185` (Profile, Bookmarks, Settings & Support)।
  * **Bottom Bar (`Y: 2240`):** `Home (🏠 X: 90)`, `Search/Trending (🔍 X: 270)`, `Grok AI (X: 450)`, `Communities (👥 X: 630)`, `Notifications (🔔 X: 810)`, `Messages (✉️ X: 990)`।
  * **Floating Post Button (`➕`):** `X: 950, Y: 2020`।
