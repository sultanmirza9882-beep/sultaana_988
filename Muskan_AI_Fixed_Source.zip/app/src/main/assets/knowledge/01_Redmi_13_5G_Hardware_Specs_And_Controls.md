# Module 1: Redmi 13 5G Hardware, Screen Coordinate Grid & Control Architecture
*(रेडमी 13 5G हार्डवेयर, स्क्रीन कोऑर्डिनेट ग्रिड और डिवाइस कंट्रोल आर्किटेक्चर)*

## 1.1 Official Hardware & Software Specifications (आधिकारिक स्पेसिफिकेशन्स)
* **Model Name & Number:** [Xiaomi Redmi 13 5G](https://www.mi.com/in/product/redmi-13-5g/) (Model ID: `2406ERN9CI` — [GSMArena](https://www.gsmarena.com/xiaomi_redmi_13_5g-13157.php))
* **Operating System:** Android 14 with [Xiaomi HyperOS](https://www.mi.com/global/hyperos/) (2 Years Android OS Updates + 4 Years Security Updates — [Xiaomi India FAQ](https://www.mi.com/in/product/redmi-13-5g/faq/))
* **Processor (SoC):** Qualcomm SM4450 Snapdragon 4 Gen 2 Accelerated Edition (4 nm), Octa-core (2x 2.3 GHz Cortex-A78 & 6x 2.0 GHz Cortex-A55), GPU: Adreno 613 ([GSMArena](https://www.gsmarena.com/xiaomi_redmi_13_5g-13157.php))
* **RAM & Storage Variants:** 6GB + 128GB, 8GB + 128GB, 8GB + 256GB (UFS 2.2 Storage + Virtual RAM Expansion up to 8GB extra; Hybrid microSDXC slot up to 1TB — [GSMArena](https://www.gsmarena.com/xiaomi_redmi_13_5g-13157.php))
* **Display Geometry (AI Agent Viewport):**
  * **Screen Size:** 6.79 inches IPS LCD, 120Hz AdaptiveSync (30Hz/48Hz/60Hz/90Hz/120Hz), 240Hz Touch Sampling Rate, 550 nits (HBM), Corning Gorilla Glass 3 ([Xiaomi India FAQ](https://www.mi.com/in/product/redmi-13-5g/faq/))
  * **Pixel Resolution:** `1080 x 2460` pixels (~396 PPI density, 20.5:9 aspect ratio) ([GSMArena](https://www.gsmarena.com/xiaomi_redmi_13_5g-13157.php))
  * **Dimensions & Weight:** `168.6 x 76.28 x 8.3 mm`, Weight: `205g`, Dual-sided Crystal Glass Design, IP53 Dust & Splash Resistant ([Xiaomi India FAQ](https://www.mi.com/in/product/redmi-13-5g/faq/))
* **Camera System & Ring Flash:**
  * **Rear Main Camera:** 108 MP (`f/1.75` / `f/1.8`, 3x In-Sensor Lossless Zoom, PDAF) + 2 MP Macro Camera (`f/2.4`), 1080p@30fps video ([Xiaomi India FAQ](https://www.mi.com/in/product/redmi-13-5g/faq/))
  * **Rear Ring Flash (Smart Notification Light):** Circular LED flash around rear module; blinks for incoming calls, alarms, and notifications ([Xiaomi India FAQ](https://www.mi.com/in/product/redmi-13-5g/faq/))
  * **Front Selfie Camera:** 13 MP (`f/2.5` wide), centered punch-hole cutout at top center (`X: 540, Y: 65`), 1080p@30fps ([GSMArena](https://www.gsmarena.com/xiaomi_redmi_13_5g-13157.php))
* **Battery & Charging:** 5030 mAh Li-Po battery, 33W Fast Charging (USB Type-C, 50% in ~30 mins) ([GSMArena](https://www.gsmarena.com/xiaomi_redmi_13_5g-13157.php))
* **Connectivity & Special Sensors:**
  * Dual Nano-SIM (5G SA/NSA bands: 1, 3, 5, 8, 28, 40, 78), Dual-band Wi-Fi 802.11 a/b/g/n/ac (2.4GHz / 5GHz), Bluetooth 5.0/5.4, GPS/GLONASS/GALILEO/BDS ([GSMArena](https://www.gsmarena.com/xiaomi_redmi_13_5g-13157.php))
  * **Infrared (IR) Blaster:** Located on the top edge for controlling TV, AC, Set-top box via the pre-installed Mi Remote app ([GSMArena](https://www.gsmarena.com/xiaomi_redmi_13_5g-13157.php))
  * **Biometrics & Sensors:** Side-mounted Fingerprint Sensor (integrated into Power button), AI Face Unlock, Accelerometer, Electronic Compass, Virtual Proximity Sensor, Ambient Light Sensor ([GSMArena](https://www.gsmarena.com/xiaomi_redmi_13_5g-13157.php))

---

## 1.2 Physical Frame & Button Locations (फिजिकल बटन और पोर्ट्स की स्थिति)
AI एजेंट को यूजर को गाइड करने या हार्डवेयर की-इवेंट्स (`keyevent`) भेजने के लिए फिजिकल लेआउट पता होना चाहिए:

| हिस्सा (Edge/Side) | क्या मौजूद है (Components) | AI Agent Keycode / Action |
| :--- | :--- | :--- |
| **Right Edge (दाहिनी साइड)** | ऊपर: **Volume Up (+)** और **Volume Down (-)** रॉकर बटन; उसके ठीक नीचे: **Power Button + Side Fingerprint Sensor** | Volume Up: `KEYCODE_VOLUME_UP (24)`<br>Volume Down: `KEYCODE_VOLUME_DOWN (25)`<br>Power/Lock: `KEYCODE_POWER (26)`<br>Screenshot: `Volume Down + Power` (एक साथ दबाएं) |
| **Left Edge (बाईं साइड)** | **Hybrid SIM Tray** (ऊपरी हिस्से में) — 2 Nano-SIM या 1 Nano-SIM + 1 microSD कार्ड | हार्डवेयर ट्रे (सिम इजेक्टर पिन से खुलती है) |
| **Top Edge (ऊपरी किनारा)** | **3.5mm Headphone Jack** और **IR Blaster (Infrared Port)** | `Mi Remote` ऐप के ज़रिये टीवी/एसी कंट्रोल करता है |
| **Bottom Edge (निचला किनारा)** | **Primary Microphone**, **USB Type-C Port** (चार्जिंग व OTG डेटा), और **Bottom-firing Mono Speaker Grille** | USB Debugging (ADB) और चार्जिंग के लिए |
| **Front Top Center (सामने ऊपर बीच में)** | **13MP Punch-Hole Camera** (`X: 540, Y: 65`) और सबसे ऊपर बारीक **Earpiece Speaker** | स्टेटस बार के बीच में यह हिस्सा टच-डेड ज़ोन (Cutout) होता है |

---

## 1.3 Screen Coordinate System for AI Agent (`1080 x 2460` Pixels)
Redmi 13 5G की स्क्रीन का रेजोल्यूशन **चौड़ाई (Width) = 1080 px** (`X: 0` बाएं से `X: 1080` दाएं तक) और **ऊंचाई (Height) = 2460 px** (`Y: 0` सबसे ऊपर से `Y: 2460` सबसे नीचे तक) है ([GSMArena](https://www.gsmarena.com/xiaomi_redmi_13_5g-13157.php)).

| स्क्रीन ज़ोन (Screen Zone) | X-Axis Range (px) | Y-Axis Range (px) |Normalized (x%, y%) | इस जगह पर क्या होता है (UI Elements Present) |
| :--- | :--- | :--- | :--- | :--- |
| **Top Status Bar (Left)** | `0 – 480` | `0 – 110` | `(0-44%, 0-4.5%)` | घड़ी (Time), नोटिफिकेशन आइकॉन्स; यहाँ से **नीचे स्वाइप (Swipe Down)** करने पर **Notification Shade** खुलता है ([Xiaomi Support](https://www.mi.com/uk/support/article/KA-33186/)) |
| **Punch-Hole Cutout (Center)** | `480 – 600` | `0 – 110` | `(44-55%, 0-4.5%)` | फ्रंट सेल्फी कैमरा (`X: 540, Y: 65`) — यहाँ टैप न करें |
| **Top Status Bar (Right)** | `600 – 1080` | `0 – 110` | `(55-100%, 0-4.5%)` | 5G/VoLTE नेटवर्क, Wi-Fi, बैटरी आइकॉन; यहाँ से **नीचे स्वाइप (Swipe Down)** करने पर **HyperOS Control Center** खुलता है ([Xiaomi Support](https://www.mi.com/uk/support/article/KA-33186/)) |
| **App Top Action Bar / Header** | `0 – 1080` | `110 – 260` | `(0-100%, 4.5-10.5%)` | बाएं (`X: 80, Y: 185`): Back Arrow / Hamburger Menu (`☰`); दाएं (`X: 990, Y: 185`): Search (`🔍`), Settings (`⚙️`), या More Options (`⋮`) |
| **Main Content / Scroll Area** | `0 – 1080` | `260 – 2120` | `(0-100%, 10.5-86%)` | ऐप्स के आइकॉन, चैट लिस्ट, रील्स, वीडियो फीड, सेटिंग्स की लिस्ट (Scroll Up: `Y: 1800 -> 500`, Scroll Down: `Y: 500 -> 1800`) |
| **Keyboard Area (When Active)** | `0 – 1080` | `1480 – 2340` | `(0-100%, 60-95%)` | जब किसी टेक्स्ट बॉक्स पर टैप किया जाता है, तो Gboard कीबोर्ड स्क्रीन के निचले 35-40% हिस्से में उभर आता है |
| **App Bottom Navigation Bar** | `0 – 1080` | `2150 – 2330` | `(0-100%, 87.5-94.7%)` | WhatsApp, YouTube, Instagram, Chrome के मुख्य 4 या 5 टैब आइकॉन्स ([Android Developers](https://developer.android.com/design/ui/mobile/guides/layout-and-content/layout-and-nav-patterns)) |
| **System Navigation Bar** | `0 – 1080` | `2330 – 2460` | `(0-100%, 94.7-100%)` | 3-Button Navigation (`Recents  square`, `Home circle`, `Back triangle`) या Full-screen Gesture Pill ([Xiaomi Support](https://www.mi.com/global/support/article/KA-33175/)) |

---

## 1.4 How the AI Agent Controls Redmi 13 5G (एजेंट मोबाइल को कैसे कंट्रोल करेगा)
AI एजेंट को मोबाइल कंट्रोल करने के लिए 3 मुख्य तरीकों से ट्रेन और इंटीग्रेट किया जाता है:

### Method A: Android Accessibility Service API (On-Device Agent App)
* एजेंट फोन के अंदर एक ऐप के रूप में चलता है जिसे `Settings > Additional settings > Accessibility > Downloaded apps` में जाकर ऑन किया जाता है।
* **Screen Reading (UI Hierarchy):** एजेंट `getRootInActiveWindow()` कॉल करके स्क्रीन पर मौजूद हर बटन का `resource-id`, `text`, `content-desc` (जैसे `"Search"`, `"Send"`, `"More options"`), और `bounds="[left,top][right,bottom]"` पढ़ता है।
* **Executing Actions:**
  * `ACTION_CLICK` — किसी भी आइकॉन या बटन पर सीधा क्लिक।
  * `ACTION_SET_TEXT` — किसी भी इनपुट बॉक्स में सीधा टेक्स्ट टाइप करना।
  * `dispatchGesture()` — किसी भी `(X, Y)` कोऑर्डिनेट पर टैप, लॉन्ग-प्रेस या स्वाइप करना।
  * `performGlobalAction()` — `GLOBAL_ACTION_BACK`, `GLOBAL_ACTION_HOME`, `GLOBAL_ACTION_RECENTS`, `GLOBAL_ACTION_NOTIFICATIONS`, `GLOBAL_ACTION_QUICK_SETTINGS`।

### Method B: ADB (Android Debug Bridge) / UIAutomator2 Commands
अगर एजेंट कंप्यूटर/सर्वर या लोकल ADB के ज़रिये फोन कंट्रोल कर रहा है, तो वह ये कमांड्स चलाता है:
* **Tap at (X, Y):** `adb shell input tap <X> <Y>` (उदाहरण: `adb shell input tap 540 2400` होम बटन दबाने के लिए)
* **Swipe / Scroll:** `adb shell input swipe <X1> <Y1> <X2> <Y2> <duration_ms>`
  * *Scroll Down (नीचे के कंटेंट देखने के लिए ऊपर स्वाइप):* `adb shell input swipe 540 1900 540 600 300`
  * *Scroll Up (ऊपर के कंटेंट देखने के लिए नीचे स्वाइप):* `adb shell input swipe 540 600 540 1900 300`
  * *Long Press (2 सेकंड):* `adb shell input swipe <X> <Y> <X> <Y> 2000`
* **System Keys:**
  * Home: `adb shell input keyevent 3`
  * Back: `adb shell input keyevent 4`
  * Recents / App Switcher: `adb shell input keyevent 187`
  * Enter / Search: `adb shell input keyevent 66`
  * Backspace / Delete: `adb shell input keyevent 67`
  * Lock / Wake Screen: `adb shell input keyevent 26` / `224`
* **Dump UI XML Tree:** `adb shell uiautomator dump /sdcard/window_dump.xml` (जिससे हर आइकॉन का सटीक कोऑर्डिनेट मिल जाता है)
* **Direct App Launch / Deep Links (Intents):**
  * Settings खोलें: `adb shell am start -a android.settings.SETTINGS`
  * Wi-Fi Settings खोलें: `adb shell am start -a android.settings.WIFI_SETTINGS`
  * WhatsApp खोलें: `adb shell monkey -p com.whatsapp -c android.intent.category.LAUNCHER 1`
  * YouTube में सर्च करें: `adb shell am start -a android.intent.action.SEARCH -p com.google.android.youtube --es query "Redmi 13 5G"`
  * Chrome में वेबसाइट खोलें: `adb shell am start -a android.intent.action.VIEW -d "https://www.google.com" com.android.chrome`
