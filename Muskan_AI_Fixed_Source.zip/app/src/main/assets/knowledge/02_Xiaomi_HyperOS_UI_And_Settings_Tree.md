# Module 2: Xiaomi HyperOS UI Layout, Icons & Complete Settings Navigation Tree
*(Xiaomi HyperOS इंटरफेस, होम स्क्रीन आइकॉन और पूरी सेटिंग्स की डायरेक्टरी)*

## 2.1 Home Screen, Control Center & System Navigation (होम स्क्रीन और नेविगेशन)
Redmi 13 5G आउट-ऑफ-द-बॉक्स Android 14 पर आधारित [Xiaomi HyperOS](https://www.mi.com/global/hyperos/) चलाता है ([Xiaomi India FAQ](https://www.mi.com/in/product/redmi-13-5g/faq/)).

### A. Home Screen Layout (`1080 x 2460`)
1. **Top Weather & Clock Widget:** `Y: 180 – 550` (बाएं घड़ी और मौसम, दाएं विजेट्स)।
2. **Main App Grid (4x6 या 5x6 Layout):** `Y: 600 – 1950` के बीच ऐप्स के आइकॉन पंक्तियों में होते हैं।
   * Column 1 X-center: `~145 px`
   * Column 2 X-center: `~340 px`
   * Column 3 X-center: `~540 px`
   * Column 4 X-center: `~740 px`
   * Column 5 X-center: `~935 px` (यदि 5x6 ग्रिड सेट है)
3. **Google Search Bar Widget (Bottom of Home Screen):** `X: 100 – 980, Y: 2020`
   * Google Icon (`G`): `X: 160, Y: 2020`
   * Text Search Area: `X: 480, Y: 2020`
   * Voice Search Mic (`🎤`): `X: 830, Y: 2020`
   * Google Lens Camera (`📷`): `X: 930, Y: 2020`
4. **Bottom Dock (Pinned Apps Row — हर होम पेज पर स्थिर रहता है):** `Y: 2180`
   * **Slot 1 (Phone / Dialer 📞):** `X: 150, Y: 2180`
   * **Slot 2 (Messages 💬):** `X: 390, Y: 2180`
   * **Slot 3 (Chrome Browser 🌐):** `X: 690, Y: 2180`
   * **Slot 4 (Camera 📷):** `X: 930, Y: 2180`
5. **App Drawer (सारे ऐप्स की लिस्ट):** होम स्क्रीन के बीच (`X: 540, Y: 1500`) से ऊपर की ओर स्वाइप (`Y: 1500 -> 400`) करने पर **App Drawer** खुलता है, जिसके सबसे ऊपर या नीचे **Search Apps Bar** होती है।

### B. Notification Shade vs. HyperOS Control Center ([Xiaomi Support](https://www.mi.com/uk/support/article/KA-33186/))
* **Notification Shade (नोटिफिकेशन पैनल):** स्क्रीन के **ऊपरी बाएं हिस्से (`X: 250, Y: 40`) से नीचे (`Y: 1200`) स्वाइप** करें। यहाँ WhatsApp, YouTube, SMS के सारे नोटिफिकेशन दिखते हैं। सभी हटाने के लिए नीचे `Clear (X)` बटन (`X: 540, Y: 2250`) दबाएं।
* **HyperOS Control Center (क्विक टॉगल पैनल):** स्क्रीन के **ऊपरी दाएं हिस्से (`X: 850, Y: 40`) से नीचे (`Y: 1200`) स्वाइप** करें।
  * **Big Pill Toggles (Top Row):**
    * **Mobile Data (मोबाइल डेटा):** `X: 290, Y: 380`
    * **Wi-Fi (वाई-फाई):** `X: 790, Y: 380` (लॉन्ग-प्रेस करने पर नेटवर्क लिस्ट खुलती है)
  * **Vertical Sliders (Middle Right):**
    * **Brightness Slider (ब्राइटनेस):** `X: 680, Y: 650 – 1050` (ऊपर/नीचे स्लाइड करें)
    * **Volume Slider (आवाज़):** `X: 900, Y: 650 – 1050` (ऊपर/नीचे स्लाइड करें)
  * **Round Quick Toggles Grid (`Y: 1150 – 1900`):**
    * Bluetooth (`X: 160, Y: 680`), Torch / Flashlight (`X: 400, Y: 680`), Mute / Silent (`X: 160, Y: 920`), Auto-brightness (`X: 400, Y: 920`), Airplane Mode, Location (GPS), Hotspot, Screen Recorder, Scanner, Dark Mode, Battery Saver, Mi Remote, DND, Cast.

### C. System Navigation Bar (`Y: 2330 – 2460`) ([Xiaomi Support](https://www.mi.com/global/support/article/KA-33175/))
* **3-Button Navigation Mode (Default Xiaomi Layout):**
  1. **Recents / Menu Button (`≡` या `▢`):** बाईं तरफ (`X: 240, Y: 2400`) — खुले हुए ऐप्स देखने और क्लियर करने के लिए।
  2. **Home Button (`○`):** बिल्कुल बीच में (`X: 540, Y: 2400`) — सीधा होम स्क्रीन पर आने के लिए (लॉन्ग प्रेस से Google Assistant / Gemini खुलता है)।
  3. **Back Button (`◁`):** दाहिनी तरफ (`X: 840, Y: 2400`) — एक स्टेप पीछे जाने के लिए। *(नोट: यदि `Mirror buttons` बंद किया गया हो, तो Back बाएं `X: 240` और Recents दाएं `X: 840` पर होता है)*।
* **Full-Screen Gestures Mode:**
  * **Home:** सबसे नीचे (`Y: 2450`) से तेज़ी से ऊपर स्वाइप करें।
  * **Recents:** सबसे नीचे से ऊपर स्वाइप करके बीच (`Y: 1600`) में 1 सेकंड रोकें।
  * **Back:** स्क्रीन के बाएं किनारे (`X: 10 -> 400`) या दाएं किनारे (`X: 1070 -> 680`) से अंदर की तरफ स्वाइप करें।

---

## 2.2 Complete Settings Menu Hierarchy (कौन सी सेटिंग कहाँ जाकर खुलेगी)
Settings खोलने के लिए: **Home Screen / App Drawer में `Settings (⚙️)` पर टैप करें**, या **Top Search Bar in Settings (`X: 540, Y: 280`)** में सेटिंग का नाम टाइप करें, या ADB इंटेंट चलाएं।

| # | मुख्य सेटिंग (Main Menu) | इसके अंदर कौन-कौन सी सब-सेटिंग्स हैं (Exact Path & Options) | यूजर कमांड उदाहरण (User Voice Intent) |
| :--- | :--- | :--- | :--- |
| **1** | **About phone**<br>*(फ़ोन के बारे में)* | `Settings > About phone` → **Xiaomi HyperOS version** (यहाँ सिस्टम अपडेट चेक होता है), **Device name**, **Storage** (भरा/खाली स्पेस), **Detailed info and specs** → *OS version पर 7 बार लगातार टैप करने से **Developer options** ऑन होता है*। | "फ़ोन में कितना स्टोरेज खाली है?", "सॉफ्टवेयर अपडेट चेक करो", "डेवलपर ऑप्शन ऑन करो" |
| **2** | **System apps updater** | `Settings > System apps updater` → Xiaomi के इनबिल्ट ऐप्स (Mi Remote, Security, File Manager) अपडेट करने के लिए। | "सिस्टम ऐप्स अपडेट करो" |
| **3** | **Security status** | `Settings > Security status` → Find device, Google Play Protect, Security update, Emergency SOS. | "मेरा फोन सुरक्षित है या नहीं चेक करो" |
| **4** | **SIM cards & mobile networks**<br>*(सिम और नेटवर्क)* | `Settings > SIM cards & mobile networks` → **SIM 1 / SIM 2** (Preferred network type: **Prefer 5G** / Prefer LTE, Access Point Names (APN), Make calls using Wi-Fi), **Data SIM**, **Turn on Mobile data**, **Data roaming**, **Set data plan**। | "5G नेटवर्क चालू करो", "सिम 1 से सिम 2 पर इंटरनेट बदलो", "Wi-Fi कॉलिंग ऑन करो" |
| **5** | **Wi-Fi**<br>*(वाई-फाई)* | `Settings > Wi-Fi` → **Turn on Wi-Fi** टॉगल (`X: 960, Y: 320`), **Wi-Fi assistant**, **Available networks** (नेटवर्क के सामने QR आइकॉन पर टैप करके पासवर्ड शेयर करें), **Additional settings**। | "वाई-फाई कनेक्ट करो", "वाई-फाई का पासवर्ड दिखाओ" |
| **6** | **Bluetooth**<br>*(ब्लूटूथ)* | `Settings > Bluetooth` → **Turn on Bluetooth** टॉगल, **Paired devices** (ईयरबड्स/वॉच), **Available devices** (नया डिवाइस पेयर करने के लिए)। | "ब्लूटूथ ऑन करके मेरे ईयरबड्स कनेक्ट करो" |
| **7** | **Portable hotspot**<br>*(हॉटस्पॉट)* | `Settings > Portable hotspot` → **Portable hotspot** (ऑन/ऑफ टॉगल), **Set up portable hotspot** (Hotspot Name और Password बदलने के लिए, Security: WPA2/WPA3, AP Band: 2.4GHz / 5GHz), **One-time data limit**। | "हॉटस्पॉट चालू करो", "हॉटस्पॉट का पासवर्ड बदलो" |
| **8** | **Connection & sharing** | `Settings > Connection & sharing` → **Quick Share (Nearby Share)**, **Cast** (टीवी पर स्क्रीन मिररिंग), **Printing**, **VPN**, **Private DNS** (`dns.adguard.com` आदि), **Android Auto**। | "टीवी पर स्क्रीन कास्ट करो", "Quick Share ऑन करो" |
| **9** | **Lock screen**<br>*(लॉक स्क्रीन)* | `Settings > Lock screen` → **Sleep** (स्क्रीन कितने समय बाद बंद हो: 15 sec से 10 min), **Raise to wake**, **Double tap to wake or turn off screen**, **Glance for Mi** (लॉक स्क्रीन वॉलपेपर कैरोसेल बंद/चालू करने के लिए), **Flashlight notification (Ring Flash)**। | "स्क्रीन टाइमआउट 5 मिनट कर दो", "डबल टैप से स्क्रीन ऑन चालू करो" |
| **10** | **Display & brightness**<br>*(डिस्प्ले और ब्राइटनेस)* | `Settings > Display & brightness` → **Light mode / Dark mode**, **Brightness level**, **Adaptive brightness**, **Reading mode** (आंखों की सुरक्षा के लिए पीली स्क्रीन), **Refresh rate** (`Default` या `Custom -> 120Hz / 60Hz`), **Text size** और **Font**। | "डार्क मोड लगाओ", "रिफ्रेश रेट 120Hz पर सेट करो", "रीडिंग मोड ऑन करो" |
| **11** | **Wallpaper & personalization** | `Settings > Wallpaper` और `Settings > Themes` → वॉलपेपर, थीम, रिंगटोन और आइकॉन साइज बदलने के लिए। | "वॉलपेपर बदलो" |
| **12** | **Sound & vibration**<br>*(आवाज़ और वाइब्रेशन)* | `Settings > Sound & vibration` → **Media / Ringtone / Alarm volume sliders**, **Ringtone** (कॉल की धुन), **Notification sound**, **Silent mode / Do Not Disturb (DND)**, **Vibrate for calls**, **Sound effects** (हेडफ़ोन इक्वलाइज़र), **Additional settings** (Dial pad tones, Tap sounds)। | "रिंगटोन बदलो", "साइलेंट मोड लगाओ", "कॉल पर वाइब्रेशन ऑन करो" |
| **13** | **Notifications & status bar**<br>*(नोटिफिकेशन व स्टेटस बार)* | `Settings > Notifications & status bar` ([Xiaomi Support](https://www.mi.com/uk/support/article/KA-33186/)) → **App notifications** (किस ऐप का नोटिफिकेशन बंद/चालू करना है), **Show notification icons**, **Show connection speed** (इंटरनेट स्पीड मीटर ऊपर दिखाने के लिए), **Battery indicator** (बैटरी प्रतिशत `%` आइकॉन के अंदर या बाहर), **Control center style**। | "ऊपर इंटरनेट स्पीड दिखाओ", "बैटरी परसेंटेज ऑन करो" |
| **14** | **Home screen**<br>*(होम स्क्रीन व नेविगेशन)* | `Settings > Home screen` ([Xiaomi Support](https://www.mi.com/global/support/article/KA-33175/)) → **Home screen** (`Classic` या `With App drawer`), **System navigation** (`Buttons` या `Gestures`), **Home screen layout** (`4x6` या `5x6`), **Arrange items in Recents**। | "साइड से स्वाइप करने वाला जेस्चर ऑन करो", "नीचे वाले 3 बटन वापस लाओ" |
| **15** | **Fingerprints, face data, and screen lock** | `Settings > Fingerprints, face data, and screen lock` → **Screen lock** (Pattern, PIN, Password), **Fingerprint unlock** (साइड पावर बटन पर फिंगरप्रिंट जोड़ें; **Fingerprint recognition method**: `Touch` या `Press`), **Face unlock**। | "फिंगरप्रिंट लॉक लगाओ", "पिन पासवर्ड बदलो" |
| **16** | **Safety & emergency** | `Settings > Safety & emergency` → **Emergency SOS** (पावर बटन 5 बार दबाने पर इमरजेंसी कॉल), **Medical info**, **Emergency contacts**, **Wireless emergency alerts**। | "इमरजेंसी नंबर जोड़ो" |
| **17** | **Privacy & security** | `Settings > Privacy` → **Permission manager** (Camera, Microphone, Location, Contacts किस ऐप के पास है), **Privacy dashboard**। | "देखो कौन सा ऐप माइक या कैमरा इस्तेमाल कर रहा है" |
| **18** | **Battery**<br>*(बैटरी)* | `Settings > Battery` → **Current mode** (`Balanced`, `Battery saver`, `Ultra battery saver`), **Battery protection** (चार्जिंग ऑप्टिमाइजेशन), **Battery check-up**, **App battery saver**। | "बैटरी सेवर ऑन करो", "देखो किस ऐप ने सबसे ज्यादा बैटरी खर्च की" |
| **19** | **Apps**<br>*(ऐप्स मैनेजमेंट)* | `Settings > Apps` → **Manage apps** (किसी भी ऐप को `Uninstall` करने, `Force stop` करने, या `Clear data / Clear cache` करने के लिए), **System app settings** (`Call settings > Call recording`), **Dual apps** (दो WhatsApp/Facebook चलाने के लिए), **Permissions** (`Autostart`), **App lock** (ऐप्स पर फिंगरप्रिंट लॉक लगाने के लिए)। | "दो व्हाट्सएप (Dual App) बनाओ", "ऐप पर लॉक लगाओ", "कॉल रिकॉर्डिंग ऑटोमैटिक ऑन करो" |
| **20** | **Additional settings**<br>*(अतिरिक्त सेटिंग्स — सबसे महत्वपूर्ण!)* | `Settings > Additional settings` →<br>• **Date and time** (तारीख और समय)<br>• **Languages & input** → `Languages` (हिंदी/English) और `Manage keyboards` (`Gboard` सेटिंग्स)<br>• **Region** (India)<br>• **Gesture shortcuts** (3-finger swipe down for Screenshot, Double press power button for Torch/Camera)<br>• **One-handed mode**<br>• **Clear speaker** (30 सेकंड की साउंड चलाकर स्पीकर की धूल साफ करता है)<br>• **Accessibility** (AI Agent की सर्विस ऑन करने, TalkBack, Magnification के लिए)<br>• **Memory extension** (2GB / 4GB / 6GB / 8GB Virtual RAM बढ़ाने के लिए)<br>• **Floating windows** और **Second space** (फोन के अंदर दूसरा गुप्त फोन प्रोफाइल) ([Xiaomi Support](https://www.mi.com/global/support/faq/details/KA-497634/))। | "कीबोर्ड की भाषा बदलो", "स्पीकर साफ करने वाला फीचर चलाओ", "रैम (RAM) बढ़ाओ", "एक्सेसिबिलिटी में AI एजेंट ऑन करो" |
| **21** | **Digital Wellbeing & parental controls** | `Settings > Digital Wellbeing & parental controls` → दिन भर में फोन कितने घंटे चला और किस ऐप पर कितना समय बीता, **App timers**, **Bedtime mode**। | "आज मैंने फोन कितनी देर चलाया?" |
| **22** | **Google & Xiaomi Account** | `Settings > Xiaomi Account` और `Settings > Google` → क्लाउड बैकअप, Find My Device, पासवर्ड मैनेजर। | "गूगल अकाउंट चेक करो" |
