# Module 6: Voice command -> JSON action examples (Redmi 13 5G, 1080x2460)
*(Exact step-by-step JSON actions using UniversalPhoneAgent's action schema)*

## Wi-Fi aur Bluetooth on karo | वाई-फाई और ब्लूटूथ चालू करो
intent: TOGGLE_QUICK_SETTINGS (System_Control)
1. `{"thought":"Open HyperOS Control Center","action":"quick_settings"}` (or `{"action":"swipe","x1":850,"y1":40,"x2":850,"y2":1200}`)
2. `{"thought":"Tap Wi-Fi pill toggle","action":"tap_xy","x":790,"y":380}`
3. `{"thought":"Tap Bluetooth round toggle","action":"tap_xy","x":160,"y":680}`
4. `{"thought":"Return to home screen","action":"home"}`

## Torch on karo | टॉर्च (फ्लैशलाइट) जलाओ
intent: TOGGLE_TORCH (System_Control)
1. `{"thought":"Open HyperOS Control Center from top-right","action":"quick_settings"}` (or `{"action":"swipe","x1":850,"y1":40,"x2":850,"y2":1200}`)
2. `{"thought":"Tap Torch / Flashlight toggle","action":"tap_xy","x":400,"y":680}`

## Display 120Hz aur Dark mode par set karo | डिस्प्ले को 120 हर्ट्ज़ (120Hz) और डार्क मोड पर सेट करो
intent: CONFIGURE_DISPLAY_SETTINGS (Settings_Navigation)
1. `{"thought":"Open Settings app","action":"open_app","name":"settings"}`
2. `{"thought":"Open Display & brightness","action":"tap_text","text":"Display & brightness"}`
3. `{"thought":"Select Dark mode card","action":"tap_text","text":"Dark mode"}` (or `{"action":"tap_xy","x":780,"y":520}`)
4. `{"thought":"Scroll down to Refresh rate","action":"scroll","direction":"down"}`
5. `{"thought":"Open Refresh rate menu","action":"tap_text","text":"Refresh rate"}`
6. `{"thought":"Select Custom refresh rate","action":"tap_text","text":"Custom"}`
7. `{"thought":"Select 120Hz","action":"tap_text","text":"120Hz"}`

## Clear speaker feature chala do | फोन का स्पीकर साफ करने वाला फीचर चलाओ
intent: RUN_CLEAR_SPEAKER (Settings_Navigation)
1. `{"thought":"Open Settings app","action":"open_app","name":"settings"}`
2. `{"thought":"Scroll down to Additional settings","action":"scroll","direction":"down"}`
3. `{"thought":"Open Additional settings","action":"tap_text","text":"Additional settings"}`
4. `{"thought":"Open Clear speaker utility","action":"tap_text","text":"Clear speaker"}`
5. `{"thought":"Turn on Clear speaker toggle","action":"tap_xy","x":960,"y":380}`

## Hotspot on karo aur password dikhao | हॉटस्पॉट ऑन करो और उसका पासवर्ड चेक करो
intent: ENABLE_HOTSPOT_VIEW_PASSWORD (Settings_Navigation)
1. `{"thought":"Open Settings app","action":"open_app","name":"settings"}`
2. `{"thought":"Open Portable hotspot settings","action":"tap_text","text":"Portable hotspot"}`
3. `{"thought":"Toggle on Portable hotspot","action":"tap_xy","x":960,"y":320}`
4. `{"thought":"Open Set up portable hotspot","action":"tap_text","text":"Set up portable hotspot"}`
5. `{"thought":"Tap eye icon next to password to reveal it","action":"tap_xy","x":960,"y":620}`

## WhatsApp par Rahul ko message bhejo ki main 10 minute mein pahunch raha hoon | व्हाट्सएप पर राहुल को मैसेज भेजो कि मैं 10 मिनट में पहुँच रहा हूँ
intent: WHATSAPP_SEND_MESSAGE (WhatsApp_Automation)
1. `{"thought":"Open WhatsApp","action":"open_app","name":"whatsapp"}`
2. `{"thought":"Tap top search bar in WhatsApp","action":"tap_xy","x":540,"y":310}`
3. `{"thought":"Type contact name Rahul","action":"type","text":"Rahul"}`
4. `{"thought":"Tap Rahul's chat from results","action":"tap_text","text":"Rahul"}` (or `{"action":"tap_xy","x":540,"y":560}`)
5. `{"thought":"Type message in chat input field","action":"type","text":"Main 10 minute mein pahunch raha hoon"}`
6. `{"thought":"Tap Send button","action":"tap_text","text":"Send"}` (or `{"action":"tap_xy","x":990,"y":1410}`)

## WhatsApp par Mummy ko video call lagao | व्हाट्सएप पर मम्मी को वीडियो कॉल लगाओ
intent: WHATSAPP_VIDEO_CALL (WhatsApp_Automation)
1. `{"thought":"Open WhatsApp","action":"open_app","name":"whatsapp"}`
2. `{"thought":"Tap Search bar","action":"tap_xy","x":540,"y":310}`
3. `{"thought":"Type Mummy","action":"type","text":"Mummy"}`
4. `{"thought":"Open Mummy's chat","action":"tap_text","text":"Mummy"}` (or `{"action":"tap_xy","x":540,"y":560}`)
5. `{"thought":"Tap Video Call icon in top bar","action":"tap_text","text":"Video call"}` (or `{"action":"tap_xy","x":740,"y":185}`)

## YouTube kholo aur Arijit Singh ke gaane chalao | यूट्यूब खोलो और अरिजीत सिंह के गाने चलाओ
intent: YOUTUBE_SEARCH_AND_PLAY (YouTube_Automation)
1. `{"thought":"Open YouTube","action":"open_app","name":"youtube"}`
2. `{"thought":"Tap Search icon at top right","action":"tap_xy","x":960,"y":185}`
3. `{"thought":"Type Arijit Singh songs","action":"type","text":"Arijit Singh songs"}`
4. `{"thought":"Submit search","action":"enter"}`
5. `{"thought":"Tap first video result","action":"tap_xy","x":540,"y":650}`

## YouTube Shorts kholo aur next video dikhao | यूट्यूब शॉर्ट्स खोलो और अगला शॉर्ट दिखाओ
intent: YOUTUBE_SHORTS_SCROLL (YouTube_Automation)
1. `{"thought":"Tap Shorts tab at bottom bar","action":"tap_text","text":"Shorts"}` (or `{"action":"tap_xy","x":325,"y":2240}`)
2. `{"thought":"Swipe up to next Short","action":"scroll","direction":"down"}`

## Instagram Reels chalao aur like karo | इंस्टाग्राम पर रील्स चलाओ और इस रील को लाइक करो
intent: INSTAGRAM_REELS_LIKE (Instagram_Automation)
1. `{"thought":"Open Instagram","action":"open_app","name":"instagram"}`
2. `{"thought":"Tap Reels tab at bottom bar (4th icon)","action":"tap_text","text":"Reels"}` (or `{"action":"tap_xy","x":755,"y":2240}`)
3. `{"thought":"Double-tap center of Reel to Like","action":"double_tap","x":540,"y":1100}` (or tap Heart at `{"action":"tap_xy","x":985,"y":1420}`)

## Facebook kholo aur friend requests dikhao | फेसबुक खोलो और देखो किन लोगों की फ्रेंड रिक्वेस्ट आई है
intent: FACEBOOK_CHECK_FRIEND_REQUESTS (Facebook_Automation)
1. `{"thought":"Open Facebook","action":"open_app","name":"facebook"}`
2. `{"thought":"Tap Friends tab in top navigation bar","action":"tap_text","text":"Friends"}` (or `{"action":"tap_xy","x":450,"y":310}`)

## Chrome mein Sarkari Result website kholo aur Hindi mein translate karo | क्रोम ब्राउज़र में सरकारी रिजल्ट वेबसाइट खोलो और उसे हिंदी में ट्रांसलेट करो
intent: CHROME_OPEN_AND_TRANSLATE (Chrome_Web_Automation)
1. `{"thought":"Open Google Chrome","action":"open_app","name":"chrome"}`
2. `{"thought":"Tap Omnibox address bar","action":"tap_xy","x":430,"y":185}`
3. `{"thought":"Type sarkari result","action":"type","text":"sarkari result"}`
4. `{"thought":"Press Enter/Search on Gboard","action":"enter"}`
5. `{"thought":"Tap first search result link","action":"tap_xy","x":540,"y":520}`
6. `{"thought":"Tap Chrome 3-dots menu at top right","action":"tap_xy","x":1005,"y":185}`
7. `{"thought":"Tap Translate option","action":"tap_text","text":"Translate"}` (or `{"action":"tap_xy","x":540,"y":1450}`)

## Keyboard mein voice typing on karo | कीबोर्ड में वॉयस टाइपिंग चालू करके बोलकर लिखो
intent: GBOARD_VOICE_TYPING (Keyboard_Control)
1. `{"thought":"Tap Gboard top-right Microphone icon","action":"tap_xy","x":1000,"y":1535}`

## Keyboard language Hindi mein badlo | कीबोर्ड की भाषा अंग्रेजी से हिंदी करो
intent: GBOARD_SWITCH_LANGUAGE (Keyboard_Control)
1. `{"thought":"Tap Globe icon left of Spacebar to switch language","action":"tap_xy","x":315,"y":2255}` (or `{"action":"long_press","x":540,"y":2255}`)
