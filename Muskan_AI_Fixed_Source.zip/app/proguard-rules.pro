# =============================================================================
# Muskan Android — R8 / ProGuard Keep Rules
# =============================================================================

# Preserve stack trace line numbers and generic/annotation metadata needed by
# Retrofit, Moshi, Kotlin reflection, and Firebase Firestore.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,RuntimeVisibleAnnotations,RuntimeVisibleParameterAnnotations

# Preserve Kotlin metadata & default constructor markers for reflective adapters.
-keep class kotlin.Metadata { *; }
-keep class kotlin.jvm.internal.DefaultConstructorMarker { *; }
-keepclassmembers class **$WhenMappings {
    <fields>;
}

# =============================================================================
# JNI & Native llama.cpp Bridge (com.example.engine.llm.LlamaCppBridge)
# =============================================================================
-keep class com.example.engine.llm.LlamaCppBridge { *; }
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}

# =============================================================================
# Moshi (Codegen + KotlinJsonAdapterFactory Reflection)
# =============================================================================
-keep @com.squareup.moshi.JsonClass class * { *; }
-keepclassmembers class * extends com.squareup.moshi.JsonAdapter {
    public <init>(com.squareup.moshi.Moshi);
    public <init>(com.squareup.moshi.Moshi, java.lang.reflect.Type[]);
}
-keepclassmembers class * {
    @com.squareup.moshi.FromJson <methods>;
    @com.squareup.moshi.ToJson <methods>;
    @com.squareup.moshi.Json <fields>;
}
-keep class com.squareup.moshi.** { *; }
-keep class com.example.api.** { *; }
-keep class com.example.data.gemini.** { *; }
-keep class com.example.data.Gemini* { *; }
-keep class com.example.data.*Request* { *; }
-keep class com.example.data.*Response* { *; }
-keep class com.example.data.Content { *; }
-keep class com.example.data.Part { *; }
-keep class com.example.data.InlineData { *; }
-keep class com.example.data.Candidate { *; }
-keep class com.example.data.GenerationConfig { *; }
-keep class com.example.data.SafetySetting { *; }
-keep class com.example.data.Tool* { *; }
-keep class com.example.data.Function* { *; }
-dontwarn com.squareup.moshi.**

# =============================================================================
# Retrofit & Coroutines Suspend Service Interfaces
# =============================================================================
-keep,allowobfuscation,allowshrinking interface retrofit2.Call
-keep,allowobfuscation,allowshrinking class retrofit2.Response
-keep,allowobfuscation,allowshrinking class kotlin.coroutines.Continuation
-keep class com.example.data.GeminiApiService { *; }
-keepclassmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}
-if interface * { @retrofit2.http.* <methods>; }
-keep,allowobfuscation interface <1>
-dontwarn retrofit2.**
-dontwarn org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement
-dontwarn javax.annotation.**

# =============================================================================
# OkHttp & Okio
# =============================================================================
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }
-keep class okio.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# =============================================================================
# Room Database (Entities, DAOs, Generated _Impl Classes)
# =============================================================================
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao interface * { *; }
-keep class * extends androidx.room.RoomDatabase {
    public <init>();
}
-keep class com.example.data.local.** { *; }
-dontwarn androidx.room.paging.**

# =============================================================================
# Firebase (Firestore POJOs, Auth, App Check) & Credential Manager
# =============================================================================
-keep class com.example.data.firebase.** { *; }
-keepclassmembers class com.example.data.firebase.** { *; }
-keepattributes RuntimeVisibleAnnotations
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }
-keep class androidx.credentials.** { *; }
-keep class com.google.android.libraries.identity.googleid.** { *; }
-dontwarn com.google.firebase.**
-dontwarn com.google.android.gms.**
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.lang.model.**

# =============================================================================
# AndroidX Security Crypto (Tink) & ML Kit Text Recognition
# =============================================================================
-keep class com.google.crypto.tink.** { *; }
-dontwarn com.google.crypto.tink.**
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**
