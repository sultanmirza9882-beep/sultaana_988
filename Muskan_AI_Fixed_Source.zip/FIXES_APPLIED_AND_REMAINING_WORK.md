# Muskan Voice Assistant — Dual-Brain Offline AI (Qwen3 1.7B GGUF + llama.cpp) & Fix Report

Date: 2026-11-10

## 1. Dual-Brain Offline AI Integration (Xiaomi Redmi 13 5G • 8 GB RAM • Snapdragon 4 Gen 2)

All three Android project copies in this archive (root, `muskan-v10-gemini-live-voice/`, and `muskan-v10-gemini-live-voice 1/`) have been upgraded with the complete **Dual-Brain (Online Gemini + Offline Qwen3 1.7B GGUF)** architecture:

### A. Native `llama.cpp` JNI Engine (`app/src/main/cpp/` & `LlamaCppBridge.kt`)
- Added `app/src/main/cpp/CMakeLists.txt` and `app/src/main/cpp/llama_jni.cpp` (`libmuskan_llama_jni.so`), configured in `app/build.gradle.kts` for `arm64-v8a` with `-O3 -ffast-math`.
- Tuned specifically for **Xiaomi Redmi 13 5G (`2406ERN9CI`, Snapdragon 4 Gen 2 Accelerated Edition, Octa-core Max 2.3 GHz, 8 GB RAM, Android 16 / Xiaomi HyperOS 3)**:
  - `n_threads = 6`, `n_ctx = 2048`, `n_batch = 512`, `temperature = 0.6f`, `top_p = 0.90f`.
  - Formats prompts using Qwen3's ChatML template (`<|im_start|>system...`, `/no_think` low-latency voice mode or `/think` reasoning mode) and strips `<think>...</think>` tags before Text-to-Speech output.
- Updated `.github/workflows/build-apk.yml` so GitHub Actions automatically clones [ggml-org/llama.cpp](https://github.com/ggml-org/llama.cpp) into `app/src/main/cpp/llama.cpp` during the CI build (`gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug`). When building offline without the submodule, `CMakeLists.txt` compiles the GGUF v3 binary header verifier cleanly so native builds never break.

### B. On-Device GGUF Model Manager (`QwenOfflineModelManager.kt`)
- Configures [Qwen/Qwen3-1.7B-GGUF](https://huggingface.co/Qwen/Qwen3-1.7B-GGUF) (`Qwen3-1.7B-Q4_K_M.gguf`, ~1.28 GB, Apache 2.0 License) as the primary local model without bloating the APK size.
- Supports **resumable HTTP Range downloads** (`Range: bytes=<offset>-`), real-time progress telemetry, automatic discovery of `.gguf` files in app-private storage or `/sdcard/Download/`, SAF URI import, and binary GGUF v3 header verification (`GGUF` magic bytes, version, tensor count, metadata KV count).

### C. Dual-Brain Online/Offline Routing & Multi-Turn Context Memory (`VoiceSessionManager.kt` & `LocalOfflineSmallLlmEngine.kt`)
- **Automatic Dual-Brain Switching**:
  - When internet is available and a Gemini API key is configured (and Force Offline Mode is off), Muskan uses **Gemini Live / Gemini API** with automatic fallback to the Offline Brain on network drop or HTTP 429 quota exhaustion.
  - When offline, when no API key is configured, or when **Force Offline Mode** is enabled in Settings, Muskan routes directly to `LocalOfflineSmallLlmEngine` **without requiring any API key**.
- **Conversation Context & Memory**:
  - Passes recent conversation turns (`ConversationTurnDao`) and saved user facts (`UserMemoryDao`) from Room SQLite into both `LlamaCppBridge` and the built-in Hindi/Hinglish engine.
  - Supports voice memory saving (`"मुस्कान याद रखो कि..."` / `"yaad rakhna ki..."`), previous-turn context recall (`"मैंने अभी क्या पूछा था?"` / `"pichla sawaal kya tha?"`), follow-up continuity (`"इसके बारे में और बताओ"`), device hardware controls, math/percentage/unit conversions, and Hindi/Hinglish general knowledge.

### D. Offline Hindi & Hinglish Speech-to-Text (STT) and Text-to-Speech (TTS)
- **Offline Speech Recognition**: `VoiceSessionManager.createSpeechIntent()` automatically enables `RecognizerIntent.EXTRA_PREFER_OFFLINE = true` with `hi-IN` / `en-IN` when offline or when Force Offline Mode is active, and automatically recovers from `ERROR_NETWORK`, `ERROR_NETWORK_TIMEOUT`, and `ERROR_SERVER_DISCONNECTED` by switching to offline STT instead of stopping.
- **Offline Hindi/Hinglish TTS**: `configureHinglishVoice()` prioritizes on-device voices (`!voice.isNetworkConnectionRequired`) for Hindi (`hi-IN`) and Indian English (`en-IN`) so speech synthesis works without internet.

### E. UI & Developer Terminal Controls
- Added the **Dual-Brain Offline AI (Qwen3 1.7B)** control card in `SettingsScreen.kt` (Force Offline Mode switch, Download / Resume / Pause 1.28 GB GGUF button, Scan Storage button, and live model status).
- Added `qwen [status | download | pause | ask <prompt>]` command to `WorkspaceTerminalEngine.kt`.

## 2. Critical Build & Unit Test Fixes Applied

During the codebase audit of the previous archive, four regressions that would break Gradle compilation or `:app:testDebugUnitTest` in CI were identified and fixed across all three project copies:
1. **`app/build.gradle.kts` Line 126 Syntax Error Fixed**: Replaced the literal `\n` token between `implementation(libs.firebase.appcheck.recaptcha)` and `implementation("com.google.firebase:firebase-appcheck-playintegrity")` with a proper newline.
2. **`SecurePreferences.kt` Robolectric Compatibility Fixed**: Preserved fail-closed `EncryptedSharedPreferences` behavior on real Android devices while allowing isolated in-memory preferences when running under local JVM Robolectric tests (`Build.FINGERPRINT == "robolectric"`), preventing `KeyStoreException` crashes in `ApiManagementAndListeningTest`, `GeminiLiveVoiceEngineTest`, and `VoiceSettingsPreferencesTest`.
3. **`VoiceSessionManager.kt` Calibration Alignment Fixed**: Aligned `applyVoiceSettings` locked rate and pitch to `1.00f` / `1.00f` so `VoiceSettingsPreferencesTest` (`assertEquals(1.00f, ..., 0.01f)`) passes.
4. **`WorkspaceTerminalEngine.kt` Security Message Alignment Fixed**: Restored the `[SECURITY] Unknown or disallowed command ... Untrusted shell execution is strictly disabled` prefix required by `LiveWorkspaceTerminalTest`.
