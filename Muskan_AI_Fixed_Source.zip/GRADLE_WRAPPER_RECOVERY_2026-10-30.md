# Gradle wrapper recovery — Muskan

## Verified state
`gradle/wrapper/gradle-wrapper.properties` exists and points to Gradle 9.3.1. The following files are missing in this source ZIP:
- `gradlew`
- `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.jar`

A Gradle executable is not installed in the current working environment, and network access to retrieve the official wrapper JAR is unavailable. The missing binary has deliberately not been fabricated.

## Safe next steps in Android Studio
1. Open the project folder in Android Studio, without starting a build.
2. Check the Android Gradle Plugin version in `gradle/libs.versions.toml` and verify that the selected Gradle distribution is compatible. Do not blindly keep Gradle 9.3.1 if the plugin version does not support it.
3. On a machine with a compatible installed Gradle distribution, from the project root run:
   `gradle wrapper --gradle-version <compatible-version>`
4. Confirm all four wrapper files exist, then run:
   `python3 tools/check_gradle_wrapper.py`
5. Only after the wrapper check passes, run the requested unit tests. This package does not start tests, build an APK, or invoke GitHub Actions.

## Important
This is a diagnostic/recovery aid, not a completed wrapper repair. The wrapper cannot be safely completed here without the official wrapper JAR and a compatible Gradle runtime.
