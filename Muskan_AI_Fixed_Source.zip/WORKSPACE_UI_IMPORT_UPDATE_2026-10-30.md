# Muskan Workspace UI Import Update — 30 October 2026

## Change
- Added an **Import Muskan source ZIP** button to the main workspace screen.
- Uses Android's system document picker; no broad storage permission is requested.
- Copies the selected ZIP to app cache, calls `ProjectWorkspaceManager.importSourceZip`, deletes the temporary copy, and reports the actual result through the existing snackbar.
- The UI explicitly states that importing source does not modify the installed APK.

## Safety and behavior
- The workspace manager's existing ZIP path, secret/config filename, entry-count, per-file and expanded-size checks remain responsible for validation.
- Existing workspace snapshot behavior remains in place.
- No GitHub or APK build actions were added.

## Validation
- Source archive ZIP integrity checked.
- Kotlin source edits were checked for balanced delimiters and import callback wiring.
- Android/Gradle compilation and on-device picker/import tests were not run in this environment.
