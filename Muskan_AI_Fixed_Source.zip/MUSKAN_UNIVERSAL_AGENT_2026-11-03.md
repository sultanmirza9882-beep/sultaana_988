# Muskan v6 — Universal assistant agent

What is new (source patch; not compiled/tested on a device in the authoring environment):

- `automation/UniversalPhoneAgent.kt`: look (UI tree + optional screenshot) -> think (Gemini JSON) -> one human-like action -> look again. Reports success only when the model says the screen proves it.
- `data/AgentLlm.kt`: raw Gemini call (own system prompt, images, JSON mode) using the existing key pool.
- Human-like cursor: curved path, tremor, press animation, curved swipes, character-by-character typing.
- `engine/learning/PhoneKnowledgeStore.kt` + `ui/TrainingActivity.kt` ("Muskan Training" launcher icon, or say "training kholo"): teach by note, text file, or screen-recording video; auto phone profile; routines Muskan completed are remembered.
- Routing: multi-step / download / story / contact requests go to the agent first; unmatched action requests fall through to it; Live voice `phone_action` tool also uses it.
- Safety rules inside the agent: stops and asks for login/OTP/payment/captcha; never types passwords; legal sources only for movies/media.

## v7 — Redmi 13 5G notes built in
- `app/src/main/assets/knowledge/` holds the Redmi 13 5G training notes (modules 1-7). `PhoneKnowledgeStore` loads them automatically on first run (77 chunks) and retrieves the most relevant ones per step, matched to the goal and the app on screen. Core rules (module 7) are always included.

## v8 — Audit Fixes Applied (Redmi 13 5G / Xiaomi HyperOS Hardening)
- Fixed corrupted Hindi UTF-8 string `"डाउनलोड"` in `UniversalPhoneAgent.shouldTakePriority()`.
- Added `double_tap`, `notifications`, and `quick_settings` actions to `UniversalPhoneAgent.execute()` and system prompt.
- Eliminated duplicate `ACTION_SET_TEXT` + `executeVerifiedType` double-typing delay in `UniversalPhoneAgent.typeHuman()` and removed duplicate cursor animation on `humanTap()`.
- Fixed false manual-touch cancellation in `MuskanAccessibilityService.onAccessibilityEvent()` (ignores app-emitted `TYPE_VIEW_SCROLLED`/`TYPE_VIEW_CLICKED` and only cancels on real user touch `TYPE_TOUCH_INTERACTION_START`).
- Added Xiaomi HyperOS native package names (`com.android.camera`, `com.miui.gallery`, `com.miui.notes`, `com.miui.calculator`, `com.mi.android.globalFileexplorer`, `com.duokan.phone.remotecontroller`, `com.miui.securitycenter`) to `AndroidManifest.xml` `<queries>` and `launchAppByName()` with Google package fallback.
- Added Gboard `(985, 2255)` proportional coordinate fallback in `MuskanAccessibilityService.submitFocusedTextField()`.
- Added bilingual Hindi/Hinglish/package synonym expansion and `update()` in `PhoneKnowledgeStore.kt` (bumped `BUILTIN_VERSION = 2`) and added in-place `"Edit karo"` button in `TrainingActivity.kt`.
- Added automatic fallback from `AgenticExecutionPlanner` to `UniversalPhoneAgent` in `VoiceSessionManager.kt` and `GeminiLiveSessionManager.kt`.
- Repaired missing parameters and aligned action JSON syntax in `assets/knowledge/06_Voice_Command_Examples.md`.

## v9 — WebSocket Integration & WebRTC Signaling Added
- `engine/network/MuskanWebSocketBridge.kt`: Full-duplex OkHttp WebSocket client with auto-reconnect (exponential backoff), outbound offline queue (100 messages), JSON ping/pong RTT latency tracking, remote `agent_command` execution via `UniversalPhoneAgent`, live `screen_snapshot` telemetry via `ScreenPerceptionEngine`, and WebRTC signal routing.
- `engine/network/WebRtcSignalingManager.kt`: JSEP / RFC 8829 compliant WebRTC Signaling state machine (`IDLE` -> `WAITING_FOR_PEER` -> `HAVE_LOCAL_OFFER` / `HAVE_REMOTE_OFFER` -> `STABLE` -> `CLOSED`), Early Trickle-ICE candidate buffering & automatic drain, Google STUN + custom TURN configuration, RFC 4566 SDP Offer/Answer generator, and dual signaling transport (WebSocket + Cloud Firestore `users/{uid}/rtc_rooms/{roomId}`).
- Wired into `TrainingActivity` (Section 5 live controls), `WorkspaceTerminalEngine` (`ws` and `webrtc` commands), `VoiceSessionManager` (Hindi/Hinglish voice triggers), `MasterSettingsHubScreen`, `firestore.rules`, and `WebSocketAndWebRtcSignalingTest.kt`.

## v10 — Zero-Beep Gemini Live Full-Duplex Voice & Silent VAD Gate
- Fixed `GeminiLiveWebSocketClient.kt` to connect with real Gemini Live Bidi models (`models/gemini-2.0-flash-live-001` -> `models/gemini-2.0-flash-exp` -> `models/gemini-2.5-flash-native-audio-preview-12-2025`) with automatic model fallback so the Live WebSocket session stays open continuously instead of failing and dropping back to `SpeechRecognizer`.
- Updated `VoiceSessionManager.kt` (`setPermissionGranted`, `startHandsFreeListening`, `startExplicitListening`) to launch `GeminiLiveSessionManager` (16kHz PCM `AudioRecord` + `VOICE_COMMUNICATION` hardware echo cancellation) directly, eliminating the repetitive Google Keyboard `SpeechRecognizer` start/stop "ding-dong" sound.
- Replaced the `ToneGenerator.TONE_PROP_BEEP` in `playAcknowledgeChime()` with silent haptic feedback so no artificial beep rings in the user's ear.
- Added `startSilentVadGatedFallback()` and `suppressSystemMicBeepBriefly()` in `VoiceSessionManager.kt`: even if offline/fallback `SpeechRecognizer` is used, silence timeouts (`ERROR_SPEECH_TIMEOUT` / `ERROR_NO_MATCH`) switch to a 100% silent `AudioRecord` VAD monitor that waits quietly until real human speech energy is detected instead of re-triggering the keyboard mic in a loop.
