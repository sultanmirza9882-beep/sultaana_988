# Muskan consolidated source patch — 2026-10-29

## Included source changes
- Android backup disabled and explicit backup/device-transfer rules retained.
- WebView configuration reviewed to remove an explicit Safe Browsing disablement.
- Added `SecurePreferences` using AndroidX Security Crypto encrypted preferences. `ApiProfileManager` and `KeyRotationPoolManager` now migrate legacy preferences to encrypted storage, commit encrypted values before clearing plaintext, and fail closed if encryption/migration fails.
- Speech recognizer automatic retries are bounded (maximum 3 consecutive timeout/audio/busy retries); missing microphone permission stops automatic listening retries and asks the user to grant permission.
- Planner cancellation is caught so the UI execution state is cleared and cancellation is not reported as success.
- Dex verifier exceptions now produce a rejected verdict; delimiter balance and simple string scanning are explicitly not described as compiler or comprehensive security verification.

## Validation performed in this environment
- Original ZIP opened and passed Python ZIP integrity check.
- XML/manifest files copied from the previously inspected patch.
- Source edits were applied to the identified Kotlin files.

## Not verified
- Gradle build and Kotlin compilation were not run in this environment.
- Unit/instrumentation tests, API migration on a real device, APK install, and runtime voice/audio tests were not run.
- AndroidX Security Crypto dependency resolution and compatibility must be confirmed by a successful Gradle sync/build.
- APK-embedded API keys cannot be made fully secret; production deployments should use a server-side API proxy and provider-side key restrictions.
- Dex's checks remain heuristic checks, not a Kotlin compiler or full security audit.

## Safe test sequence
1. Keep the original project/ZIP unchanged and make a separate AI Studio project copy.
2. Upload this ZIP or merge the changed files into that copy; confirm the files actually replaced the matching paths.
3. Run Gradle sync/build. If it fails, save the full first error and send it for a follow-up patch.
4. Install only the newly built APK; test first launch, saved API profile migration, API request, microphone permission denied/granted, timeout recovery, canceling a task, and normal task completion.
5. Do not report the patch as production-ready until these checks pass.
