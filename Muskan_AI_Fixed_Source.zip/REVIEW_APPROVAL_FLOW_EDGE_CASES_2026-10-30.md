# Muskan Review/Apply Edge-Case Hardening

Date: 2026-10-30

## Changes made
- Reject duplicate paths within a single reviewed patch. This prevents two entries for the same file from silently overwriting one another in sequence.
- Give pre-patch snapshots a short UUID suffix so two snapshots created in the same millisecond do not target the same directory.
- Verify that the snapshot directory exists and can be listed before starting source writes.
- Expanded the static regression script to check these safeguards.

## Validation
`tools/review_approval_flow_check.py`: 14/14 source-text checks passed.
ZIP integrity is checked after packaging.

## Important limits
These are source-level changes and static checks only. Kotlin compilation, Android UI/device testing, injected filesystem failures, and real snapshot restoration were not run. Do not treat this as runtime verification or an APK build.

## Additional hardening
- Source ZIP import now rejects duplicate file paths rather than silently allowing a later ZIP entry to overwrite an earlier entry.
- The static checker includes a regression assertion for this behavior.

Latest result: 15/15 static source checks passed. This remains source-text validation only; no Kotlin compilation or Android runtime test was run.

## Rollback safety update
- Failed patch recovery now copies and verifies the snapshot before swapping directories.
- The current workspace is moved aside before activation of the restored tree; if activation fails, recovery attempts to move the displaced tree back.
- Manual rollback now targets the latest `before_patch_` snapshot rather than accidentally selecting an import snapshot.
- The pre-rollback workspace is retained as a safety copy instead of being deleted.
- Static regression checker result: 19/19 checks passed.

Limit: static source-text checks only. Kotlin compilation, Android runtime tests, injected write/rename failures, and real rollback execution were not run.

## Snapshot integrity verification update
- Added SHA-256 inventory comparison for source snapshots and their staged copies. A snapshot copy must match relative paths and file contents before patch writes or directory swaps proceed.
- Snapshot copying now checks directory creation failures instead of silently ignoring failed `mkdirs()` calls.
- Updated static checker: 24 source-text assertions expected.

Limit: this is static validation, not Kotlin compilation or Android runtime execution. No injected filesystem-failure test has been run.
