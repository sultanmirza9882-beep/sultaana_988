#!/usr/bin/env python3
"""Static mirror of SelfDevelopmentEngine.isSelfDevelopmentPrompt.
Run from repository root: python3 tools/static_prompt_routing_check.py
This checks examples against the keyword list; it does not execute Kotlin.
"""
import re
from pathlib import Path

engine = Path("app/src/main/java/com/example/engine/dev/SelfDevelopmentEngine.kt").read_text(encoding="utf-8")
tests = Path("app/src/test/java/com/example/SelfDevelopmentPromptRoutingTest.kt").read_text(encoding="utf-8")
block = engine.split("val hasBuildIntent = listOf(", 1)[1].split(").any { p.contains(it) }", 1)[0]
phrases = re.findall(r'"((?:\\.|[^"\\])*)"', block)
positive_section = tests.split("@Test fun doesNotRouteOrdinaryQuestionsAsCodeChanges()", 1)[0]
positive = re.findall(r'assertTrue\(SelfDevelopmentEngine\.isSelfDevelopmentPrompt\("([^"]+)"\)\)', positive_section)
match = re.search(r'val prompts = listOf\((.*?)\)\s*prompts\.forEach', positive_section, re.S)
if match:
    positive += re.findall(r'"([^"]+)"', match.group(1))
negative_section = tests.split("@Test fun doesNotRouteOrdinaryQuestionsAsCodeChanges()", 1)[1]
negative = re.findall(r'assertFalse\(SelfDevelopmentEngine\.isSelfDevelopmentPrompt\("([^"]+)"\)\)', negative_section)
route = lambda value: any(phrase.lower() in value.lower() for phrase in phrases)
failed_positive = [value for value in positive if not route(value)]
failed_negative = [value for value in negative if route(value)]
print(f"Static routing examples: {len(positive) + len(negative)}")
print(f"Positive expected route: {len(positive) - len(failed_positive)}/{len(positive)}")
print(f"Negative expected no-route: {len(negative) - len(failed_negative)}/{len(negative)}")
if failed_positive or failed_negative or not positive or not negative:
    print("Positive failures:", failed_positive)
    print("Negative false positives:", failed_negative)
    raise SystemExit(1)
print("PASS (static mirror only; not a Kotlin/JUnit execution)")
