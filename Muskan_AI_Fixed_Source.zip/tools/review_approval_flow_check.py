#!/usr/bin/env python3
"""Static regression checks for Muskan's staged source-patch review flow.
This does not compile Kotlin or exercise Android UI/runtime behavior.
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
activity = (ROOT / 'app/src/main/java/com/example/MainActivity.kt').read_text(encoding='utf-8')
engine = (ROOT / 'app/src/main/java/com/example/engine/dev/SelfDevelopmentEngine.kt').read_text(encoding='utf-8')
workspace = (ROOT / 'app/src/main/java/com/example/engine/dev/ProjectWorkspaceManager.kt').read_text(encoding='utf-8')
checks = {
    'UI lists pending drafts': 'listPendingDrafts(context)' in activity,
    'UI opens a selected draft for review': 'loadDraftFilesForReview(context, draft.draftId)' in activity,
    'UI has explicit approve/apply control': 'Text("Approve & apply")' in activity and 'applyReviewedPatch(context, patch)' in activity,
    'UI has cancel control': 'Text("Cancel")' in activity and 'reviewDraftId = null' in activity,
    'generation stages draft for review': 'DRAFT_REQUIRES_REVIEW' in engine and 'Never apply changes without explicit review/approval.' in engine,
    'draft loader rejects non-pending drafts': 'require(manifest.optString("status") == "DRAFT_REQUIRES_REVIEW")' in engine,
    'successful apply marks draft status': 'markDraftApplied(context, draftId)' in activity and 'APPLIED_TO_PRIVATE_SOURCE_WORKSPACE' in engine,
    'patch application requires imported workspace': 'Import a source project before applying changes.' in workspace,
    'patch paths are canonical-path confined': 'target.canonicalPath.startsWith(dir.canonicalPath + File.separator)' in workspace,
    'snapshot is made before writes': workspace.index('copyTree(dir, backup)') < workspace.index('target.writeText(content, Charsets.UTF_8)'),
    'duplicate paths in one patch are rejected': 'require(seenPaths.add(path)) { \"Duplicate patch path rejected:' in workspace,
    'snapshot names avoid same-millisecond collisions': 'UUID.randomUUID().toString().take(8)' in workspace,
    'snapshot is checked before patch writes': 'Could not verify the source snapshot before writing.' in workspace,
    'no build/test success is falsely claimed': 'Android build/tests have not run.' in workspace,
    'source ZIP import rejects duplicate file entries': 'require(importedPaths.add(relative)) { \"Duplicate ZIP entry rejected:' in workspace,
    'failed apply restores through staged directory swap': 'failed_apply_${UUID.randomUUID()}' in workspace and 'Original source snapshot restored.' in workspace,
    'failed restore preserves displaced workspace': 'if (!dir.exists() && failed.exists()) failed.renameTo(dir)' in workspace,
    'rollback selects patch snapshots only': 'it.name.startsWith(\"before_patch_\")' in workspace,
    'rollback retains prior workspace as safety copy': 'Previous workspace retained as ${displaced.name}' in workspace,
    'snapshot contents verified with SHA-256 inventory': 'private fun treesMatch(source: File, copy: File): Boolean' in workspace and 'return inventory(source) == inventory(copy)' in workspace,
    'snapshot digest uses streaming SHA-256': 'MessageDigest.getInstance("SHA-256")' in workspace and 'while (true)' in workspace,
    'patch snapshot verified before first write': 'treesMatch(dir, backup)' in workspace and workspace.index('treesMatch(dir, backup)') < workspace.index('target.writeText(content, Charsets.UTF_8)'),
    'restore copy verified before directory swap': 'treesMatch(backup!!, restore)' in workspace and workspace.index('treesMatch(backup!!, restore)') < workspace.index('if (dir.exists()) check(dir.renameTo(failed))'),
    'manual rollback copy verified before directory swap': 'treesMatch(latest, rollback)' in workspace and workspace.index('treesMatch(latest, rollback)') < workspace.index('if (current.exists()) check(current.renameTo(displaced))'),
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' - ' + label)
print(f'RESULT: {sum(checks.values())}/{len(checks)} static checks passed')
sys.exit(0 if all(checks.values()) else 1)
