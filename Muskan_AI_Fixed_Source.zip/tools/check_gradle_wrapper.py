#!/usr/bin/env python3
"""Check whether the Gradle wrapper is complete; does not download or build anything."""
from pathlib import Path
import sys

required = [
    Path("gradlew"),
    Path("gradlew.bat"),
    Path("gradle/wrapper/gradle-wrapper.jar"),
    Path("gradle/wrapper/gradle-wrapper.properties"),
]
missing = [str(p) for p in required if not p.is_file()]
if missing:
    print("Gradle wrapper is incomplete.")
    for item in missing:
        print(f"MISSING: {item}")
    print("No build or tests were started.")
    sys.exit(1)
print("Gradle wrapper files are present.")
